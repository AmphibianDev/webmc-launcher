#!/usr/bin/env python3
"""
webmc-helper - run real Minecraft + Fabric on this machine, keep nothing.

The contract, in the words of the design it implements:

    the page only launches Minecraft; Minecraft still runs on your computer,
    just ... temporarily.

So every byte this helper writes goes into one sandbox directory under /tmp
(`/tmp/webmc-<nonce>`), and the whole thing is deleted when the session's files
have been handed to the page - or after `--autoclean` seconds, whichever is
first. Nothing is installed, no service is registered, nothing is left behind.

    page (github.io or this helper's own /)  ──HTTP──▶  127.0.0.1:7645
                                                            │
                                          downloads ────────┤ Mojang / Fabric / Modrinth
                                          (through the     │
                                           SOCKS tunnel    │
                                           when direct     │
                                           is blocked)     │
                                                            ▼
                                          /tmp/webmc-XXXX/  ──▶ java ... KnotClient
                                                            │
                                          saves + logs ─────┤ zip
                                                            ▼
                                                    page stores it (OPFS)
                                                            │
                                                    POST /api/cleanup ──▶ rm -rf

Endpoints (all JSON):
    GET  /                  the page, with this helper's own token baked in
    GET  /go?to=<page-url>  redirect to a hosted page with the token in the fragment
    GET  /api/hello         identity + capability probe (no token needed)
    GET  /api/versions      Mojang's release list (cached, fetched lazily)
    GET  /api/status        phase, progress, instance, pid, exit code
    GET  /api/log?since=N   log lines after index N
    POST /api/launch        {version, loader, mods, username, memory, assets}
    POST /api/stop          kill the game
    POST /api/restore       body = a bundle zip from a previous session
    GET  /api/result        exit code, collected files, bundle size
    GET  /api/bundle.zip    the collected saves/logs/screenshot bundle
    POST /api/cleanup       delete the sandbox

Only Python 3.9's standard library is used. Downloads shell out to `curl`,
because curl speaks SOCKS5 with remote DNS (`socks5h://`) and does parallel
transfers, which is exactly what a poisoned resolver needs.
"""

import argparse
import errno
import hashlib
import http.server
import json
import os
import platform
import re
import secrets
import shutil
import signal
import socket
import socketserver
import subprocess
import sys
import tarfile
import threading
import time
import urllib.parse
import uuid as uuidlib
import zipfile

VERSION = "0.1.0"
NAME = "webmc-helper"

MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
RESOURCES_URL = "https://resources.download.minecraft.net"
FABRIC_META = "https://meta.fabricmc.net/v2"
MODRINTH_API = "https://api.modrinth.com/v2"
ADOPTIUM_API = "https://api.adoptium.net/v3"

DEFAULT_VERSION = "1.21.11"
DEFAULT_MEMORY = "2G"

# Origin allowlist for the browser-side fetch. The page is either served by this
# helper, or hosted on GitHub Pages, or served by the repo's own test server.
ORIGIN_PATTERNS = [
    re.compile(r"^http://(localhost|127\.0\.0\.1)(:\d+)?$"),
    re.compile(r"^https://localhost(:\d+)?$"),
    re.compile(r"^https://[a-z0-9-]+\.github\.io$"),
    re.compile(r"^https://[a-z0-9-]+\.pages\.dev$"),
]

PROXY_CANDIDATES = [
    "socks5h://127.0.0.1:1080",
    "socks5h://127.0.0.1:1088",
    "socks5h://127.0.0.1:10808",
    "socks5h://127.0.0.1:7890",
]

ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


def log_ts():
    return time.strftime("%H:%M:%S")


# --------------------------------------------------------------------------- os facts


def os_name():
    p = sys.platform
    if p == "darwin":
        return "osx"
    if p.startswith("win"):
        return "windows"
    return "linux"


def os_arch():
    m = platform.machine().lower()
    if m in ("arm64", "aarch64"):
        return "arm64"
    if m in ("x86_64", "amd64"):
        return "x86_64"
    return m


def os_version():
    if os_name() == "osx":
        return platform.mac_ver()[0]
    return platform.release()


# --------------------------------------------------------------------------- rules

def _rule_applies(rule, features):
    """Mojang's rule predicate: os name/arch/version plus launcher features."""
    cond = rule.get("os")
    if cond:
        if "name" in cond and cond["name"] != os_name():
            return False
        if "arch" in cond:
            want = cond["arch"]
            have = os_arch()
            # Mojang says "x86" for 32-bit intel; treat it as a prefix match so a
            # rule written for x86 also matches x86_64 only when it says so.
            if want == "x86":
                if have not in ("x86", "i386", "i686"):
                    return False
            elif want != have:
                return False
        if "version" in cond:
            try:
                if not re.search(cond["version"], os_version()):
                    return False
            except re.error:
                return False
    feats = rule.get("features")
    if feats:
        for k, v in feats.items():
            if bool(features.get(k, False)) != bool(v):
                return False
    return True


def rules_allow(rules, features):
    """Empty rules mean allowed; otherwise the *last* matching rule decides."""
    if not rules:
        return True
    allow = False
    for rule in rules:
        if _rule_applies(rule, features):
            allow = (rule.get("action") == "allow")
    return allow


# --------------------------------------------------------------------------- curl

class CurlError(RuntimeError):
    pass


class Curl:
    """Thin curl wrapper: SOCKS-aware, parallel-capable, sha1-verifying."""

    def __init__(self, proxy=None, retries=3):
        self.proxy = proxy
        self.retries = retries
        self.curl = shutil.which("curl") or "/usr/bin/curl"
        self._lock = threading.Lock()
        self.bytes_in = 0

    def _base(self):
        args = [self.curl, "-sS", "-L", "--fail", "--connect-timeout", "20",
                "--retry", str(self.retries), "--retry-connrefused",
                "--retry-delay", "1", "--create-dirs"]
        if self.proxy:
            args += ["--proxy", self.proxy]
        return args

    def get(self, url, dest=None, sha1=None, timeout=900, headers=()):
        """Download to dest (or return bytes when dest is None)."""
        if dest and sha1 and os.path.exists(dest) and sha1_of(dest) == sha1:
            return dest  # already there, and correct
        args = self._base() + ["-m", str(timeout)]
        for h in headers:
            args += ["-H", h]
        if dest:
            os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
            tmp = dest + ".part"
            args += ["-o", tmp, url]
        else:
            args += [url]
        proc = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if proc.returncode != 0:
            if dest and os.path.exists(dest + ".part"):
                os.unlink(dest + ".part")
            raise CurlError("curl %s -> %s: %s" % (
                url, proc.returncode, proc.stderr.decode("utf-8", "replace").strip()[:300]))
        if dest:
            if sha1 and sha1_of(tmp) != sha1:
                os.unlink(tmp)
                raise CurlError("sha1 mismatch for %s" % url)
            os.replace(tmp, dest)
            with self._lock:
                self.bytes_in += os.path.getsize(dest)
            return dest
        with self._lock:
            self.bytes_in += len(proc.stdout)
        return proc.stdout

    def json(self, url, timeout=120, headers=()):
        raw = self.get(url, dest=None, timeout=timeout, headers=headers)
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError as exc:
            raise CurlError("bad json from %s: %s" % (url, exc))

    def batch(self, items, progress=None, workers=16, headers=()):
        """items: [(url, dest, sha1|None)]. Parallel, verifies, retries stragglers.

        Large batches go through a single `curl --parallel -K config` process:
        one process for thousands of objects, rather than thousands of processes.
        """
        todo = [it for it in items if not (it[2] and os.path.exists(it[1])
                                           and sha1_of(it[1]) == it[2])]
        if not todo:
            if progress:
                progress(len(items), len(items))
            return []
        if progress:
            progress(len(items) - len(todo), len(items))
        failed = []
        if len(todo) > 24:
            failed = self._batch_parallel(todo, progress, len(items),
                                          len(items) - len(todo), workers)
        else:
            failed = self._batch_threads(todo, progress, len(items),
                                         len(items) - len(todo), workers)
        # verify + retry, individually, so a bad file can never survive
        for attempt in range(2):
            if not failed:
                break
            retry, failed = failed, []
            for item in retry:
                url, dest, sha1 = item
                try:
                    self.get(url, dest=dest, sha1=sha1, headers=headers)
                except CurlError as exc:
                    failed.append(item)
                    self._last_error = str(exc)
            if progress:
                progress(len(items) - len(failed), len(items), attempt + 2)
        return failed

    def _batch_threads(self, todo, progress, total, already, workers):
        from concurrent.futures import ThreadPoolExecutor
        failed = []
        done = [already]
        lock = threading.Lock()

        def one(item):
            url, dest, sha1 = item
            try:
                self.get(url, dest=dest, sha1=sha1)
            except CurlError:
                with lock:
                    failed.append(item)
            finally:
                with lock:
                    done[0] += 1
                    if progress:
                        progress(done[0], total)

        with ThreadPoolExecutor(max_workers=workers) as pool:
            list(pool.map(one, todo))
        return failed

    def _batch_parallel(self, todo, progress, total, already, workers):
        cfg = tempfile_in_dir()
        failed = []
        try:
            with open(cfg, "w") as fh:
                for url, dest, _sha1 in todo:
                    fh.write('url = "%s"\noutput = "%s"\n' % (url, dest))
            args = self._base() + ["--parallel", "--parallel-max", str(workers),
                                   "-K", cfg]
            if self.proxy:
                args += ["--proxy", self.proxy]
            proc = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            err = proc.stderr.decode("utf-8", "replace")
            # which ones actually arrived intact?
            done = 0
            for item in todo:
                if os.path.exists(item[1]) and (not item[2] or sha1_of(item[1]) == item[2]):
                    done += 1
                else:
                    failed.append(item)
            if progress:
                progress(already + done, total)
            if failed and not err.strip():
                err = "(curl --parallel reported no detail)"
            self._last_error = err.strip()[-400:] if failed else ""
        finally:
            if os.path.exists(cfg):
                os.unlink(cfg)
        return failed


def tempfile_in_dir():
    d = os.environ.get("TMPDIR", "/tmp")
    return os.path.join(d, "webmc-curl-%s.conf" % secrets.token_hex(6))


def sha1_of(path, chunk=1 << 20):
    h = hashlib.sha1()
    with open(path, "rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


# --------------------------------------------------------------------------- java

VER_RE = re.compile(r'version "([^"]+)"')


def java_major(java_path):
    try:
        proc = subprocess.run([java_path, "-version"], stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, timeout=30)
    except Exception:
        return 0
    out = proc.stdout.decode("utf-8", "replace")
    m = VER_RE.search(out)
    if not m:
        return 0
    v = m.group(1)
    if v.startswith("1."):
        try:
            return int(v.split(".")[1])
        except ValueError:
            return 0
    try:
        return int(re.match(r"(\d+)", v).group(1))
    except Exception:
        return 0


def find_javas():
    """Every java on the machine, best-effort, cheapest checks first."""
    cands = []
    env = os.environ.get("WEBMC_JAVA")
    if env:
        cands.append(env)
    home = os.environ.get("JAVA_HOME")
    if home:
        cands.append(os.path.join(home, "bin", "java"))
    for base, globs in (
        (os.path.expanduser("~/.jdks"), ("*/Contents/Home/bin/java", "*/bin/java")),
        ("/Library/Java/JavaVirtualMachines", ("*/Contents/Home/bin/java",)),
        (os.path.expanduser("~/Library/Java/JavaVirtualMachines"), ("*/Contents/Home/bin/java",)),
        ("/opt/homebrew/opt", ("openjdk*/bin/java", "openjdk@*/bin/java")),
        ("/usr/local/opt", ("openjdk*/bin/java", "openjdk@*/bin/java")),
    ):
        if not os.path.isdir(base):
            continue
        for g in globs:
            import glob as _glob
            cands.extend(sorted(_glob.glob(os.path.join(base, g)), reverse=True))
    which = shutil.which("java")
    if which:
        cands.append(which)
    out = []
    for c in cands:
        if c and os.path.exists(c) and os.access(c, os.X_OK) and c not in out:
            out.append(c)
    return out


def pick_java(required, explicit=None, log=None):
    if explicit:
        if not os.path.exists(explicit):
            raise RuntimeError("--java %s does not exist" % explicit)
        return explicit, java_major(explicit)
    found = []
    for c in find_javas():
        mj = java_major(c)
        if mj:
            found.append((mj, c))
    if not found:
        return None, 0
    found.sort(key=lambda t: -t[0])
    if log:
        log("java candidates: " + ", ".join("%d @ %s" % (m, c) for m, c in found[:6]))
    best_major, best = found[0]
    if best_major < required:
        return best, best_major  # caller decides whether to fetch a JRE
    return best, best_major


def fetch_jre(major, root, curl, log):
    arch = {"arm64": "aarch64", "x86_64": "x64"}.get(os_arch(), "x64")
    plat = "mac" if os_name() == "osx" else ("windows" if os_name() == "windows" else "linux")
    ext = "zip" if plat == "windows" else "tar.gz"
    url = "%s/binary/latest/%d/ga/%s/%s/jre/hotspot/normal/eclipse" % (
        ADOPTIUM_API, major, plat, arch)
    log("no Java %d here - fetching a JRE from Adoptium (%s/%s)" % (major, plat, arch))
    dest = os.path.join(root, "jre.%s" % ext)
    curl.get(url, dest=dest, timeout=1800)
    out = os.path.join(root, "jre")
    os.makedirs(out, exist_ok=True)
    if ext == "tar.gz":
        with tarfile.open(dest) as tf:
            tf.extractall(out)
    else:
        with zipfile.ZipFile(dest) as zf:
            zf.extractall(out)
    for base, _dirs, files in os.walk(out):
        if "java" in files and os.path.basename(base) == "bin":
            cand = os.path.join(base, "java")
            if os.access(cand, os.X_OK):
                return cand, java_major(cand)
    raise RuntimeError("fetched a JRE but could not find bin/java in it")


# --------------------------------------------------------------------------- downloads

def maven_to_path(coords):
    """group:artifact:version[:classifier] -> (relative path, file name)."""
    parts = coords.split(":")
    if len(parts) < 3:
        return None, None
    group, artifact, version = parts[0], parts[1], parts[2]
    classifier = parts[3] if len(parts) > 3 else None
    name = "%s-%s%s.jar" % (artifact, version, ("-" + classifier) if classifier else "")
    return "/".join([group.replace(".", "/"), artifact, version, name]), name


def vanilla_url(group, artifact, version, classifier=None, repo="https://libraries.minecraft.net"):
    rel, name = maven_to_path(":".join([group, artifact, version] + ([classifier] if classifier else [])))
    return "%s/%s" % (repo, rel), rel


# --------------------------------------------------------------------------- session

class Session:
    """One sandbox, one game, one lifecycle."""

    def __init__(self, cfg, curl):
        self.cfg = cfg
        self.curl = curl
        self.lock = threading.RLock()
        self.lines = []
        self.state = "idle"          # idle|running|exited|cancelled|failed
        self.phase = ""
        self.phase_label = ""
        self.done = 0
        self.total = 0
        self.error = None
        self.instance = {}
        self.pid = None
        self.exit_code = None
        self.started_at = None
        self.ended_at = None
        self.result = None           # collected bundle info
        self.proc = None
        self.thread = None
        self.cleanup_deadline = None
        self.java = None
        self.java_major = 0
        self.jre_fetched = False
        self._versions_cache = None

    # ---------------------------------------------------------------- root paths
    @property
    def root(self):
        return self.cfg.root

    @property
    def game_dir(self):
        return os.path.join(self.root, "game")

    @property
    def libs_dir(self):
        return os.path.join(self.root, "libraries")

    @property
    def assets_dir(self):
        return os.path.join(self.root, "assets")

    @property
    def natives_dir(self):
        return os.path.join(self.root, "natives")

    @property
    def versions_dir(self):
        return os.path.join(self.root, "versions")

    @property
    def bundle_path(self):
        return os.path.join(self.root, "session.zip")

    def write_file(self, rel, data):
        path = os.path.join(self.root, rel)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as fh:
            fh.write(data if isinstance(data, bytes) else data.encode("utf-8"))
        return path

    # ---------------------------------------------------------------- status
    def log(self, line, echo=True):
        line = ANSI_RE.sub("", str(line)).rstrip("\n")
        if not line.strip():
            return
        with self.lock:
            self.lines.append("[%s] %s" % (log_ts(), line))
            if len(self.lines) > 4000:
                del self.lines[:1000]
        if echo:
            sys.stdout.write("  %s\n" % line)
            sys.stdout.flush()

    def set(self, **kw):
        with self.lock:
            for k, v in kw.items():
                setattr(self, k, v)

    def status(self):
        with self.lock:
            total = self.total or 0
            data = {
                "state": self.state,
                "phase": self.phase,
                "phaseLabel": self.phase_label,
                "progress": {
                    "done": self.done,
                    "total": total,
                    "percent": int(100 * self.done / total) if total else None,
                },
                "instance": dict(self.instance),
                "pid": self.pid,
                "exitCode": self.exit_code,
                "startedAt": self.started_at,
                "endedAt": self.ended_at,
                "error": self.error,
                "java": self.java,
                "javaMajor": self.java_major,
                "jreFetched": self.jre_fetched,
                "downloadedBytes": self.curl.bytes_in,
                "lines": len(self.lines),
                "result": self.result,
            }
        self.refresh_cleanup_deadline()
        data["cleanupAt"] = self.cleanup_deadline
        return data

    def refresh_cleanup_deadline(self):
        """After the game exits and the bundle exists, the sandbox gets a timer."""
        with self.lock:
            if (self.state in ("exited", "failed") and self.result
                    and self.cleanup_deadline is None and self.cfg.autoclean):
                self.cleanup_deadline = time.time() + self.cfg.autoclean

    def lines_since(self, n):
        with self.lock:
            return self.lines[n:], len(self.lines)

    # ---------------------------------------------------------------- lifecycle
    def start(self, opts):
        with self.lock:
            if self.state == "running":
                raise RuntimeError("a session is already running")
            self.state = "running"
            self.error = None
            self.exit_code = None
            self.result = None
            self.done = 0
            self.total = 0
            self.cleanup_deadline = None
            self.started_at = time.time()
            self.ended_at = None
        self.thread = threading.Thread(target=self._run, args=(opts,), daemon=True)
        self.thread.start()

    def stop(self):
        with self.lock:
            proc = self.proc
        if proc and proc.poll() is None:
            self.log("stop requested - sending SIGTERM to pid %d" % proc.pid)
            try:
                proc.terminate()
            except Exception:
                pass
            for _ in range(40):
                if proc.poll() is not None:
                    break
                time.sleep(0.25)
            if proc.poll() is None:
                self.log("still alive - SIGKILL")
                try:
                    proc.kill()
                except Exception:
                    pass
            return True
        return False

    def _progress(self, label, done, total):
        with self.lock:
            self.phase_label = label
            self.done = done
            self.total = total

    def _phase(self, name, label=None, total=0):
        with self.lock:
            self.phase = name
            self.phase_label = label or name
            self.done = 0
            self.total = total
        if label:
            self.log(label)

    # ---------------------------------------------------------------- the run
    def _run(self, opts):
        try:
            self.log("sandbox: %s" % self.root)
            self._prepare_root()
            mc_version = opts["version"]
            required = 21

            # ---- java
            self._phase("java", "looking for a Java runtime")
            java, major = pick_java(required, explicit=self.cfg.java, log=self.log)
            if not java or major < required:
                if self.cfg.no_jre_download:
                    raise RuntimeError(
                        "no Java %d found (best: %s) and --no-jre-download was given"
                        % (required, java or "none"))
                if java:
                    self.log("best local Java is %d, this version needs %d - fetching one "
                             "into the sandbox (it dies with the sandbox)" % (major, required))
                java, major = fetch_jre(required, self.root, self.curl, self.log)
                self.jre_fetched = True
            self.java = java
            self.java_major = major
            self.log("java: %s (%d)" % (java, major))

            # ---- version metadata
            self._phase("metadata", "reading %s from Mojang" % mc_version)
            vjson, vurl = self._version_json(mc_version)
            self.log("client: %s (%d MB)" % (
                vjson["id"], vjson["downloads"]["client"]["size"] // (1 << 20)))

            # ---- vanilla files
            client_jar = self._client_jar(vjson)
            libs = self._libraries(vjson, self.curl)
            assets_ok = self._assets(vjson, opts.get("assets", True))

            # ---- fabric
            loader_ver = opts.get("loader") or "stable"
            profile, loader_ver = self._fabric_profile(mc_version, loader_ver)
            fabric_libs = self._fabric_libraries(profile)
            all_libs = libs + fabric_libs

            # ---- mods
            mods = self._mods(opts.get("mods") or [], mc_version, loader_ver)
            local = list(self.cfg.mod_jar or []) + list(opts.get("localMods") or [])
            mods += self._local_mods(local)

            # ---- command
            self._phase("launch", "starting the game")
            cmd, classpath = self._build_command(
                vjson, profile, client_jar, all_libs, mc_version, loader_ver,
                opts.get("username") or "Player", opts.get("memory") or DEFAULT_MEMORY,
                mods)
            self.write_file("launch-command.txt",
                            "\n".join(shell_quote(c) for c in cmd) + "\n")
            if self.cfg.dry_run:
                self.log("dry run: command written to %s/launch-command.txt"
                         % self.root)
                self.log("dry run: not starting the game")
                self.instance = {
                    "version": mc_version, "loader": "fabric-%s" % loader_ver,
                    "mods": [m["name"] for m in mods],
                    "username": opts.get("username") or "Player",
                    "memory": opts.get("memory") or DEFAULT_MEMORY, "offline": True,
                }
                with self.lock:
                    self.state = "exited"
                    self.exit_code = 0
                    self.phase = "dry-run"
                    self.phase_label = "dry run complete"
                    self.ended_at = time.time()
                self._collect()
                return
            self.log("classpath: %d entries" % len(classpath))
            self.log("mods: %s" % (", ".join(m["name"] for m in mods) if mods else "(none)"))
            self.log("assets: %s" % ("downloaded" if assets_ok else "SKIPPED (missing sounds/textures)"))

            logfile = open(os.path.join(self.root, "console.log"), "wb")
            self.proc = subprocess.Popen(cmd, cwd=self.game_dir, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
            self.pid = self.proc.pid
            self.instance = {
                "version": mc_version,
                "loader": "fabric-%s" % loader_ver,
                "mods": [m["name"] for m in mods],
                "username": opts.get("username") or "Player",
                "memory": opts.get("memory") or DEFAULT_MEMORY,
                "offline": True,
            }
            self.log("pid %d - minecraft is running; close the window when you are done" % self.pid)
            with self.lock:
                self.state = "running"
            sink = threading.Thread(target=self._pump, args=(self.proc.stdout, logfile),
                                    daemon=True)
            sink.start()
            code = self.proc.wait()
            sink.join(timeout=10)
            logfile.close()
            self.exit_code = code
            self.log("game exited with code %s" % code)
            self._collect()
            with self.lock:
                self.state = "cancelled" if code not in (0, None) and code < 0 else "exited"
                self.phase = "done"
                self.phase_label = "session finished"
                self.ended_at = time.time()
        except Exception as exc:  # noqa: BLE001 - surfaced to the page
            self.error = "%s: %s" % (type(exc).__name__, exc)
            self.log("FAILED - %s" % self.error)
            with self.lock:
                self.state = "failed"
                self.phase = "failed"
                self.phase_label = "failed"
                self.ended_at = time.time()
        finally:
            self.refresh_cleanup_deadline()

    def _pump(self, stream, logfile):
        interesting = re.compile(
            r"Loading \d+ mods|fabric-loader|KnotClient|LWJGL|Backend library|Setting user|"
            r"OpenGL|Sound engine|Started|Stopping|Exception|Error|crash|Mixin|"
            r"Preparing|Reloading|thread", re.I)
        for raw in iter(stream.readline, b""):
            logfile.write(raw)
            logfile.flush()
            text = ANSI_RE.sub("", raw.decode("utf-8", "replace"))
            if interesting.search(text):
                self.log(text, echo=False)
            else:
                with self.lock:
                    self.lines.append("[%s] %s" % (log_ts(), text.rstrip()))

    # ---------------------------------------------------------------- sandbox
    def _prepare_root(self):
        os.makedirs(self.root, mode=0o700, exist_ok=True)
        os.chmod(self.root, 0o700)
        for d in (self.game_dir, self.libs_dir, self.assets_dir,
                  os.path.join(self.assets_dir, "indexes"),
                  os.path.join(self.assets_dir, "objects"),
                  self.natives_dir, self.versions_dir,
                  os.path.join(self.game_dir, "mods"),
                  os.path.join(self.game_dir, "saves")):
            os.makedirs(d, exist_ok=True)
        self._link_cache()

    def _link_cache(self):
        """Optional: borrow Mojang's immutable files from a cache instead of
        re-downloading 450 MB every time. Off by default - the promise is that a
        session leaves nothing behind, and only the visitor can decide to trade
        that for speed. The sandbox symlinks the cache; deleting the sandbox
        unlinks them and leaves the cache alone."""
        if not self.cfg.cache:
            return
        cache = os.path.abspath(os.path.expanduser(self.cfg.cache))
        for name in ("assets", "libraries"):
            src = os.path.join(cache, name)
            dst = os.path.join(self.root, name)
            os.makedirs(os.path.join(src, "indexes"), exist_ok=True)
            os.makedirs(os.path.join(src, "objects"), exist_ok=True)
            if os.path.islink(dst):
                os.unlink(dst)
            elif os.path.isdir(dst):
                shutil.rmtree(dst, ignore_errors=True)
            elif os.path.exists(dst):
                os.unlink(dst)
            os.symlink(src, dst)
        # the client jar and the version json are immutable too, so they cache by
        # name: a second launch then needs no network for them at all
        cver = os.path.join(cache, "versions")
        os.makedirs(cver, exist_ok=True)
        for entry in os.listdir(cver):
            src = os.path.join(cver, entry)
            dst = os.path.join(self.versions_dir, entry)
            if os.path.exists(dst) or os.path.islink(dst):
                continue
            os.symlink(src, dst)
        self.log("cache: assets, libraries and the client jar are borrowed from %s" % cache)

    def _version_json(self, version):
        cache = os.path.join(self.versions_dir, "%s.json" % version)
        if os.path.exists(cache):
            with open(cache) as fh:
                data = json.load(fh)
            return data, data.get("_url", "")
        manifest = self.curl.json(MANIFEST_URL, headers=self._ua())
        rels = [v for v in manifest["versions"] if v["type"] == "release"]
        match = None
        for v in manifest["versions"]:
            if v["id"] == version:
                match = v
                break
        if not match:
            near = ", ".join(v["id"] for v in (rels or manifest["versions"])[:8])
            raise RuntimeError("version %s is not in Mojang's list (newest releases: %s)"
                               % (version, near))
        data = self.curl.json(match["url"], headers=self._ua())
        data["_url"] = match["url"]
        os.makedirs(self.versions_dir, exist_ok=True)
        with open(cache, "w") as fh:
            json.dump(data, fh)
        return data, match["url"]

    def versions(self):
        with self.lock:
            if self._versions_cache:
                return self._versions_cache
        manifest = self.curl.json(MANIFEST_URL, headers=self._ua())
        rel = [v["id"] for v in manifest["versions"] if v["type"] == "release"][:40]
        allv = [v["id"] for v in manifest["versions"]][:40]
        out = {"latest": manifest["latest"], "releases": rel, "newest": allv}
        with self.lock:
            self._versions_cache = out
        return out

    def _client_jar(self, vjson):
        dl = vjson["downloads"]["client"]
        dest = os.path.join(self.versions_dir, "%s" % dl.get("path", "client.jar"))
        if os.path.isdir(dest):
            dest = os.path.join(dest, "client.jar")
        self._phase("client", "client jar (%.0f MB)" % (dl["size"] / 1048576.0))
        self.curl.get(dl["url"], dest=dest, sha1=dl.get("sha1"), headers=self._ua())
        self._progress("client jar", 1, 1)
        return dest

    def _libraries(self, vjson, curl):
        features = self._features()
        wanted = []
        natives = []
        for lib in vjson["libraries"]:
            if not rules_allow(lib.get("rules"), features):
                continue
            art = lib.get("downloads", {}).get("artifact")
            if art:
                wanted.append((art["url"], os.path.join(self.libs_dir, art["path"]),
                               art.get("sha1"), lib.get("name", "")))
            elif lib.get("name"):
                # no explicit downloads block: build it from maven coordinates
                rel, _name = maven_to_path(lib["name"])
                if rel:
                    repo = (lib.get("url") or "https://libraries.minecraft.net").rstrip("/")
                    wanted.append(("%s/%s" % (repo, rel), os.path.join(self.libs_dir, rel),
                                   None, lib.get("name", "")))
            if lib.get("natives"):
                natives.append(lib)
        # Apple Silicon: Mojang lists both natives-macos and natives-macos-arm64 with
        # identical rules, so both would land on the classpath and LWJGL could extract
        # the x86_64 dylib. Prefer the arm64 variant and drop the plain one.
        wanted = self._prefer_arch(wanted)
        self._phase("libraries", "libraries (%d)" % len(wanted), len(wanted))
        failed = curl.batch([(u, d, s) for u, d, s, _n in wanted],
                            progress=self._progress_cb("libraries"), headers=self._ua())
        if failed:
            self.log("WARNING: %d libraries failed: %s" % (
                len(failed), "; ".join(os.path.basename(f[1]) for f in failed[:4])))
        paths = [d for _u, d, _s, _n in wanted if os.path.exists(d)]
        # classic natives (pre-1.19): extract into natives/
        for lib in natives:
            art = lib.get("downloads", {}).get("classifiers", {}) or {}
            key = lib["natives"].get(os_name())
            if key and key in art:
                entry = art[key]
                jar = os.path.join(self.libs_dir, entry["path"])
                try:
                    curl.get(entry["url"], dest=jar, sha1=entry.get("sha1"))
                    self._extract_natives(jar, self.natives_dir, lib.get("extract"))
                    paths.append(jar)
                except CurlError as exc:
                    self.log("native %s failed: %s" % (lib.get("name"), exc))
        return paths

    def _prefer_arch(self, wanted):
        if os_name() != "osx" or os_arch() != "arm64":
            return wanted
        out = []
        bases = set()
        for url, dest, sha1, name in wanted:
            if ":natives-macos-arm64" in name or "natives-macos-arm64" in url:
                bases.add(name.split(":natives-macos-arm64")[0])
        for url, dest, sha1, name in wanted:
            if "natives-macos" in name and "natives-macos-arm64" not in name:
                base = name.split(":natives-macos")[0]
                if base in bases:
                    continue  # arm64 variant exists; skip x86_64
            out.append((url, dest, sha1, name))
        return out

    def _extract_natives(self, jar, dest, extract):
        exclude = (extract or {}).get("exclude", []) or []
        with zipfile.ZipFile(jar) as zf:
            for info in zf.namelist():
                if info.endswith("/"):
                    continue
                if any(info.startswith(e) for e in exclude):
                    continue
                target = os.path.join(dest, info)
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with zf.open(info) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out)
                if info.endswith(".dylib") or info.endswith(".so") or info.endswith(".dll"):
                    os.chmod(target, 0o755)

    def _assets(self, vjson, download=True):
        idx = vjson["assetIndex"]
        idx_path = os.path.join(self.assets_dir, "indexes", "%s.json" % idx["id"])
        self._phase("assets", "asset index %s" % idx["id"])
        self.curl.get(idx["url"], dest=idx_path, sha1=idx.get("sha1"), headers=self._ua())
        if not download:
            self.log("asset download skipped on request")
            return False
        with open(idx_path) as fh:
            data = json.load(fh)
        objects = data["objects"]
        items = []
        for name, obj in objects.items():
            h = obj["hash"]
            items.append(("%s/%s/%s" % (RESOURCES_URL, h[:2], h),
                          os.path.join(self.assets_dir, "objects", h[:2], h), h))
        mb = sum(o["size"] for o in objects.values()) / 1048576.0
        self._phase("assets", "assets (%d objects, %.0f MB)" % (len(items), mb), len(items))
        t0 = time.time()
        failed = self.curl.batch(items, progress=self._progress_cb("assets"),
                                 headers=self._ua())
        if failed:
            # Missing assets are survivable: the game runs with missing textures.
            self.log("WARNING: %d assets missing (~%s). The game will still start." % (
                len(failed), "; ".join(os.path.basename(f[1]) for f in failed[:3])))
        self.log("assets done in %.0fs" % (time.time() - t0))
        return True

    def _fabric_profile(self, mc_version, loader):
        if loader in ("none", "vanilla", ""):
            return None, None
        want = None if loader in ("stable", "latest", None) else loader.lstrip("fabric-loader-")
        cache_file = self._fabric_cache_path(mc_version, want) if (want and self.cfg.cache) else None
        if cache_file and os.path.exists(cache_file):
            with open(cache_file) as fh:
                prof = json.load(fh)
            self.log("fabric loader %s for %s (from the cache; no network needed)"
                     % (prof.get("_loader"), mc_version))
            return prof, prof.get("_loader")
        meta = None
        try:
            meta = self.curl.json("%s/versions/loader/%s" % (FABRIC_META, mc_version),
                                  headers=self._ua())
        except CurlError:
            if want is None:
                cached = self._newest_cached_fabric(mc_version)
                if cached:
                    prof, lv = cached
                    self.log("fabric: meta.fabricmc.net is unreachable, so the cached "
                             "loader %s is being used for %s" % (lv, mc_version))
                    return prof, lv
            raise
        if not meta:
            raise RuntimeError("Fabric has no loader for Minecraft %s" % mc_version)
        if want is None:
            stable = [e for e in meta if e["loader"].get("stable")]
            pick = (stable[0] if stable else meta[0]) if loader != "latest" else meta[0]
        else:
            pick = None
            for e in meta:
                if e["loader"]["version"] == want:
                    pick = e
                    break
            if not pick:
                raise RuntimeError("Fabric loader %s does not exist for %s (newest: %s)"
                                   % (want, mc_version, ", ".join(
                                       e["loader"]["version"] for e in meta[:5])))
        lv = pick["loader"]["version"]
        self.log("fabric loader %s for %s%s" % (
            lv, mc_version, "" if pick["loader"].get("stable") else " (not marked stable)"))
        prof = self.curl.json("%s/versions/loader/%s/%s/profile/json" % (
            FABRIC_META, mc_version, lv), headers=self._ua())
        prof["_loader"] = lv
        path = self._fabric_cache_path(mc_version, lv)
        if path:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as fh:
                json.dump(prof, fh, indent=1)
        return prof, lv

    def _fabric_cache_path(self, mc_version, loader_version):
        if not self.cfg.cache or not loader_version:
            return None
        cache = os.path.abspath(os.path.expanduser(self.cfg.cache))
        return os.path.join(cache, "fabric", "%s-%s.json" % (mc_version, loader_version))

    def _newest_cached_fabric(self, mc_version):
        """The loader profile from the most recent cached launch of this version,
        so a machine with no network can still start what it started before."""
        if not self.cfg.cache:
            return None
        cache = os.path.abspath(os.path.expanduser(self.cfg.cache))
        directory = os.path.join(cache, "fabric")
        if not os.path.isdir(directory):
            return None
        best = None
        for name in os.listdir(directory):
            if not name.startswith(mc_version + "-") or not name.endswith(".json"):
                continue
            path = os.path.join(directory, name)
            try:
                with open(path) as fh:
                    prof = json.load(fh)
                stamp = os.path.getmtime(path)
            except (OSError, ValueError):
                continue
            if best is None or stamp > best[0]:
                best = (stamp, prof)
        if not best:
            return None
        prof = best[1]
        return prof, prof.get("_loader")

    def _fabric_libraries(self, profile):
        if not profile:
            return []
        out = []
        for lib in profile.get("libraries", []):
            if not rules_allow(lib.get("rules"), self._features()):
                continue
            name = lib.get("name")
            repo = (lib.get("url") or "https://maven.fabricmc.net/").rstrip("/")
            rel, _n = maven_to_path(name)
            if not rel:
                continue
            out.append(os.path.join(self.libs_dir, rel))
            dest = os.path.join(self.libs_dir, rel)
            if not os.path.exists(dest):
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                self.curl.get("%s/%s" % (repo, rel), dest=dest, headers=self._ua())
        if out:
            self._phase("fabric", "fabric %s libraries" % profile.get("_loader"),
                        len(profile.get("libraries", [])))
            self._progress("fabric libraries", len(out), len(out))
        return out

    def _mods(self, slugs, mc_version, loader_ver):
        out = []
        if not slugs:
            return out
        self._phase("mods", "mods from Modrinth (%d)" % len(slugs), len(slugs))
        mods_dir = os.path.join(self.game_dir, "mods")
        for i, slug in enumerate(slugs):
            try:
                q = urllib.parse.urlencode({
                    "loaders": json.dumps(["fabric"]),
                    "game_versions": json.dumps([mc_version]),
                })
                versions = self.curl.json("%s/project/%s/version?%s" % (MODRINTH_API, slug, q),
                                          headers=self._ua())
                if not versions:
                    self.log("mod %s has no Fabric build for %s - skipped" % (slug, mc_version))
                    self._progress("mods", i + 1, len(slugs))
                    continue
                v = versions[0]
                files = [f for f in v["files"] if f.get("primary")] or v["files"]
                f = files[0]
                dest = os.path.join(mods_dir, f["filename"])
                self.curl.get(f["url"], dest=dest, headers=self._ua())
                self.log("mod %s %s -> %s" % (v.get("name") or slug, v["version_number"],
                                              f["filename"]))
                out.append({"name": v.get("name") or slug, "slug": slug,
                            "version": v["version_number"], "file": f["filename"],
                            "path": dest})
            except CurlError as exc:
                self.log("mod %s could not be fetched: %s" % (slug, exc))
            self._progress("mods", i + 1, len(slugs))
        return out

    def _local_mods(self, paths):
        """Jars already on this machine, copied into the sandbox's mods folder.
        These are deleted with everything else when the session ends."""
        out = []
        mods_dir = os.path.join(self.game_dir, "mods")
        for p in paths:
            src = os.path.abspath(os.path.expanduser(p))
            if not os.path.exists(src):
                self.log("mod jar %s does not exist - skipped" % src)
                continue
            if not src.endswith(".jar"):
                self.log("mod jar %s is not a .jar - skipped" % src)
                continue
            dest = os.path.join(mods_dir, os.path.basename(src))
            shutil.copy2(src, dest)
            self.log("mod %s (local file, copied into the sandbox)" % os.path.basename(src))
            out.append({"name": os.path.basename(src), "slug": "local",
                        "version": "local file", "file": os.path.basename(src),
                        "path": dest})
        return out

    def _features(self):
        return {
            "is_demo_user": False,
            "has_custom_resolution": False,
            "has_quick_plays_support": False,
            "is_quick_play_singleplayer": False,
            "is_quick_play_multiplayer": False,
            "is_quick_play_realms": False,
        }

    # ---------------------------------------------------------------- command
    def _build_command(self, vjson, profile, client_jar, libs, mc_version, loader_ver,
                       username, memory, mods):
        features = self._features()
        if profile:
            main_class = profile.get("mainClass") or vjson["mainClass"]
            version_name = profile.get("id") or ("fabric-loader-%s-%s" % (loader_ver, mc_version))
            jvm_args = list(vjson["arguments"]["jvm"])
            for a in profile.get("arguments", {}).get("jvm", []) or []:
                if isinstance(a, str) or rules_allow(a.get("rules"), features):
                    jvm_args.append(a)
            game_args = profile.get("arguments", {}).get("game") or vjson["arguments"]["game"]
            version_type = "Fabric"
        else:
            main_class = vjson["mainClass"]
            version_name = vjson["id"]
            jvm_args = list(vjson["arguments"]["jvm"])
            game_args = vjson["arguments"]["game"]
            version_type = vjson.get("type", "release")

        classpath = list(libs)
        if client_jar not in classpath:
            classpath.append(client_jar)
        cp = os.pathsep.join(classpath)
        offline_uuid = offline_uuid_for(username)
        sub = {
            "auth_player_name": username,
            "version_name": version_name,
            "game_directory": self.game_dir,
            "assets_root": self.assets_dir,
            "assets_index_name": vjson["assetIndex"]["id"],
            "auth_uuid": offline_uuid,
            "auth_access_token": "0",
            "auth_session": "0",
            "user_type": "legacy",
            "version_type": version_type,
            "user_properties": "{}",
            "clientid": "",
            "auth_xuid": "",
            "launcher_name": NAME,
            "launcher_version": VERSION,
            "natives_directory": self.natives_dir,
            "library_directory": self.libs_dir,
            "classpath": cp,
            "classpath_separator": os.pathsep,
            "resolution_width": "1280",
            "resolution_height": "720",
            "quickPlayPath": "",
            "quickPlaySingleplayer": "",
            "quickPlayMultiplayer": "",
            "quickPlayRealms": "",
        }
        cmd = [self.java, "-Xmx%s" % memory]
        if os_name() == "osx":
            cmd += ["-Dapple.awt.application.appearance=system"]
        cmd += ["-Dfabric.gameJarPath=%s" % client_jar]
        cmd += materialise(jvm_args, sub, features)
        cmd += [main_class]
        cmd += materialise(game_args, sub, features)
        return cmd, classpath

    # ---------------------------------------------------------------- collect
    def _collect(self):
        self._phase("collect", "collecting what the session wrote")
        wanted = ["saves", "logs", "crash-reports", "screenshots", "config",
                  "options.txt", "servers.dat", "usercache.json", "realms_persistence.json"]
        files = []
        with zipfile.ZipFile(self.bundle_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for rel in wanted:
                src = os.path.join(self.game_dir, rel)
                if not os.path.exists(src):
                    continue
                if os.path.isfile(src):
                    zf.write(src, rel)
                    files.append({"path": rel, "size": os.path.getsize(src)})
                    continue
                for base, _dirs, names in os.walk(src):
                    for n in names:
                        full = os.path.join(base, n)
                        arc = os.path.relpath(full, self.game_dir)
                        try:
                            zf.write(full, arc)
                            files.append({"path": arc, "size": os.path.getsize(full)})
                        except OSError:
                            pass
            # the console log is ours, and it is the thing that explains a crash
            console = os.path.join(self.root, "console.log")
            if os.path.exists(console):
                zf.write(console, "console.log")
                files.append({"path": "console.log", "size": os.path.getsize(console)})
            launch = os.path.join(self.root, "launch-command.txt")
            if os.path.exists(launch):
                zf.write(launch, "launch-command.txt")
                files.append({"path": "launch-command.txt", "size": os.path.getsize(launch)})
        total = os.path.getsize(self.bundle_path)
        worlds = sorted({f["path"].split("/")[1] for f in files
                         if f["path"].startswith("saves/") and len(f["path"].split("/")) > 2})
        self.result = {
            "bundle": "session.zip",
            "bytes": total,
            "files": len(files),
            "worlds": worlds,
            "hasCrash": any(f["path"].startswith("crash-reports/") for f in files),
            "exitCode": self.exit_code,
            "collectedAt": time.time(),
        }
        self.log("collected %d files (%.1f MB) into session.zip%s" % (
            len(files), total / 1048576.0,
            " - worlds: " + ", ".join(worlds) if worlds else ""))
        return self.result

    def restore(self, blob):
        """Put a previous session's bundle back into the game dir before launch.

        The page calls this *after* cleanup has deleted the sandbox, so the whole
        tree has to be rebuilt first - on a warm cache that costs nothing.
        """
        self._prepare_root()
        tmp = os.path.join(self.root, "restore-%s.zip" % secrets.token_hex(4))
        with open(tmp, "wb") as fh:
            fh.write(blob)
        count = 0
        with zipfile.ZipFile(tmp) as zf:
            for info in zf.namelist():
                if info.startswith("/") or ".." in info.split("/"):
                    continue
                zf.extract(info, self.game_dir)
                count += 1
        os.unlink(tmp)
        self.log("restored %d files from the browser into the sandbox" % count)
        return {"restored": count}

    def cleanup(self):
        """Delete the sandbox. This is the promise the whole design rests on."""
        if not os.path.isdir(self.root):
            return {"removed": 0, "path": self.root, "already": True}
        if self.cfg.keep:
            return {"removed": 0, "path": self.root, "kept": True,
                    "note": "--keep was given, nothing deleted"}
        size = 0
        for base, _dirs, names in os.walk(self.root):
            for n in names:
                try:
                    size += os.path.getsize(os.path.join(base, n))
                except OSError:
                    pass
        shutil.rmtree(self.root, ignore_errors=True)
        with self.lock:
            self.cleanup_deadline = None
        self.log("deleted %s (%.1f MB freed)" % (self.root, size / 1048576.0))
        return {"removed": size, "path": self.root, "gone": not os.path.exists(self.root)}

    # ---------------------------------------------------------------- helpers
    def _ua(self):
        return ("User-Agent: %s/%s (+https://github.com/derek/webmc)" % (NAME, VERSION),)

    def _progress_cb(self, label):
        def cb(done, total, _round=None):
            self._progress(label, done, total)
        return cb


def materialise(args, sub, features):
    """Flatten and substitute Mojang's argument list."""
    out = []
    for a in args:
        if isinstance(a, str):
            out.append(a)
            continue
        if not rules_allow(a.get("rules"), features):
            continue
        val = a.get("value")
        if isinstance(val, list):
            out.extend(val)
        elif val is not None:
            out.append(val)
    return [substitute(x, sub) for x in out]


PLACEHOLDER = re.compile(r"\$\{([a-zA-Z0-9_]+)\}")


def substitute(text, sub):
    return PLACEHOLDER.sub(lambda m: str(sub.get(m.group(1), "")), text)


def offline_uuid_for(name):
    digest = bytearray(hashlib.md5(("OfflinePlayer:" + name).encode("utf-8")).digest())
    digest[6] = (digest[6] & 0x0F) | 0x30
    digest[8] = (digest[8] & 0x3F) | 0x80
    return str(uuidlib.UUID(bytes=bytes(digest)))


def shell_quote(s):
    if re.match(r"^[A-Za-z0-9_@%+=:,./-]+$", s or ""):
        return s
    return "'" + (s or "").replace("'", "'\\''") + "'"


def port_open(host, port, timeout=0.25):
    s = socket.socket()
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def detect_proxy(explicit, curl_log):
    if explicit in ("none", "direct", ""):
        return None
    if explicit:
        return explicit
    for cand in PROXY_CANDIDATES:
        host_port = cand.split("://", 1)[1]
        host, port = host_port.split(":")
        if not port_open(host, int(port)):
            continue
        try:
            probe = Curl(proxy=cand)
            probe.get(MANIFEST_URL, dest=None, timeout=25)
            curl_log("proxy: %s (Mojang reachable through it)" % cand)
            return cand
        except CurlError as exc:
            curl_log("proxy candidate %s could not reach Mojang: %s" % (cand, exc))
    return None


# --------------------------------------------------------------------------- page

PAGE_SUFFIX = """
<script>
window.__WEBMC__ = { helper: "http://127.0.0.1:%(port)d", token: "%(token)s",
                     served: "helper" };
</script>
"""


# --------------------------------------------------------------------------- http

class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "%s/%s" % (NAME, VERSION)
    protocol_version = "HTTP/1.1"

    # ---- plumbing
    def log_message(self, fmt, *args):
        if self.server.verbose:
            sys.stderr.write("http %s\n" % (fmt % args))

    def _cors(self):
        origin = self.headers.get("Origin")
        allowed = None
        if origin:
            if origin in self.server.extra_origins or any(p.match(origin) for p in ORIGIN_PATTERNS):
                allowed = origin
        if allowed:
            self.send_header("Access-Control-Allow-Origin", allowed)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers",
                         "content-type, x-webmc-token, access-control-request-private-network")
        # Chrome 142+ gates public -> loopback behind Local Network Access. Answering
        # the preflight with this header is what keeps the bridge usable where an
        # admin has not blocked it outright.
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Cache-Control", "no-store")

    def _send(self, code, body=b"", ctype="application/json", extra=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code, obj):
        self._send(code, json.dumps(obj, indent=1))

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return b""
        return self.rfile.read(n)

    def _json_body(self):
        raw = self._body()
        if not raw:
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError:
            return {}

    def _authed(self):
        if self.path.split("?")[0] in ("/api/hello", "/", "/go", "/favicon.ico"):
            return True
        return self.headers.get("X-WebMC-Token") == self.server.token

    def _guard(self):
        if self._authed():
            return True
        self._json(403, {"error": "bad or missing X-WebMC-Token"})
        return False

    # ---- routes
    def do_OPTIONS(self):
        self._send(204)

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        parts = urllib.parse.urlsplit(self.path)
        path, query = parts.path, urllib.parse.parse_qs(parts.query)
        s = self.server.session
        if path == "/favicon.ico":
            return self._send(204)
        if path == "/":
            return self._page()
        if path == "/go":
            return self._go(query)
        if path == "/api/hello":
            return self._json(200, {
                "ok": True, "name": NAME, "version": VERSION,
                "platform": {"os": os_name(), "arch": os_arch(), "version": os_version()},
                "sandbox": self.server.session.root,
                "proxy": self.server.curl.proxy or "direct",
                "downloads": self.server.curl.bytes_in,
                "autocleanSeconds": s.cfg.autoclean,
                "features": ["fabric", "real-jvm", "opfs-bundle", "restore", "modrinth"],
            })
        if not self._guard():
            return
        if path == "/api/status":
            return self._json(200, s.status())
        if path == "/api/versions":
            try:
                return self._json(200, s.versions())
            except CurlError as exc:
                return self._json(502, {"error": str(exc)})
        if path == "/api/log":
            since = int((query.get("since") or ["0"])[0] or 0)
            lines, nxt = s.lines_since(since)
            return self._json(200, {"lines": lines, "next": nxt})
        if path == "/api/result":
            return self._json(200, {"result": s.result, "state": s.state,
                                    "exitCode": s.exit_code, "error": s.error})
        if path == "/api/bundle.zip":
            if not s.result or not os.path.exists(s.bundle_path):
                return self._json(404, {"error": "no bundle yet"})
            with open(s.bundle_path, "rb") as fh:
                blob = fh.read()
            return self._send(200, blob, "application/zip", {
                "Content-Disposition": 'attachment; filename="webmc-session.zip"'})
        return self._json(404, {"error": "no such endpoint", "path": path})

    def do_POST(self):
        path = urllib.parse.urlsplit(self.path).path
        s = self.server.session
        if not self._guard():
            return
        if path == "/api/launch":
            body = self._json_body()
            opts = {
                "version": body.get("version") or DEFAULT_VERSION,
                "loader": body.get("loader") or "stable",
                "mods": body.get("mods") or [],
                "username": body.get("username") or "Player",
                "memory": body.get("memory") or DEFAULT_MEMORY,
                "assets": body.get("assets", True),
            }
            try:
                s.start(opts)
            except RuntimeError as exc:
                return self._json(409, {"error": str(exc)})
            return self._json(202, {"started": True, "instance": opts})
        if path == "/api/stop":
            return self._json(200, {"stopped": s.stop(), "state": s.status()["state"]})
        if path == "/api/restore":
            blob = self._body()
            if not blob:
                return self._json(400, {"error": "empty body"})
            try:
                return self._json(200, s.restore(blob))
            except Exception as exc:  # noqa: BLE001
                return self._json(400, {"error": "not a usable bundle: %s" % exc})
        if path == "/api/cleanup":
            return self._json(200, s.cleanup())
        return self._json(404, {"error": "no such endpoint", "path": path})

    # ---- the helper's own copy of the page
    def _page(self):
        page = self.server.page_path
        if not page or not os.path.exists(page):
            return self._json(200, {
                "name": NAME, "version": VERSION,
                "note": "page not found next to the helper; use /api/* or pass --page",
                "hint": "http://127.0.0.1:%d/api/hello" % self.server.server_address[1],
            })
        with open(page, "rb") as fh:
            html = fh.read().decode("utf-8")
        inject = PAGE_SUFFIX % {"port": self.server.server_address[1],
                                "token": self.server.token}
        # This has to land before the page's own script runs, or the page cannot see the
        # token it was just handed. Injecting it at the end made a helper-served page
        # say "not connected" while talking to the helper that served it.
        placed = False
        for marker, before in (("<head>", False), ("</head>", True), ("</body>", True)):
            if marker in html:
                html = html.replace(marker, (inject + marker) if before else (marker + inject), 1)
                placed = True
                break
        if not placed:
            html = inject + html
        self._send(200, html, "text/html; charset=utf-8")

    def _go(self, query):
        """Hand the token to a hosted copy of the page, via the URL fragment."""
        target = (query.get("to") or [""])[0]
        if not target:
            return self._send(400, "missing ?to=", "text/plain")
        parsed = urllib.parse.urlsplit(target)
        ok = (parsed.scheme in ("http", "https") and (
            any(p.match("%s://%s" % (parsed.scheme, parsed.netloc)) for p in ORIGIN_PATTERNS)
            or parsed.netloc.endswith("github.io")))
        if not ok:
            return self._send(400, "refusing to redirect to %s" % target, "text/plain")
        frag = "helper=http://127.0.0.1:%d&t=%s" % (self.server.server_address[1],
                                                    self.server.token)
        sep = "&" if "#" in target else "#"
        loc = target + sep + frag
        self.send_response(302)
        self._cors()
        self.send_header("Location", loc)
        self.send_header("Content-Length", "0")
        self.end_headers()


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, addr, handler, session, curl, token, page_path, origins, verbose):
        self.session = session
        self.curl = curl
        self.token = token
        self.page_path = page_path
        self.extra_origins = set(origins)
        self.verbose = verbose
        super().__init__(addr, handler)


# --------------------------------------------------------------------------- cli

def default_root():
    return os.path.join("/tmp", "webmc-%s" % secrets.token_hex(4))


def sweep_stale_sandboxes(older_than=6 * 3600, keep=None, log=print):
    """A helper that was killed hard (or a machine that went down) leaves its
    sandbox behind. /tmp is emptied on reboot anyway, but the promise is that
    nothing survives a session, so clear out anything old enough that it cannot
    belong to a session still in progress."""
    removed = 0
    freed = 0
    now = time.time()
    try:
        names = os.listdir("/tmp")
    except OSError:
        return 0, 0
    for name in names:
        if not name.startswith("webmc-"):
            continue
        # Only real sandboxes (webmc-<8 hex>) - a directory someone named
        # /tmp/webmc-cache is their business, not litter.
        if not re.fullmatch(r"webmc-[0-9a-f]{8}", name):
            continue
        path = os.path.join("/tmp", name)
        if keep and os.path.abspath(path) == os.path.abspath(keep):
            continue
        if not os.path.isdir(path):
            continue
        try:
            age = now - os.path.getmtime(path)
        except OSError:
            continue
        if age < older_than:
            continue
        try:
            for base, _dirs, files in os.walk(path):
                for f in files:
                    try:
                        freed += os.path.getsize(os.path.join(base, f))
                    except OSError:
                        pass
            shutil.rmtree(path, ignore_errors=True)
            removed += 1
        except OSError:
            pass
    if removed:
        log("cleared %d leftover sandbox(es) from earlier runs (%.0f MB)"
            % (removed, freed / 1048576.0))
    return removed, freed


def install_signal_handlers(log=print):
    """Closing the terminal window, or any ordinary kill, has to run the cleanup
    that deletes the sandbox. Without this a double-clicked .command that the
    visitor closes would leave 600 MB under /tmp."""
    def bye(signum, _frame):
        try:
            name = signal.Signals(signum).name
        except Exception:
            name = str(signum)
        log("\n  received %s - cleaning up" % name)
        raise SystemExit(0)
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGQUIT):
        try:
            signal.signal(sig, bye)
        except (ValueError, OSError, AttributeError):
            pass


def parse_args(argv):
    ap = argparse.ArgumentParser(
        prog=NAME,
        description="Run real Minecraft + Fabric locally from a web page, keep nothing.")
    ap.add_argument("--port", type=int, default=7645)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--root", default=None,
                    help="sandbox directory (default /tmp/webmc-<random>)")
    ap.add_argument("--allow-origin", action="append", default=[], metavar="ORIGIN",
                    help="extra page origin allowed to talk to this helper")
    ap.add_argument("--page", default=None, help="path to the launcher page to serve at /")
    ap.add_argument("--page-url", default=None,
                    help="hosted page to hand the token to when /go is used")
    ap.add_argument("--open", action="store_true", help="open the browser at / (or /go)")
    ap.add_argument("--java", default=None, help="java executable to use")
    ap.add_argument("--proxy", default=None,
                    help="SOCKS/HTTP proxy for downloads, or 'none' (default: auto)")
    ap.add_argument("--no-jre-download", action="store_true",
                    help="never fetch a JRE; fail instead")
    ap.add_argument("--keep", action="store_true",
                    help="do not delete the sandbox at the end (debugging)")
    ap.add_argument("--cache", default=os.environ.get("WEBMC_CACHE_DIR") or None,
                    help="reuse assets and libraries from this directory instead of "
                         "downloading them again (off by default: a session normally "
                         "downloads everything into its sandbox)")
    ap.add_argument("--autoclean", type=int, default=900,
                    help="seconds after the session ends before the sandbox is deleted "
                         "(0 disables; default 900)")
    ap.add_argument("--server-only", action="store_true",
                    help="start idle: no game is launched until the page asks")
    ap.add_argument("--launch", action="store_true",
                    help="launch immediately instead of waiting for the page")
    ap.add_argument("--version", default=DEFAULT_VERSION,
                    help="Minecraft version (default %s)" % DEFAULT_VERSION)
    ap.add_argument("--loader", default="stable",
                    help="Fabric loader version, 'stable' or 'none'")
    ap.add_argument("--mods", default="",
                    help="comma-separated Modrinth slugs, e.g. fabric-api,modmenu")
    ap.add_argument("--mod-jar", action="append", default=[], metavar="PATH",
                    help="a Fabric mod jar on this machine to copy into the sandbox "
                         "(repeatable). It is deleted with the sandbox afterwards.")
    ap.add_argument("--username", default="Player")
    ap.add_argument("--memory", default=DEFAULT_MEMORY)
    ap.add_argument("--no-assets", action="store_true",
                    help="skip the ~450 MB of sounds and textures")
    ap.add_argument("--dry-run", action="store_true",
                    help="download everything, build the command, do not start the game")
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--print-token", action="store_true")
    return ap.parse_args(argv)


def main(argv=None):
    args = parse_args(argv if argv is not None else sys.argv[1:])
    cfg = argparse.Namespace(**vars(args))
    if not cfg.root:
        cfg.root = default_root()
    cfg.root = os.path.abspath(os.path.expanduser(cfg.root))
    install_signal_handlers()

    print("")
    print("  %s %s" % (NAME, VERSION))
    print("  " + "-" * 62)
    sweep_stale_sandboxes(keep=cfg.root)

    curl = Curl()
    proxy = detect_proxy(args.proxy, lambda m: print("  " + m))
    curl.proxy = proxy
    if not proxy:
        print("  proxy: none (using the network directly)")

    # which proxy did we end up with, and does it work at all?
    try:
        curl.get(MANIFEST_URL, dest=None, timeout=20)
        print("  network: Mojang reachable")
    except CurlError as exc:
        print("  network: NOT reachable - %s" % exc)
        print("  hint: if this machine needs a SOCKS tunnel, run it on 127.0.0.1:1080")
        print("        or pass --proxy socks5h://host:port")

    session = Session(cfg, curl)
    page = args.page
    if not page:
        guess = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             os.pardir, "page", "index.html")
        page = os.path.abspath(guess)
    token = secrets.token_hex(16)
    try:
        httpd = Server((args.host, args.port), Handler, session, curl, token, page,
                       args.allow_origin, args.verbose)
    except OSError as exc:
        if exc.errno in (errno.EADDRINUSE, errno.EACCES):
            print("  ERROR: cannot listen on %s:%d - %s" % (args.host, args.port, exc))
            print("  hint: something else is on that port; use --port 7646")
            return 2
        raise
    port = httpd.server_address[1]
    url = "http://%s:%d/" % (args.host, port)
    print("  page:   %s" % url)
    if page and os.path.exists(page):
        print("  serving %s" % page)
    if args.page_url:
        print("  hosted: %s/go?to=%s" % (url, urllib.parse.quote(args.page_url, safe="")))
    if args.print_token:
        print("  token:  %s" % token)

    if args.open:
        opener = "open" if os_name() == "osx" else ("start" if os_name() == "windows" else "xdg-open")
        target = url
        if args.page_url:
            target = "%sgo?to=%s" % (url, urllib.parse.quote(args.page_url, safe=""))
        threading.Timer(0.6, lambda: subprocess.run([opener, target])).start()

    if args.launch:
        opts = {
            "version": args.version,
            "loader": args.loader,
            "mods": [m.strip() for m in (args.mods or "").split(",") if m.strip()],
            "localMods": list(args.mod_jar or []),
            "username": args.username,
            "memory": args.memory,
            "assets": not args.no_assets,
        }
        print("  launching %s%s with %s" % (
            opts["version"],
            " + fabric" if opts["loader"] not in ("none", "") else "",
            ", ".join(opts["mods"]) or "no mods"))
        print("")
        session.start(opts)

    if not args.server_only:
        print("")
        print("  Play is a button on the page; this process only listens.")
        print("  Everything is written under %s and deleted after" % cfg.root)
        print("  the session's files have been saved. Ctrl-C to quit.")
    print("")
    try:
        httpd.serve_forever()
    except (KeyboardInterrupt, SystemExit):
        print("\n  shutting down")
    finally:
        session.stop()
        if not cfg.keep:
            session.cleanup()
        else:
            print("  --keep was given: %s is still there" % cfg.root)
        httpd.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
