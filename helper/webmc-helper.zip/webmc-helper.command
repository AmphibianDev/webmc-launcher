#!/bin/bash
# webmc-helper - one file, and nothing installed.
#
# Double-click it. It makes one staging directory under /tmp, puts everything it needs in there
# (a Python runtime if this machine has none, the helper itself, the game, the Java runtime), and
# deletes the whole directory when the session ends.
#
#   press Play at:   https://amphibiandev.github.io/webmc-launcher/local.html
#   stop it with:    pkill -f webmc_helper        (or let it exit by itself when idle)
#   watch it work:   WEBMC_FOREGROUND=1 ./webmc-helper.command
#   uninstall:       ./webmc-helper.command --uninstall
#
# WHAT IT NEEDS FROM THE MACHINE: bash, curl and tar. That is all - all three ship with macOS and
# with Windows 10+, and nothing here needs Xcode command line tools, Homebrew, or Java installed.
set -u

STAGE="$(mktemp -d "${TMPDIR:-/tmp}/webmc.XXXXXX")" || exit 1
SOURCE="$STAGE/webmc_helper.py"
export WEBMC_CLEANUP_DIR="$STAGE"

PY=""
if [ "${WEBMC_FORCE_FETCH:-0}" = "0" ] && command -v python3 >/dev/null 2>&1; then
  if python3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 8) else 1)' 2>/dev/null; then
    PY="$(command -v python3)"
  fi
fi

if [ -z "$PY" ]; then
  case "$(uname -s)-$(uname -m)" in
    Darwin-arm64)  PBSTARGET="aarch64-apple-darwin" ;;
    Darwin-x86_64) PBSTARGET="x86_64-apple-darwin" ;;
    Linux-x86_64)  PBSTARGET="x86_64-unknown-linux-gnu" ;;
    Linux-aarch64) PBSTARGET="aarch64-unknown-linux-gnu" ;;
    *) echo "webmc-helper: unsupported system $(uname -s) $(uname -m)"; exit 1 ;;
  esac
  PBSURL="https://github.com/astral-sh/python-build-standalone/releases/download/20261013/cpython-3.11.17+20261013-${PBSTARGET}-install_only.tar.gz"
  echo "This machine has no Python 3, so webmc-helper is fetching one into its own folder:"
  echo "    $STAGE"
  echo "Nothing is installed, and it is deleted with the rest when the session ends."
  if ! curl -fsSL --retry 2 -m 600 "$PBSURL" -o "$STAGE/python.tar.gz"; then
    echo "Could not fetch the Python runtime. Check this machine can reach github.com."
    curl -s -o /dev/null -m 5 https://github.com || echo "  (github.com is unreachable from here)"
    rm -rf "$STAGE"
    read -r -p "press return to close " _
    exit 1
  fi
  mkdir -p "$STAGE/py" && tar -xzf "$STAGE/python.tar.gz" -C "$STAGE/py" || { rm -rf "$STAGE"; exit 1; }
  rm -f "$STAGE/python.tar.gz"
  PY="$STAGE/py/python/bin/python3"
  if [ ! -x "$PY" ]; then
    echo "The fetched runtime did not unpack where expected. Nothing was left behind; giving up."
    rm -rf "$STAGE"
    read -r -p "press return to close " _
    exit 1
  fi
fi

cat > "$SOURCE" <<'WEBMC_HELPER_SOURCE'
#!/usr/bin/env python3
"""
webmc-helper - run real Minecraft + Fabric on this machine, keep nothing.

The contract, in the words of the design it implements:

    the page only launches Minecraft; Minecraft still runs on your computer,
    just ... temporarily.

So every byte this helper writes goes into one sandbox directory under /tmp
(`/tmp/webmc-<nonce>`), and the whole thing is deleted when the session's files
have been handed to the page - or after `--autoclean` seconds, whichever is
first. Nothing is installed, no service is registered, nothing is left behind.

    page (github.io or this helper's own /)  ──HTTP──▶  127.0.0.1:7645
                                                            │
                                          downloads ────────┤ Mojang / Fabric / Modrinth
                                          (through the     │
                                           SOCKS tunnel    │
                                           when direct     │
                                           is blocked)     │
                                                            ▼
                                          /tmp/webmc-XXXX/  ──▶ java ... KnotClient
                                                            │
                                          saves + logs ─────┤ zip
                                                            ▼
                                                    page stores it (OPFS)
                                                            │
                                                    POST /api/cleanup ──▶ rm -rf

Endpoints (all JSON):
    GET  /                  the page, with this helper's own token baked in
    GET  /go?to=<page-url>  redirect to a hosted page with the token in the fragment    GET  /api/hello         identity + capability probe (no token needed)
    GET  /api/versions      Mojang's release list (cached, fetched lazily)
    GET  /api/search?q=&mc= Modrinth search, run here so it works behind a filtered network
    GET  /api/status        phase, progress, instance, pid, exit code, cleanup receipt
    GET  /api/log?since=N   log lines after index N
    GET  /api/localmods     the mod jars the page has handed over for this session
    POST /api/launch        {version, loader, mods, username, memory, assets}
    POST /api/stop          kill the game
    POST /api/localmods     body = one .jar, name in X-WebMC-Mod-Name (?clear=1, ?drop=name)
    POST /api/restore       body = a bundle zip from a previous session
    GET  /api/result        exit code, collected files, bundle size
    GET  /api/bundle.zip    the collected saves/logs/screenshot bundle
    POST /api/cleanup       delete the sandbox

Only Python 3.9's standard library is used. Downloads shell out to `curl`,
because curl speaks SOCKS5 with remote DNS (`socks5h://`) and does parallel
transfers, which is exactly what a poisoned resolver needs.
"""

import argparse
import base64
import errno
import hashlib
import http.server
import io
import json
import os
import platform
import re
import secrets
import shutil
import signal
import socket
import socketserver
import struct
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import uuid as uuidlib
import zipfile

VERSION = "0.1.0"
NAME = "webmc-helper"

MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
RESOURCES_URL = "https://resources.download.minecraft.net"
FABRIC_META = "https://meta.fabricmc.net/v2"
# Forge and NeoForge publish a version document *inside their installer jar*, which is what a
# launcher needs - no installation step, no patching by hand. Reading it out is what makes the
# other two loaders the same shape as Fabric here.
LOADER_MAVEN = {
    "forge": "https://maven.minecraftforge.net/",
    "neoforge": "https://maven.neoforged.net/releases/",
}
LOADER_METADATA = {
    "forge": "https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml",
    "neoforge": "https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml",
}
LOADER_KINDS = ("fabric", "forge", "neoforge", "none")

# When Mojang (or Fabric, or Modrinth) is unreachable from the visitor's network, everything can
# be fetched through one relay instead: it maps straight onto the upstream URLs, so nothing else in
# this file has to know. See relay/ for the Cloudflare Worker that does it.
RELAY_PREFIXES = (
    ("https://piston-meta.mojang.com", "piston-meta"),
    ("https://piston-data.mojang.com", "piston-data"),
    ("https://resources.download.minecraft.net", "resources"),
    ("https://libraries.minecraft.net", "libraries"),
    ("https://maven.fabricmc.net", "fabric-maven"),
    ("https://meta.fabricmc.net", "fabric-meta"),
    ("https://maven.minecraftforge.net", "forge-maven"),
    ("https://maven.neoforged.net/releases", "neoforge-maven"),
    ("https://api.modrinth.com", "modrinth"),
    ("https://api.adoptium.net", "adoptium"),
)


# The relays this helper will use when the page (or the command line) does not name one. Deploying a
# Worker once and putting its URL here is what turns "everybody deploys their own" into "it works".
# Order matters: the first that answers /health wins, so list a spare. An empty tuple means the
# helper simply downloads directly, which is what most networks want anyway.
DEFAULT_RELAYS = (
    # The relay this project deployed for everyone. On a network that blocks workers.dev it simply
    # does not answer, and the helper downloads directly instead. Add a second URL here (a Render
    # deployment, or your own domain) and the helper tries them in order.
    "https://webmc-relay.webmc-helper.workers.dev",
)

_RELAY_CHOICE = {"probed": False, "url": None}
OFF = ("off", "none", "no", "direct", "-")


def relay_reachable(url, timeout=5):
    """Does this relay answer /health? Cheap, and it is the only thing that decides."""
    try:
        request = urllib.request.Request(url.rstrip("/") + "/health",
                                        headers={"User-Agent": "webmc-helper"})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status == 200
    except Exception:
        return False


def resolve_relay(requested, log=None, timeout=5):
    """Decide which relay to use. "off" means none, a URL means that one, and nothing means the
    built-in list — probed once per helper, so a launch never pays for it twice."""
    if requested and str(requested).strip().lower() in OFF:
        return None
    if requested and str(requested).strip():
        return str(requested).strip().rstrip("/")
    if _RELAY_CHOICE["probed"]:
        return _RELAY_CHOICE["url"]
    _RELAY_CHOICE["probed"] = True
    for candidate in DEFAULT_RELAYS:
        if relay_reachable(candidate, timeout=timeout):
            _RELAY_CHOICE["url"] = candidate.rstrip("/")
            if log:
                log("relay: using the built-in relay %s (say \"off\" to download directly)"
                    % _RELAY_CHOICE["url"])
            return _RELAY_CHOICE["url"]
    if DEFAULT_RELAYS and log:
        log("relay: none of the %d built-in relays answered; downloading directly"
            % len(DEFAULT_RELAYS))
    return None


def relayed(url, relay):
    """Rewrite an upstream URL to go through the relay, if one is configured."""
    if not relay:
        return url
    base = relay.rstrip("/")
    for upstream, prefix in RELAY_PREFIXES:
        if url.startswith(upstream):
            return "%s/%s%s" % (base, prefix, url[len(upstream):])
    return url
# What this helper will actually launch. Forge and NeoForge are resolved, downloaded and merged
# below - that part works and was verified as far as their bootstrap - but neither ships a usable
# client jar: their own installer runs installertools over the vanilla jar to produce
# client-<mc>-<stamp>-srg.jar and ...-extra.jar, and the bootstrap refuses to start without them.
# Until that patch step is implemented, they are refused up front rather than half-launched.
SUPPORTED_LOADERS = ("fabric", "none")
MODRINTH_API = "https://api.modrinth.com/v2"
ADOPTIUM_API = "https://api.adoptium.net/v3"

DEFAULT_VERSION = "1.21.11"

# The single-file build (tools/publish-helper.py) puts the launcher page in here as base64, so
# one downloadable .command can serve its own page without a folder of files next to it. In the
# repository this is empty and the page is read from page/index.html as usual.
_EMBEDDED_PAGE = "PCFET0NUWVBFIGh0bWw+CjxodG1sIGxhbmc9ImVuIj4KPGhlYWQ+CjxtZXRhIGNoYXJzZXQ9InV0Zi04IiAvPgo8bWV0YSBuYW1lPSJ2aWV3cG9ydCIgY29udGVudD0id2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEiIC8+Cjx0aXRsZT5XZWJNQzwvdGl0bGU+CjwhLS0KICBBIGxhdW5jaGVyIHdob3NlIGludGVyZmFjZSBpcyBhIHdlYiBwYWdlLCBhbmQgd2hpY2gga2VlcHMgbm90aGluZyBvZiB0aGUgZ2FtZSBvbiB0aGUgbWFjaGluZS4KCiAgU2hlbGw6IGEgdG9wIGJhciB5b3UgbmF2aWdhdGUsIGFuIGltbWVyc2l2ZSBoZXJvIGZvciB0aGUgaW5zdGFsbGF0aW9uLCBhbmQgb25lIGZ1bGwtd2lkdGggYWN0aXZpdHkKICBkcmF3ZXIgdGhhdCBzbGlkZXMgdXAgZnJvbSB0aGUgYm90dG9tLiBUaGVyZSBpcyBubyByYWlsIGFuZCBubyBwZXJtYW5lbnQgc2lkZSBjb2x1bW4g4oCUIHRoZSBsb2cgaGFzCiAgdGhlIHdob2xlIHdpZHRoIG9mIHRoZSB3aW5kb3cgd2hlbiB5b3Ugd2FudCBpdCwgYW5kIGEgc3RyaXAgeW91IGNhbiB3YXRjaCB3aGVuIHlvdSBkbyBub3QuCgogIFRoZSBwYWdlIGNhbm5vdCBzdGFydCBhIHByb2dyYW0sIHJlYWQgYSBmaWxlLCBvciBzZWUgL3RtcC4gQSBoZWxwZXIgb24gdGhpcyBtYWNoaW5lIGRvZXMgdGhhdDsgdGhpcwogIGlzIHRoZSBpbnRlcmZhY2UgdG8gaXQuCi0tPgo8c3R5bGU+CiAgOnJvb3R7CiAgICAtLWJnOiMwYzBkMTA7IC0taW5rOiNlZWYwZjQ7IC0tbXV0ZWQ6I2E0YTdiMDsgLS1kaW06IzZkNzA3YTsKICAgIC0tbGluZTojZmZmZmZmMTQ7IC0tbGluZTI6I2ZmZmZmZjI2OwogICAgLS1ncmVlbjojNDhhOTJmOyAtLWdyZWVuMjojNjNjOTNmOyAtLWdyZWVuMzojOTZlZjZjOwogICAgLS1ibHVlOiM2M2E0ZWY7IC0tcmVkOiNkNDY4NWE7IC0tYW1iZXI6I2UwYjIzYzsKICAgIC0tZ2xhc3M6I2ZmZmZmZjBhOyAtLWdsYXNzMjojZmZmZmZmMTI7CiAgICAtLXI6MThweDsgLS1yMjoxMXB4OyAtLXIzOjhweDsKICAgIC0tc2hhZG93OjAgMjRweCA2MHB4ICMwMDAwMDA3MywgMCAxcHggMCAjZmZmZmZmMTIgaW5zZXQ7CiAgfQogICp7Ym94LXNpemluZzpib3JkZXItYm94fQogIGh0bWwsYm9keXtoZWlnaHQ6MTAwJTttYXJnaW46MH0KICBib2R5e2JhY2tncm91bmQ6dmFyKC0tYmcpO2NvbG9yOnZhcigtLWluayk7b3ZlcmZsb3c6aGlkZGVuOwogICAgICAgZm9udDoxNXB4LzEuNTUgLWFwcGxlLXN5c3RlbSxCbGlua01hY1N5c3RlbUZvbnQsIlNlZ29lIFVJIixSb2JvdG8sSGVsdmV0aWNhLEFyaWFsLHNhbnMtc2VyaWY7CiAgICAgICBsZXR0ZXItc3BhY2luZzouMDA0ZW07LXdlYmtpdC1mb250LXNtb290aGluZzphbnRpYWxpYXNlZH0KICBhe2NvbG9yOnZhcigtLWJsdWUpO3RleHQtZGVjb3JhdGlvbjpub25lfSBhOmhvdmVye3RleHQtZGVjb3JhdGlvbjp1bmRlcmxpbmV9CiAgY29kZXtmb250OjEyLjVweC8xLjUgdWktbW9ub3NwYWNlLFNGTW9uby1SZWd1bGFyLE1lbmxvLG1vbm9zcGFjZTtiYWNrZ3JvdW5kOiMwODA5MGI7CiAgICAgICBib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpO3BhZGRpbmc6MXB4IDZweDtib3JkZXItcmFkaXVzOjVweDtjb2xvcjojZDdkOWUwfQogIHN2Z3t3aWR0aDoxOHB4O2hlaWdodDoxOHB4O3N0cm9rZTpjdXJyZW50Q29sb3I7ZmlsbDpub25lO3N0cm9rZS13aWR0aDoxLjc7c3Ryb2tlLWxpbmVjYXA6cm91bmQ7CiAgICAgIHN0cm9rZS1saW5lam9pbjpyb3VuZH0KICA6Oi13ZWJraXQtc2Nyb2xsYmFye3dpZHRoOjEycHg7aGVpZ2h0OjEycHh9CiAgOjotd2Via2l0LXNjcm9sbGJhci10aHVtYntiYWNrZ3JvdW5kOiMzNzM5NDEzMztib3JkZXItcmFkaXVzOjhweDtib3JkZXI6NHB4IHNvbGlkIHRyYW5zcGFyZW50OwogICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jbGlwOmNvbnRlbnQtYm94fQogIDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWI6aG92ZXJ7YmFja2dyb3VuZDojNGE0YzU2MzM7YmFja2dyb3VuZC1jbGlwOmNvbnRlbnQtYm94fQoKICAvKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gYXRtb3NwaGVyZSAqLwogIC5hdG1vc3twb3NpdGlvbjpmaXhlZDtpbnNldDowO3otaW5kZXg6MDtwb2ludGVyLWV2ZW50czpub25lO292ZXJmbG93OmhpZGRlbn0KICAuYXRtb3M6YmVmb3Jle2NvbnRlbnQ6IiI7cG9zaXRpb246YWJzb2x1dGU7aW5zZXQ6LTMwJTsKICAgIGJhY2tncm91bmQ6Y29uaWMtZ3JhZGllbnQoZnJvbSAxMjBkZWcgYXQgNTUlIDM1JSwgIzQ4YTkyZjFjLCAjNjNhNGVmMTcsICM4ZTVjZTgxOSwgIzQ4YTkyZjFjKTsKICAgIGZpbHRlcjpibHVyKDgwcHgpO2FuaW1hdGlvbjpzcGluIDU0cyBsaW5lYXIgaW5maW5pdGV9CiAgLmF0bW9zOmFmdGVye2NvbnRlbnQ6IiI7cG9zaXRpb246YWJzb2x1dGU7aW5zZXQ6MDsKICAgIGJhY2tncm91bmQ6cmFkaWFsLWdyYWRpZW50KDEyMHJlbSA3MHJlbSBhdCA1MCUgLTE1JSwgI2ZmZmZmZjBlLCB0cmFuc3BhcmVudCA2MCUpLAogICAgICAgICAgICAgICByYWRpYWwtZ3JhZGllbnQoODByZW0gNjByZW0gYXQgNTAlIDEyMCUsICMwMDAwMDBhNiwgdHJhbnNwYXJlbnQgNjAlKX0KICBAa2V5ZnJhbWVzIHNwaW57dG97dHJhbnNmb3JtOnJvdGF0ZSgzNjBkZWcpfX0KICAub3Jie3Bvc2l0aW9uOmFic29sdXRlO3dpZHRoOjQ2cmVtO2hlaWdodDo0NnJlbTtsZWZ0OnZhcigtLW14LDUwJSk7dG9wOnZhcigtLW15LDQyJSk7CiAgICAgICBtYXJnaW46LTIzcmVtIDAgMCAtMjNyZW07Ym9yZGVyLXJhZGl1czo1MCU7ZmlsdGVyOmJsdXIoNHB4KTtvcGFjaXR5Oi40MjsKICAgICAgIGJhY2tncm91bmQ6cmFkaWFsLWdyYWRpZW50KGNpcmNsZSwjNjNjOTNmM2EgMCUsIzYzYTRlZjI2IDQ0JSx0cmFuc3BhcmVudCA3MCUpOwogICAgICAgdHJhbnNpdGlvbjpvcGFjaXR5IC43c30KICAub3ZlcmxheXtwb3NpdGlvbjpmaXhlZDtpbnNldDowO3otaW5kZXg6MTtwb2ludGVyLWV2ZW50czpub25lfQogIGJvZHkuZngtZ2xvdyAub3ZlcmxheXtib3gtc2hhZG93Omluc2V0IDAgMCAyNjBweCAjMDAwMDAwYWJ9CiAgYm9keS5meC1ncmlkIC5vdmVybGF5e2JhY2tncm91bmQtaW1hZ2U6bGluZWFyLWdyYWRpZW50KCNmZmZmZmYwYSAxcHgsdHJhbnNwYXJlbnQgMXB4KSwKICAgICAgICAgICAgICAgICAgICAgICAgbGluZWFyLWdyYWRpZW50KDkwZGVnLCNmZmZmZmYwYSAxcHgsdHJhbnNwYXJlbnQgMXB4KTsKICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1zaXplOjQ0cHggNDRweDsKICAgICAgICAgICAgICAgICAgICAgICAgbWFzay1pbWFnZTpyYWRpYWwtZ3JhZGllbnQoOTAlIDcwJSBhdCA1MCUgMjAlLCMwMDAgMTIlLHRyYW5zcGFyZW50IDc4JSl9CiAgYm9keS5meC1zY2FuIC5vdmVybGF5e2JhY2tncm91bmQ6cmVwZWF0aW5nLWxpbmVhci1ncmFkaWVudCgjZmZmZmZmMDggMCAxcHgsdHJhbnNwYXJlbnQgMXB4IDRweCl9CiAgYm9keS5meC1zY2FuIC5vdmVybGF5OmFmdGVye2NvbnRlbnQ6IiI7cG9zaXRpb246YWJzb2x1dGU7aW5zZXQ6MDsKICAgIGJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KCMwMDAwLCNmZmZmZmYxMiA0NiUsIzAwMDApO2FuaW1hdGlvbjpzd2VlcCA5cyBsaW5lYXIgaW5maW5pdGV9CiAgQGtleWZyYW1lcyBzd2VlcHswJXt0cmFuc2Zvcm06dHJhbnNsYXRlWSgtNjIlKX0xMDAle3RyYW5zZm9ybTp0cmFuc2xhdGVZKDYyJSl9fQoKICAvKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gc2hlbGwgKi8KICAuc2hlbGx7cG9zaXRpb246cmVsYXRpdmU7ei1pbmRleDoyO2hlaWdodDoxMDB2aDtkaXNwbGF5OmZsZXg7ZmxleC1kaXJlY3Rpb246Y29sdW1ufQogIC50b3BiYXJ7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6MTZweDtwYWRkaW5nOjE0cHggMjJweDtmbGV4Om5vbmV9CiAgLm1hcmt7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6MTJweH0KICAuY3ViZXt3aWR0aDozMnB4O2hlaWdodDozMnB4O2JvcmRlci1yYWRpdXM6MTBweDtmbGV4Om5vbmU7cG9zaXRpb246cmVsYXRpdmU7CiAgICAgICAgYmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQoMTUwZGVnLCM5ZGYxNzMsIzNmOGEyOSA1OCUsIzFmNGExNyk7CiAgICAgICAgYm94LXNoYWRvdzowIDhweCAyMnB4ICMwMDA3LCAwIDAgMjZweCAjNjNjOTNmM2QsIGluc2V0IDAgMXB4IDAgI2ZmZmZmZjQwfQogIC5jdWJlOmFmdGVye2NvbnRlbnQ6IiI7cG9zaXRpb246YWJzb2x1dGU7aW5zZXQ6OHB4IDhweCBhdXRvIDhweDtoZWlnaHQ6OXB4O2JvcmRlci1yYWRpdXM6M3B4OwogICAgICAgICAgICAgIGJhY2tncm91bmQ6IzAwMDAwMDQyfQogIC5tYXJrIGJ7Zm9udC1zaXplOjE3LjVweDtsZXR0ZXItc3BhY2luZzotLjAxNWVtfQogIC5tYXJrIHNwYW57ZGlzcGxheTpibG9jaztmb250LXNpemU6OS41cHg7bGV0dGVyLXNwYWNpbmc6LjI0ZW07dGV4dC10cmFuc2Zvcm06dXBwZXJjYXNlO2NvbG9yOnZhcigtLWRpbSl9CgogIC50YWJze2Rpc3BsYXk6ZmxleDtnYXA6NHB4O3BhZGRpbmc6NXB4O2JvcmRlcjoxcHggc29saWQgdmFyKC0tbGluZSk7Ym9yZGVyLXJhZGl1czo5OXB4OwogICAgICAgIGJhY2tncm91bmQ6dmFyKC0tZ2xhc3MpO2JhY2tkcm9wLWZpbHRlcjpibHVyKDE4cHgpIHNhdHVyYXRlKDE0MCUpfQogIC50YWJzIGJ1dHRvbntib3JkZXI6MDtiYWNrZ3JvdW5kOm5vbmU7Y29sb3I6dmFyKC0tbXV0ZWQpO3BhZGRpbmc6OXB4IDE4cHg7Ym9yZGVyLXJhZGl1czo5OXB4OwogICAgICAgICAgICAgICBmb250LXNpemU6MTRweDtkaXNwbGF5OmlubGluZS1mbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6OXB4OwogICAgICAgICAgICAgICB0cmFuc2l0aW9uOmNvbG9yIC4xNXMsIGJhY2tncm91bmQgLjE1c30KICAudGFicyBidXR0b246aG92ZXJ7Y29sb3I6dmFyKC0taW5rKTtiYWNrZ3JvdW5kOiNmZmZmZmYwZH0KICAudGFicyBidXR0b24ub257Y29sb3I6IzBlMWEwOTtiYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCgxODBkZWcsI2E5ZjE4NCwjNjNjOTNmKTtmb250LXdlaWdodDo2MDA7CiAgICAgICAgICAgICAgICAgIGJveC1zaGFkb3c6MCA2cHggMThweCAjM2Y4YTI5NTJ9CiAgLnRhYnMgYnV0dG9uIHN2Z3t3aWR0aDoxNnB4O2hlaWdodDoxNnB4fQogIC5ncm93e2ZsZXg6MX0KICAuc3RhdHVze2Rpc3BsYXk6aW5saW5lLWZsZXg7YWxpZ24taXRlbXM6Y2VudGVyO2dhcDo5cHg7Zm9udC1zaXplOjEycHg7cGFkZGluZzo3cHggMTRweDsKICAgICAgICAgIGJvcmRlcjoxcHggc29saWQgdmFyKC0tbGluZSk7Ym9yZGVyLXJhZGl1czo5OXB4O2JhY2tncm91bmQ6dmFyKC0tZ2xhc3MpOwogICAgICAgICAgY29sb3I6dmFyKC0tbXV0ZWQpO2JhY2tkcm9wLWZpbHRlcjpibHVyKDE2cHgpO3doaXRlLXNwYWNlOm5vd3JhcH0KICAuZG90e3dpZHRoOjdweDtoZWlnaHQ6N3B4O2JvcmRlci1yYWRpdXM6NTAlO2JhY2tncm91bmQ6dmFyKC0tZGltKTtmbGV4Om5vbmV9CiAgLmRvdC5va3tiYWNrZ3JvdW5kOnZhcigtLWdyZWVuMik7Ym94LXNoYWRvdzowIDAgMTBweCB2YXIoLS1ncmVlbjIpfQogIC5kb3QuYmFke2JhY2tncm91bmQ6dmFyKC0tcmVkKX0KICAuZG90LmJ1c3l7YmFja2dyb3VuZDp2YXIoLS1hbWJlcik7YW5pbWF0aW9uOmJsaW5rIDEuMXMgZWFzZS1pbi1vdXQgaW5maW5pdGV9CiAgQGtleWZyYW1lcyBibGlua3s1MCV7b3BhY2l0eTouM319CgogIC8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSB3b3Jrc3BhY2UgKi8KICAud29ya3NwYWNle2ZsZXg6MTttaW4taGVpZ2h0OjA7b3ZlcmZsb3c6YXV0bztwYWRkaW5nOjZweCAyMnB4IDIycHh9CiAgLnBhbmV7ZGlzcGxheTpub25lO21heC13aWR0aDoxNTAwcHg7bWFyZ2luOjAgYXV0b30KICAucGFuZS5vbntkaXNwbGF5OmJsb2NrO2FuaW1hdGlvbjpyaXNlIC4zcyBjdWJpYy1iZXppZXIoLjMsMCwuMiwxKX0KICBAa2V5ZnJhbWVzIHJpc2V7ZnJvbXtvcGFjaXR5OjA7dHJhbnNmb3JtOnRyYW5zbGF0ZVkoMTBweCl9dG97b3BhY2l0eToxO3RyYW5zZm9ybTpub25lfX0KCiAgLmhlcm97Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKTtib3JkZXItcmFkaXVzOnZhcigtLXIpO3BhZGRpbmc6MzRweCAzOHB4OwogICAgICAgIGJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KDEyMGRlZywjMWQyMDI3Y2MsIzE1MTcxYmQ5IDYwJSksdmFyKC0tZ2xhc3MpOwogICAgICAgIGJhY2tkcm9wLWZpbHRlcjpibHVyKDI0cHgpIHNhdHVyYXRlKDE1MCUpO2JveC1zaGFkb3c6dmFyKC0tc2hhZG93KTtwb3NpdGlvbjpyZWxhdGl2ZTsKICAgICAgICBvdmVyZmxvdzpoaWRkZW59CiAgLmhlcm86YmVmb3Jle2NvbnRlbnQ6IiI7cG9zaXRpb246YWJzb2x1dGU7aW5zZXQ6LTQwJSAtMTAlIGF1dG8gLTEwJTtoZWlnaHQ6MjIwcHg7CiAgICBiYWNrZ3JvdW5kOnJhZGlhbC1ncmFkaWVudCg1NSUgMTAwJSBhdCAzMCUgMTAwJSwjNjNjOTNmMjIsdHJhbnNwYXJlbnQgNzIlKX0KICAuaGVybzphZnRlcntjb250ZW50OiIiO3Bvc2l0aW9uOmFic29sdXRlO3JpZ2h0Oi0xMjBweDt0b3A6LTE2MHB4O3dpZHRoOjQyMHB4O2hlaWdodDo0MjBweDsKICAgIGJvcmRlci1yYWRpdXM6NTAlO2JhY2tncm91bmQ6cmFkaWFsLWdyYWRpZW50KGNpcmNsZSwjNjNhNGVmMjIsdHJhbnNwYXJlbnQgNjYlKX0KICAuaGVybyAucGFke3Bvc2l0aW9uOnJlbGF0aXZlO3otaW5kZXg6Mn0KICAua2lja2Vye2ZvbnQtc2l6ZToxMXB4O2xldHRlci1zcGFjaW5nOi4yNGVtO3RleHQtdHJhbnNmb3JtOnVwcGVyY2FzZTtjb2xvcjp2YXIoLS1kaW0pfQogIC5oZXJvIGgxe21hcmdpbjoxMnB4IDAgNnB4O2ZvbnQtc2l6ZTpjbGFtcCg0NnB4LDd2dyw4MHB4KTtsaW5lLWhlaWdodDouOTQ7bGV0dGVyLXNwYWNpbmc6LS4wNDVlbTsKICAgICAgICAgICBmb250LXdlaWdodDo3NTA7CiAgICAgICAgICAgYmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQoOTZkZWcsI2ZmZmZmZiA2JSwjZGZmNWNkIDQ2JSwjOGZlNjY1IDk2JSk7CiAgICAgICAgICAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6dGV4dDtiYWNrZ3JvdW5kLWNsaXA6dGV4dDstd2Via2l0LXRleHQtZmlsbC1jb2xvcjp0cmFuc3BhcmVudH0KICAuaGVybyAubGVkZXtjb2xvcjp2YXIoLS1tdXRlZCk7Zm9udC1zaXplOjE0LjVweDttYXgtd2lkdGg6NjBjaDttYXJnaW4tdG9wOjE0cHh9CiAgLmNoaXBze2Rpc3BsYXk6ZmxleDtmbGV4LXdyYXA6d3JhcDtnYXA6OXB4O21hcmdpbi10b3A6MjBweH0KICAuY2hpcHtmb250LXNpemU6MTJweDtwYWRkaW5nOjVweCAxM3B4O2JvcmRlci1yYWRpdXM6OTlweDtib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpOwogICAgICAgIGJhY2tncm91bmQ6I2ZmZmZmZjBhO2NvbG9yOnZhcigtLW11dGVkKX0KICAuY2hpcC5vbntjb2xvcjojZTJmYmQzO2JvcmRlci1jb2xvcjojM2Y2ZjJjO2JhY2tncm91bmQ6IzFlMmMxNjtib3gtc2hhZG93OjAgMCAxOHB4ICM2M2M5M2YzMH0KCiAgLnBpY2tlcntkaXNwbGF5OmdyaWQ7Z3JpZC10ZW1wbGF0ZS1jb2x1bW5zOjEuMWZyIDEuMWZyIGF1dG87Z2FwOjE0cHg7YWxpZ24taXRlbXM6ZW5kO21hcmdpbi10b3A6MjZweH0KICAucGxheXtoZWlnaHQ6NjZweDtwYWRkaW5nOjAgNDZweDtmb250LXNpemU6MjFweDtmb250LXdlaWdodDo3NTA7bGV0dGVyLXNwYWNpbmc6LjFlbTtib3JkZXI6MDsKICAgICAgICBib3JkZXItcmFkaXVzOjE0cHg7Y29sb3I6IzBjMWEwNjtjdXJzb3I6cG9pbnRlcjsKICAgICAgICBiYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCgxODBkZWcsI2E5ZjE4NCwjNWNiZTM3IDY4JSwjNGFhMjJjKTsKICAgICAgICBib3gtc2hhZG93OjAgMTZweCA0MHB4ICMyYjY3MWE4MCwgMCAwIDYwcHggIzYzYzkzZjNkLCBpbnNldCAwIDFweCAwICNmZmZmZmY2NjsKICAgICAgICBkaXNwbGF5OmlubGluZS1mbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6MTJweH0KICAucGxheTpob3Zlcjpub3QoOmRpc2FibGVkKXtmaWx0ZXI6YnJpZ2h0bmVzcygxLjA2KX0KICAucGxheTpkaXNhYmxlZHtiYWNrZ3JvdW5kOiMyNDI2MmM7Y29sb3I6dmFyKC0tZGltKTtib3gtc2hhZG93Om5vbmU7Y3Vyc29yOm5vdC1hbGxvd2VkfQogIC5zdG9we2hlaWdodDo2NnB4O3BhZGRpbmc6MCAzMnB4O2ZvbnQtc2l6ZToxNnB4O2ZvbnQtd2VpZ2h0OjcwMDtib3JkZXItcmFkaXVzOjE0cHg7CiAgICAgICAgYmFja2dyb3VuZDojM2MyNjI0O2JvcmRlcjoxcHggc29saWQgIzZmM2MzNjtjb2xvcjojZmZiM2FiO2N1cnNvcjpwb2ludGVyfQoKICAuZmFjdHN7ZGlzcGxheTpncmlkO2dyaWQtdGVtcGxhdGUtY29sdW1uczpyZXBlYXQoNCwxZnIpO2dhcDoxNHB4O21hcmdpbi10b3A6MTZweH0KICAuZmFjdHtib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpO2JvcmRlci1yYWRpdXM6dmFyKC0tcjIpO3BhZGRpbmc6MTZweCAxOHB4O2JhY2tncm91bmQ6dmFyKC0tZ2xhc3MpOwogICAgICAgIGJhY2tkcm9wLWZpbHRlcjpibHVyKDE4cHgpfQogIC5mYWN0IC5re2ZvbnQtc2l6ZToxMC41cHg7bGV0dGVyLXNwYWNpbmc6LjJlbTt0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7Y29sb3I6dmFyKC0tZGltKX0KICAuZmFjdCAudntmb250LXNpemU6MTlweDtmb250LXdlaWdodDo2NTA7bWFyZ2luLXRvcDo3cHg7bGV0dGVyLXNwYWNpbmc6LS4wMWVtOwogICAgICAgICAgIG92ZXJmbG93OmhpZGRlbjt0ZXh0LW92ZXJmbG93OmVsbGlwc2lzO3doaXRlLXNwYWNlOm5vd3JhcH0KICAuZmFjdCAuc3tmb250LXNpemU6MTEuNXB4O2NvbG9yOnZhcigtLWRpbSk7bWFyZ2luLXRvcDozcHg7b3ZlcmZsb3c6aGlkZGVuO3RleHQtb3ZlcmZsb3c6ZWxsaXBzaXM7CiAgICAgICAgICAgd2hpdGUtc3BhY2U6bm93cmFwfQoKICAucGFuZWx7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKTtib3JkZXItcmFkaXVzOnZhcigtLXIpO2JhY2tncm91bmQ6dmFyKC0tZ2xhc3MpOwogICAgICAgICBiYWNrZHJvcC1maWx0ZXI6Ymx1cigyMHB4KTtib3gtc2hhZG93OnZhcigtLXNoYWRvdyk7cGFkZGluZzoyNHB4IDI2cHg7bWFyZ2luLXRvcDoxNnB4fQogIC5wYW5lbCBoMnttYXJnaW46MCAwIDE2cHg7Zm9udC1zaXplOjEycHg7bGV0dGVyLXNwYWNpbmc6LjJlbTt0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7CiAgICAgICAgICAgIGNvbG9yOnZhcigtLWRpbSk7Zm9udC13ZWlnaHQ6NzAwO2Rpc3BsYXk6ZmxleDthbGlnbi1pdGVtczpjZW50ZXI7Z2FwOjEwcHh9CiAgLnBhbmVsIGgyIC5ncm93e2ZsZXg6MX0KICAuY29sc3tkaXNwbGF5OmdyaWQ7Z3JpZC10ZW1wbGF0ZS1jb2x1bW5zOjFmciAxZnI7Z2FwOjE2cHh9CiAgLmNvbHMze2Rpc3BsYXk6Z3JpZDtncmlkLXRlbXBsYXRlLWNvbHVtbnM6cmVwZWF0KDMsMWZyKTtnYXA6MTZweH0KICBsYWJlbHtkaXNwbGF5OmJsb2NrO2ZvbnQtc2l6ZToxMS41cHg7Y29sb3I6dmFyKC0tbXV0ZWQpO21hcmdpbjowIDAgNnB4O2xldHRlci1zcGFjaW5nOi4wM2VtfQogIGlucHV0LHNlbGVjdHt3aWR0aDoxMDAlO2JhY2tncm91bmQ6IzBhMGIwZGNjO2JvcmRlcjoxcHggc29saWQgdmFyKC0tbGluZSk7Ym9yZGVyLXJhZGl1czp2YXIoLS1yMik7CiAgICAgICAgICAgICAgIHBhZGRpbmc6MTJweCAxM3B4O2ZvbnQ6aW5oZXJpdDtmb250LXNpemU6MTRweDtjb2xvcjp2YXIoLS1pbmspOwogICAgICAgICAgICAgICB0cmFuc2l0aW9uOmJvcmRlci1jb2xvciAuMTVzLCBib3gtc2hhZG93IC4xNXN9CiAgaW5wdXQ6Zm9jdXMsc2VsZWN0OmZvY3Vze291dGxpbmU6bm9uZTtib3JkZXItY29sb3I6IzYzYzkzZjk5O2JveC1zaGFkb3c6MCAwIDAgNHB4ICM2M2M5M2YxY30KICBidXR0b257Zm9udDppbmhlcml0O2N1cnNvcjpwb2ludGVyO2JvcmRlci1yYWRpdXM6dmFyKC0tcjIpO2JvcmRlcjoxcHggc29saWQgdmFyKC0tbGluZSk7CiAgICAgICAgIGJhY2tncm91bmQ6dmFyKC0tZ2xhc3MyKTtjb2xvcjp2YXIoLS1pbmspO3BhZGRpbmc6MTBweCAxNnB4O2ZvbnQtc2l6ZToxNHB4OwogICAgICAgICBkaXNwbGF5OmlubGluZS1mbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6OXB4O2p1c3RpZnktY29udGVudDpjZW50ZXI7CiAgICAgICAgIHRyYW5zaXRpb246dHJhbnNmb3JtIC4xMnMsIGJhY2tncm91bmQgLjE1cywgYm9yZGVyLWNvbG9yIC4xNXN9CiAgYnV0dG9uOmhvdmVyOm5vdCg6ZGlzYWJsZWQpe2JhY2tncm91bmQ6I2ZmZmZmZjFjO2JvcmRlci1jb2xvcjp2YXIoLS1saW5lMik7dHJhbnNmb3JtOnRyYW5zbGF0ZVkoLTFweCl9CiAgYnV0dG9uOmFjdGl2ZTpub3QoOmRpc2FibGVkKXt0cmFuc2Zvcm06bm9uZX0KICBidXR0b246ZGlzYWJsZWR7b3BhY2l0eTouNDtjdXJzb3I6bm90LWFsbG93ZWR9CiAgYnV0dG9uLnRpbnl7cGFkZGluZzo2cHggMTJweDtmb250LXNpemU6MTIuNXB4fQogIGJ1dHRvbi5kYW5nZXJ7YmFja2dyb3VuZDojM2MyNjI0O2JvcmRlci1jb2xvcjojNmYzYzM2O2NvbG9yOiNmZmIzYWJ9CiAgLnJvd3tkaXNwbGF5OmZsZXg7Z2FwOjEycHg7YWxpZ24taXRlbXM6ZmxleC1lbmR9CiAgLnJvdz4qe2ZsZXg6MX0gLnJvdyAuZml4ZWR7ZmxleDowIDAgYXV0b30KICAuaGludHtmb250LXNpemU6MTIuNXB4O2NvbG9yOnZhcigtLWRpbSk7bGluZS1oZWlnaHQ6MS43fQogIC53YXJue2JvcmRlcjoxcHggc29saWQgIzZkNWExZjtiYWNrZ3JvdW5kOiMyNDFmMTFjYztjb2xvcjojZThjZjhhO3BhZGRpbmc6MTRweCAxNnB4OwogICAgICAgIGJvcmRlci1yYWRpdXM6dmFyKC0tcjIpO2ZvbnQtc2l6ZToxM3B4O2xpbmUtaGVpZ2h0OjEuNjh9CiAgLmJhZHtib3JkZXI6MXB4IHNvbGlkICM2ZjNjMzY7YmFja2dyb3VuZDojMmIxYzFhY2M7Y29sb3I6I2ZmYjNhYjtwYWRkaW5nOjE0cHggMTZweDsKICAgICAgIGJvcmRlci1yYWRpdXM6dmFyKC0tcjIpO2ZvbnQtc2l6ZToxM3B4O2xpbmUtaGVpZ2h0OjEuNjh9CiAgLnN0ZXBze21hcmdpbjoxMnB4IDAgMDtwYWRkaW5nLWxlZnQ6MjBweDtmb250LXNpemU6MTNweDtjb2xvcjp2YXIoLS1tdXRlZCk7bGluZS1oZWlnaHQ6MS45fQogIC5jaGVja3tkaXNwbGF5OmZsZXg7Z2FwOjExcHg7YWxpZ24taXRlbXM6ZmxleC1zdGFydDttYXJnaW46MDtjb2xvcjp2YXIoLS1pbmspO2ZvbnQtc2l6ZToxMy41cHh9CiAgLmNoZWNrIGlucHV0e3dpZHRoOmF1dG87bWFyZ2luLXRvcDo0cHg7ZmxleDpub25lfQogIGRldGFpbHMgc3VtbWFyeXtjdXJzb3I6cG9pbnRlcjtjb2xvcjp2YXIoLS1tdXRlZCk7Zm9udC1zaXplOjEzcHg7cGFkZGluZzoycHggMH0KICAuZHJvcHtib3JkZXI6MS41cHggZGFzaGVkIHZhcigtLWxpbmUyKTtib3JkZXItcmFkaXVzOnZhcigtLXIpO3BhZGRpbmc6MjZweDt0ZXh0LWFsaWduOmNlbnRlcjsKICAgICAgICBjb2xvcjp2YXIoLS1tdXRlZCk7Zm9udC1zaXplOjEzLjVweDtjdXJzb3I6cG9pbnRlcjt0cmFuc2l0aW9uOi4xNnN9CiAgLmRyb3A6aG92ZXIsLmRyb3Aub3Zlcntib3JkZXItY29sb3I6IzYzYzkzZjtjb2xvcjp2YXIoLS1pbmspO2JhY2tncm91bmQ6IzYzYzkzZjEyfQogIC5tb2Rze2xpc3Qtc3R5bGU6bm9uZTttYXJnaW46MTZweCAwIDA7cGFkZGluZzowO2ZvbnQtc2l6ZToxMy41cHh9CiAgLm1vZHMgbGl7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6MTJweDtwYWRkaW5nOjExcHggMTNweDtib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpOwogICAgICAgICAgIGJvcmRlci1yYWRpdXM6dmFyKC0tcjIpO21hcmdpbi1ib3R0b206OHB4O2JhY2tncm91bmQ6I2ZmZmZmZjA3fQogIC5tb2RzIC5ubXtmbGV4OjE7bWluLXdpZHRoOjA7b3ZlcmZsb3c6aGlkZGVuO3RleHQtb3ZlcmZsb3c6ZWxsaXBzaXM7d2hpdGUtc3BhY2U6bm93cmFwfQogIC50YWd7ZGlzcGxheTppbmxpbmUtYmxvY2s7Zm9udC1zaXplOjkuNXB4O2xldHRlci1zcGFjaW5nOi4xM2VtO3RleHQtdHJhbnNmb3JtOnVwcGVyY2FzZTsKICAgICAgIGNvbG9yOnZhcigtLWRpbSk7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKTtib3JkZXItcmFkaXVzOjk5cHg7cGFkZGluZzoycHggOXB4O2ZsZXg6bm9uZX0KICAudGFnLm1pbmV7Y29sb3I6I2IwZTc5NTtib3JkZXItY29sb3I6IzNhNjMzMH0KICAudGFnLmh1Yntjb2xvcjojYThjZGYyO2JvcmRlci1jb2xvcjojMmY0ZjcwfQogIC5yZXN1bHRze2xpc3Qtc3R5bGU6bm9uZTttYXJnaW46MTZweCAwIDA7cGFkZGluZzowO21heC1oZWlnaHQ6MzQwcHg7b3ZlcmZsb3c6YXV0bztmb250LXNpemU6MTMuNXB4fQogIC5yZXN1bHRzIGxpe2Rpc3BsYXk6ZmxleDtnYXA6MTJweDthbGlnbi1pdGVtczpjZW50ZXI7cGFkZGluZzoxMXB4IDRweDsKICAgICAgICAgICAgICBib3JkZXItYm90dG9tOjFweCBzb2xpZCB2YXIoLS1saW5lKX0KICAucmVzdWx0cyAubm17ZmxleDoxO21pbi13aWR0aDowfQogIC5yZXN1bHRzIC5ubSBie2ZvbnQtd2VpZ2h0OjYwMH0KICAucmVzdWx0cyAubm0gZGl2e2NvbG9yOnZhcigtLWRpbSk7Zm9udC1zaXplOjEycHg7d2hpdGUtc3BhY2U6bm93cmFwO292ZXJmbG93OmhpZGRlbjsKICAgICAgICAgICAgICAgICAgIHRleHQtb3ZlcmZsb3c6ZWxsaXBzaXN9CgogIC8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSB0aGUgZHJhd2VyICovCiAgLmRyYXdlcntmbGV4Om5vbmU7Ym9yZGVyLXRvcDoxcHggc29saWQgdmFyKC0tbGluZSk7YmFja2dyb3VuZDojMGEwYjBlY2M7YmFja2Ryb3AtZmlsdGVyOmJsdXIoMjRweCk7CiAgICAgICAgICBkaXNwbGF5OmZsZXg7ZmxleC1kaXJlY3Rpb246Y29sdW1uO2hlaWdodDo1MnB4O3RyYW5zaXRpb246aGVpZ2h0IC4yNnMgY3ViaWMtYmV6aWVyKC40LDAsLjIsMSl9CiAgYm9keS5kcmF3ZXItb3BlbiAuZHJhd2Vye2hlaWdodDo0NnZofQogIC5zdHJpcHtkaXNwbGF5OmZsZXg7YWxpZ24taXRlbXM6Y2VudGVyO2dhcDoxNHB4O3BhZGRpbmc6MCAyMnB4O2hlaWdodDo1MnB4O2ZsZXg6bm9uZTtjdXJzb3I6cG9pbnRlcn0KICAuc3RyaXAgYntmb250LXNpemU6MTFweDtsZXR0ZXItc3BhY2luZzouMmVtO3RleHQtdHJhbnNmb3JtOnVwcGVyY2FzZTtjb2xvcjp2YXIoLS1kaW0pfQogIC50cmFja3tmbGV4OjE7aGVpZ2h0OjZweDtib3JkZXItcmFkaXVzOjk5cHg7YmFja2dyb3VuZDojZmZmZmZmMTI7b3ZlcmZsb3c6aGlkZGVuO3Bvc2l0aW9uOnJlbGF0aXZlfQogIC50cmFjayBpe2Rpc3BsYXk6YmxvY2s7aGVpZ2h0OjEwMCU7d2lkdGg6MDtib3JkZXItcmFkaXVzOjk5cHg7CiAgICAgICAgICAgYmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQoOTBkZWcsIzQ4YTkyZiwjOTZlZjZjKTt0cmFuc2l0aW9uOndpZHRoIC40c30KICAudHJhY2suaW5kZXQgaXt3aWR0aDozMCU7YW5pbWF0aW9uOnNsaWRlIDEuM3MgZWFzZS1pbi1vdXQgaW5maW5pdGV9CiAgQGtleWZyYW1lcyBzbGlkZXswJXttYXJnaW4tbGVmdDotMzAlfTEwMCV7bWFyZ2luLWxlZnQ6MTAwJX19CiAgLnN0cmlwIC5waGFzZXtmb250LXNpemU6MTIuNXB4O2NvbG9yOnZhcigtLW11dGVkKTttaW4td2lkdGg6MTZjaH0KICAuc3RyaXAgLnBjdHtmb250LXNpemU6MTJweDtjb2xvcjp2YXIoLS1kaW0pO21pbi13aWR0aDo5Y2g7dGV4dC1hbGlnbjpyaWdodH0KICAuc3RyaXAgLnRvZ2dsZXtmb250LXNpemU6MTEuNXB4O2NvbG9yOnZhcigtLW11dGVkKTtib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpOwogICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6OTlweDtwYWRkaW5nOjRweCAxMnB4O2JhY2tncm91bmQ6dmFyKC0tZ2xhc3MpfQogIC5kcmF3ZXJib2R5e2ZsZXg6MTttaW4taGVpZ2h0OjA7ZGlzcGxheTpub25lO2JvcmRlci10b3A6MXB4IHNvbGlkIHZhcigtLWxpbmUpfQogIGJvZHkuZHJhd2VyLW9wZW4gLmRyYXdlcmJvZHl7ZGlzcGxheTpmbGV4O2ZsZXgtZGlyZWN0aW9uOmNvbHVtbn0KICAubG9ndG9vbHN7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6MTBweDtwYWRkaW5nOjEwcHggMjJweDtmbGV4Om5vbmU7CiAgICAgICAgICAgIGJvcmRlci1ib3R0b206MXB4IHNvbGlkIHZhcigtLWxpbmUpfQogIC5sb2d0b29scyBie2ZvbnQtc2l6ZToxMXB4O2xldHRlci1zcGFjaW5nOi4yZW07dGV4dC10cmFuc2Zvcm06dXBwZXJjYXNlO2NvbG9yOnZhcigtLWRpbSl9CiAgLnJlY2VpcHR7ZGlzcGxheTpub25lO3BhZGRpbmc6MTZweCAyMnB4O2JhY2tncm91bmQ6IzE2MjAwZmNjO2ZvbnQtc2l6ZToxM3B4O2xpbmUtaGVpZ2h0OjEuNzU7CiAgICAgICAgICAgbWF4LWhlaWdodDo0MCU7b3ZlcmZsb3c6YXV0bztib3JkZXItYm90dG9tOjFweCBzb2xpZCB2YXIoLS1saW5lKX0KICAucmVjZWlwdCBoM3ttYXJnaW46MCAwIDEwcHg7Zm9udC1zaXplOjEzcHg7Y29sb3I6I2IwZTc5NX0KICAucmVjZWlwdCAubGluZXtjb2xvcjp2YXIoLS1tdXRlZCl9IC5yZWNlaXB0IGJ7Y29sb3I6dmFyKC0taW5rKX0KICAuY29uc29sZXtmbGV4OjE7bWluLWhlaWdodDowO292ZXJmbG93OmF1dG87cGFkZGluZzoxNnB4IDIycHg7CiAgICAgICAgICAgZm9udDoxMi41cHgvMS44NSB1aS1tb25vc3BhY2UsU0ZNb25vLVJlZ3VsYXIsTWVubG8sbW9ub3NwYWNlO3doaXRlLXNwYWNlOnByZS13cmFwOwogICAgICAgICAgIHdvcmQtYnJlYWs6YnJlYWstd29yZDtjb2xvcjojYzljYmQzfQogIC5jb25zb2xlIC5le2NvbG9yOiNmZjlhOTB9IC5jb25zb2xlIC5ne2NvbG9yOiM5ZWUwN2Z9IC5jb25zb2xlIC5ke2NvbG9yOiM2ZDcwN2F9CgogIC8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSBkb2NzICovCiAgLmRvY3ttYXgtd2lkdGg6OTAwcHh9CiAgLmRvYyBoM3tmb250LXNpemU6MjFweDttYXJnaW46MzRweCAwIDEycHg7Zm9udC13ZWlnaHQ6NjUwO2xldHRlci1zcGFjaW5nOi0uMDJlbX0KICAuZG9jIGgzOmZpcnN0LW9mLXR5cGV7bWFyZ2luLXRvcDo0cHh9CiAgLmRvYyBwLC5kb2MgbGl7Y29sb3I6I2M4Y2FkMjtmb250LXNpemU6MTRweH0KICAuZG9jIC5sZWFke2ZvbnQtc2l6ZToxNi41cHg7Y29sb3I6dmFyKC0tbXV0ZWQpfQogIC5kb2MgdGFibGV7Ym9yZGVyLWNvbGxhcHNlOmNvbGxhcHNlO3dpZHRoOjEwMCU7bWFyZ2luOjE4cHggMDtmb250LXNpemU6MTMuNXB4fQogIC5kb2MgdGgsLmRvYyB0ZHtib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpO3BhZGRpbmc6MTBweCAxM3B4O3RleHQtYWxpZ246bGVmdDt2ZXJ0aWNhbC1hbGlnbjp0b3B9CiAgLmRvYyB0aHtiYWNrZ3JvdW5kOiNmZmZmZmYwYTtjb2xvcjp2YXIoLS1tdXRlZCk7Zm9udC13ZWlnaHQ6NjUwO2ZvbnQtc2l6ZToxMXB4O2xldHRlci1zcGFjaW5nOi4xZW07CiAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2V9CiAgLmRvYyBocntib3JkZXI6MDtib3JkZXItdG9wOjFweCBzb2xpZCB2YXIoLS1saW5lKTttYXJnaW46MzBweCAwfQogIC50b2N7ZGlzcGxheTpmbGV4O2ZsZXgtd3JhcDp3cmFwO2dhcDo4cHg7bWFyZ2luOjEwcHggMCAyNnB4fQogIC50b2MgYXtmb250LXNpemU6MTIuNXB4O3BhZGRpbmc6NnB4IDEzcHg7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKTtib3JkZXItcmFkaXVzOjk5cHg7CiAgICAgICAgIGNvbG9yOnZhcigtLW11dGVkKTtiYWNrZ3JvdW5kOiNmZmZmZmYwOX0KICAudG9jIGE6aG92ZXJ7Y29sb3I6dmFyKC0taW5rKTtib3JkZXItY29sb3I6dmFyKC0tbGluZTIpO3RleHQtZGVjb3JhdGlvbjpub25lfQoKICBkaWFsb2d7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKTtiYWNrZ3JvdW5kOiMxNTE2MWFjYztiYWNrZHJvcC1maWx0ZXI6Ymx1cigyNnB4KTtjb2xvcjp2YXIoLS1pbmspOwogICAgICAgICBib3JkZXItcmFkaXVzOnZhcigtLXIpO21heC13aWR0aDo3MDBweDtwYWRkaW5nOjA7Ym94LXNoYWRvdzp2YXIoLS1zaGFkb3cpfQogIGRpYWxvZzo6YmFja2Ryb3B7YmFja2dyb3VuZDojMDAwMDAwYjN9CiAgZGlhbG9nIC5pbm5lcntwYWRkaW5nOjI4cHggMzBweH0KICBkaWFsb2cgaDN7bWFyZ2luOjAgMCAxNHB4O2ZvbnQtc2l6ZToxOXB4fQogIGRpYWxvZyBwe2ZvbnQtc2l6ZToxMy41cHg7Y29sb3I6dmFyKC0tbXV0ZWQpO2xpbmUtaGVpZ2h0OjEuOH0KICBAbWVkaWEgKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSl7ICp7YW5pbWF0aW9uOm5vbmUgIWltcG9ydGFudDt0cmFuc2l0aW9uOm5vbmUgIWltcG9ydGFudH0gfQo8L3N0eWxlPgo8L2hlYWQ+Cjxib2R5IGNsYXNzPSJmeC1nbG93Ij4KPGRpdiBjbGFzcz0iYXRtb3MiIGlkPSJiZyIgYXJpYS1oaWRkZW49InRydWUiPjxkaXYgY2xhc3M9Im9yYiI+PC9kaXY+PC9kaXY+CjxkaXYgY2xhc3M9Im92ZXJsYXkiIGlkPSJmeCIgYXJpYS1oaWRkZW49InRydWUiPjwvZGl2PgoKPGRpdiBjbGFzcz0ic2hlbGwiIGlkPSJhcHAiPgogIDwhLS0gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIHRvcCBiYXIgLS0+CiAgPGhlYWRlciBjbGFzcz0idG9wYmFyIj4KICAgIDxkaXYgY2xhc3M9Im1hcmsiPgogICAgICA8ZGl2IGNsYXNzPSJjdWJlIj48L2Rpdj4KICAgICAgPGRpdj48Yj5XZWJNQzwvYj48c3Bhbj5sYXVuY2hlcjwvc3Bhbj48L2Rpdj4KICAgIDwvZGl2PgogICAgPGRpdiBjbGFzcz0idGFicyI+CiAgICAgIDxidXR0b24gaWQ9Im5hdlBsYXkiIGNsYXNzPSJvbiI+CiAgICAgICAgPHN2ZyB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwb2x5Z29uIHBvaW50cz0iNyw0IDIwLDEyIDcsMjAiIGZpbGw9ImN1cnJlbnRDb2xvciIgc3Ryb2tlPSJub25lIi8+PC9zdmc+CiAgICAgICAgUGxheTwvYnV0dG9uPgogICAgICA8YnV0dG9uIGlkPSJuYXZNb2RzIj4KICAgICAgICA8c3ZnIHZpZXdCb3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTMgN2w5LTQgOSA0LTkgNC05LTR6Ii8+PHBhdGggZD0iTTMgN3YxMGw5IDQgOS00VjciLz48L3N2Zz4KICAgICAgICBNb2RzPC9idXR0b24+CiAgICAgIDxidXR0b24gaWQ9Im5hdlNldHRpbmdzIj4KICAgICAgICA8c3ZnIHZpZXdCb3g9IjAgMCAyNCAyNCI+PGNpcmNsZSBjeD0iMTIiIGN5PSIxMiIgcj0iMyIvPjxwYXRoIGQ9Ik0xMiAydjNNMTIgMTl2M00yIDEyaDNNMTkgMTJoM001IDVsMiAyTTE3IDE3bDIgMk0xOSA1bC0yIDJNNyAxN2wtMiAyIi8+PC9zdmc+CiAgICAgICAgU2V0dGluZ3M8L2J1dHRvbj4KICAgICAgPGJ1dHRvbiBpZD0ibmF2RG9jIj4KICAgICAgICA8c3ZnIHZpZXdCb3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTQgNWEyIDIgMCAwMTItMmg5bDUgNXYxMWEyIDIgMCAwMS0yIDJINmEyIDIgMCAwMS0yLTJ6Ii8+PHBhdGggZD0iTTggOGg1TTggMTJoOE04IDE2aDYiLz48L3N2Zz4KICAgICAgICBEb2N1bWVudGF0aW9uPC9idXR0b24+CiAgICA8L2Rpdj4KICAgIDxkaXYgY2xhc3M9Imdyb3ciPjwvZGl2PgogICAgPHNwYW4gY2xhc3M9InN0YXR1cyIgaWQ9ImNvbm4iPjxpIGNsYXNzPSJkb3QiIGlkPSJjZCI+PC9pPjxzcGFuIGlkPSJjdCI+Y29ubmVjdGluZ+KApjwvc3Bhbj48L3NwYW4+CiAgICA8c3BhbiBjbGFzcz0ic3RhdHVzIiBpZD0id2hlcmUiPuKAlDwvc3Bhbj4KICAgIDxhIGNsYXNzPSJzdGF0dXMiIGhyZWY9IiMiIGlkPSJvcGVubG9jYWwyIiBzdHlsZT0iZGlzcGxheTpub25lIj5oZWxwZXIncyBvd24gcGFnZTwvYT4KICAgIDxhIGNsYXNzPSJzdGF0dXMiIGhyZWY9IiMiIGlkPSJzdGF5IiBzdHlsZT0iZGlzcGxheTpub25lIj5zdGF5IGhlcmUgaW5zdGVhZDwvYT4KICA8L2hlYWRlcj4KCiAgPCEtLSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gd29ya3NwYWNlIC0tPgogIDxkaXYgY2xhc3M9IndvcmtzcGFjZSI+CiAgICA8IS0tIHBsYXkgLS0+CiAgICA8c2VjdGlvbiBjbGFzcz0icGFuZSBvbiIgaWQ9InZpZXdQbGF5Ij4KICAgICAgPGRpdiBjbGFzcz0iaGVybyI+CiAgICAgICAgPGRpdiBjbGFzcz0icGFkIj4KICAgICAgICAgIDxkaXYgY2xhc3M9ImtpY2tlciIgaWQ9InZpZXdTdWIiPnJlYWwgTWluZWNyYWZ0LCBrZXB0IG5vd2hlcmU8L2Rpdj4KICAgICAgICAgIDxoMSBpZD0idmVyc2lvbkJpZyI+MS4yMS4xMTwvaDE+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJsZWRlIj5UaGUgcmVhbCBKYXZhIGNsaWVudCB3aXRoIEZhYnJpYywgcnVubmluZyBvbiB0aGlzIGNvbXB1dGVyIGZyb20gb25lIGZvbGRlcgogICAgICAgICAgICB1bmRlciA8Y29kZT4vdG1wPC9jb2RlPiB0aGF0IGlzIGRlbGV0ZWQgdGhlIG1vbWVudCB5b3UgY2xvc2UgaXQuIFlvdXIgd29ybGQsIHlvdXIgbW9kcyBhbmQKICAgICAgICAgICAgeW91ciBzZXR0aW5ncyBzdGF5IGluIHRoaXMgYnJvd3NlciDigJQgbm90aGluZyBuZXN0cyBvbiB0aGUgbWFjaGluZS48L2Rpdj4KICAgICAgICAgIDxkaXYgY2xhc3M9ImNoaXBzIj4KICAgICAgICAgICAgPHNwYW4gY2xhc3M9ImNoaXAiIGlkPSJjaGlwUnVubmluZyI+aWRsZTwvc3Bhbj4KICAgICAgICAgICAgPHNwYW4gY2xhc3M9ImNoaXAiIGlkPSJjaGlwTW9kcyI+bm8gbW9kczwvc3Bhbj4KICAgICAgICAgICAgPHNwYW4gY2xhc3M9ImNoaXAiIGlkPSJjaGlwTWVtb3J5Ij4yRzwvc3Bhbj4KICAgICAgICAgICAgPHNwYW4gY2xhc3M9ImNoaXAiIGlkPSJjaGlwQXNzZXRzIj5hc3NldHM6IGRvd25sb2FkPC9zcGFuPgogICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJwaWNrZXIiPgogICAgICAgICAgICA8ZGl2PgogICAgICAgICAgICAgIDxsYWJlbCBmb3I9InZlcnNpb24iPk1pbmVjcmFmdCB2ZXJzaW9uPC9sYWJlbD4KICAgICAgICAgICAgICA8c2VsZWN0IGlkPSJ2ZXJzaW9uIj48L3NlbGVjdD4KICAgICAgICAgICAgPC9kaXY+CiAgICAgICAgICAgIDxkaXY+CiAgICAgICAgICAgICAgPGxhYmVsIGZvcj0ibG9hZGVyIj5Nb2QgbG9hZGVyPC9sYWJlbD4KICAgICAgICAgICAgICA8c2VsZWN0IGlkPSJsb2FkZXIiPgogICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT0ic3RhYmxlIiBzZWxlY3RlZD5GYWJyaWMg4oCUIG5ld2VzdCBzdGFibGU8L29wdGlvbj4KICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ImxhdGVzdCI+RmFicmljIOKAlCBuZXdlc3Q8L29wdGlvbj4KICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ImN1c3RvbSI+RmFicmljIOKAlCBhIHNwZWNpZmljIHZlcnNpb27igKY8L29wdGlvbj4KICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9Im5vbmUiPlZhbmlsbGEg4oCUIG5vIEZhYnJpYzwvb3B0aW9uPgogICAgICAgICAgICAgIDwvc2VsZWN0PgogICAgICAgICAgICAgIDxpbnB1dCBpZD0ibG9hZGVyY3VzdG9tIiBwbGFjZWhvbGRlcj0iZS5nLiAwLjE5LjUiIHN0eWxlPSJkaXNwbGF5Om5vbmU7bWFyZ2luLXRvcDo4cHgiIC8+CiAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8ZGl2PgogICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9InBsYXkiIGlkPSJwbGF5IiBkaXNhYmxlZD7ilrYmbmJzcDsgUExBWTwvYnV0dG9uPgogICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9InN0b3AiIGlkPSJzdG9wIiBzdHlsZT0iZGlzcGxheTpub25lIj7ilqAmbmJzcDsgU1RPUDwvYnV0dG9uPgogICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgIDwvZGl2PgogICAgICA8L2Rpdj4KCiAgICAgIDxkaXYgY2xhc3M9ImZhY3RzIj4KICAgICAgICA8ZGl2IGNsYXNzPSJmYWN0Ij48ZGl2IGNsYXNzPSJrIj5KYXZhPC9kaXY+PGRpdiBjbGFzcz0idiIgaWQ9ImZhY3RKYXZhIj5ub3QgbG9va2VkIGZvciB5ZXQ8L2Rpdj4KICAgICAgICAgIDxkaXYgY2xhc3M9InMiIGlkPSJmYWN0SmF2YVN1YiI+ZmV0Y2hlZCBpbnRvIHRoZSBzYW5kYm94IGlmIHRoaXMgbWFjaGluZSBoYXMgbm9uZTwvZGl2PjwvZGl2PgogICAgICAgIDxkaXYgY2xhc3M9ImZhY3QiPjxkaXYgY2xhc3M9ImsiPlNhbmRib3g8L2Rpdj48ZGl2IGNsYXNzPSJ2IiBpZD0iZmFjdFNhbmRib3giPuKAlDwvZGl2PgogICAgICAgICAgPGRpdiBjbGFzcz0icyIgaWQ9ImZhY3RTYW5kYm94U3ViIj5kZWxldGVkIHdoZW4gdGhlIHNlc3Npb24gZW5kczwvZGl2PjwvZGl2PgogICAgICAgIDxkaXYgY2xhc3M9ImZhY3QiPjxkaXYgY2xhc3M9ImsiPlN0b3JhZ2U8L2Rpdj48ZGl2IGNsYXNzPSJ2IiBpZD0iZmFjdFN0b3JhZ2UiPuKAlDwvZGl2PgogICAgICAgICAgPGRpdiBjbGFzcz0icyIgaWQ9ImZhY3RTdG9yYWdlU3ViIj5pbiB0aGlzIGJyb3dzZXIsIG5ldmVyIHVwbG9hZGVkPC9kaXY+PC9kaXY+CiAgICAgICAgPGRpdiBjbGFzcz0iZmFjdCI+PGRpdiBjbGFzcz0iayI+U2Vzc2lvbnM8L2Rpdj48ZGl2IGNsYXNzPSJ2IiBpZD0iZmFjdFNlc3Npb25zIj5ub25lIHlldDwvZGl2PgogICAgICAgICAgPGRpdiBjbGFzcz0icyI+bW9yZSB0aGFuIG9uZSBjYW4gcnVuIGF0IG9uY2U8L2Rpdj48L2Rpdj4KICAgICAgPC9kaXY+CgogICAgICA8ZGl2IGNsYXNzPSJwYW5lbCIgaWQ9InN0YXR1c0NhcmQiPgogICAgICAgIDxoMj5TdGF0dXM8c3BhbiBjbGFzcz0iZ3JvdyI+PC9zcGFuPjxzcGFuIGNsYXNzPSJoaW50IiBpZD0icGN0Ij48L3NwYW4+PC9oMj4KICAgICAgICA8ZGl2IGNsYXNzPSJ0cmFjayIgaWQ9ImJhciI+PGk+PC9pPjwvZGl2PgogICAgICAgIDxkaXYgY2xhc3M9ImhpbnQiIHN0eWxlPSJtYXJnaW4tdG9wOjExcHgiPgogICAgICAgICAgPHN0cm9uZyBpZD0icGhhc2UiIHN0eWxlPSJjb2xvcjp2YXIoLS1pbmspO2ZvbnQtd2VpZ2h0OjYwMCI+UmVhZHk8L3N0cm9uZz4KICAgICAgICAgIDxzcGFuIGlkPSJpbnN0YW5jZSI+PC9zcGFuPgogICAgICAgIDwvZGl2PgogICAgICAgIDxkaXYgY2xhc3M9ImhpbnQiIGlkPSJuZXRzdGF0Ij48L2Rpdj4KICAgICAgICA8ZGl2IGlkPSJub3RyZWFkeSIgc3R5bGU9ImRpc3BsYXk6bm9uZTttYXJnaW4tdG9wOjE0cHgiPjwvZGl2PgogICAgICAgIDxkaXYgaWQ9Im9mZmxpbmUiIHN0eWxlPSJkaXNwbGF5Om5vbmU7bWFyZ2luLXRvcDoxNHB4Ij4KICAgICAgICAgIDxkaXYgY2xhc3M9ImJhZCIgaWQ9Im9mZmxpbmV0ZXh0Ij48L2Rpdj4KICAgICAgICAgIDxkaXYgaWQ9InNob3J0Y3V0Ym94IiBzdHlsZT0iZGlzcGxheTpub25lIj4KICAgICAgICAgICAgPGRpdiBjbGFzcz0iaGludCIgc3R5bGU9ImNvbG9yOnZhcigtLWluayk7bWFyZ2luLXRvcDoxNHB4Ij4KICAgICAgICAgICAgICA8Yj5tYWNPUzogc3RhcnQgdGhlIGhlbHBlciBmb3IgbWUuPC9iPiBUaGUgU2hvcnRjdXQgZmV0Y2hlcyBpdCBpbnRvIDxjb2RlPi90bXA8L2NvZGU+LAogICAgICAgICAgICAgIHJ1bnMgaXQgdGhlcmUsIGFuZCB3aGVuIHRoZSBzZXNzaW9uIGVuZHMgdGhlIGhlbHBlciBkZWxldGVzIGl0c2VsZiBhbmQgaXRzIGZvbGRlci4KICAgICAgICAgICAgICBOb3RoaW5nIGlzIGluc3RhbGxlZCwgYW5kIG5vdGhpbmcgc3Vydml2ZXMuCiAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8YnV0dG9uIGlkPSJraWNraGVscGVyIiBzdHlsZT0ibWFyZ2luLXRvcDoxMXB4Ij5TdGFydCB0aGUgaGVscGVyIGZvciBtZTwvYnV0dG9uPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJoaW50IiBpZD0ia2lja3MiIHN0eWxlPSJtYXJnaW4tdG9wOjlweCI+PC9kaXY+CiAgICAgICAgICAgIDxkZXRhaWxzIHN0eWxlPSJtYXJnaW4tdG9wOjE0cHgiPgogICAgICAgICAgICAgIDxzdW1tYXJ5Pk9uZS10aW1lOiBtYWtlIHRoYXQgU2hvcnRjdXQgKDQgc3RlcHMsIGFib3V0IGEgbWludXRlKTwvc3VtbWFyeT4KICAgICAgICAgICAgICA8b2wgY2xhc3M9InN0ZXBzIj4KICAgICAgICAgICAgICAgIDxsaT5PcGVuIDxiPlNob3J0Y3V0czwvYj4sIHByZXNzIDxiPis8L2I+LjwvbGk+CiAgICAgICAgICAgICAgICA8bGk+QWRkIHRoZSBhY3Rpb24gPGI+UnVuIFNoZWxsIFNjcmlwdDwvYj4uPC9saT4KICAgICAgICAgICAgICAgIDxsaT5TZXQgPGI+UGFzcyBJbnB1dDwvYj4gdG8gPGI+dG8gc3RkaW48L2I+LCBwYXN0ZSB0aGlzOjwvbGk+CiAgICAgICAgICAgICAgPC9vbD4KICAgICAgICAgICAgICA8Y29kZSBpZD0ic2hlbGxsaW5lIiBzdHlsZT0iZGlzcGxheTpibG9jaztwYWRkaW5nOjExcHg7bWFyZ2luLXRvcDo4cHg7d2hpdGUtc3BhY2U6cHJlLXdyYXA7d29yZC1icmVhazpicmVhay1hbGwiPjwvY29kZT4KICAgICAgICAgICAgICA8YnV0dG9uIGlkPSJjb3B5bGluZSIgc3R5bGU9Im1hcmdpbi10b3A6MTBweCI+Q29weSB0aGUgbGluZTwvYnV0dG9uPgogICAgICAgICAgICAgIDxkaXYgY2xhc3M9ImhpbnQiIGlkPSJjb3B5b2siIHN0eWxlPSJtYXJnaW4tdG9wOjhweCI+PC9kaXY+CiAgICAgICAgICAgICAgPG9sIGNsYXNzPSJzdGVwcyIgc3RhcnQ9IjQiPgogICAgICAgICAgICAgICAgPGxpPk5hbWUgaXQgZXhhY3RseSA8Yj5XZWJNQyBIZWxwZXI8L2I+IGFuZCBzYXZlLgogICAgICAgICAgICAgICAgICA8Yj5TaG9ydGN1dHMg4oaSIFNldHRpbmdzIOKGkiBBZHZhbmNlZCDihpIgQWxsb3cgUnVubmluZyBTY3JpcHRzPC9iPiBvbmNlLjwvbGk+CiAgICAgICAgICAgICAgPC9vbD4KICAgICAgICAgICAgPC9kZXRhaWxzPgogICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8ZGl2IGlkPSJnZXRoZWxwZXIiIHN0eWxlPSJkaXNwbGF5Om5vbmUiPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJoaW50IiBzdHlsZT0iY29sb3I6dmFyKC0taW5rKTttYXJnaW4tdG9wOjE0cHgiPjxiPk9yIGluc3RhbGwgaXQgb25jZS48L2I+PC9kaXY+CiAgICAgICAgICAgIDxvbCBjbGFzcz0ic3RlcHMiPgogICAgICAgICAgICAgIDxsaT48YSBpZD0iemlwZGwiIGhyZWY9ImhlbHBlci93ZWJtYy1oZWxwZXIuemlwIiBkb3dubG9hZD5Eb3dubG9hZCB3ZWJtYy1oZWxwZXIuemlwPC9hPiBhbmQgZG91YmxlLWNsaWNrIGl0LjwvbGk+CiAgICAgICAgICAgICAgPGxpPkRvdWJsZS1jbGljayA8Y29kZT53ZWJtYy1oZWxwZXIuY29tbWFuZDwvY29kZT46IGl0IGluc3RhbGxzIGl0c2VsZiBhbmQgc3RhcnRzIGF0IGV2ZXJ5IGxvZ2luLjwvbGk+CiAgICAgICAgICAgICAgPGxpPkNvbWUgYmFjayBhbmQgcHJlc3MgUExBWS48L2xpPgogICAgICAgICAgICA8L29sPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJoaW50Ij5BbHJlYWR5IHJ1bm5pbmc/IDxhIGhyZWY9IiMiIGlkPSJvcGVubG9jYWwiPk9wZW4gdGhlIGhlbHBlcidzIHBhZ2U8L2E+LjwvZGl2PgogICAgICAgICAgPC9kaXY+CiAgICAgICAgPC9kaXY+CiAgICAgIDwvZGl2PgogICAgPC9zZWN0aW9uPgoKICAgIDwhLS0gbW9kcyAtLT4KICAgIDxzZWN0aW9uIGNsYXNzPSJwYW5lIiBpZD0idmlld01vZHMiPgogICAgICA8ZGl2IGNsYXNzPSJjb2xzIj4KICAgICAgICA8ZGl2IGNsYXNzPSJwYW5lbCI+CiAgICAgICAgICA8aDI+WW91ciBtb2RzPHNwYW4gY2xhc3M9Imdyb3ciPjwvc3Bhbj48c3BhbiBjbGFzcz0idGFnIiBpZD0ibW9kY291bnQiPjwvc3Bhbj48L2gyPgogICAgICAgICAgPGRpdiBjbGFzcz0iZHJvcCIgaWQ9ImRyb3AiPgogICAgICAgICAgICA8Yj5Ecm9wIG1vZCAuamFyIGZpbGVzIGhlcmU8L2I+PGJyIC8+b3IgY2xpY2sgdG8gY2hvb3NlIHRoZW0KICAgICAgICAgICAgPGRpdiBjbGFzcz0iaGludCIgc3R5bGU9Im1hcmdpbi10b3A6OHB4Ij5LZXB0IGluIHRoaXMgYnJvd3NlciwgbmV2ZXIgb24gdGhlIGNvbXB1dGVyLCBhbmQKICAgICAgICAgICAgICBoYW5kZWQgdG8gdGhlIGhlbHBlciBiZWZvcmUgZWFjaCBsYXVuY2guPC9kaXY+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDxpbnB1dCB0eXBlPSJmaWxlIiBpZD0icGlja2VyIiBhY2NlcHQ9Ii5qYXIiIG11bHRpcGxlIHN0eWxlPSJkaXNwbGF5Om5vbmUiIC8+CiAgICAgICAgICA8dWwgY2xhc3M9Im1vZHMiIGlkPSJtb2RsaXN0Ij48L3VsPgogICAgICAgICAgPGRpdiBjbGFzcz0iaGludCIgaWQ9Im1vZGhpbnQiPjwvZGl2PgogICAgICAgIDwvZGl2PgogICAgICAgIDxkaXYgY2xhc3M9InBhbmVsIj4KICAgICAgICAgIDxoMj5Gcm9tIE1vZHJpbnRoPC9oMj4KICAgICAgICAgIDxkaXYgY2xhc3M9InJvdyI+CiAgICAgICAgICAgIDxpbnB1dCBpZD0ic2VhcmNoIiBwbGFjZWhvbGRlcj0ic29kaXVtLCBsaXRoaXVtLCBpcmlz4oCmIiAvPgogICAgICAgICAgICA8YnV0dG9uIGNsYXNzPSJmaXhlZCIgaWQ9ImRvYnNlYXJjaCI+U2VhcmNoPC9idXR0b24+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDx1bCBjbGFzcz0icmVzdWx0cyIgaWQ9InJlc3VsdHMiPjwvdWw+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJoaW50IiBpZD0ic2VhcmNoaGludCIgc3R5bGU9Im1hcmdpbi10b3A6MTJweCI+U2VhcmNoZWQgYnkgdGhlIGhlbHBlciwgc28gaXQgd29ya3MKICAgICAgICAgICAgZXZlbiBvbiBhIG5ldHdvcmsgd2hlcmUgdGhpcyBicm93c2VyIGNhbm5vdCByZWFjaCBNb2RyaW50aC48L2Rpdj4KICAgICAgICA8L2Rpdj4KICAgICAgPC9kaXY+CiAgICA8L3NlY3Rpb24+CgogICAgPCEtLSBzZXR0aW5ncyAtLT4KICAgIDxzZWN0aW9uIGNsYXNzPSJwYW5lIiBpZD0idmlld1NldHRpbmdzIj4KICAgICAgPGRpdiBjbGFzcz0iY29scyI+CiAgICAgICAgPGRpdiBjbGFzcz0icGFuZWwiPgogICAgICAgICAgPGgyPlRoZSBnYW1lPC9oMj4KICAgICAgICAgIDxkaXYgY2xhc3M9ImNvbHMiPgogICAgICAgICAgICA8ZGl2PjxsYWJlbCBmb3I9InVzZXJuYW1lIj5Vc2VybmFtZSAob2ZmbGluZSk8L2xhYmVsPgogICAgICAgICAgICAgIDxpbnB1dCBpZD0idXNlcm5hbWUiIHZhbHVlPSJQbGF5ZXIiIG1heGxlbmd0aD0iMTYiIC8+PC9kaXY+CiAgICAgICAgICAgIDxkaXY+PGxhYmVsIGZvcj0ibWVtb3J5Ij5NZW1vcnk8L2xhYmVsPgogICAgICAgICAgICAgIDxpbnB1dCBpZD0ibWVtb3J5IiB2YWx1ZT0iMkciIC8+PC9kaXY+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDxkaXYgc3R5bGU9Im1hcmdpbi10b3A6MTRweCI+PGxhYmVsIGZvcj0iYXNzZXRzIj5Tb3VuZHMgYW5kIHRleHR1cmVzPC9sYWJlbD4KICAgICAgICAgICAgPHNlbGVjdCBpZD0iYXNzZXRzIj4KICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPSIxIiBzZWxlY3RlZD5Eb3dubG9hZCB0aGVtICh+NDMwIE1CLCBvbmNlIGEgc2Vzc2lvbik8L29wdGlvbj4KICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPSIwIj5Ta2lwIOKAlCBzaWxlbnQgYW5kIHRleHR1cmVsZXNzLCBidXQgZmFzdDwvb3B0aW9uPjwvc2VsZWN0PjwvZGl2PgogICAgICAgICAgPGxhYmVsIGNsYXNzPSJjaGVjayIgc3R5bGU9Im1hcmdpbi10b3A6MTZweCI+CiAgICAgICAgICAgIDxpbnB1dCB0eXBlPSJjaGVja2JveCIgaWQ9InJlc3RvcmUiIGNoZWNrZWQgLz4KICAgICAgICAgICAgPHNwYW4+UHV0IHRoaXMgYnJvd3NlcidzIGxhc3Qgc2Vzc2lvbiBiYWNrIGJlZm9yZSBwbGF5aW5nCiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9ImhpbnQiIHN0eWxlPSJkaXNwbGF5OmJsb2NrIj5Xb3JsZHMsIG9wdGlvbnMgYW5kIHNjcmVlbnNob3RzIGxpdmUgaW4gdGhpcwogICAgICAgICAgICAgICAgYnJvd3Nlci4gTm90aGluZyBpcyB1cGxvYWRlZC48L3NwYW4+PC9zcGFuPgogICAgICAgICAgPC9sYWJlbD4KICAgICAgICA8L2Rpdj4KCiAgICAgICAgPGRpdiBjbGFzcz0icGFuZWwiPgogICAgICAgICAgPGgyPkFwcGVhcmFuY2U8L2gyPgogICAgICAgICAgPGRpdiBjbGFzcz0iY29scyI+CiAgICAgICAgICAgIDxkaXY+PGxhYmVsIGZvcj0iZnhTZWxlY3QiPlNjcmVlbiBlZmZlY3Q8L2xhYmVsPgogICAgICAgICAgICAgIDxzZWxlY3QgaWQ9ImZ4U2VsZWN0Ij4KICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ImZ4LWdsb3ciPkRlcHRoIOKAlCBhIHNvZnQgdmlnbmV0dGU8L29wdGlvbj4KICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ImZ4LWdyaWQiPkdyaWQg4oCUIGEgZmFpbnQgbGF0dGljZTwvb3B0aW9uPgogICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT0iZngtc2NhbiI+U2NhbmxpbmVzIOKAlCBhIHNsb3cgc3dlZXA8L29wdGlvbj4KICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9Im5vbmUiPk5vbmUg4oCUIGZsYXQgYW5kIGZhc3Q8L29wdGlvbj4KICAgICAgICAgICAgICA8L3NlbGVjdD48L2Rpdj4KICAgICAgICAgICAgPGRpdj48bGFiZWwgZm9yPSJtb3Rpb25TZWxlY3QiPkJhY2tncm91bmQ8L2xhYmVsPgogICAgICAgICAgICAgIDxzZWxlY3QgaWQ9Im1vdGlvblNlbGVjdCI+CiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPSJmb2xsb3ciPkZvbGxvd3MgdGhlIHBvaW50ZXI8L29wdGlvbj4KICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9InN0aWxsIj5TdGlsbDwvb3B0aW9uPgogICAgICAgICAgICAgIDwvc2VsZWN0PjwvZGl2PgogICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJoaW50IiBzdHlsZT0ibWFyZ2luLXRvcDoxM3B4Ij5UaGUgb3JiIGZvbGxvd3MgdGhlIHBvaW50ZXIgYXMgYSBjb21wb3NpdGVkIG1vdmUsCiAgICAgICAgICAgIG9uY2UgcGVyIGFuaW1hdGlvbiBmcmFtZS4gVHVybiBpdCBvZmYgb24gYSBtYWNoaW5lIHRoYXQgd291bGQgcmF0aGVyIGhhdmUgdGhlIGN5Y2xlcy48L2Rpdj4KICAgICAgICA8L2Rpdj4KICAgICAgPC9kaXY+CgogICAgICA8ZGl2IGNsYXNzPSJwYW5lbCI+CiAgICAgICAgPGgyPklmIGEgbmV0d29yayBibG9ja3MgdGhpbmdzPC9oMj4KICAgICAgICA8cCBjbGFzcz0iaGludCIgc3R5bGU9ImNvbG9yOnZhcigtLWluayk7bWFyZ2luOjAgMCAxNHB4Ij4KICAgICAgICAgIE1vc3QgcGVvcGxlIGNhbiBpZ25vcmUgdGhpcyBwYW5lbC4gSXQgaXMgZm9yIGEgc2Nob29sIG9yIHdvcmtwbGFjZSBuZXR3b3JrIHRoYXQgYmxvY2tzCiAgICAgICAgICA8Yj5Nb2phbmc8L2I+IChzbyB0aGUgZ2FtZSB3aWxsIG5vdCBkb3dubG9hZCkgb3IgYmxvY2tzIDxiPmdhbWUgcG9ydHM8L2I+IChzbyB5b3UgY2Fubm90IGpvaW4KICAgICAgICAgIGEgc2VydmVyKS4KICAgICAgICA8L3A+CiAgICAgICAgPGRpdiBjbGFzcz0iY29sczMiPgogICAgICAgICAgPGRpdj48bGFiZWwgZm9yPSJyZWxheU1vZGUiPlJlbGF5PC9sYWJlbD4KICAgICAgICAgICAgPHNlbGVjdCBpZD0icmVsYXlNb2RlIj4KICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPSJhdXRvIiBzZWxlY3RlZD5BdXRvbWF0aWMg4oCUIHVzZSB0aGUgYnVpbHQtaW4gb25lIGlmIHRoZXJlIGlzIG9uZTwvb3B0aW9uPgogICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9Im9mZiI+TmV2ZXIg4oCUIGFsd2F5cyBjb25uZWN0IGRpcmVjdGx5PC9vcHRpb24+CiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT0iY3VzdG9tIj5NeSBvd24gcmVsYXnigKY8L29wdGlvbj4KICAgICAgICAgICAgPC9zZWxlY3Q+PC9kaXY+CiAgICAgICAgICA8ZGl2PjxsYWJlbCBmb3I9InNlcnZlciI+Sm9pbiB0aGlzIHNlcnZlciBzdHJhaWdodCBhd2F5IChvcHRpb25hbCk8L2xhYmVsPgogICAgICAgICAgICA8aW5wdXQgaWQ9InNlcnZlciIgcGxhY2Vob2xkZXI9InBsYXkuZXhhbXBsZS5uZXQ6MjU1NjUiIC8+PC9kaXY+CiAgICAgICAgICA8ZGl2PjxsYWJlbD4mbmJzcDs8L2xhYmVsPgogICAgICAgICAgICA8YnV0dG9uIGlkPSJyZWxheVRlc3QiIHN0eWxlPSJ3aWR0aDoxMDAlIj5UZXN0IHRoZSByZWxheTwvYnV0dG9uPjwvZGl2PgogICAgICAgIDwvZGl2PgogICAgICAgIDxkaXYgaWQ9InJlbGF5Q3VzdG9tUm93IiBzdHlsZT0iZGlzcGxheTpub25lO21hcmdpbi10b3A6MTRweCI+CiAgICAgICAgICA8bGFiZWwgZm9yPSJyZWxheSI+WW91ciByZWxheSdzIGFkZHJlc3M8L2xhYmVsPgogICAgICAgICAgPGlucHV0IGlkPSJyZWxheSIgcGxhY2Vob2xkZXI9Imh0dHBzOi8vd2VibWMtcmVsYXkueW91LndvcmtlcnMuZGV2IiAvPgogICAgICAgIDwvZGl2PgogICAgICAgIDxkaXYgY2xhc3M9ImhpbnQiIGlkPSJyZWxheUluVXNlIiBzdHlsZT0ibWFyZ2luLXRvcDoxMXB4Ij48L2Rpdj4KICAgICAgICA8ZGl2IGNsYXNzPSJoaW50IiBpZD0icmVsYXlTdGF0ZSIgc3R5bGU9Im1hcmdpbi10b3A6NnB4Ij48L2Rpdj4KICAgICAgICA8ZGl2IGNsYXNzPSJoaW50IiBzdHlsZT0ibWFyZ2luLXRvcDoxMHB4Ij4KICAgICAgICAgIDxiPk1vc3QgcGVvcGxlIG5ldmVyIHRvdWNoIHRoaXMuPC9iPiBPbiBBdXRvbWF0aWMgdGhlIGxhdW5jaGVyIHVzZXMgaXRzIG93biByZWxheSB3aGVuCiAgICAgICAgICB5b3VyIG5ldHdvcmsgbmVlZHMgb25lIGFuZCBjb25uZWN0cyBkaXJlY3RseSB3aGVuIGl0IGRvZXMgbm90IOKAlCBhbmQgYSByZWxheSBzZXJ2ZXMKICAgICAgICAgIGRvd25sb2FkcywgdGhlIGdhbWUncyBvd24gY29ubmVjdGlvbnMgYW5kIHRoZSBzZXJ2ZXIgYmVsb3csIHNvIGl0IGlzIG9uZSBzZXR0aW5nLCBub3QKICAgICAgICAgIHRocmVlLiBDaG9vc2UgPGI+TXkgb3duIHJlbGF5PC9iPiB0byB1c2UgeW91cnMgaW5zdGVhZDogZGVwbG95IGl0IG9uY2Ugd2l0aAogICAgICAgICAgPGNvZGU+bnB4IHdyYW5nbGVyIGRlcGxveSByZWxheS9yZWxheS5qcyAtLW5hbWUgd2VibWMtcmVsYXkgLS1jb21wYXRpYmlsaXR5LWRhdGUgMjAyNi0wMS0wMTwvY29kZT4sCiAgICAgICAgICBwYXN0ZSB0aGUgVVJMLCBhbmQgdmVyaWZ5IGl0IGZyb20gdGhlIGJsb2NrZWQgbmV0d29yayB3aXRoCiAgICAgICAgICA8Y29kZT5weXRob24zIHJlbGF5L3Rlc3QtcmVsYXkucHkgWU9VUi1VUkw8L2NvZGU+LgogICAgICAgIDwvZGl2PgogICAgICAgIDxsYWJlbCBjbGFzcz0iY2hlY2siIHN0eWxlPSJtYXJnaW4tdG9wOjE2cHgiPgogICAgICAgICAgPGlucHV0IHR5cGU9ImNoZWNrYm94IiBpZD0icHJveHlBbGwiIC8+CiAgICAgICAgICA8c3Bhbj5TZW5kIHRoZSBnYW1lIHRocm91Z2ggdGhlIHJlbGF5IGFzIHdlbGwKICAgICAgICAgICAgPHNwYW4gY2xhc3M9ImhpbnQiIHN0eWxlPSJkaXNwbGF5OmJsb2NrIj5UaWNrIHRoaXMgaWYgeW91IGNhbiBkb3dubG9hZCB0aGUgZ2FtZSBidXQgY2Fubm90CiAgICAgICAgICAgICAgam9pbiBhIHNlcnZlcjogdGhlIGdhbWUncyBvd24gY29ubmVjdGlvbnMgdGhlbiB0cmF2ZWwgaW5zaWRlIHRoZSByZWxheSB0b28uPC9zcGFuPjwvc3Bhbj4KICAgICAgICA8L2xhYmVsPgogICAgICAgIDxkZXRhaWxzIHN0eWxlPSJtYXJnaW4tdG9wOjE4cHgiPgogICAgICAgICAgPHN1bW1hcnk+QWR2YW5jZWQ6IHJlc3RyaWN0ZWQgbW9kZTwvc3VtbWFyeT4KICAgICAgICAgIDxkaXYgY2xhc3M9ImhpbnQiIHN0eWxlPSJtYXJnaW4tdG9wOjExcHgiPgogICAgICAgICAgICA8bGFiZWwgY2xhc3M9ImNoZWNrIiBzdHlsZT0ibWFyZ2luLWJvdHRvbTo5cHgiPgogICAgICAgICAgICAgIDxpbnB1dCB0eXBlPSJjaGVja2JveCIgaWQ9InJlc3RyaWN0ZWQiIC8+CiAgICAgICAgICAgICAgPHNwYW4+QnJpbmcgb3VyIG93biBKYXZhLCBhbmQgbG9vayBub3doZXJlIGVsc2Ugb24gdGhpcyBtYWNoaW5lPC9zcGFuPgogICAgICAgICAgICA8L2xhYmVsPgogICAgICAgICAgICBJdCBoZWxwcyB3aGVuIEphdmEgPGI+aXMgbm90IGluc3RhbGxlZDwvYj4sIG9yIHRoZSBtYWNoaW5lJ3MgSmF2YSBpcyA8Yj5ibG9ja2VkPC9iPjogYQogICAgICAgICAgICBydW50aW1lIGlzIGZldGNoZWQgaW50byB0aGUgc2Vzc2lvbidzIGZvbGRlciBhbmQgZGllcyB3aXRoIGl0LgogICAgICAgICAgICA8YnI+PGJyPgogICAgICAgICAgICBJdCBkb2VzIDxiPm5vdDwvYj4gZ2V0IGFyb3VuZCBhIHBvbGljeSB0aGF0IGJsb2NrcyB1bmtub3duIHByb2dyYW1zIChBcHBMb2NrZXIsIFdEQUMsIE1ETSwKICAgICAgICAgICAgc2NyZWVuLXRpbWUgb3IgcGFyZW50YWwgY29udHJvbHMpLiBUaG9zZSBhcmUgZW5mb3JjZWQgYnkgdGhlIG9wZXJhdGluZyBzeXN0ZW0sIGFuZCBub3RoaW5nCiAgICAgICAgICAgIGhlcmUg4oCUIGFuZCBub3RoaW5nIGFueSBvdGhlciBsYXVuY2hlciBjb3VsZCBkbyDigJQgY2hhbmdlcyB0aGF0LiBPbiBzdWNoIGEgbWFjaGluZSB0aGUgb25seQogICAgICAgICAgICB0aGluZyB0aGF0IHJ1bnMgaXMgYSBsYXVuY2hlciB0aGF0IGluc3RhbGxzIG5vdGhpbmcgYXQgYWxsOiB0aGUgYnJvd3NlciB0aWVyLgogICAgICAgICAgPC9kaXY+CiAgICAgICAgPC9kZXRhaWxzPgogICAgICA8L2Rpdj4KCiAgICAgIDxkaXYgY2xhc3M9InBhbmVsIj4KICAgICAgICA8aDI+VGhlIGhlbHBlcjwvaDI+CiAgICAgICAgPGRpdiBjbGFzcz0icm93Ij4KICAgICAgICAgIDxpbnB1dCBpZD0iaGVscGVyIiBwbGFjZWhvbGRlcj0iaHR0cDovLzEyNy4wLjAuMTo3NjQ1IiAvPgogICAgICAgICAgPGJ1dHRvbiBjbGFzcz0iZml4ZWQiIGlkPSJjb25uZWN0Ij5Db25uZWN0PC9idXR0b24+CiAgICAgICAgPC9kaXY+CiAgICAgICAgPGRpdiBjbGFzcz0iaGludCIgaWQ9ImNvbm5oaW50IiBzdHlsZT0ibWFyZ2luLXRvcDoxMXB4Ij48L2Rpdj4KICAgICAgICA8ZGl2IHN0eWxlPSJtYXJnaW4tdG9wOjE2cHg7ZGlzcGxheTpmbGV4O2dhcDoxMXB4O2ZsZXgtd3JhcDp3cmFwIj4KICAgICAgICAgIDxidXR0b24gaWQ9ImNvcHlkaWFnIj5Db3B5IGRpYWdub3N0aWNzPC9idXR0b24+CiAgICAgICAgICA8YnV0dG9uIGlkPSJoZWxwIj5Ib3cgdGhpcyB3b3JrczwvYnV0dG9uPgogICAgICAgIDwvZGl2PgogICAgICAgIDxkaXYgY2xhc3M9ImhpbnQiIGlkPSJkaWFnc3RhdGUiIHN0eWxlPSJtYXJnaW4tdG9wOjEwcHgiPjwvZGl2PgogICAgICA8L2Rpdj4KICAgIDwvc2VjdGlvbj4KCiAgICA8IS0tIGRvY3VtZW50YXRpb24gLS0+CiAgICA8c2VjdGlvbiBjbGFzcz0icGFuZSIgaWQ9InZpZXdEb2MiPgogICAgICA8ZGl2IGNsYXNzPSJwYW5lbCBkb2MiPgogICAgICAgIDxoMj5Eb2N1bWVudGF0aW9uPC9oMj4KICAgICAgICA8cCBjbGFzcz0ibGVhZCI+V2ViTUMgaXMgYSBNaW5lY3JhZnQgbGF1bmNoZXIgd2hvc2UgaW50ZXJmYWNlIGlzIGEgd2ViIHBhZ2UsIGFuZCB3aG9zZSBwcm9taXNlCiAgICAgICAgICBpcyB0aGF0IHRoZSBjb21wdXRlciBpdCBydW5zIG9uIGlzIGJvcnJvd2VkIHJhdGhlciB0aGFuIHVzZWQ6IHRoZSBnYW1lLCB0aGUgSmF2YSBydW50aW1lIGFuZAogICAgICAgICAgdGhlIGhlbHBlciBhcmUgYWxsIGRlbGV0ZWQgd2hlbiB0aGUgc2Vzc2lvbiBlbmRzLjwvcD4KICAgICAgICA8ZGl2IGNsYXNzPSJ0b2MiPgogICAgICAgICAgPGEgaHJlZj0iI2QxIj5XaHkgdGhlIHBhZ2UgY2Fubm90IGxhdW5jaCBhbnl0aGluZzwvYT4KICAgICAgICAgIDxhIGhyZWY9IiNkMiI+V2hhdCB0aGUgaGVscGVyIGRvZXMsIHN0ZXAgYnkgc3RlcDwvYT4KICAgICAgICAgIDxhIGhyZWY9IiNkMyI+V2hhdCBpcyBsZWZ0IGFmdGVyd2FyZHM8L2E+CiAgICAgICAgICA8YSBocmVmPSIjZDQiPldoZXJlIHlvdXIgd29ybGQgbGl2ZXM8L2E+CiAgICAgICAgICA8YSBocmVmPSIjZDUiPk5ldHdvcmtzIHRoYXQgYmxvY2sgdGhpbmdzPC9hPgogICAgICAgICAgPGEgaHJlZj0iI2Q2Ij5Nb3JlIHRoYW4gb25lIHdpbmRvdzwvYT4KICAgICAgICAgIDxhIGhyZWY9IiNkNyI+TW9kIGxvYWRlcnM8L2E+CiAgICAgICAgICA8YSBocmVmPSIjZDgiPldoZW4gc29tZXRoaW5nIGdvZXMgd3Jvbmc8L2E+CiAgICAgICAgPC9kaXY+CgogICAgICAgIDxoMyBpZD0iZDEiPldoeSB0aGUgcGFnZSBjYW5ub3QgbGF1bmNoIGFueXRoaW5nPC9oMz4KICAgICAgICA8cD5UaGlzIGlzIHRoZSBmaXJzdCB0aGluZyB0byB1bmRlcnN0YW5kLCBiZWNhdXNlIGV2ZXJ5dGhpbmcgZWxzZSBmb2xsb3dzIGZyb20gaXQuIEEgd2ViIHBhZ2UKICAgICAgICAgIGNhbm5vdCBzdGFydCBhIHByb2dyYW0sIHJlYWQgYSBmaWxlLCBvciBsb29rIGluc2lkZSA8Y29kZT4vdG1wPC9jb2RlPi4gVGhlcmUgaXMgbm8gQVBJIGZvcgogICAgICAgICAgaXQ6IFdlYkFzc2VtYmx5IGFuZCBhbiBpbi1wYWdlIEpWTSBhcmUgc2FuZGJveGVkLCA8Y29kZT5maWxlOi8vPC9jb2RlPiBnaXZlcyBhbiBvcGFxdWUgb3JpZ2luCiAgICAgICAgICB0aGF0IGNhbm5vdCBldmVuIHJlYWNoIDxjb2RlPjEyNy4wLjAuMTwvY29kZT4sIGEgY3VzdG9tIHByb3RvY29sIGhhbmRsZXIgYW5kIGEgYnJvd3NlcgogICAgICAgICAgZXh0ZW5zaW9uIGJvdGggbmVlZCBhbiBpbnN0YWxsZXIgZmlyc3QsIGFuZCBhIHBhZ2UgaGFzIG5ldmVyIGJlZW4gYWxsb3dlZCB0byBydW4gYSBmaWxlIGl0CiAgICAgICAgICBkb3dubG9hZGVkLjwvcD4KICAgICAgICA8cD5UaGF0IGlzIG5vdCBhbiBvdmVyc2lnaHQuIFRoZSBmZWF0dXJlcyB0aGF0IG9uY2UgZGlkIGFsbG93IGl0IOKAlCBBY3RpdmVYIGNvbnRyb2xzLCBKYXZhCiAgICAgICAgICBhcHBsZXRzLCBOZXRzY2FwZSBwbHVnaW5zLCBGbGFzaCDigJQgd2VyZSBhbGwgcmVtb3ZlZCBwcmVjaXNlbHkgYmVjYXVzZSBhIHBhZ2UgYmVpbmcgYWJsZSB0byBydW4KICAgICAgICAgIG5hdGl2ZSBjb2RlIGlzIGEgc2VjdXJpdHkgaG9sZSByYXRoZXIgdGhhbiBhIGZlYXR1cmUuPC9wPgogICAgICAgIDxwPkxvY2FsIE5ldHdvcmsgQWNjZXNzLCBpbiBjdXJyZW50IENocm9taXVtLCBtYWtlcyB0aGUgYm91bmRhcnkgZXhwbGljaXQuIE1lYXN1cmVkIGZyb20gYQogICAgICAgICAgcHVibGljIHBhZ2UgKHRoaXMgbGF1bmNoZXIgb24gR2l0SHViIFBhZ2VzKSB0byB0aGUgaGVscGVyIG9uIDxjb2RlPjEyNy4wLjAuMTwvY29kZT46PC9wPgogICAgICAgIDx0YWJsZT4KICAgICAgICAgIDx0cj48dGg+Um91dGU8L3RoPjx0aD5SZXN1bHQ8L3RoPjwvdHI+CiAgICAgICAgICA8dHI+PHRkPjxjb2RlPmZldGNoKCk8L2NvZGU+PC90ZD48dGQ+UmVmdXNlZCwgb3IgYSBwZXJtaXNzaW9uIHByb21wdCDigJQg4oCcUGVybWlzc2lvbiB3YXMgZGVuaWVkCiAgICAgICAgICAgIGZvciB0aGlzIHJlcXVlc3QgdG8gYWNjZXNzIHRoZSA8Y29kZT5sb29wYmFjazwvY29kZT4gYWRkcmVzcyBzcGFjZS7igJ08L3RkPjwvdHI+CiAgICAgICAgICA8dHI+PHRkPmFuIDxjb2RlPiZsdDtpZnJhbWUmZ3Q7PC9jb2RlPjwvdGQ+PHRkPlJlZnVzZWQ6IHRoZSBmcmFtZSB0cmVlIGNvbWVzIGJhY2sgd2l0aCBubwogICAgICAgICAgICBjaGlsZCBmcmFtZSBhdCBhbGwuIEEgYmxvY2tlZCBmcmFtZSBzdGlsbCBmaXJlcyA8Y29kZT5sb2FkPC9jb2RlPiwgc28gdGhhdCBldmVudCBwcm92ZXMKICAgICAgICAgICAgbm90aGluZy48L3RkPjwvdHI+CiAgICAgICAgICA8dHI+PHRkPmEgdG9wLWxldmVsIG5hdmlnYXRpb248L3RkPjx0ZD48Yj5BbGxvd2VkPC9iPiwgd2l0aCBubyBwcm9tcHQgYW5kIG5vIGNvbnNvbGUKICAgICAgICAgICAgZXJyb3IuPC90ZD48L3RyPgogICAgICAgIDwvdGFibGU+CiAgICAgICAgPHA+VHdvIHRoaW5ncyBhcmUgd29ydGggdGVsbGluZyBhbiBhZG1pbmlzdHJhdG9yLCBiZWNhdXNlIHRoZXkgZGVjaWRlIHdoZXRoZXIgYW55IG9mIHRoaXMKICAgICAgICAgIHdvcmtzIG9uIGEgbWFuYWdlZCBtYWNoaW5lOiB0aGUgcGVybWlzc2lvbiBpcyBjYWxsZWQgPGI+TG9jYWwgTmV0d29yayBBY2Nlc3M8L2I+IGluCiAgICAgICAgICBDaHJvbWl1beKAmXMgc2l0ZSBzZXR0aW5ncywgYW5kIG9uZSBwb2xpY3kgY2FuIHJlZnVzZSBpdCBvdXRyaWdodCDigJQKICAgICAgICAgIDxjb2RlPkxvY2FsTmV0d29ya0FjY2Vzc0Jsb2NrZWRGb3JVcmxzPC9jb2RlPi4gV2hlcmUgdGhhdCBwb2xpY3kgaXMgc2V0LCBub3RoaW5nIG9uIGEgcGFnZQogICAgICAgICAgY2FuIHJlYWNoIGEgbG9jYWwgaGVscGVyIGF0IGFsbCwgYW5kIHRoZSBoZWxwZXIncyBvd24gcGFnZSAod2hpY2ggaXMgdGhlIHNhbWUgb3JpZ2luIGFzIHRoZQogICAgICAgICAgaGVscGVyKSBpcyB0aGUgb25seSByb3V0ZSBsZWZ0LjwvcD4KICAgICAgICA8cD5UaGF0IGxhc3Qgcm93IGlzIHdoeSB0aGlzIGxhdW5jaGVyIGJlaGF2ZXMgdGhlIHdheSBpdCBkb2VzOiB0aGUgR2l0SHViIHBhZ2UgY2Fubm90CiAgICAgICAgICA8aT5kcml2ZTwvaT4gdGhlIGhlbHBlciwgc28gaXQgaGFuZHMgdGhlIHRhYiB0byB0aGUgaGVscGVyJ3Mgb3duIHBhZ2UgdGhlIG1vbWVudCBpdCBsb2FkcywKICAgICAgICAgIHdoaWNoIGlzIGFsbG93ZWQgdG8gdGFsayB0byBpdCDigJQgc2FtZSBvcmlnaW4sIG5vIHByb21wdC48L3A+CgogICAgICAgIDxoMyBpZD0iZDIiPldoYXQgdGhlIGhlbHBlciBkb2VzLCBzdGVwIGJ5IHN0ZXA8L2gzPgogICAgICAgIDxvbD4KICAgICAgICAgIDxsaT48Yj5PbmUgc3RhZ2luZyBkaXJlY3RvcnkuPC9iPiBFdmVyeXRoaW5nIGdvZXMgdGhlcmUgYW5kIG5vd2hlcmUgZWxzZTogYSBQeXRob24gcnVudGltZSBpZgogICAgICAgICAgICB0aGUgbWFjaGluZSBoYXMgbm9uZSwgdGhlIGhlbHBlciwgYW5kIGxhdGVyIHRoZSBnYW1lLjwvbGk+CiAgICAgICAgICA8bGk+PGI+QSBKYXZhIHJ1bnRpbWUsIGZvdW5kIG9yIGZldGNoZWQuPC9iPiBOb3RoaW5nIG5lZWRzIHRvIGJlIGluc3RhbGxlZDsgaWYgdGhlIG1hY2hpbmUgaGFzCiAgICAgICAgICAgIG5vIHVzYWJsZSBKYXZhLCBhIEpSRSBpcyBkb3dubG9hZGVkIGludG8gdGhlIHN0YWdpbmcgZGlyZWN0b3J5IGFuZCBkaWVzIHdpdGggaXQuPC9saT4KICAgICAgICAgIDxsaT48Yj5UaGUgZ2FtZSwgZnJvbSBNb2phbmcuPC9iPiBDbGllbnQsIHRoZSB2ZXJzaW9uJ3Mgb3duIGxpYnJhcmllcyBhbmQgdGhlIGFzc2V0cywgZXZlcnkKICAgICAgICAgICAgZmlsZSB2ZXJpZmllZCBhZ2FpbnN0IGl0cyBwdWJsaXNoZWQgU0hBLTEsIGRvd25sb2FkZWQgaW4gcGFyYWxsZWwgaW50byB0aGUgc2FuZGJveC48L2xpPgogICAgICAgICAgPGxpPjxiPlRoZSBsb2FkZXIgYW5kIHlvdXIgbW9kcy48L2I+IEZhYnJpYydzIHByb2ZpbGUgZnJvbSBGYWJyaWMncyBvd24gbWV0YWRhdGE7IHlvdXIgamFycwogICAgICAgICAgICBmcm9tIHRoaXMgYnJvd3NlcidzIHN0b3JhZ2UsIG9yIGZldGNoZWQgZnJvbSBNb2RyaW50aCBmb3IgdGhlIHZlcnNpb24geW91IHBpY2tlZC48L2xpPgogICAgICAgICAgPGxpPjxiPlRoZSByZWFsIGNsaWVudCBzdGFydHMuPC9iPiBBbiBvcmRpbmFyeQogICAgICAgICAgICA8Y29kZT5qYXZhIOKApktub3RDbGllbnQ8L2NvZGU+IHByb2Nlc3MsIHdpdGggYSBub3JtYWwgd2luZG93LCBleGFjdGx5IGFzIGFueSBsYXVuY2hlciB3b3VsZAogICAgICAgICAgICBydW4gaXQuPC9saT4KICAgICAgICAgIDxsaT48Yj5Zb3Ugd2F0Y2ggaXQgaGVyZS48L2I+IFRoZSBjbGllbnQncyBvd24gb3V0cHV0LCBzdHJlYW1lZCBsaXZlIGludG8gdGhlIGRyYXdlciBhdCB0aGUKICAgICAgICAgICAgYm90dG9tIG9mIHRoZSB3aW5kb3cg4oCUIHdoaWNoIGlzIHdoeSBhIGNyYXNoIGlzIHJlYWRhYmxlIGluc3RlYWQgb2YgbXlzdGVyaW91cy48L2xpPgogICAgICAgICAgPGxpPjxiPldoZW4gaXQgZXhpdHM8L2I+IOKAlCBjbG9zZWQsIGNyYXNoZWQsIG9yIHN0b3BwZWQgZnJvbSBoZXJlIOKAlCB0aGUgaGVscGVyIGNvbGxlY3RzIHNhdmVzLAogICAgICAgICAgICBsb2dzLCBzY3JlZW5zaG90cywgY29uZmlndXJhdGlvbiwgY3Jhc2ggcmVwb3J0cyBhbmQgaXRzIG93biBhY2NvdW50IG9mIHRoZSBzZXNzaW9uIGludG8gb25lCiAgICAgICAgICAgIHppcC48L2xpPgogICAgICAgICAgPGxpPjxiPlRoaXMgcGFnZSB0YWtlcyB0aGF0IHppcDwvYj4gaW50byBicm93c2VyIHN0b3JhZ2UsIGFuZCB0ZWxscyB0aGUgaGVscGVyIHRvIGRlbGV0ZSB0aGUKICAgICAgICAgICAgc2FuZGJveC4gTm9ib2R5IGhhcyB0byBwcmVzcyBhbnl0aGluZzogc2F2aW5nIGlzIGF1dG9tYXRpYy48L2xpPgogICAgICAgICAgPGxpPjxiPk5vdGhpbmcgaXMgbGVmdCBmb3IgeW91IHRvIHRpZHkgdXAuPC9iPiBJZiB0aGUgcGFnZSBuZXZlciBjb21lcyBiYWNrIHRoZSBoZWxwZXIKICAgICAgICAgICAgZGVsZXRlcyB0aGUgc2FuZGJveCBpdHNlbGYgYWZ0ZXIgYSBkZWFkbGluZTsgaWYgdGhlIGhlbHBlciBpcyBraWxsZWQgb3V0cmlnaHQgdGhlIG5leHQgb25lCiAgICAgICAgICAgIGZpbmRzIHRoZSBsZWZ0b3ZlciBieSBpdHMgb3duZXIgZmlsZTsgaWYgdGhlIG1hY2hpbmUgcmVib290cyB0aGUgT1MgY2xlYXJzIGl0cyBvd24gdGVtcAogICAgICAgICAgICBkaXJlY3RvcnkuPC9saT4KICAgICAgICA8L29sPgoKICAgICAgICA8aDMgaWQ9ImQzIj5XaGF0IGlzIGxlZnQgYWZ0ZXJ3YXJkczwvaDM+CiAgICAgICAgPHRhYmxlPgogICAgICAgICAgPHRyPjx0aD5Ib3cgeW91IHN0YXJ0IGl0PC90aD48dGg+V2hhdCByZW1haW5zIHdoZW4gdGhlIHNlc3Npb24gZW5kczwvdGg+PC90cj4KICAgICAgICAgIDx0cj48dGQ+PGI+VHJhbnNpZW50PC9iPiDigJQgdGhlIG1hY09TIFNob3J0Y3V0LCBvciA8Y29kZT5XRUJNQ19UUkFOU0lFTlQ9MTwvY29kZT48L3RkPgogICAgICAgICAgICA8dGQ+PGI+Tm90aGluZyBhdCBhbGwuPC9iPiBUaGUgc3RhZ2luZyBkaXJlY3RvcnkgZ29lcyB0b286IHRoZSBQeXRob24gcnVudGltZSwgdGhlIGhlbHBlciwKICAgICAgICAgICAgICB0aGUgSmF2YSBydW50aW1lLCB0aGUgZ2FtZSwgdGhlIHNhbmRib3guPC90ZD48L3RyPgogICAgICAgICAgPHRyPjx0ZD48Yj5JbnN0YWxsZWQ8L2I+IOKAlCB0aGUgZG91YmxlLWNsaWNrIGZpbGUsIG9yIDxjb2RlPi0taW5zdGFsbDwvY29kZT48L3RkPgogICAgICAgICAgICA8dGQ+PGI+VHdvIHNtYWxsIGZpbGVzPC9iPjogb25lIFB5dGhvbiBmaWxlIGluIEFwcGxpY2F0aW9uIFN1cHBvcnQsIG9uZSBsYXVuY2ggYWdlbnQgc28gaXQKICAgICAgICAgICAgICBzdGFydHMgYXQgZXZlcnkgbG9naW4uIFRoZSBnYW1lIGlzIHN0aWxsIGRlbGV0ZWQgZXZlcnkgc2Vzc2lvbiwgYW5kCiAgICAgICAgICAgICAgPGNvZGU+LS11bmluc3RhbGw8L2NvZGU+IHJlbW92ZXMgYm90aC48L3RkPjwvdHI+CiAgICAgICAgICA8dHI+PHRkPjxiPkJyb3dzZXIgc3RvcmFnZTwvYj48L3RkPgogICAgICAgICAgICA8dGQ+WW91ciB3b3JsZCwgeW91ciBtb2RzIGFuZCB5b3VyIHNldHRpbmdzLCBpbiB0aGlzIG9yaWdpbidzIG93biBzdG9yYWdlLiBUaGF0IGlzIHRoZSBvbmUKICAgICAgICAgICAgICB0aGluZyB3aGljaCBwZXJzaXN0cyBvbiBwdXJwb3NlIOKAlCBpdCBpcyB3aGF0IG1ha2VzIHRoZSBnYW1lIGRpc3Bvc2FibGUuPC90ZD48L3RyPgogICAgICAgIDwvdGFibGU+CiAgICAgICAgPHA+PGNvZGU+d2VibWNfaGVscGVyLnB5IC0tYXVkaXQ8L2NvZGU+IHByaW50cyBleGFjdGx5IHdoYXQgdGhlIGhlbHBlciBoYXMgb24gdGhlIG1hY2hpbmUgYW5kCiAgICAgICAgICBub3RoaW5nIGVsc2UuPC9wPgoKICAgICAgICA8aDMgaWQ9ImQ0Ij5XaGVyZSB5b3VyIHdvcmxkIGxpdmVzPC9oMz4KICAgICAgICA8cD5JbiB0aGlzIGJyb3dzZXIsIHVuZGVyIHRoaXMgcGFnZSdzIG9yaWdpbi4gSXQgaXMgbmV2ZXIgdXBsb2FkZWQsIGFuZCB0aGVyZSBpcyBubyBhY2NvdW50LgogICAgICAgICAgVGhlIGNvbnNlcXVlbmNlIHdvcnRoIGtub3dpbmc6IHN0b3JhZ2UgYmVsb25ncyB0byBhbiA8aT5vcmlnaW48L2k+LCBzbyB0aGUgaG9zdGVkIHBhZ2UgYW5kCiAgICAgICAgICB0aGUgaGVscGVyJ3MgcGFnZSBhcmUgZGlmZmVyZW50IHN0b3Jlcy4gVGhhdCBpcyBleGFjdGx5IHdoeSB0aGUgaG9zdGVkIHBhZ2UgaGFuZHMgdGhlIHRhYgogICAgICAgICAgb3ZlciBvbiBhcnJpdmFsIGluc3RlYWQgb2YgcnVubmluZyBhIHNlc3Npb24gaXRzZWxmIOKAlCBvbmUgb3JpZ2luLCBvbmUgd29ybGQsIG5vIHN1cnByaXNlcy48L3A+CgogICAgICAgIDxoMyBpZD0iZDUiPk5ldHdvcmtzIHRoYXQgYmxvY2sgdGhpbmdzPC9oMz4KICAgICAgICA8dGFibGU+CiAgICAgICAgICA8dHI+PHRoPldoYXQgaXMgYmxvY2tlZDwvdGg+PHRoPldoYXQgdG8gZG88L3RoPjwvdHI+CiAgICAgICAgICA8dHI+PHRkPkEgcHJveHkgaXMgcmVxdWlyZWQgZm9yIGFsbCBvdXRib3VuZCB0cmFmZmljPC90ZD4KICAgICAgICAgICAgPHRkPlRoZSBoZWxwZXIgZGV0ZWN0cyBhIFNPQ0tTNSBwcm94eSBvbiA8Y29kZT4xMjcuMC4wLjE8L2NvZGU+ICgxMDgwLCAxMDg4LCAxMDgwOCwgNzg5MCkgYW5kCiAgICAgICAgICAgICAgdXNlcyBpdCwgcmVzb2x2aW5nIG5hbWVzIGF0IHRoZSBwcm94eSwgb3IgdGFrZXMgPGNvZGU+LS1wcm94eSBzb2NrczVoOi8vaG9zdDpwb3J0PC9jb2RlPi48L3RkPjwvdHI+CiAgICAgICAgICA8dHI+PHRkPk1vamFuZyBpcyB1bnJlYWNoYWJsZTwvdGQ+CiAgICAgICAgICAgIDx0ZD48Yj5BdXRvbWF0aWMuPC9iPiBUaGUgbGF1bmNoZXIncyBvd24gcmVsYXkgZmV0Y2hlcyBmb3IgeW91IG92ZXIgb3JkaW5hcnkgSFRUUFMsIGZyb20KICAgICAgICAgICAgICBDbG91ZGZsYXJlIGluc3RlYWQgb2YgZnJvbSB0aGlzIG1hY2hpbmUsIGFuZCBjYWNoZXMgd2hhdCBpdCBmZXRjaGVkIGF0IHRoZSBlZGdlLiBBIG5ldHdvcmsgdGhhdCBibG9ja3MgdGhlIHJlbGF5J3Mgb3duIGhvc3RuYW1lIGlzCiAgICAgICAgICAgICAgYW5zd2VyZWQgd2l0aCB0aGUgc2FtZSByZWxheSBzb21ld2hlcmUgaXQgZG9lcyBub3Qg4oCUIHRoZSBXb3JrZXIgYW5kIGEgTm9kZSB2ZXJzaW9uCiAgICAgICAgICAgICAgb2YgaXQgYXJlIGJvdGggaW4gdGhpcyByZXBvc2l0b3J5LiBBCiAgICAgICAgICAgICAgbmV0d29yayB0aGF0IGJsb2NrcyBNb2phbmcgaXMgZXhhY3RseSB3aGF0IGl0IGV4aXN0cyBmb3IsIHNvIG5vYm9keSBoYXMgdG8gZGVwbG95CiAgICAgICAgICAgICAgYW55dGhpbmcuIDxiPlNldHRpbmdzIOKGkiBSZWxheSDihpIgTXkgb3duIHJlbGF5PC9iPiBwb2ludHMgaXQgYXQgb25lIHlvdSBkZXBsb3llZCBpbnN0ZWFkLAogICAgICAgICAgICAgIGFuZCA8Yj5OZXZlcjwvYj4gdHVybnMgaXQgb2ZmLjwvdGQ+PC90cj4KICAgICAgICAgIDx0cj48dGQ+SmF2YSBpcyBub3QgaW5zdGFsbGVkLCBvciB0aGUgbWFjaGluZSdzIEphdmEgaXMgYmxvY2tlZDwvdGQ+CiAgICAgICAgICAgIDx0ZD48Yj5BZHZhbmNlZDogcmVzdHJpY3RlZCBtb2RlPC9iPiDigJQgYSBydW50aW1lIGZldGNoZWQgaW50byB0aGUgc2Vzc2lvbidzIGZvbGRlciwgdXNpbmcKICAgICAgICAgICAgICBub3RoaW5nIHRoZSBtYWNoaW5lIGhhcy4gSXQgZG9lcyA8Yj5ub3Q8L2I+IGdldCBwYXN0IGEgcG9saWN5IHRoYXQgYmxvY2tzIHVua25vd24KICAgICAgICAgICAgICBwcm9ncmFtczogQXBwTG9ja2VyLCBXREFDLCBNRE0sIHNjcmVlbi10aW1lIGFuZCBwYXJlbnRhbCBjb250cm9scyBhcmUgZW5mb3JjZWQgYnkgdGhlCiAgICAgICAgICAgICAgb3BlcmF0aW5nIHN5c3RlbSwgYW5kIG5vIGxhdW5jaGVyIGNhbiBjaGFuZ2UgdGhhdC4gT24gc3VjaCBhIG1hY2hpbmUgdGhlIG9ubHkgdGhpbmcgdGhhdAogICAgICAgICAgICAgIHJ1bnMgaXMgdGhlIGJyb3dzZXIgdGllci48L3RkPjwvdHI+CiAgICAgICAgICA8dHI+PHRkPk1pbmVjcmFmdCBzZXJ2ZXJzIGFyZSB1bnJlYWNoYWJsZSAob25seSA0NDMgZ2V0cyBvdXQpPC90ZD4KICAgICAgICAgICAgPHRkPlB1dCB0aGUgc2VydmVyIGluIDxiPlNldHRpbmdzIOKGkiBKb2luIHRoaXMgc2VydmVyPC9iPiBhbmQgdGljayA8Yj5TZW5kIHRoZSBnYW1lIHRocm91Z2gKICAgICAgICAgICAgICB0aGUgcmVsYXk8L2I+LiBUaGUgZ2FtZSdzIGNvbm5lY3Rpb25zIHRyYXZlbCBpbnNpZGUgYSBXZWJTb2NrZXQgdG8gdGhlIHJlbGF5LCB3aGljaCBkaWFscwogICAgICAgICAgICAgIHRoZSBzZXJ2ZXIsIGFuZCB0aGUgY2xpZW50IGpvaW5zIGF1dG9tYXRpY2FsbHkuIFRoZSBwcm90b2NvbCBpcyB0aGUKICAgICAgICAgICAgICA8Y29kZT5nb2xkcHJveHkudjE8L2NvZGU+IG9uZSB0aGlzIHJlcG9zaXRvcnkncyBnYXRld2F5IGFscmVhZHkgc3BlYWtzOyB0aGUgcmVsYXkgcmVmdXNlcwogICAgICAgICAgICAgIGFueSBzZXNzaW9uIHRoYXQgZG9lcyBub3QgYmVnaW4gd2l0aCBhIE1pbmVjcmFmdCBoYW5kc2hha2UsIGJlY2F1c2UgYSByZWxheSB0aGF0IGRpYWxsZWQKICAgICAgICAgICAgICBhbnkgcG9ydCBmb3IgYW55IGJ5dGVzIHdvdWxkIGJlIGEgcG9ydCBzY2FubmVyLjwvdGQ+PC90cj4KICAgICAgICA8L3RhYmxlPgoKICAgICAgICA8aDMgaWQ9ImQ2Ij5Nb3JlIHRoYW4gb25lIHdpbmRvdzwvaDM+CiAgICAgICAgPHA+RXZlcnkgUExBWSBpcyBpdHMgb3duIHNlc3Npb24sIHdpdGggaXRzIG93biBzYW5kYm94LCBpdHMgb3duIEphdmEgcHJvY2VzcyBhbmQgaXRzIG93biBsb2cuCiAgICAgICAgICBUd28gd2luZG93cyBjYW4gcnVuIGF0IG9uY2UsIGluY2x1ZGluZyB0d28gZGlmZmVyZW50IHZlcnNpb25zLCBhbmQgc3RvcHBpbmcgb25lIGRvZXMgbm90CiAgICAgICAgICB0b3VjaCB0aGUgb3RoZXIuIEVhY2ggZmluaXNoZWQgc2Vzc2lvbiBpcyBzdG9yZWQgYW5kIGVhY2ggZGVsZXRlcyBpdHMgb3duIHNhbmRib3guPC9wPgoKICAgICAgICA8aDMgaWQ9ImQ3Ij5Nb2QgbG9hZGVyczwvaDM+CiAgICAgICAgPHRhYmxlPgogICAgICAgICAgPHRyPjx0aD5Mb2FkZXI8L3RoPjx0aD5TdGF0ZTwvdGg+PC90cj4KICAgICAgICAgIDx0cj48dGQ+PGI+RmFicmljPC9iPjwvdGQ+PHRkPldvcmtzLCBmb3IgYW55IHZlcnNpb24gRmFicmljIHN1cHBvcnRzOiBtb2RzIGFyZSBsb2FkZWQgYXQgcGxheQogICAgICAgICAgICB0aW1lIGJ5IGEgcmVhbCBKVk0sIGZyb20gamFycyB5b3UgZHJvcHBlZCBoZXJlIG9yIGZyb20gTW9kcmludGguPC90ZD48L3RyPgogICAgICAgICAgPHRyPjx0ZD5Gb3JnZSwgTmVvRm9yZ2U8L3RkPjx0ZD5Ob3Qgc3VwcG9ydGVkIHlldDogdGhlaXIgYnVpbGRzIHJlc29sdmUgYW5kIHRoZWlyIGxpYnJhcmllcwogICAgICAgICAgICBkb3dubG9hZCwgYnV0IG5laXRoZXIgc2hpcHMgYSB1c2FibGUgY2xpZW50IGphciDigJQgdGhlaXIgaW5zdGFsbGVyIHJ1bnMgYSBwYXRjaGluZyBzdGVwIG92ZXIKICAgICAgICAgICAgTW9qYW5nJ3MgamFyIGFuZCB0aGVpciBib290c3RyYXAgcmVmdXNlcyB0byBzdGFydCB3aXRob3V0IGl0LiBBc2tpbmcgZm9yIG9uZSBpcyByZWZ1c2VkIHdpdGgKICAgICAgICAgICAgdGhhdCBleHBsYW5hdGlvbiByYXRoZXIgdGhhbiBoYWxmLWxhdW5jaGVkLjwvdGQ+PC90cj4KICAgICAgICA8L3RhYmxlPgoKICAgICAgICA8aDMgaWQ9ImQ4Ij5XaGVuIHNvbWV0aGluZyBnb2VzIHdyb25nPC9oMz4KICAgICAgICA8dGFibGU+CiAgICAgICAgICA8dHI+PHRoPlN5bXB0b208L3RoPjx0aD5DYXVzZSBhbmQgYW5zd2VyPC90aD48L3RyPgogICAgICAgICAgPHRyPjx0ZD5Ob3RoaW5nIGhhcHBlbnMgd2hlbiB5b3UgcHJlc3MgUExBWTwvdGQ+CiAgICAgICAgICAgIDx0ZD5ObyBoZWxwZXIgaXMgcnVubmluZy4gVGhlIHN0YXR1cyBwYW5lbCBvZmZlcnMgdGhlIFNob3J0Y3V0LCB0aGUgZG93bmxvYWQsIG9yIHRoZSBsaW5rIHRvCiAgICAgICAgICAgICAgdGhlIGhlbHBlcidzIG93biBwYWdlLjwvdGQ+PC90cj4KICAgICAgICAgIDx0cj48dGQ+4oCcbm8gaGVscGVy4oCdIGFsdGhvdWdoIGl0IGlzIHJ1bm5pbmc8L3RkPgogICAgICAgICAgICA8dGQ+VGhpcyBicm93c2VyIGJsb2NrZWQgdGhlIHJlcXVlc3Q6IHVzZSB0aGUgaGVscGVyJ3Mgb3duIHBhZ2UsIG9yIGFsbG93IExvY2FsIE5ldHdvcmsKICAgICAgICAgICAgICBBY2Nlc3MgZm9yIHRoaXMgc2l0ZS48L3RkPjwvdHI+CiAgICAgICAgICA8dHI+PHRkPkEgbGF1bmNoIGZhaWxzIHdpdGggPGNvZGU+RmFpbGVkIHRvIGNvbm5lY3Q8L2NvZGU+IHRvIE1vamFuZzwvdGQ+CiAgICAgICAgICAgIDx0ZD5UaGUgbmV0d29yayBibG9ja3MgaXQsIG9yIGEgcHJveHkgdGhhdCB3YXMgdXAgaGFzIGdvbmUuIFNldCBhIHJlbGF5LCBvciByZXN0YXJ0IHRoZQogICAgICAgICAgICAgIHByb3h5LjwvdGQ+PC90cj4KICAgICAgICAgIDx0cj48dGQ+VGhlIGdhbWUgc3RhcnRzIHNpbGVudCBhbmQgdGV4dHVyZWxlc3M8L3RkPgogICAgICAgICAgICA8dGQ+QXNzZXRzIHdlcmUgc2tpcHBlZCBvciBmYWlsZWQ7IHRoZSBsb2cgc2F5cyB3aGljaC48L3RkPjwvdHI+CiAgICAgICAgICA8dHI+PHRkPkEgY3Jhc2g8L3RkPgogICAgICAgICAgICA8dGQ+UmVhZCB0aGUgZHJhd2VyLCBvciB0YWtlIHRoZSBzZXNzaW9uIHppcDogaXQgaG9sZHMgdGhlIGNsaWVudCdzIG93biBsb2cgYW5kIGFueSBjcmFzaAogICAgICAgICAgICAgIHJlcG9ydC4gPGI+Q29weSBkaWFnbm9zdGljczwvYj4gaW4gU2V0dGluZ3MgcHV0cyBldmVyeXRoaW5nIHdvcnRoIHBhc3Rpbmcgb24geW91cgogICAgICAgICAgICAgIGNsaXBib2FyZC48L3RkPjwvdHI+CiAgICAgICAgPC90YWJsZT4KICAgICAgICA8aHI+CiAgICAgICAgPHAgY2xhc3M9ImhpbnQiPlRoZSBwcm9taXNlIGluIG9uZSBzZW50ZW5jZTogdGhlIGdhbWUgcnVucyBvbiB5b3VyIGNvbXB1dGVyLCBmcm9tIGEgZGlyZWN0b3J5CiAgICAgICAgICB1bmRlciA8Y29kZT4vdG1wPC9jb2RlPiB0aGF0IGlzIGRlbGV0ZWQgd2hlbiBpdCBlbmRzLCB3aGlsZSB5b3VyIHdvcmxkIGFuZCB5b3VyIG1vZHMgbGl2ZSBpbgogICAgICAgICAgeW91ciBicm93c2VyIOKAlCBzbyB0aGUgbWFjaGluZSBpcyBib3Jyb3dlZCBmb3IgYW4gaG91ciByYXRoZXIgdGhhbiBjaGFuZ2VkLjwvcD4KICAgICAgPC9kaXY+CiAgICA8L3NlY3Rpb24+CiAgPC9kaXY+CgogIDwhLS0gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIGRyYXdlciAtLT4KICA8ZGl2IGNsYXNzPSJkcmF3ZXIiPgogICAgPGRpdiBjbGFzcz0ic3RyaXAiIGlkPSJkcmF3ZXJTdHJpcFJvdyI+CiAgICAgIDxpIGNsYXNzPSJkb3QiIGlkPSJjZG90MiI+PC9pPgogICAgICA8Yj5BY3Rpdml0eTwvYj4KICAgICAgPHNwYW4gY2xhc3M9InBoYXNlIiBpZD0ibG9nU3RhdGUiPndhaXRpbmc8L3NwYW4+CiAgICAgIDxkaXYgY2xhc3M9InRyYWNrIiBpZD0iZHJhd2VyVHJhY2siPjxpPjwvaT48L2Rpdj4KICAgICAgPHNwYW4gY2xhc3M9InBjdCIgaWQ9ImRyYXdlclBjdCI+PC9zcGFuPgogICAgICA8YnV0dG9uIGNsYXNzPSJ0b2dnbGUiIGlkPSJsb2dIaWRlIj5TaG93IGxvZzwvYnV0dG9uPgogICAgPC9kaXY+CiAgICA8ZGl2IGNsYXNzPSJkcmF3ZXJib2R5Ij4KICAgICAgPGRpdiBjbGFzcz0ibG9ndG9vbHMiPgogICAgICAgIDxiPkxvZzwvYj48c3BhbiBjbGFzcz0iaGludCIgaWQ9ImxvZ0ZvciI+bm8gc2Vzc2lvbjwvc3Bhbj48c3BhbiBjbGFzcz0iZ3JvdyI+PC9zcGFuPgogICAgICAgIDxidXR0b24gY2xhc3M9InRpbnkiIGlkPSJsb2dDbGVhciI+Q2xlYXIgdGhlIHZpZXc8L2J1dHRvbj4KICAgICAgPC9kaXY+CiAgICAgIDxkaXYgY2xhc3M9InJlY2VpcHQiIGlkPSJyZWNlaXB0Ij48L2Rpdj4KICAgICAgPGRpdiBjbGFzcz0iY29uc29sZSIgaWQ9ImxvZyI+PHNwYW4gY2xhc3M9ImQiPlRoZSBoZWxwZXIncyBsb2cgYXBwZWFycyBoZXJlIOKAlCBpbmNsdWRpbmcKTWluZWNyYWZ0J3Mgb3duLCBzbyBhIGNyYXNoIGlzIHJlYWRhYmxlIGluc3RlYWQgb2YgbXlzdGVyaW91cy48L3NwYW4+PC9kaXY+CiAgICA8L2Rpdj4KICA8L2Rpdj4KPC9kaXY+Cgo8ZGlhbG9nIGlkPSJhYm91dCI+CiAgPGRpdiBjbGFzcz0iaW5uZXIiPgogICAgPGgzPkhvdyB0aGlzIHdvcmtzPC9oMz4KICAgIDxwPk1pbmVjcmFmdCBuZXZlciBiZWNvbWVzIGEgd2ViIGFwcCBoZXJlLiBBIGhlbHBlciBvbiB0aGlzIG1hY2hpbmUgZG93bmxvYWRzIHRoZSByZWFsIGNsaWVudCBhbmQKICAgICAgdGhlIEphdmEgcnVudGltZSBpbnRvIG9uZSBkaXJlY3RvcnkgdW5kZXIgPGNvZGU+L3RtcDwvY29kZT4sIHN0YXJ0cyBpdCB3aXRoIEZhYnJpYywgYW5kIHdoZW4gdGhlCiAgICAgIHNlc3Npb24gZW5kcyBpdCBoYW5kcyB0aGUgc2F2ZXMgdG8geW91ciBicm93c2VyIGFuZCBkZWxldGVzIHRoZSBkaXJlY3RvcnkuPC9wPgogICAgPHA+VGhpcyBwYWdlIGNhbm5vdCBzdGFydCBhIHByb2dyYW0sIHJlYWQgYSBmaWxlLCBvciBzZWUgPGNvZGU+L3RtcDwvY29kZT4g4oCUIHRoZSBoZWxwZXIgZG9lcyB0aGF0CiAgICAgIHBhcnQuIDxiPkRvY3VtZW50YXRpb248L2I+IGluIHRoZSB0YWJzIGFib3ZlIGhhcyB0aGUgbG9uZyB2ZXJzaW9uLjwvcD4KICAgIDxkaXYgY2xhc3M9ImhpbnQiIGlkPSJhYm91dGt2cyIgc3R5bGU9Im1hcmdpbi10b3A6MTNweCI+PC9kaXY+CiAgICA8ZGl2IHN0eWxlPSJtYXJnaW4tdG9wOjE4cHg7dGV4dC1hbGlnbjpyaWdodCI+PGJ1dHRvbiBpZD0iYWJvdXRjbG9zZSI+Q2xvc2U8L2J1dHRvbj48L2Rpdj4KICA8L2Rpdj4KPC9kaWFsb2c+Cgo8c2NyaXB0PgoidXNlIHN0cmljdCI7CmNvbnN0ICQgPSAoaWQpID0+IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTsKY29uc3QgTFMgPSAid2VibWMubG9jYWwuIjsKY29uc3Qgc3RhdGUgPSB7IGhlbHBlcjpudWxsLCB0b2tlbjpudWxsLCBvbmxpbmU6ZmFsc2UsIHNlc3Npb25zOltdLCBzZWxlY3RlZDpudWxsLAogICAgICAgICAgICAgICAgc2luY2U6e30sIHNsdWdzOltdLCBzbHVnc01ldGE6e30sIHJlc3VsdDpudWxsLCBzZWVuOnt9LCB0aW1lcjpudWxsIH07CgovKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSB2aWV3cyAqLwpjb25zdCBWSUVXUyA9IHsKICB2aWV3UGxheTogICAgIFsiUGxheSIsICJwaWNrIGEgdmVyc2lvbiBhbmQgcHJlc3MgUExBWSDigJQgbW9yZSB0aGFuIG9uZSBjYW4gcnVuIGF0IG9uY2UiXSwKICB2aWV3TW9kczogICAgIFsiTW9kcyIsICJqYXJzIGZyb20gdGhpcyBicm93c2VyLCBvciBmcm9tIE1vZHJpbnRoIl0sCiAgdmlld1NldHRpbmdzOiBbIlNldHRpbmdzIiwgInRoaXMgaW5zdGFsbGF0aW9uLCBhbmQgdGhlIGhlbHBlciJdLAogIHZpZXdEb2M6ICAgICAgWyJEb2N1bWVudGF0aW9uIiwgImhvdyBhbGwgb2YgdGhpcyB3b3JrcywgYW5kIHdoYXQgaXQgbGVhdmVzIGJlaGluZCJdLAp9OwpmdW5jdGlvbiBzaG93KHZpZXcpewogIGZvciAoY29uc3QgaWQgb2YgT2JqZWN0LmtleXMoVklFV1MpKSAkKGlkKS5jbGFzc0xpc3QudG9nZ2xlKCJvbiIsIGlkID09PSB2aWV3KTsKICBmb3IgKGNvbnN0IFtidG4sIHZdIG9mIFtbIm5hdlBsYXkiLCJ2aWV3UGxheSJdLFsibmF2TW9kcyIsInZpZXdNb2RzIl0sCiAgICAgICAgICAgICAgICAgICAgICAgICAgWyJuYXZTZXR0aW5ncyIsInZpZXdTZXR0aW5ncyJdLFsibmF2RG9jIiwidmlld0RvYyJdXSkKICAgICQoYnRuKS5jbGFzc0xpc3QudG9nZ2xlKCJvbiIsIHYgPT09IHZpZXcpOwogIGlmICgkKCJ2aWV3VGl0bGUiKSkgaWYgKCQoInZpZXdUaXRsZSIpKSAkKCJ2aWV3VGl0bGUiKS50ZXh0Q29udGVudCA9IFZJRVdTW3ZpZXddWzBdOwogICQoInZpZXdTdWIiKS50ZXh0Q29udGVudCA9IFZJRVdTW3ZpZXddWzFdOwp9CiQoIm5hdlBsYXkiKS5vbmNsaWNrID0gKCkgPT4gc2hvdygidmlld1BsYXkiKTsKJCgibmF2TW9kcyIpLm9uY2xpY2sgPSAoKSA9PiBzaG93KCJ2aWV3TW9kcyIpOwokKCJuYXZTZXR0aW5ncyIpLm9uY2xpY2sgPSAoKSA9PiBzaG93KCJ2aWV3U2V0dGluZ3MiKTsKJCgibmF2RG9jIikub25jbGljayA9ICgpID0+IHNob3coInZpZXdEb2MiKTsKCi8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IHN0b3JhZ2UgKi8KY29uc3QgU3RvcmUgPSAoKCkgPT4gewogIGNvbnN0IERCTiA9ICJ3ZWJtYy1sb2NhbCIsIExPRyA9ICJzZXNzaW9uIiwgTU9EUyA9ICJtb2RzIjsKICBmdW5jdGlvbiBpZGIoKXsKICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzLCByZWopID0+IHsKICAgICAgY29uc3QgciA9IGluZGV4ZWREQi5vcGVuKERCTiwgMik7CiAgICAgIHIub251cGdyYWRlbmVlZGVkID0gKCkgPT4gewogICAgICAgIGNvbnN0IGRiID0gci5yZXN1bHQ7CiAgICAgICAgaWYgKCFkYi5vYmplY3RTdG9yZU5hbWVzLmNvbnRhaW5zKExPRykpIGRiLmNyZWF0ZU9iamVjdFN0b3JlKExPRyk7CiAgICAgICAgaWYgKCFkYi5vYmplY3RTdG9yZU5hbWVzLmNvbnRhaW5zKE1PRFMpKSBkYi5jcmVhdGVPYmplY3RTdG9yZShNT0RTKTsKICAgICAgfTsKICAgICAgci5vbnN1Y2Nlc3MgPSAoKSA9PiByZXMoci5yZXN1bHQpOyByLm9uZXJyb3IgPSAoKSA9PiByZWooci5lcnJvcik7CiAgICB9KTsKICB9CiAgZnVuY3Rpb24gaWRiT3Aoc3RvcmUsIG1vZGUsIGZuKXsKICAgIHJldHVybiBpZGIoKS50aGVuKGRiID0+IG5ldyBQcm9taXNlKChyZXMsIHJlaikgPT4gewogICAgICBjb25zdCB0ID0gZGIudHJhbnNhY3Rpb24oc3RvcmUsIG1vZGUpOwogICAgICBjb25zdCByZXEgPSBmbih0Lm9iamVjdFN0b3JlKHN0b3JlKSk7CiAgICAgIHQub25jb21wbGV0ZSA9ICgpID0+IHJlcyhyZXEgJiYgcmVxLnJlc3VsdCk7IHQub25lcnJvciA9ICgpID0+IHJlaih0LmVycm9yKTsKICAgIH0pKTsKICB9CiAgY29uc3Qgb3BmcyA9ICEhKG5hdmlnYXRvci5zdG9yYWdlICYmIG5hdmlnYXRvci5zdG9yYWdlLmdldERpcmVjdG9yeSk7CiAgYXN5bmMgZnVuY3Rpb24gZGlyKG5hbWUsIGNyZWF0ZSl7CiAgICBjb25zdCByb290ID0gYXdhaXQgbmF2aWdhdG9yLnN0b3JhZ2UuZ2V0RGlyZWN0b3J5KCk7CiAgICByZXR1cm4gcm9vdC5nZXREaXJlY3RvcnlIYW5kbGUobmFtZSwgeyBjcmVhdGU6ICEhY3JlYXRlIH0pOwogIH0KICByZXR1cm4gewogICAga2luZDogb3BmcyA/ICJPUEZTIiA6ICJJbmRleGVkREIiLAogICAgYXN5bmMgcHV0KGtleSwgYmxvYil7IHJldHVybiB0aGlzLnB1dEluKExPRywga2V5LCBibG9iKTsgfSwKICAgIGFzeW5jIHB1dEluKHN0b3JlLCBrZXksIGJsb2IpewogICAgICBpZiAob3Bmcyl7CiAgICAgICAgY29uc3QgZCA9IGF3YWl0IGRpcihzdG9yZSwgdHJ1ZSk7CiAgICAgICAgY29uc3QgZmggPSBhd2FpdCBkLmdldEZpbGVIYW5kbGUoa2V5LCB7IGNyZWF0ZTp0cnVlIH0pOwogICAgICAgIGNvbnN0IHcgPSBhd2FpdCBmaC5jcmVhdGVXcml0YWJsZSgpOyBhd2FpdCB3LndyaXRlKGJsb2IpOyBhd2FpdCB3LmNsb3NlKCk7IHJldHVybjsKICAgICAgfQogICAgICBhd2FpdCBpZGJPcChzdG9yZSwgInJlYWR3cml0ZSIsIHMgPT4gcy5wdXQoYmxvYiwga2V5KSk7CiAgICB9LAogICAgYXN5bmMgZ2V0KGtleSl7IHJldHVybiB0aGlzLmdldEZyb20oTE9HLCBrZXkpOyB9LAogICAgYXN5bmMgZ2V0RnJvbShzdG9yZSwga2V5KXsKICAgICAgaWYgKG9wZnMpewogICAgICAgIHRyeSB7IGNvbnN0IGQgPSBhd2FpdCBkaXIoc3RvcmUsIGZhbHNlKTsgY29uc3QgZmggPSBhd2FpdCBkLmdldEZpbGVIYW5kbGUoa2V5KTsKICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgZmguZ2V0RmlsZSgpOyB9IGNhdGNoKGUpeyByZXR1cm4gbnVsbDsgfQogICAgICB9CiAgICAgIHJldHVybiAoYXdhaXQgaWRiT3Aoc3RvcmUsICJyZWFkb25seSIsIHMgPT4gcy5nZXQoa2V5KSkpIHx8IG51bGw7CiAgICB9LAogICAgYXN5bmMgbGlzdChzdG9yZSl7CiAgICAgIGlmIChvcGZzKXsKICAgICAgICBjb25zdCBvdXQgPSBbXTsKICAgICAgICB0cnkgewogICAgICAgICAgY29uc3QgZCA9IGF3YWl0IGRpcihzdG9yZSwgZmFsc2UpOwogICAgICAgICAgZm9yIGF3YWl0IChjb25zdCBbbmFtZSwgaGFuZGxlXSBvZiBkLmVudHJpZXMoKSl7CiAgICAgICAgICAgIGlmIChoYW5kbGUua2luZCAhPT0gImZpbGUiKSBjb250aW51ZTsKICAgICAgICAgICAgb3V0LnB1c2goeyBuYW1lLCBzaXplOiAoYXdhaXQgaGFuZGxlLmdldEZpbGUoKSkuc2l6ZSB9KTsKICAgICAgICAgIH0KICAgICAgICB9IGNhdGNoKGUpe30KICAgICAgICByZXR1cm4gb3V0LnNvcnQoKGEsYikgPT4gYS5uYW1lLmxvY2FsZUNvbXBhcmUoYi5uYW1lKSk7CiAgICAgIH0KICAgICAgY29uc3Qga2V5cyA9IChhd2FpdCBpZGJPcChzdG9yZSwgInJlYWRvbmx5IiwgcyA9PiBzLmdldEFsbEtleXMoKSkpIHx8IFtdOwogICAgICByZXR1cm4ga2V5cy5tYXAobmFtZSA9PiAoeyBuYW1lLCBzaXplOjAgfSkpLnNvcnQoKGEsYikgPT4gYS5uYW1lLmxvY2FsZUNvbXBhcmUoYi5uYW1lKSk7CiAgICB9LAogICAgYXN5bmMgcmVtb3ZlKHN0b3JlLCBrZXkpewogICAgICBpZiAob3Bmcyl7IHRyeSB7IGNvbnN0IGQgPSBhd2FpdCBkaXIoc3RvcmUsIGZhbHNlKTsgYXdhaXQgZC5yZW1vdmVFbnRyeShrZXkpOyB9IGNhdGNoKGUpe30gcmV0dXJuOyB9CiAgICAgIGF3YWl0IGlkYk9wKHN0b3JlLCAicmVhZHdyaXRlIiwgcyA9PiBzLmRlbGV0ZShrZXkpKTsKICAgIH0sCiAgICBhc3luYyBwZXJzaXN0KCl7IHRyeSB7IHJldHVybiBuYXZpZ2F0b3Iuc3RvcmFnZSAmJiBuYXZpZ2F0b3Iuc3RvcmFnZS5wZXJzaXN0CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGF3YWl0IG5hdmlnYXRvci5zdG9yYWdlLnBlcnNpc3QoKSA6IGZhbHNlOyB9IGNhdGNoKGUpeyByZXR1cm4gZmFsc2U7IH0gfSwKICAgIGFzeW5jIHVzYWdlKCl7IHRyeSB7IGNvbnN0IGUgPSBhd2FpdCBuYXZpZ2F0b3Iuc3RvcmFnZS5lc3RpbWF0ZSgpOwogICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgdXNlZDplLnVzYWdlfHwwLCBxdW90YTplLnF1b3RhfHwwIH07IH0gY2F0Y2goZSl7IHJldHVybiB7dXNlZDowLHF1b3RhOjB9OyB9IH0KICB9Owp9KSgpOwpjb25zdCBmbXQgPSAoYikgPT4gewogIGlmICghYikgcmV0dXJuICIwIEIiOwogIGNvbnN0IHUgPSBbIkIiLCJLQiIsIk1CIiwiR0IiXTsgbGV0IGkgPSAwOwogIHdoaWxlIChiID49IDEwMjQgJiYgaSA8IHUubGVuZ3RoLTEpeyBiIC89IDEwMjQ7IGkrKzsgfQogIHJldHVybiBiLnRvRml4ZWQoYiA8IDEwICYmIGkgPiAwID8gMSA6IDApICsgIiAiICsgdVtpXTsKfTsKY29uc3QgYWdvID0gKHQpID0+IHsKICBpZiAoIXQpIHJldHVybiAiIjsKICBjb25zdCBzID0gTWF0aC5tYXgoMCwgTWF0aC5mbG9vcigoRGF0ZS5ub3coKSAtIHQgKiAxMDAwKSAvIDEwMDApKTsKICBpZiAocyA8IDYwKSByZXR1cm4gcyArICJzIjsKICBpZiAocyA8IDM2MDApIHJldHVybiBNYXRoLmZsb29yKHMgLyA2MCkgKyAibSAiICsgKHMgJSA2MCkgKyAicyI7CiAgcmV0dXJuIE1hdGguZmxvb3IocyAvIDM2MDApICsgImggIiArIE1hdGguZmxvb3IoKHMgJSAzNjAwKSAvIDYwKSArICJtIjsKfTsKCi8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IGpvdXJuYWwgKi8KY29uc3QgSm91cm5hbCA9IHsKICBsaW5lczogW10sIG1ldGE6IHt9LCBsYXN0V3JpdGU6IDAsIGRpcnR5OiBmYWxzZSwgS0VZOiAiam91cm5hbC5qc29uIiwKICBub3RlKGxpbmUpewogICAgdGhpcy5saW5lcy5wdXNoKGxpbmUpOwogICAgaWYgKHRoaXMubGluZXMubGVuZ3RoID4gMzAwMCkgdGhpcy5saW5lcy5zcGxpY2UoMCwgdGhpcy5saW5lcy5sZW5ndGggLSAzMDAwKTsKICAgIHRoaXMuZGlydHkgPSB0cnVlOwogIH0sCiAgdXBkYXRlKGYpeyBPYmplY3QuYXNzaWduKHRoaXMubWV0YSwgZik7IHRoaXMuZGlydHkgPSB0cnVlOyB9LAogIGFzeW5jIGZsdXNoKGZvcmNlKXsKICAgIGlmICghdGhpcy5kaXJ0eSkgcmV0dXJuOwogICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTsKICAgIGlmICghZm9yY2UgJiYgbm93IC0gdGhpcy5sYXN0V3JpdGUgPCAyNTAwKSByZXR1cm47CiAgICB0aGlzLmxhc3RXcml0ZSA9IG5vdzsgdGhpcy5kaXJ0eSA9IGZhbHNlOwogICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtKU09OLnN0cmluZ2lmeSh7IG1ldGE6IHRoaXMubWV0YSwgbGluZXM6IHRoaXMubGluZXMgfSldLAogICAgICAgICAgICAgICAgICAgICAgICAgIHsgdHlwZToiYXBwbGljYXRpb24vanNvbiIgfSk7CiAgICB0cnkgeyBhd2FpdCBTdG9yZS5wdXRJbigic2Vzc2lvbiIsIHRoaXMuS0VZLCBibG9iKTsgfSBjYXRjaChlKXt9CiAgfSwKICBhc3luYyBsb2FkKCl7CiAgICB0cnkgewogICAgICBjb25zdCBibG9iID0gYXdhaXQgU3RvcmUuZ2V0RnJvbSgic2Vzc2lvbiIsIHRoaXMuS0VZKTsKICAgICAgaWYgKCFibG9iKSByZXR1cm4gbnVsbDsKICAgICAgY29uc3QgZGF0YSA9IEpTT04ucGFyc2UoYXdhaXQgYmxvYi50ZXh0KCkpOwogICAgICByZXR1cm4gKGRhdGEgJiYgZGF0YS5saW5lcyAmJiBkYXRhLmxpbmVzLmxlbmd0aCkgPyBkYXRhIDogbnVsbDsKICAgIH0gY2F0Y2goZSl7IHJldHVybiBudWxsOyB9CiAgfSwKICBhc3luYyBjbGVhcigpeyB0cnkgeyBhd2FpdCBTdG9yZS5yZW1vdmUoInNlc3Npb24iLCB0aGlzLktFWSk7IH0gY2F0Y2goZSl7fSB9LAogIHN1bW1hcnkoKXsgY29uc3QgbSA9IHRoaXMubWV0YSB8fCB7fTsKICAgICAgICAgICAgIHJldHVybiAobS5waGFzZSB8fCAiPyIpICsgKG0uc3RhcnRlZEF0ID8gIiDCtyBzdGFydGVkICIgKyBuZXcgRGF0ZShtLnN0YXJ0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoKSA6ICIiKTsgfQp9OwoKLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gY29ubmVjdGlvbiAqLwpjb25zdCBob3N0ZWQgPSAhL14oMTI3XC4wXC4wXC4xfGxvY2FsaG9zdHxcWzo6MVxdKSQvLnRlc3QobG9jYXRpb24uaG9zdG5hbWUpOwpmdW5jdGlvbiBsc0dldChrKXsgdHJ5IHsgcmV0dXJuIGxvY2FsU3RvcmFnZS5nZXRJdGVtKExTK2spOyB9IGNhdGNoKGUpeyByZXR1cm4gbnVsbDsgfSB9CmZ1bmN0aW9uIGxzU2V0KGssIHYpeyB0cnkgeyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShMUytrLCB2KTsgfSBjYXRjaChlKXt9IH0KZnVuY3Rpb24gbHNEZWwoayl7IHRyeSB7IGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKExTK2spOyB9IGNhdGNoKGUpe30gfQoKZnVuY3Rpb24gYWRvcHRGcmFnbWVudCgpewogIGNvbnN0IGYgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKGxvY2F0aW9uLmhhc2gucmVwbGFjZSgvXiMvLCAiIikpOwogIGlmIChmLmdldCgiaGVscGVyIikpIHN0YXRlLmhlbHBlciA9IGYuZ2V0KCJoZWxwZXIiKS5yZXBsYWNlKC9cLyQvLCAiIik7CiAgaWYgKGYuZ2V0KCJ0IikpIHN0YXRlLnRva2VuID0gZi5nZXQoInQiKTsKICBpZiAoZi5nZXQoImhlbHBlciIpKXsKICAgIGhpc3RvcnkucmVwbGFjZVN0YXRlKG51bGwsICIiLCBsb2NhdGlvbi5wYXRobmFtZSArIGxvY2F0aW9uLnNlYXJjaCk7CiAgICByZW1lbWJlcigpOwogIH0KfQpmdW5jdGlvbiByZW1lbWJlcigpewogIGlmICghc3RhdGUuaGVscGVyKSByZXR1cm47CiAgbHNTZXQoImhlbHBlciIsIHN0YXRlLmhlbHBlcik7CiAgaWYgKHN0YXRlLnRva2VuKSBsc1NldCgidG9rZW4iLCBzdGF0ZS50b2tlbik7Cn0KZnVuY3Rpb24gY29ubmVjdGlvbigpewogIGlmICh3aW5kb3cuX19XRUJNQ19fICYmIHdpbmRvdy5fX1dFQk1DX18uaGVscGVyKXsKICAgIHN0YXRlLmhlbHBlciA9IHdpbmRvdy5fX1dFQk1DX18uaGVscGVyOwogICAgc3RhdGUudG9rZW4gPSB3aW5kb3cuX19XRUJNQ19fLnRva2VuOwogICAgcmV0dXJuICJoZWxwZXIiOwogIH0KICBhZG9wdEZyYWdtZW50KCk7CiAgaWYgKCFzdGF0ZS5oZWxwZXIpeyBzdGF0ZS5oZWxwZXIgPSBsc0dldCgiaGVscGVyIik7IHN0YXRlLnRva2VuID0gbHNHZXQoInRva2VuIik7IH0KICBpZiAoIXN0YXRlLmhlbHBlciAmJiAvXigxMjdcLjBcLjBcLjF8bG9jYWxob3N0fFxbOjoxXF0pJC8udGVzdChsb2NhdGlvbi5ob3N0bmFtZSkgJiYgbG9jYXRpb24ucG9ydCl7CiAgICBzdGF0ZS5oZWxwZXIgPSBsb2NhdGlvbi5vcmlnaW47CiAgICByZXR1cm4gIm9yaWdpbiI7CiAgfQogIHJldHVybiBzdGF0ZS5oZWxwZXIgPyAic3RvcmVkIiA6ICJub25lIjsKfQphc3luYyBmdW5jdGlvbiBhcGkocGF0aCwgb3B0cyl7CiAgY29uc3QgbyA9IE9iamVjdC5hc3NpZ24oeyBjYWNoZToibm8tc3RvcmUiIH0sIG9wdHMgfHwge30pOwogIG8uaGVhZGVycyA9IE9iamVjdC5hc3NpZ24oe30sIG8uaGVhZGVycyk7CiAgaWYgKHN0YXRlLnRva2VuKSBvLmhlYWRlcnNbIlgtV2ViTUMtVG9rZW4iXSA9IHN0YXRlLnRva2VuOwogIGlmIChvLmJvZHkgJiYgdHlwZW9mIG8uYm9keSA9PT0gInN0cmluZyIpIG8uaGVhZGVyc1siQ29udGVudC1UeXBlIl0gPSAiYXBwbGljYXRpb24vanNvbiI7CiAgaWYgKG8udGltZW91dCl7IGNvbnN0IGFjID0gbmV3IEFib3J0Q29udHJvbGxlcigpOyBvLnNpZ25hbCA9IGFjLnNpZ25hbDsKICAgICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBhYy5hYm9ydCgpLCBvLnRpbWVvdXQpOyB9CiAgY29uc3QgciA9IGF3YWl0IGZldGNoKHN0YXRlLmhlbHBlci5yZXBsYWNlKC9cLyQvLCAiIikgKyBwYXRoLCBvKTsKICBpZiAoIXIub2spewogICAgbGV0IGRldGFpbCA9IHIuc3RhdHVzICsgIiAiICsgci5zdGF0dXNUZXh0OwogICAgdHJ5IHsgY29uc3QgaiA9IGF3YWl0IHIuanNvbigpOyBpZiAoai5lcnJvcikgZGV0YWlsID0gai5lcnJvcjsgfSBjYXRjaChlKXt9CiAgICBjb25zdCBlcnIgPSBuZXcgRXJyb3IoZGV0YWlsKTsgZXJyLnN0YXR1cyA9IHIuc3RhdHVzOyB0aHJvdyBlcnI7CiAgfQogIHJldHVybiByOwp9CmNvbnN0IGpnZXQgPSBhc3luYyAocCwgdCkgPT4gKGF3YWl0IGFwaShwLCB7IHRpbWVvdXQ6IHQgfSkpLmpzb24oKTsKZnVuY3Rpb24gc2V0Q29ubihraW5kLCB0ZXh0KXsgJCgiY2QiKS5jbGFzc05hbWUgPSAiY2RvdCAiICsga2luZDsgJCgiY2RvdDIiKS5jbGFzc05hbWUgPSAiY2RvdCAiICsga2luZDsKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJCgiY3QiKS50ZXh0Q29udGVudCA9IHRleHQ7IH0KCi8qIGhhbmRpbmcgb3ZlcjogYSBwdWJsaWMgcGFnZSBtYXkgbm90IGZldGNoIG9yIGZyYW1lIDEyNy4wLjAuMSwgYnV0IGl0IG1heSBuYXZpZ2F0ZSB0byBpdCAqLwpmdW5jdGlvbiBoYW5kT3ZlcigpewogIGNvbnN0IGxvYWRlciA9ICQoImxvYWRlciIpLnZhbHVlID09PSAiY3VzdG9tIgogICAgPyAoJCgibG9hZGVyY3VzdG9tIikudmFsdWUudHJpbSgpIHx8ICJzdGFibGUiKSA6ICQoImxvYWRlciIpLnZhbHVlOwogIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoeyBwbGF5OiIxIiwgdjogJCgidmVyc2lvbiIpLnZhbHVlIHx8ICIxLjIxLjExIiwgbDogbG9hZGVyLAogICAgbTogKHN0YXRlLnNsdWdzIHx8IFtdKS5qb2luKCIsIiksIHU6ICQoInVzZXJuYW1lIikudmFsdWUudHJpbSgpIHx8ICJQbGF5ZXIiLAogICAgbWVtOiAkKCJtZW1vcnkiKS52YWx1ZS50cmltKCkgfHwgIjJHIiB9KTsKICBpZiAoJCgicmVsYXkiKS52YWx1ZS50cmltKCkpIHBhcmFtcy5zZXQoInJlbGF5IiwgJCgicmVsYXkiKS52YWx1ZS50cmltKCkpOwogIGxvY2F0aW9uLmhyZWYgPSAiaHR0cDovLzEyNy4wLjAuMTo3NjQ1LyMiICsgcGFyYW1zLnRvU3RyaW5nKCk7Cn0KZnVuY3Rpb24gc2hvd09mZmxpbmUoa2luZCl7CiAgJCgicGxheSIpLmRpc2FibGVkID0gZmFsc2U7CiAgJCgib2ZmbGluZSIpLnN0eWxlLmRpc3BsYXkgPSAiIjsKICBjb25zdCB0ID0gJCgib2ZmbGluZXRleHQiKTsKICBpZiAoa2luZCA9PT0gInRva2VuIil7CiAgICB0LmNsYXNzTmFtZSA9ICJiYWQiOwogICAgdC5pbm5lckhUTUwgPSAiQSBoZWxwZXIgaXMgbGlzdGVuaW5nIHRoZXJlIGJ1dCByZWplY3RlZCB0aGlzIHBhZ2UncyB0b2tlbiDigJQgaXQgd2FzIHN0YXJ0ZWQgYnkgYW4gIiArCiAgICAgICJlYXJsaWVyIHJ1bi4gU3RvcCBpdCwgc3RhcnQgaXQgYWdhaW4sIGFuZCB1c2UgdGhlIGxpbmsgaXQgb3BlbnMuIjsKICB9IGVsc2UgewogICAgdC5jbGFzc05hbWUgPSAid2FybiI7CiAgICB0LmlubmVySFRNTCA9ICJObyBoZWxwZXIgYW5zd2VyZWQgb24gPGNvZGU+IiArIChzdGF0ZS5oZWxwZXIgfHwgInRoZSBoZWxwZXIgYWRkcmVzcyIpICsgIjwvY29kZT4uICIgKwogICAgICAiRWl0aGVyIG5vbmUgaXMgcnVubmluZywgb3IgdGhpcyBicm93c2VyIGJsb2NrZWQgbG9jYWwgbmV0d29yayBhY2Nlc3MgZm9yIHRoaXMgc2l0ZS4iOwogIH0KICAkKCJnZXRoZWxwZXIiKS5zdHlsZS5kaXNwbGF5ID0gaG9zdGVkID8gIiIgOiAibm9uZSI7CiAgJCgid2hlcmUiKS50ZXh0Q29udGVudCA9IGhvc3RlZCA/ICJob3N0ZWQgcGFnZSDCtyBoZWxwZXIgb24gdGhpcyBtYWNoaW5lIiA6ICLigJQiOwp9CmFzeW5jIGZ1bmN0aW9uIHByb2JlKGV4cGxpY2l0KXsKICBpZiAoIXN0YXRlLmhlbHBlcil7IHNldENvbm4oImJhZCIsICJubyBoZWxwZXIgc2V0Iik7IHNob3dPZmZsaW5lKCJkb3duIik7IHJldHVybiBmYWxzZTsgfQogIGlmIChleHBsaWNpdCkgc2V0Q29ubigiYnVzeSIsICJjb250YWN0aW5n4oCmIik7CiAgdHJ5IHsKICAgIGNvbnN0IGhlbGxvID0gYXdhaXQgamdldCgiL2FwaS9oZWxsbyIsIDI1MDApOwogICAgc3RhdGUub25saW5lID0gdHJ1ZTsgc3RhdGUuaGVsbG8gPSBoZWxsbzsKICAgIHNldENvbm4oIm9rIiwgImhlbHBlciAiICsgaGVsbG8udmVyc2lvbik7CiAgICAkKCJvZmZsaW5lIikuc3R5bGUuZGlzcGxheSA9ICJub25lIjsKICAgICQoIndoZXJlIikudGV4dENvbnRlbnQgPSBoZWxsby5wbGF0Zm9ybS5vcyArICIvIiArIGhlbGxvLnBsYXRmb3JtLmFyY2ggKyAiIMK3ICIgKyBTdG9yZS5raW5kICsKICAgICAgIiDCtyAiICsgKGhlbGxvLnNlc3Npb25zIHx8IDApICsgIiBzZXNzaW9uKHMpIjsKICAgICQoImNvbm5oaW50IikuaW5uZXJIVE1MID0gIkNvbm5lY3RlZC4gRG93bmxvYWRzICIgKwogICAgICAoaGVsbG8ucHJveHkgPT09ICJkaXJlY3QiID8gImdvIHN0cmFpZ2h0IG91dCIgOiAiZ28gdGhyb3VnaCA8Y29kZT4iICsgaGVsbG8ucHJveHkgKyAiPC9jb2RlPiIpICsKICAgICAgKGhlbGxvLnJlbGF5ID8gIiDCtyByZWxheSA8Y29kZT4iICsgaGVsbG8ucmVsYXkgKyAiPC9jb2RlPiIgOiAiIikgKwogICAgICAiIMK3IHNhbmRib3ggPGNvZGU+IiArIGhlbGxvLnNhbmRib3ggKyAiPC9jb2RlPi4iOwogICAgJCgiYWJvdXRrdnMiKS5pbm5lckhUTUwgPSAiaGVscGVyICIgKyBoZWxsby52ZXJzaW9uICsgIiDCtyAiICsgaGVsbG8ucGxhdGZvcm0ub3MgKyAiICIgKwogICAgICBoZWxsby5wbGF0Zm9ybS5hcmNoICsgIiDCtyBwcm94eSAiICsgaGVsbG8ucHJveHkgKyAiIMK3IHN0b3JhZ2UgIiArIFN0b3JlLmtpbmQ7CiAgICBsc1NldCgic2VlbkhlbHBlciIsICIxIik7CiAgICByZW1lbWJlcigpOwogICAgJCgicGxheSIpLmRpc2FibGVkID0gZmFsc2U7CiAgICBsb2FkVmVyc2lvbnMoKTsKICAgIHJlZnJlc2goKTsKICAgIHVwZGF0ZUZhY3RzKCk7CiAgICByZXR1cm4gdHJ1ZTsKICB9IGNhdGNoIChlKXsKICAgIHN0YXRlLm9ubGluZSA9IGZhbHNlOwogICAgc2V0Q29ubigiYmFkIiwgKGUgJiYgZS5zdGF0dXMgPT09IDQwMykgPyAidG9rZW4gcmVqZWN0ZWQiIDogIm5vIGhlbHBlciIpOwogICAgJCgicGxheSIpLmRpc2FibGVkID0gZmFsc2U7CiAgICAkKCJjb25uaGludCIpLmlubmVySFRNTCA9ICJMYXN0IGVycm9yOiA8Y29kZT4iICsgKGUubWVzc2FnZSB8fCBlKSArICI8L2NvZGU+IjsKICAgIHNob3dPZmZsaW5lKChlICYmIGUuc3RhdHVzID09PSA0MDMpID8gInRva2VuIiA6ICJibG9ja2VkIik7CiAgICByZXR1cm4gZmFsc2U7CiAgfQp9CgovKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSB2ZXJzaW9ucyAqLwpsZXQgdmVyc2lvbnNMb2FkZWQgPSBmYWxzZTsKYXN5bmMgZnVuY3Rpb24gbG9hZFZlcnNpb25zKCl7CiAgaWYgKHZlcnNpb25zTG9hZGVkIHx8ICFzdGF0ZS5vbmxpbmUpIHJldHVybjsKICBjb25zdCBzZWwgPSAkKCJ2ZXJzaW9uIik7CiAgdHJ5IHsKICAgIGNvbnN0IGogPSBhd2FpdCBqZ2V0KCIvYXBpL3ZlcnNpb25zIiwgMzAwMDApOwogICAgY29uc3Qgd2FudCA9IHNlbC5kYXRhc2V0LndhbnQgfHwgIjEuMjEuMTEiOwogICAgc2VsLmlubmVySFRNTCA9ICIiOwogICAgZm9yIChjb25zdCBpZCBvZiBqLnJlbGVhc2VzLnNsaWNlKDAsIDMwKSl7CiAgICAgIGNvbnN0IG8gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCJvcHRpb24iKTsgby52YWx1ZSA9IGlkOyBvLnRleHRDb250ZW50ID0gaWQ7CiAgICAgIHNlbC5hcHBlbmRDaGlsZChvKTsKICAgIH0KICAgIHNlbC52YWx1ZSA9IFsuLi5zZWwub3B0aW9uc10uc29tZShvID0+IG8udmFsdWUgPT09IHdhbnQpID8gd2FudCA6IChzZWwub3B0aW9uc1swXSB8fCB7fSkudmFsdWU7CiAgICB2ZXJzaW9uc0xvYWRlZCA9IHRydWU7CiAgfSBjYXRjaCAoZSl7CiAgICBzZWwuaW5uZXJIVE1MID0gJzxvcHRpb24gdmFsdWU9IjEuMjEuMTEiPjEuMjEuMTEgKHRoZSBsaXN0IGNvdWxkIG5vdCBiZSByZWFkKTwvb3B0aW9uPic7CiAgfQp9CgovKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBzZXNzaW9ucyAqLwpmdW5jdGlvbiBub3RlUHJvZ3Jlc3Mocyl7CiAgLy8gT25lIGxpbmUgb2YgcGxhaW4gbGFuZ3VhZ2UgZm9yIHdoYXRldmVyIHRoZSBuZXdlc3Qgc2Vzc2lvbiBpcyBkb2luZy4gVGhlcmUgaXMgbm8gbGlzdDogYQogIC8vIHNlc3Npb24gaXMgc2F2ZWQgZm9yIHlvdSB3aGVuIGl0IGVuZHMsIHNvIHRoZXJlIGlzIG5vdGhpbmcgdG8gcHJlc3MuCiAgaWYgKCFzKXsgJCgicGhhc2UiKS50ZXh0Q29udGVudCA9ICJSZWFkeSI7ICQoImluc3RhbmNlIikudGV4dENvbnRlbnQgPSAiIjsgcmV0dXJuOyB9CiAgY29uc3QgaW5zdCA9IHMuaW5zdGFuY2UgfHwge307CiAgY29uc3QgcCA9IHMucHJvZ3Jlc3MgfHwge307CiAgY29uc3QgYmFyID0gJCgiYmFyIik7CiAgJCgicGhhc2UiKS50ZXh0Q29udGVudCA9IHMucGhhc2VMYWJlbCB8fCBzLnBoYXNlIHx8IHMuc3RhdGU7CiAgY29uc3QgcGVyY2VudCA9IChwLnBlcmNlbnQgPT09IG51bGwgfHwgcC5wZXJjZW50ID09PSB1bmRlZmluZWQpID8gbnVsbCA6IHAucGVyY2VudDsKICBpZiAocy5zdGF0ZSA9PT0gInJ1bm5pbmciICYmIHBlcmNlbnQgPT09IG51bGwpewogICAgYmFyLmNsYXNzTmFtZSA9ICJiYXIgaW5kZXQiOwogICAgJCgicGN0IikudGV4dENvbnRlbnQgPSBwLnRvdGFsID8gKHAuZG9uZSArICIgLyAiICsgcC50b3RhbCkgOiAiIjsKICB9IGVsc2UgewogICAgYmFyLmNsYXNzTmFtZSA9ICJiYXIiOwogICAgYmFyLmZpcnN0Q2hpbGQuc3R5bGUud2lkdGggPSAocGVyY2VudCB8fCAocy5zdGF0ZSA9PT0gInJ1bm5pbmciID8gMCA6IDEwMCkpICsgIiUiOwogICAgJCgicGN0IikudGV4dENvbnRlbnQgPSBwZXJjZW50ID09PSBudWxsID8gIiIgOiBwZXJjZW50ICsgIiUgICgiICsgcC5kb25lICsgIiAvICIgKyBwLnRvdGFsICsgIikiOwogIH0KICAkKCJpbnN0YW5jZSIpLnRleHRDb250ZW50ID0gaW5zdC52ZXJzaW9uCiAgICA/ICIgwrcgIiArIGluc3QudmVyc2lvbiArICIgwrcgIiArIChpbnN0LmxvYWRlciB8fCAidmFuaWxsYSIpICsKICAgICAgKGluc3QubW9kcyAmJiBpbnN0Lm1vZHMubGVuZ3RoID8gIiDCtyAiICsgaW5zdC5tb2RzLmxlbmd0aCArICIgbW9kKHMpIiA6ICIiKQogICAgOiAiIjsKICAkKCJuZXRzdGF0IikudGV4dENvbnRlbnQgPSBzLmRvd25sb2FkZWRCeXRlcyA/ICJkb3dubG9hZGVkICIgKyBmbXQocy5kb3dubG9hZGVkQnl0ZXMpIDogIiI7CiAgJCgiY2hpcFJ1bm5pbmciKS50ZXh0Q29udGVudCA9IHMuc3RhdGUgPT09ICJydW5uaW5nIiA/ICJydW5uaW5nIiA6IChzLnNpZCA/ICJsYXN0IHNlc3Npb24iIDogImlkbGUiKTsKICAkKCJjaGlwUnVubmluZyIpLmNsYXNzTmFtZSA9ICJjaGlwIiArIChzLnN0YXRlID09PSAicnVubmluZyIgPyAiIG9uIiA6ICIiKTsKfQoKLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gbW9kcyAqLwphc3luYyBmdW5jdGlvbiByZW5kZXJNb2RzKCl7CiAgY29uc3QgaXRlbXMgPSBhd2FpdCBTdG9yZS5saXN0KCJtb2RzIik7CiAgY29uc3QgbGlzdCA9ICQoIm1vZGxpc3QiKTsKICBsaXN0LmlubmVySFRNTCA9ICIiOwogIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcyl7CiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoImxpIik7CiAgICBsaS5pbm5lckhUTUwgPSAnPHNwYW4gY2xhc3M9Im5tIj4nICsgaXRlbS5uYW1lICsgJzwvc3Bhbj48c3BhbiBjbGFzcz0idGFnIG1pbmUiPm1pbmU8L3NwYW4+JyArCiAgICAgICAgICAgICAgICAgICAnPHNwYW4gY2xhc3M9Im1ldGEiPicgKyAoaXRlbS5zaXplID8gZm10KGl0ZW0uc2l6ZSkgOiAiIikgKyAiPC9zcGFuPiI7CiAgICBjb25zdCBkZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCJidXR0b24iKTsgZGVsLmNsYXNzTmFtZSA9ICJ0aW55IjsgZGVsLnRleHRDb250ZW50ID0gInJlbW92ZSI7CiAgICBkZWwub25jbGljayA9IGFzeW5jICgpID0+IHsKICAgICAgYXdhaXQgU3RvcmUucmVtb3ZlKCJtb2RzIiwgaXRlbS5uYW1lKTsKICAgICAgaWYgKHN0YXRlLm9ubGluZSl7IHRyeSB7IGF3YWl0IGFwaSgiL2FwaS9sb2NhbG1vZHM/ZHJvcD0iICsgZW5jb2RlVVJJQ29tcG9uZW50KGl0ZW0ubmFtZSksIHttZXRob2Q6IlBPU1QifSk7IH0gY2F0Y2goZSl7fSB9CiAgICAgIGxvZ0xpbmUoInJlbW92ZWQgIiArIGl0ZW0ubmFtZSArICIgZnJvbSB0aGlzIGJyb3dzZXIiKTsKICAgICAgcmVuZGVyTW9kcygpOwogICAgfTsKICAgIGxpLmFwcGVuZENoaWxkKGRlbCk7CiAgICBsaXN0LmFwcGVuZENoaWxkKGxpKTsKICB9CiAgZm9yIChjb25zdCBzbHVnIG9mIHN0YXRlLnNsdWdzKXsKICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgibGkiKTsKICAgIGxpLmlubmVySFRNTCA9ICc8c3BhbiBjbGFzcz0ibm0iPicgKyAoc3RhdGUuc2x1Z3NNZXRhW3NsdWddIHx8IHNsdWcpICsgJzwvc3Bhbj4nICsKICAgICAgICAgICAgICAgICAgICc8c3BhbiBjbGFzcz0idGFnIGh1YiI+bW9kcmludGg8L3NwYW4+JzsKICAgIGNvbnN0IGRlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoImJ1dHRvbiIpOyBkZWwuY2xhc3NOYW1lID0gInRpbnkiOyBkZWwudGV4dENvbnRlbnQgPSAicmVtb3ZlIjsKICAgIGRlbC5vbmNsaWNrID0gKCkgPT4geyBzdGF0ZS5zbHVncyA9IHN0YXRlLnNsdWdzLmZpbHRlcihzID0+IHMgIT09IHNsdWcpOyBzYXZlU2x1Z3MoKTsgcmVuZGVyTW9kcygpOyB9OwogICAgbGkuYXBwZW5kQ2hpbGQoZGVsKTsKICAgIGxpc3QuYXBwZW5kQ2hpbGQobGkpOwogIH0KICBjb25zdCB0b3RhbCA9IGl0ZW1zLmxlbmd0aCArIHN0YXRlLnNsdWdzLmxlbmd0aDsKICAkKCJtb2Rjb3VudCIpLnRleHRDb250ZW50ID0gdG90YWwgPyB0b3RhbCArICIgYWRkZWQiIDogIm5vbmUgeWV0IjsKICAkKCJjaGlwTW9kcyIpLnRleHRDb250ZW50ID0gdG90YWwgPyB0b3RhbCArICIgbW9kKHMpIiA6ICJubyBtb2RzIjsKICAkKCJtb2RoaW50IikudGV4dENvbnRlbnQgPSB0b3RhbAogICAgPyAiWW91ciBqYXJzIGFyZSBzdG9yZWQgaW4gdGhpcyBicm93c2VyIGFuZCBoYW5kZWQgdG8gdGhlIGhlbHBlciBiZWZvcmUgZWFjaCBsYXVuY2guIiA6ICIiOwp9CmZ1bmN0aW9uIHNhdmVTbHVncygpewogIGxzU2V0KCJzbHVncyIsIEpTT04uc3RyaW5naWZ5KHN0YXRlLnNsdWdzKSk7CiAgbHNTZXQoInNsdWdzTWV0YSIsIEpTT04uc3RyaW5naWZ5KHN0YXRlLnNsdWdzTWV0YSkpOwp9CmZ1bmN0aW9uIGxvYWRTbHVncygpewogIHRyeSB7CiAgICBzdGF0ZS5zbHVncyA9IEpTT04ucGFyc2UobHNHZXQoInNsdWdzIikgfHwgIltdIik7CiAgICBzdGF0ZS5zbHVnc01ldGEgPSBKU09OLnBhcnNlKGxzR2V0KCJzbHVnc01ldGEiKSB8fCAie30iKTsKICB9IGNhdGNoKGUpeyBzdGF0ZS5zbHVncyA9IFtdOyBzdGF0ZS5zbHVnc01ldGEgPSB7fTsgfQp9CmFzeW5jIGZ1bmN0aW9uIGFkZEZpbGVzKGZpbGVzKXsKICBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZXMpewogICAgaWYgKCEvXC5qYXIkL2kudGVzdChmaWxlLm5hbWUpKXsgbG9nTGluZSgic2tpcHBlZCAiICsgZmlsZS5uYW1lICsgIiDigJQgbm90IGEgLmphciIsICJlIik7IGNvbnRpbnVlOyB9CiAgICBpZiAoZmlsZS5zaXplID4gNjQqMTAyNCoxMDI0KXsgbG9nTGluZSgic2tpcHBlZCAiICsgZmlsZS5uYW1lICsgIiDigJQgbGFyZ2VyIHRoYW4gNjQgTUIiLCAiZSIpOyBjb250aW51ZTsgfQogICAgYXdhaXQgU3RvcmUucHV0SW4oIm1vZHMiLCBmaWxlLm5hbWUsIGZpbGUpOwogICAgbG9nTGluZSgia2VwdCAiICsgZmlsZS5uYW1lICsgIiAoIiArIGZtdChmaWxlLnNpemUpICsgIikgaW4gdGhpcyBicm93c2VyIik7CiAgICBpZiAoc3RhdGUub25saW5lKXsKICAgICAgdHJ5IHsKICAgICAgICBjb25zdCByID0gYXdhaXQgKGF3YWl0IGFwaSgiL2FwaS9sb2NhbG1vZHMiLCB7IG1ldGhvZDoiUE9TVCIsCiAgICAgICAgICBoZWFkZXJzOnsgIlgtV2ViTUMtTW9kLU5hbWUiOiBmaWxlLm5hbWUgfSwgYm9keTogZmlsZSwgdGltZW91dDo2MDAwMCB9KSkuanNvbigpOwogICAgICAgIGxvZ0xpbmUoImhlbHBlciBhY2NlcHRlZCAiICsgci5uYW1lICsgKHIudGl0bGUgPyAiICgiICsgci50aXRsZSArICIgIiArIChyLnZlcnNpb258fCIiKSArICIpIiA6ICIiKSwgImciKTsKICAgICAgfSBjYXRjaCAoZSl7CiAgICAgICAgbG9nTGluZSgiaGVscGVyIHJlZnVzZWQgIiArIGZpbGUubmFtZSArICI6ICIgKyBlLm1lc3NhZ2UsICJlIik7CiAgICAgICAgYXdhaXQgU3RvcmUucmVtb3ZlKCJtb2RzIiwgZmlsZS5uYW1lKTsKICAgICAgfQogICAgfQogIH0KICBhd2FpdCBTdG9yZS5wZXJzaXN0KCk7CiAgcmVuZGVyTW9kcygpOwp9CmFzeW5jIGZ1bmN0aW9uIHB1c2hNb2RzKCl7CiAgY29uc3QgaXRlbXMgPSBhd2FpdCBTdG9yZS5saXN0KCJtb2RzIik7CiAgbGV0IHB1c2hlZCA9IDA7CiAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKXsKICAgIGNvbnN0IGJsb2IgPSBhd2FpdCBTdG9yZS5nZXRGcm9tKCJtb2RzIiwgaXRlbS5uYW1lKTsKICAgIGlmICghYmxvYikgY29udGludWU7CiAgICB0cnkgewogICAgICBhd2FpdCBhcGkoIi9hcGkvbG9jYWxtb2RzIiwgeyBtZXRob2Q6IlBPU1QiLCBoZWFkZXJzOnsgIlgtV2ViTUMtTW9kLU5hbWUiOiBpdGVtLm5hbWUgfSwKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9keTogYmxvYiwgdGltZW91dDo2MDAwMCB9KTsKICAgICAgcHVzaGVkKys7CiAgICB9IGNhdGNoIChlKXsgbG9nTGluZSgiY291bGQgbm90IGhhbmQgIiArIGl0ZW0ubmFtZSArICIgdG8gdGhlIGhlbHBlcjogIiArIGUubWVzc2FnZSwgImUiKTsgfQogIH0KICBpZiAocHVzaGVkKSBsb2dMaW5lKCJoYW5kZWQgIiArIHB1c2hlZCArICIgb2YgeW91ciBtb2QgamFyKHMpIHRvIHRoZSBoZWxwZXIiLCAiZyIpOwogIHJldHVybiBwdXNoZWQ7Cn0KYXN5bmMgZnVuY3Rpb24gc2VhcmNoTW9kcygpewogIGNvbnN0IHEgPSAkKCJzZWFyY2giKS52YWx1ZS50cmltKCk7CiAgaWYgKCFxKXsgJCgic2VhcmNoaGludCIpLnRleHRDb250ZW50ID0gIlR5cGUgc29tZXRoaW5nIHRvIHNlYXJjaCBmb3IuIjsgcmV0dXJuOyB9CiAgJCgicmVzdWx0cyIpLmlubmVySFRNTCA9ICIiOwogICQoInNlYXJjaGhpbnQiKS5jbGFzc05hbWUgPSAiaGludCI7ICQoInNlYXJjaGhpbnQiKS50ZXh0Q29udGVudCA9ICJzZWFyY2hpbmfigKYiOwogIGNvbnN0IG1jID0gJCgidmVyc2lvbiIpLnZhbHVlIHx8ICIxLjIxLjExIjsKICB0cnkgewogICAgY29uc3QgaiA9IGF3YWl0IGpnZXQoIi9hcGkvc2VhcmNoP3E9IiArIGVuY29kZVVSSUNvbXBvbmVudChxKSArICImbWM9IiArIGVuY29kZVVSSUNvbXBvbmVudChtYyksIDQ1MDAwKTsKICAgIGlmICghai5yZXN1bHRzLmxlbmd0aCl7ICQoInNlYXJjaGhpbnQiKS50ZXh0Q29udGVudCA9ICJub3RoaW5nIG1hdGNoZWQuIjsgcmV0dXJuOyB9CiAgICAkKCJzZWFyY2hoaW50IikudGV4dENvbnRlbnQgPSBqLnJlc3VsdHMubGVuZ3RoICsgIiByZXN1bHRzIGZyb20gTW9kcmludGggKEZhYnJpYywgIiArIG1jICsgIikiOwogICAgZm9yIChjb25zdCByIG9mIGoucmVzdWx0cyl7CiAgICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgibGkiKTsKICAgICAgbGkuaW5uZXJIVE1MID0gJzxkaXYgY2xhc3M9Im5tIj48Yj4nICsgci50aXRsZSArICI8L2I+PGRpdj4iICsgci5kZXNjcmlwdGlvbiArICI8L2Rpdj48L2Rpdj4iOwogICAgICBjb25zdCBhZGQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCJidXR0b24iKTsKICAgICAgYWRkLmNsYXNzTmFtZSA9ICJ0aW55IjsKICAgICAgYWRkLnRleHRDb250ZW50ID0gc3RhdGUuc2x1Z3MuaW5jbHVkZXMoci5zbHVnKSA/ICJhZGRlZCIgOiAiYWRkIjsKICAgICAgYWRkLmRpc2FibGVkID0gc3RhdGUuc2x1Z3MuaW5jbHVkZXMoci5zbHVnKTsKICAgICAgYWRkLm9uY2xpY2sgPSAoKSA9PiB7CiAgICAgICAgc3RhdGUuc2x1Z3MucHVzaChyLnNsdWcpOyBzdGF0ZS5zbHVnc01ldGFbci5zbHVnXSA9IHIudGl0bGU7CiAgICAgICAgc2F2ZVNsdWdzKCk7IHJlbmRlck1vZHMoKTsKICAgICAgICBhZGQudGV4dENvbnRlbnQgPSAiYWRkZWQiOyBhZGQuZGlzYWJsZWQgPSB0cnVlOwogICAgICAgIGxvZ0xpbmUoIndpbGwgZmV0Y2ggIiArIHIudGl0bGUgKyAiIGZyb20gTW9kcmludGggd2hlbiB5b3UgcGxheSIpOwogICAgICB9OwogICAgICBsaS5hcHBlbmRDaGlsZChhZGQpOwogICAgICAkKCJyZXN1bHRzIikuYXBwZW5kQ2hpbGQobGkpOwogICAgfQogIH0gY2F0Y2ggKGUpewogICAgJCgic2VhcmNoaGludCIpLmNsYXNzTmFtZSA9ICJ3YXJuIjsKICAgICQoInNlYXJjaGhpbnQiKS50ZXh0Q29udGVudCA9ICJzZWFyY2ggZmFpbGVkOiAiICsgZS5tZXNzYWdlOwogIH0KfQoKLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gc3RhdHVzICsgbG9nICovCmZ1bmN0aW9uIGxvZ0xpbmUodGV4dCwgY2xzKXsKICBjb25zdCBlbCA9ICQoImxvZyIpOwogIGNvbnN0IGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoImRpdiIpOwogIGlmIChjbHMpIGRpdi5jbGFzc05hbWUgPSBjbHM7CiAgZWxzZSBpZiAoL1xiRVJST1JcYnxFeGNlcHRpb258RkFJTEVEfGNyYXNoL2kudGVzdCh0ZXh0KSkgZGl2LmNsYXNzTmFtZSA9ICJlIjsKICBlbHNlIGlmICgvZmFicmljfExvYWRpbmcgXGQrIG1vZHN8aXMgcnVubmluZ3xhY2NlcHRlZHxyZXN0b3JlZHxkZWxldGVkfGtlcHQgL2kudGVzdCh0ZXh0KSkgZGl2LmNsYXNzTmFtZSA9ICJnIjsKICBlbHNlIGlmICgvXlxbcGFnZVxdLy50ZXN0KHRleHQpKSBkaXYuY2xhc3NOYW1lID0gImQiOwogIGRpdi50ZXh0Q29udGVudCA9IHRleHQ7CiAgZWwuYXBwZW5kQ2hpbGQoZGl2KTsKICB3aGlsZSAoZWwuY2hpbGROb2Rlcy5sZW5ndGggPiAxMjAwKSBlbC5yZW1vdmVDaGlsZChlbC5maXJzdENoaWxkKTsKICBlbC5zY3JvbGxUb3AgPSBlbC5zY3JvbGxIZWlnaHQ7Cn0KCmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2goKXsKICBpZiAoIXN0YXRlLm9ubGluZSkgcmV0dXJuOwogIGxldCBkYXRhOwogIHRyeSB7IGRhdGEgPSBhd2FpdCBqZ2V0KCIvYXBpL3Nlc3Npb25zIiwgODAwMCk7IH0gY2F0Y2goZSl7IHJldHVybjsgfQogIGNvbnN0IHByZXZpb3VzID0gc3RhdGUuc2Vzc2lvbnMgfHwgW107CiAgc3RhdGUuc2Vzc2lvbnMgPSBkYXRhLnNlc3Npb25zIHx8IFtdOwogIGNvbnN0IHJ1bm5pbmcgPSBzdGF0ZS5zZXNzaW9ucy5maWx0ZXIocyA9PiBzLnN0YXRlID09PSAicnVubmluZyIpOwogIGNvbnN0IG5ld2VzdCA9IHN0YXRlLnNlc3Npb25zWzBdIHx8IG51bGw7CiAgaWYgKG5ld2VzdCkgc3RhdGUuc2VsZWN0ZWQgPSBuZXdlc3Quc2lkOwogIG5vdGVQcm9ncmVzcyhuZXdlc3QpOwogICQoImxvZ1N0YXRlIikudGV4dENvbnRlbnQgPSBydW5uaW5nLmxlbmd0aAogICAgPyBydW5uaW5nLmxlbmd0aCArIChydW5uaW5nLmxlbmd0aCA9PT0gMSA/ICIgcnVubmluZyIgOiAiIHJ1bm5pbmciKSA6ICJpZGxlIjsKICBKb3VybmFsLnVwZGF0ZSh7IHBoYXNlOiAkKCJwaGFzZSIpLnRleHRDb250ZW50LCBzdGF0ZTogcnVubmluZy5sZW5ndGggPyAicnVubmluZyIgOiAiaWRsZSIsCiAgICAgICAgICAgICAgICAgICBzdGFydGVkQXQ6IG5ld2VzdCAmJiBuZXdlc3Quc3RhcnRlZEF0ID8gbmV3ZXN0LnN0YXJ0ZWRBdCAqIDEwMDAgOiBudWxsIH0pOwogIEpvdXJuYWwuZmx1c2goKTsKICB1cGRhdGVGYWN0cygpOwogIC8vIEEgc2Vzc2lvbiB0aGF0IGVuZGVkIHdoaWxlIHdlIHdlcmUgd2F0Y2hpbmc6IGl0cyBmaWxlcyBhcmUgdGFrZW4gYW5kIHN0b3JlZCBoZXJlLCB0aGVuIHRoZQogIC8vIGhlbHBlciBpcyB0b2xkIHRvIGRlbGV0ZSB0aGUgc2FuZGJveC4gTm9ib2R5IGhhcyB0byBwcmVzcyBhbnl0aGluZy4KICBmb3IgKGNvbnN0IHMgb2Ygc3RhdGUuc2Vzc2lvbnMpewogICAgY29uc3Qgd2FzID0gcHJldmlvdXMuZmluZCh4ID0+IHguc2lkID09PSBzLnNpZCkgfHwge307CiAgICBpZiAod2FzLnN0YXRlID09PSAicnVubmluZyIgJiYgcy5zdGF0ZSAhPT0gInJ1bm5pbmciKSBhd2FpdCBzZXNzaW9uRW5kZWQocyk7CiAgfQogIHBvbGxMb2coKTsKfQoKYXN5bmMgZnVuY3Rpb24gcG9sbExvZygpewogIGlmICghc3RhdGUub25saW5lIHx8ICFzdGF0ZS5zZWxlY3RlZCkgcmV0dXJuOwogIGNvbnN0IHNpZCA9IHN0YXRlLnNlbGVjdGVkOwogIGNvbnN0IHNpbmNlID0gc3RhdGUuc2luY2Vbc2lkXSB8fCAwOwogIHRyeSB7CiAgICBjb25zdCBqID0gYXdhaXQgamdldCgiL2FwaS9sb2c/aWQ9IiArIGVuY29kZVVSSUNvbXBvbmVudChzaWQpICsgIiZzaW5jZT0iICsgc2luY2UsIDgwMDApOwogICAgaWYgKHNpZCA9PT0gc3RhdGUuc2VsZWN0ZWQpewogICAgICBmb3IgKGNvbnN0IGxpbmUgb2Ygai5saW5lcyl7IGxvZ0xpbmUobGluZSk7IEpvdXJuYWwubm90ZShsaW5lKTsgfQogICAgfQogICAgc3RhdGUuc2luY2Vbc2lkXSA9IGoubmV4dDsKICAgIGF3YWl0IEpvdXJuYWwuZmx1c2goKTsKICB9IGNhdGNoKGUpe30KfQoKYXN5bmMgZnVuY3Rpb24gc2Vzc2lvbkVuZGVkKHMpewogIGNvbnN0IHJlcyA9IHMucmVzdWx0OwogIGlmICghcmVzKSByZXR1cm47CiAgbG9nTGluZSgic2Vzc2lvbiAiICsgcy5zaWQgKyAiIGZpbmlzaGVkIOKAlCAiICsgcmVzLmZpbGVzICsgIiBmaWxlKHMpLCAiICsgZm10KHJlcy5ieXRlcykgKwogICAgICAgICAgKHJlcy53b3JsZHMgJiYgcmVzLndvcmxkcy5sZW5ndGggPyAiLCB3b3JsZChzKTogIiArIHJlcy53b3JsZHMuam9pbigiLCAiKSA6ICIiKSwgImciKTsKICBsZXQgY2xlYW51cCA9IG51bGw7CiAgdHJ5IHsKICAgIGNvbnN0IGJsb2IgPSBhd2FpdCAoYXdhaXQgYXBpKCIvYXBpL2J1bmRsZS56aXA/aWQ9IiArIGVuY29kZVVSSUNvbXBvbmVudChzLnNpZCksCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHRpbWVvdXQ6MTgwMDAwIH0pKS5ibG9iKCk7CiAgICAvLyBzYXZlZCBoZXJlLCBpbiB0aGlzIGJyb3dzZXIsIHdpdGhvdXQgYmVpbmcgYXNrZWQ6IHRoZSB3b3JsZCBjb21lcyBiYWNrIG9uIHRoZSBuZXh0IFBMQVkKICAgIGF3YWl0IFN0b3JlLnB1dCgibGFzdC1zZXNzaW9uLnppcCIsIGJsb2IpOwogICAgYXdhaXQgU3RvcmUucGVyc2lzdCgpOwogICAgbG9nTGluZSgic3RvcmVkICIgKyBmbXQoYmxvYi5zaXplKSArICIgaW4gIiArIFN0b3JlLmtpbmQsICJnIik7CiAgfSBjYXRjaCAoZSl7CiAgICBpZiAoZSAmJiBlLnN0YXR1cyA9PT0gNDA0KSBsb2dMaW5lKCJ0aGF0IHNlc3Npb24ncyBmaWxlcyB3ZXJlIGFscmVhZHkgY29sbGVjdGVkIiwgImciKTsKICAgIGVsc2UgbG9nTGluZSgiY291bGQgbm90IHN0b3JlIHRoZSBzZXNzaW9uOiAiICsgZS5tZXNzYWdlLCAiZSIpOwogIH0KICB0cnkgewogICAgY2xlYW51cCA9IGF3YWl0IChhd2FpdCBhcGkoIi9hcGkvY2xlYW51cD9pZD0iICsgZW5jb2RlVVJJQ29tcG9uZW50KHMuc2lkKSwKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbWV0aG9kOiJQT1NUIiwgdGltZW91dDo2MDAwMCB9KSkuanNvbigpOwogICAgbG9nTGluZSgiaGVscGVyIGRlbGV0ZWQgIiArIGNsZWFudXAucGF0aCArCiAgICAgICAgICAgIChjbGVhbnVwLnJlbW92ZWQgPyAiICgiICsgZm10KGNsZWFudXAucmVtb3ZlZCkgKyAiIGZyZWVkKSIgOiAiIiksICJnIik7CiAgfSBjYXRjaCAoZSl7IGxvZ0xpbmUoImNvdWxkIG5vdCBhc2sgdGhlIGhlbHBlciB0byBjbGVhbiB1cDogIiArIGUubWVzc2FnZSwgImUiKTsgfQogIHNob3dSZWNlaXB0KHJlcywgY2xlYW51cCwgcy5zaWQpOwp9CgpmdW5jdGlvbiBzaG93UmVjZWlwdChyZXMsIGNsZWFudXAsIHNpZCl7CiAgaWYgKCFyZXMgJiYgIWNsZWFudXApIHJldHVybjsKICBjb25zdCBib3ggPSAkKCJyZWNlaXB0Iik7CiAgYm94LnN0eWxlLmRpc3BsYXkgPSAiIjsgYm94LmlubmVySFRNTCA9ICIiOwogIGNvbnN0IGggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCJoMyIpOwogIGgudGV4dENvbnRlbnQgPSAiU2Vzc2lvbiBmaW5pc2hlZCDigJQgbm90aGluZyBsZWZ0IG9uIHRoaXMgY29tcHV0ZXIiOwogIGJveC5hcHBlbmRDaGlsZChoKTsKICBjb25zdCBsaW5lcyA9IFtdOwogIGlmIChyZXMpewogICAgbGluZXMucHVzaCgocmVzLndvcmxkcyAmJiByZXMud29ybGRzLmxlbmd0aCkKICAgICAgPyAiPGI+IiArIHJlcy53b3JsZHMubGVuZ3RoICsgIiB3b3JsZChzKTwvYj4gc2F2ZWQgdG8gdGhpcyBicm93c2VyOiAiICsgcmVzLndvcmxkcy5qb2luKCIsICIpCiAgICAgIDogIk5vIHdvcmxkIHdhcyBjcmVhdGVkIGluIHRoaXMgc2Vzc2lvbi4iKTsKICAgIGxpbmVzLnB1c2goIjxiPiIgKyByZXMuZmlsZXMgKyAiIGZpbGVzPC9iPiAoIiArIGZtdChyZXMuYnl0ZXMpICsgIikga2VwdCBpbiB0aGlzIGJyb3dzZXIgYW5kIGJ5ICIgKwogICAgICAgICAgICAgICAidGhlIGhlbHBlciwgc28gdGhlIG5leHQgbGF1bmNoIHN0YXJ0cyBmcm9tIHRoZW0gd2hpY2hldmVyIHBhZ2UgeW91IHVzZS4iKTsKICAgIGlmIChyZXMuaGFzQ3Jhc2gpIGxpbmVzLnB1c2goIkEgY3Jhc2ggcmVwb3J0IHdhcyBpbmNsdWRlZCDigJQgaXQgaXMgaW4gdGhlIHppcCBiZWxvdy4iKTsKICB9CiAgaWYgKGNsZWFudXAgJiYgY2xlYW51cC5nb25lKQogICAgbGluZXMucHVzaCgiVGhlIGhlbHBlciBkZWxldGVkIDxiPiIgKyBjbGVhbnVwLnBhdGggKyAiPC9iPiIgKwogICAgICAgICAgICAgICAoY2xlYW51cC5yZW1vdmVkID8gIiAoIiArIGZtdChjbGVhbnVwLnJlbW92ZWQpICsgIiBmcmVlZCkiIDogIiIpICsgIi4iKTsKICBjb25zdCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCJkaXYiKTsKICBkaXYuY2xhc3NOYW1lID0gImxpbmUiOwogIGRpdi5pbm5lckhUTUwgPSBsaW5lcy5tYXAobCA9PiAi4pyUICIgKyBsKS5qb2luKCI8YnI+Iik7CiAgYm94LmFwcGVuZENoaWxkKGRpdik7CiAgY29uc3QgYWN0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoImRpdiIpOwogIGFjdHMuc3R5bGUubWFyZ2luVG9wID0gIjExcHgiOwogIGFjdHMuaW5uZXJIVE1MID0gJzxhIGhyZWY9IiMiIGlkPSJkbHppcCI+ZG93bmxvYWQgdGhlIHNlc3Npb24gemlwPC9hPiAmbmJzcDvCtyZuYnNwOyAnICsKICAgICAgICAgICAgICAgICAgICc8YSBocmVmPSIjIiBpZD0iZGVsc2Vzc2lvbiI+Zm9yZ2V0IGV2ZXJ5dGhpbmcgdGhpcyBwYWdlIHN0b3JlZDwvYT4nOwogIGJveC5hcHBlbmRDaGlsZChhY3RzKTsKICAkKCJkbHppcCIpLm9uY2xpY2sgPSBhc3luYyAoZSkgPT4gewogICAgZS5wcmV2ZW50RGVmYXVsdCgpOwogICAgY29uc3QgYmxvYiA9IGF3YWl0IFN0b3JlLmdldChzaWQgPyAic2Vzc2lvbi0iICsgc2lkICsgIi56aXAiIDogImxhc3Qtc2Vzc2lvbi56aXAiKTsKICAgIGlmICghYmxvYikgcmV0dXJuOwogICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoImEiKTsKICAgIGEuaHJlZiA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7IGEuZG93bmxvYWQgPSAid2VibWMtc2Vzc2lvbi56aXAiOyBhLmNsaWNrKCk7CiAgfTsKICAkKCJkZWxzZXNzaW9uIikub25jbGljayA9IGFzeW5jIChlKSA9PiB7CiAgICBlLnByZXZlbnREZWZhdWx0KCk7CiAgICBhd2FpdCBTdG9yZS5yZW1vdmUoInNlc3Npb24iLCAibGFzdC1zZXNzaW9uLnppcCIpOwogICAgZm9yIChjb25zdCBtIG9mIGF3YWl0IFN0b3JlLmxpc3QoIm1vZHMiKSkgYXdhaXQgU3RvcmUucmVtb3ZlKCJtb2RzIiwgbS5uYW1lKTsKICAgIHN0YXRlLnNsdWdzID0gW107IHNhdmVTbHVncygpOwogICAgYm94LnN0eWxlLmRpc3BsYXkgPSAibm9uZSI7IHJlbmRlck1vZHMoKTsKICAgIGxvZ0xpbmUoImNsZWFyZWQgZXZlcnl0aGluZyB0aGlzIHBhZ2UgaGFkIHN0b3JlZCBpbiB0aGUgYnJvd3NlciIsICJnIik7CiAgfTsKfQpmdW5jdGlvbiBzaG93UmVjb3Zlcnkoail7CiAgY29uc3QgYm94ID0gJCgicmVjZWlwdCIpOwogIGJveC5zdHlsZS5kaXNwbGF5ID0gIiI7IGJveC5pbm5lckhUTUwgPSAiIjsKICBib3guaW5uZXJIVE1MID0gIjxoMz5BbiBlYXJsaWVyIHNlc3Npb24gc3RvcHBlZCBiZWZvcmUgdGhpcyBicm93c2VyIHNhdmVkIGl0PC9oMz4iICsKICAgICc8ZGl2IGNsYXNzPSJsaW5lIj5JdHMgbG9nIHN1cnZpdmVkIGhlcmU6IDxiPicgKyBKb3VybmFsLnN1bW1hcnkoKSArICI8L2I+PC9kaXY+IiArCiAgICAnPGRpdiBjbGFzcz0iY29uc29sZSIgc3R5bGU9Im1heC1oZWlnaHQ6MTcwcHg7bWFyZ2luLXRvcDo5cHg7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1lZGdlKTsnICsKICAgICdib3JkZXItcmFkaXVzOjZweCI+JyArIGoubGluZXMuc2xpY2UoLTE0KS5qb2luKCI8YnI+IikgKyAiPC9kaXY+IiArCiAgICAnPGRpdiBzdHlsZT0ibWFyZ2luLXRvcDoxMXB4Ij48YSBocmVmPSIjIiBpZD0iZm9yZ2V0am91cm5hbCI+Zm9yZ2V0IGl0PC9hPjwvZGl2Pic7CiAgJCgiZm9yZ2V0am91cm5hbCIpLm9uY2xpY2sgPSBhc3luYyAoZSkgPT4gewogICAgZS5wcmV2ZW50RGVmYXVsdCgpOyBhd2FpdCBKb3VybmFsLmNsZWFyKCk7IGJveC5zdHlsZS5kaXNwbGF5ID0gIm5vbmUiOwogIH07Cn0KCi8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IGxhdW5jaCAqLwphc3luYyBmdW5jdGlvbiBsYXVuY2goKXsKICBpZiAoIXN0YXRlLm9ubGluZSl7IGhhbmRPdmVyKCk7IHJldHVybjsgfQogIGNvbnN0IGxvYWRlciA9ICQoImxvYWRlciIpLnZhbHVlID09PSAiY3VzdG9tIgogICAgPyAoJCgibG9hZGVyY3VzdG9tIikudmFsdWUudHJpbSgpIHx8ICJzdGFibGUiKSA6ICQoImxvYWRlciIpLnZhbHVlOwogICQoImxvZyIpLmlubmVySFRNTCA9ICIiOwogIGxvZ0xpbmUoIltwYWdlXSBhc2tpbmcgZm9yICIgKyAoJCgidmVyc2lvbiIpLnZhbHVlIHx8ICIxLjIxLjExIikgKwogICAgICAgICAgKGxvYWRlciA9PT0gIm5vbmUiID8gIiAodmFuaWxsYSkiIDogIiB3aXRoIEZhYnJpYyAiICsgbG9hZGVyKSk7CiAgdHJ5IHsKICAgIGF3YWl0IHB1c2hNb2RzKCk7CiAgICBpZiAoJCgicmVzdG9yZSIpLmNoZWNrZWQpewogICAgICBjb25zdCBibG9iID0gYXdhaXQgU3RvcmUuZ2V0KCJsYXN0LXNlc3Npb24uemlwIik7CiAgICAgIGlmIChibG9iICYmIGJsb2Iuc2l6ZSl7CiAgICAgICAgbG9nTGluZSgicHV0dGluZyB0aGlzIGJyb3dzZXIncyBsYXN0IHNlc3Npb24gYmFjayAoIiArIGZtdChibG9iLnNpemUpICsgIikiKTsKICAgICAgICB0cnkgeyBhd2FpdCBhcGkoIi9hcGkvcmVzdG9yZSIsIHsgbWV0aG9kOiJQT1NUIiwgYm9keTogYmxvYiwgdGltZW91dDoxMjAwMDAgfSk7IH0KICAgICAgICBjYXRjaCAoZSl7IGxvZ0xpbmUoImNvdWxkIG5vdCByZXN0b3JlIChhIHNlc3Npb24gbXVzdCBleGlzdCBmaXJzdCk6ICIgKyBlLm1lc3NhZ2UpOyB9CiAgICAgIH0KICAgIH0KICAgIGNvbnN0IHIgPSBhd2FpdCAoYXdhaXQgYXBpKCIvYXBpL2xhdW5jaCIsIHsgbWV0aG9kOiJQT1NUIiwgYm9keTogSlNPTi5zdHJpbmdpZnkoewogICAgICB2ZXJzaW9uOiAkKCJ2ZXJzaW9uIikudmFsdWUgfHwgIjEuMjEuMTEiLAogICAgICBsb2FkZXJLaW5kOiAiZmFicmljIiwKICAgICAgbG9hZGVyOiBsb2FkZXIsCiAgICAgIG1vZHM6IHN0YXRlLnNsdWdzLAogICAgICB1c2VybmFtZTogJCgidXNlcm5hbWUiKS52YWx1ZS50cmltKCkgfHwgIlBsYXllciIsCiAgICAgIG1lbW9yeTogJCgibWVtb3J5IikudmFsdWUudHJpbSgpIHx8ICIyRyIsCiAgICAgIGFzc2V0czogJCgiYXNzZXRzIikudmFsdWUgPT09ICIxIiwKICAgICAgcmVsYXk6IHJlbGF5Q2hvaWNlKCksCiAgICAgIHR1bm5lbFNlcnZlcjogJCgic2VydmVyIikudmFsdWUudHJpbSgpIHx8IG51bGwsCiAgICAgIHR1bm5lbEV2ZXJ5dGhpbmc6ICQoInByb3h5QWxsIikuY2hlY2tlZCwKICAgICAgcmVzdHJpY3RlZDogJCgicmVzdHJpY3RlZCIpLmNoZWNrZWQsCiAgICAgIC8vIHRoZSBoZWxwZXIga2VlcHMgaXRzIG93biBjb3B5IG9mIHRoZSBsYXN0IHNlc3Npb24sIHNvICJyZXN0b3JlIiBhbHNvIGRlY2lkZXMgd2hldGhlciB0bwogICAgICAvLyBzdGFydCBmcm9tIHRoYXQgd2hlbiB0aGlzIGJyb3dzZXIgaGFzIG5vdGhpbmcgKGEgZGlmZmVyZW50IG9yaWdpbiBkb2VzIGV4YWN0bHkgdGhhdCkKICAgICAgcmVzdG9yZTogJCgicmVzdG9yZSIpLmNoZWNrZWQKICAgIH0pfSkpLmpzb24oKTsKICAgIHN0YXRlLnJlc3VsdCA9IG51bGw7CiAgICBsb2dMaW5lKCJbcGFnZV0gc2Vzc2lvbiAiICsgci5pZCArICIgc3RhcnRlZCIsICJnIik7CiAgICBzdGF0ZS5zZWxlY3RlZCA9IHIuaWQ7CiAgICBzdGF0ZS5zaW5jZVtyLmlkXSA9IDA7CiAgICBpZiAoIXN0YXRlLnRpbWVyKSBzdGF0ZS50aW1lciA9IHNldEludGVydmFsKHJlZnJlc2gsIDEwMDApOwogICAgcmVmcmVzaCgpOwogIH0gY2F0Y2ggKGUpewogICAgbG9nTGluZSgiY291bGQgbm90IHN0YXJ0OiAiICsgZS5tZXNzYWdlLCAiZSIpOwogICAgJCgicGhhc2UiKS50ZXh0Q29udGVudCA9ICJDb3VsZCBub3Qgc3RhcnQiOwogIH0KfQoKLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gdGhlIGZhY3RzIHJvdyAqLwphc3luYyBmdW5jdGlvbiB1cGRhdGVGYWN0cygpewogIGNvbnN0IGggPSBzdGF0ZS5oZWxsbyB8fCB7fTsKICBjb25zdCBlc3QgPSBhd2FpdCBTdG9yZS51c2FnZSgpOwogIGNvbnN0IHJ1bnRpbWUgPSBoLmpyZUZldGNoZWQgPyAiZmV0Y2hlZCBpbnRvIHRoZSBzYW5kYm94IgogICAgICAgICAgICAgICAgOiAoaC5qYXZhID8gU3RyaW5nKGguamF2YSkuc3BsaXQoIi8iKS5zbGljZSgtMywgLTIpWzBdIHx8ICJvbiB0aGlzIG1hY2hpbmUiIDogIuKAlCIpOwogIGlmICgkKCJmYWN0SmF2YSIpKSAkKCJmYWN0SmF2YSIpLnRleHRDb250ZW50ID0gaC5qYXZhID8gKGguamF2YU1ham9yID8gIkphdmEgIiArIGguamF2YU1ham9yIDogImphdmEiKSA6ICJub3QgbG9va2VkIGZvciB5ZXQiOwogIGlmICgkKCJmYWN0SmF2YVN1YiIpKSAkKCJmYWN0SmF2YVN1YiIpLnRleHRDb250ZW50ID0gcnVudGltZTsKICBpZiAoJCgiZmFjdFNhbmRib3giKSkgJCgiZmFjdFNhbmRib3giKS50ZXh0Q29udGVudCA9IGguc2FuZGJveCA/IGguc2FuZGJveC5yZXBsYWNlKC9eLipcLy8sICIiKSA6ICLigJQiOwogIGlmICgkKCJmYWN0U2FuZGJveFN1YiIpKSAkKCJmYWN0U2FuZGJveFN1YiIpLnRleHRDb250ZW50ID0gImRlbGV0ZWQgd2hlbiB0aGUgc2Vzc2lvbiBlbmRzIjsKICBpZiAoJCgiZmFjdFN0b3JhZ2UiKSkgJCgiZmFjdFN0b3JhZ2UiKS50ZXh0Q29udGVudCA9IGZtdChlc3QudXNlZCk7CiAgaWYgKCQoImZhY3RTdG9yYWdlU3ViIikpICQoImZhY3RTdG9yYWdlU3ViIikudGV4dENvbnRlbnQgPSBTdG9yZS5raW5kICsgIiBpbiB0aGlzIGJyb3dzZXIiOwogIGlmICh0eXBlb2Ygc2hvd1JlbGF5SW5Vc2UgPT09ICJmdW5jdGlvbiIpIHNob3dSZWxheUluVXNlKCk7CiAgaWYgKCQoImZhY3RTZXNzaW9ucyIpKSAkKCJmYWN0U2Vzc2lvbnMiKS50ZXh0Q29udGVudCA9IChzdGF0ZS5zZXNzaW9ucyB8fCBbXSkubGVuZ3RoCiAgICA/IChzdGF0ZS5zZXNzaW9ucyB8fCBbXSkubGVuZ3RoICsgIiB0aGlzIHZpc2l0IiA6ICJub25lIHlldCI7Cn0KCi8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IGRpYWdub3N0aWNzICovCmFzeW5jIGZ1bmN0aW9uIGRpYWdub3N0aWNzKCl7CiAgY29uc3QgaCA9IHN0YXRlLmhlbGxvIHx8IHt9LCBwbGF0Zm9ybSA9IGgucGxhdGZvcm0gfHwge307CiAgY29uc3QgZXN0ID0gYXdhaXQgU3RvcmUudXNhZ2UoKTsKICBjb25zdCBtb2RzID0gYXdhaXQgU3RvcmUubGlzdCgibW9kcyIpOwogIGNvbnN0IGxvZyA9ICQoImxvZyIpLnRleHRDb250ZW50LnRyaW0oKS5zcGxpdCgiXG4iKTsKICBjb25zdCB0ZXh0ID0gWwogICAgIndlYm1jLWhlbHBlciBkaWFnbm9zdGljcyIsCiAgICAiaGVscGVyICAgICA6ICIgKyAoaC52ZXJzaW9uIHx8ICJub3QgY29ubmVjdGVkIikgKwogICAgICAocGxhdGZvcm0ub3MgPyAiICAoIiArIHBsYXRmb3JtLm9zICsgIiAiICsgcGxhdGZvcm0udmVyc2lvbiArICIsICIgKyBwbGF0Zm9ybS5hcmNoICsgIikiIDogIiIpLAogICAgInBhZ2UgICAgICAgOiAiICsgKGhvc3RlZCA/ICJob3N0ZWQgY29weSBhdCAiICsgbG9jYXRpb24uaG9zdCA6ICJzZXJ2ZWQgYnkgdGhlIGhlbHBlciIpLAogICAgImhlbHBlciB1cmwgOiAiICsgKHN0YXRlLmhlbHBlciB8fCAiKG5vbmUpIikgKyAiICB0b2tlbjogIiArIChzdGF0ZS50b2tlbiA/ICJzdG9yZWQiIDogIm5vbmUiKSwKICAgICJkb3dubG9hZHMgIDogIiArIChoLnByb3h5IHx8ICI/IikgKyAoaC5yZWxheSA/ICIgIHJlbGF5OiAiICsgaC5yZWxheSA6ICIiKSwKICAgICJzZXNzaW9ucyAgIDogIiArIChzdGF0ZS5zZXNzaW9ucyB8fCBbXSkubWFwKHMgPT4gcy5zaWQgKyAiPSIgKyBzLnN0YXRlKS5qb2luKCIsICIpLAogICAgImJyb3dzZXIgc3RvOiAiICsgU3RvcmUua2luZCArICIsICIgKyBmbXQoZXN0LnVzZWQpICsgIiBvZiAiICsgZm10KGVzdC5xdW90YSksCiAgICAibXkgbW9kcyAgICA6ICIgKyAobW9kcy5sZW5ndGggPyBtb2RzLm1hcChtID0+IG0ubmFtZSArICIgKCIgKyBmbXQobS5zaXplKSArICIpIikuam9pbigiLCAiKSA6ICJub25lIiksCiAgICAibW9kcmludGggICA6ICIgKyAoc3RhdGUuc2x1Z3MubGVuZ3RoID8gc3RhdGUuc2x1Z3Muam9pbigiLCAiKSA6ICJub25lIiksCiAgICAidmVyc2lvbiAgICA6ICIgKyAoJCgidmVyc2lvbiIpLnZhbHVlIHx8ICI/IikgKyAiICBsb2FkZXI6ICIgKyAkKCJsb2FkZXIiKS52YWx1ZSArCiAgICAgICIgIG1lbW9yeTogIiArICQoIm1lbW9yeSIpLnZhbHVlICsgIiAgYXNzZXRzOiAiICsgKCQoImFzc2V0cyIpLnZhbHVlID09PSAiMSIgPyAieWVzIiA6ICJubyIpLAogICAgInJlbGF5IHNldCAgOiAiICsgKCQoInJlbGF5IikudmFsdWUudHJpbSgpIHx8ICJubyIpLAogICAgIiIsICItLS0gdGhlIGhlbHBlcidzIGxvZywgbGFzdCAyMDAgbGluZXMgLS0tIiwgLi4ubG9nLnNsaWNlKC0yMDApCiAgXS5qb2luKCJcbiIpOwogIHRyeSB7CiAgICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh0ZXh0KTsKICAgICQoImRpYWdzdGF0ZSIpLnRleHRDb250ZW50ID0gImNvcGllZCB0byB0aGUgY2xpcGJvYXJkIOKAlCBwYXN0ZSBpdCBpbnRvIHRoZSBpc3N1ZSI7CiAgfSBjYXRjaCAoZSl7CiAgICBjb25zdCB0YSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoInRleHRhcmVhIik7CiAgICB0YS52YWx1ZSA9IHRleHQ7CiAgICB0YS5zdHlsZS5jc3NUZXh0ID0gInBvc2l0aW9uOmZpeGVkO3RvcDoxMHB4O2xlZnQ6MTBweDt3aWR0aDo5MCU7aGVpZ2h0OjUwJTt6LWluZGV4Ojk5IjsKICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQodGEpOyB0YS5zZWxlY3QoKTsKICAgICQoImRpYWdzdGF0ZSIpLnRleHRDb250ZW50ID0gInNlbGVjdCBhbGwgYW5kIGNvcHkgKHRoZSBjbGlwYm9hcmQgQVBJIHdhcyByZWZ1c2VkKSI7CiAgfQp9CgovKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBiYWNrZ3JvdW5kICovCihmdW5jdGlvbiBiYWNrZ3JvdW5kKCl7CiAgY29uc3QgYmcgPSAkKCJiZyIpOwogIGxldCBmcmFtZSA9IG51bGwsIG14ID0gMC41LCBteSA9IDAuNDsKICBmdW5jdGlvbiBwYWludCgpewogICAgZnJhbWUgPSBudWxsOwogICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnN0eWxlLnNldFByb3BlcnR5KCItLW14IiwgKG14ICogMTAwKS50b0ZpeGVkKDIpICsgIiUiKTsKICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zdHlsZS5zZXRQcm9wZXJ0eSgiLS1teSIsIChteSAqIDEwMCkudG9GaXhlZCgyKSArICIlIik7CiAgfQogIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCJwb2ludGVybW92ZSIsIChlKSA9PiB7CiAgICBpZiAobW90aW9uKCkgPT09ICJzdGlsbCIpIHJldHVybjsKICAgIG14ID0gZS5jbGllbnRYIC8gd2luZG93LmlubmVyV2lkdGg7CiAgICBteSA9IGUuY2xpZW50WSAvIHdpbmRvdy5pbm5lckhlaWdodDsKICAgIGlmIChmcmFtZSA9PT0gbnVsbCkgZnJhbWUgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUocGFpbnQpOwogIH0sIHsgcGFzc2l2ZTp0cnVlIH0pOwogIGZ1bmN0aW9uIG1vdGlvbigpeyB0cnkgeyByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oTFMgKyAibW90aW9uIikgfHwgImZvbGxvdyI7IH0gY2F0Y2goZSl7IHJldHVybiAiZm9sbG93IjsgfSB9CiAgd2luZG93LmFwcGx5TW90aW9uID0gKHZhbHVlKSA9PiB7CiAgICB0cnkgeyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShMUyArICJtb3Rpb24iLCB2YWx1ZSk7IH0gY2F0Y2goZSl7fQogICAgYmcuc3R5bGUub3BhY2l0eSA9IHZhbHVlID09PSAic3RpbGwiID8gIjAuNTUiIDogIjEiOwogIH07CiAgd2luZG93LmFwcGx5RnggPSAodmFsdWUpID0+IHsKICAgIGRvY3VtZW50LmJvZHkuY2xhc3NOYW1lID0gZG9jdW1lbnQuYm9keS5jbGFzc05hbWUucmVwbGFjZSgvXGJmeC1cUysvZywgIiIpLnRyaW0oKTsKICAgIGlmICh2YWx1ZSAmJiB2YWx1ZSAhPT0gIm5vbmUiKSBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5hZGQodmFsdWUpOwogICAgdHJ5IHsgbG9jYWxTdG9yYWdlLnNldEl0ZW0oTFMgKyAiZngiLCB2YWx1ZSB8fCAibm9uZSIpOyB9IGNhdGNoKGUpe30KICB9Owp9KSgpOwoKLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gd2lyaW5nICovCmNvbnN0IFNIT1JUQ1VUX05BTUUgPSAiV2ViTUMgSGVscGVyIjsKY29uc3QgU0hFTExfTElORSA9ICJEPSQobWt0ZW1wIC1kIC90bXAvd2VibWMuWFhYWFhYKSAmJiBjZCBcIiREXCIgJiYgY3VybCAtZnNTTCAiICsKICAiaHR0cHM6Ly9hbXBoaWJpYW5kZXYuZ2l0aHViLmlvL3dlYm1jLWxhdW5jaGVyL2hlbHBlci93ZWJtYy1oZWxwZXIuemlwIC1vIGguemlwICYmICIgKwogICJkaXR0byAteCAtayBoLnppcCAuICYmIHJtIGguemlwICYmIFdFQk1DX1RSQU5TSUVOVD0xIFdFQk1DX1BBR0VfVVJMPSIgKwogICJodHRwczovL2FtcGhpYmlhbmRldi5naXRodWIuaW8vd2VibWMtbGF1bmNoZXIvbG9jYWwuaHRtbCAuL3dlYm1jLWhlbHBlci5jb21tYW5kIjsKYXN5bmMgZnVuY3Rpb24gc3RhcnRWaWFTaG9ydGN1dCgpewogIGNvbnN0IG5vdGUgPSAkKCJraWNrcyIpOwogIG5vdGUudGV4dENvbnRlbnQgPSAiYXNraW5nIFNob3J0Y3V0cyBmb3IgXHUyMDFjIiArIFNIT1JUQ1VUX05BTUUgKyAiXHUyMDFk4oCmIjsKICBsb2NhdGlvbi5ocmVmID0gInNob3J0Y3V0czovL3J1bi1zaG9ydGN1dD9uYW1lPSIgKyBlbmNvZGVVUklDb21wb25lbnQoU0hPUlRDVVRfTkFNRSk7CiAgZm9yIChsZXQgaSA9IDA7IGkgPCA0MDsgaSsrKXsKICAgIGF3YWl0IG5ldyBQcm9taXNlKHIgPT4gc2V0VGltZW91dChyLCAxNTAwKSk7CiAgICBpZiAoYXdhaXQgcHJvYmUoZmFsc2UpKXsgbm90ZS50ZXh0Q29udGVudCA9ICJ0aGUgaGVscGVyIGlzIHVwIOKAlCBwcmVzcyBQTEFZIjsgcmV0dXJuOyB9CiAgICBub3RlLnRleHRDb250ZW50ID0gIndhaXRpbmcgZm9yIHRoZSBoZWxwZXLigKYgIiArICgoaSArIDEpICogMS41KS50b0ZpeGVkKDApICsgInMiOwogIH0KICBub3RlLnRleHRDb250ZW50ID0gIml0IGRpZCBub3QgY29tZSB1cC4gSXMgdGhlIFNob3J0Y3V0IG5hbWVkIGV4YWN0bHkgXHUyMDFjIiArIFNIT1JUQ1VUX05BTUUgKwogICAgIlx1MjAxZCwgYW5kIGlzIEFsbG93IFJ1bm5pbmcgU2NyaXB0cyBvbj8iOwp9CiQoImNvbm5lY3QiKS5vbmNsaWNrID0gKCkgPT4geyBzdGF0ZS5oZWxwZXIgPSAkKCJoZWxwZXIiKS52YWx1ZS50cmltKCkucmVwbGFjZSgvXC8kLywgIiIpOyBwcm9iZSh0cnVlKTsgfTsKJCgicGxheSIpLm9uY2xpY2sgPSBsYXVuY2g7CgokKCJoZWxwIikub25jbGljayA9ICgpID0+ICQoImFib3V0Iikuc2hvd01vZGFsKCk7CiQoImFib3V0Y2xvc2UiKS5vbmNsaWNrID0gKCkgPT4gJCgiYWJvdXQiKS5jbG9zZSgpOwokKCJjb3B5ZGlhZyIpLm9uY2xpY2sgPSBkaWFnbm9zdGljczsKJCgia2lja2hlbHBlciIpLm9uY2xpY2sgPSBzdGFydFZpYVNob3J0Y3V0OwokKCJsb2dDbGVhciIpLm9uY2xpY2sgPSAoKSA9PiB7ICQoImxvZyIpLmlubmVySFRNTCA9ICIiOyB9OwokKCJkcmF3ZXJTdHJpcFJvdyIpLm9uY2xpY2sgPSAoZSkgPT4gewogIGlmIChlLnRhcmdldCAmJiBlLnRhcmdldC5pZCA9PT0gImxvZ0hpZGUiKSByZXR1cm47CiAgJCgibG9nSGlkZSIpLmNsaWNrKCk7Cn07CiQoImxvZ0hpZGUiKS5vbmNsaWNrID0gKCkgPT4gewogIC8vIFRoZSBhY3Rpdml0eSBkcmF3ZXI6IGNvbGxhcHNlZCBpdCBpcyBhIHN0cmlwIHlvdSBjYW4gd2F0Y2ggcHJvZ3Jlc3MgaW4sIGV4cGFuZGVkIGl0IGlzIHRoZQogIC8vIHdob2xlIGxvZyBhY3Jvc3MgdGhlIHdpZHRoIG9mIHRoZSB3aW5kb3cuCiAgY29uc3Qgb3BlbiA9IGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnRvZ2dsZSgiZHJhd2VyLW9wZW4iKTsKICAkKCJsb2dIaWRlIikudGV4dENvbnRlbnQgPSBvcGVuID8gIkhpZGUgbG9nIiA6ICJTaG93IGxvZyI7Cn07CiQoImNvcHlsaW5lIikub25jbGljayA9IGFzeW5jICgpID0+IHsKICB0cnkgeyBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChTSEVMTF9MSU5FKTsgJCgiY29weW9rIikudGV4dENvbnRlbnQgPSAiY29waWVkIjsgfQogIGNhdGNoIChlKXsgJCgiY29weW9rIikudGV4dENvbnRlbnQgPSAic2VsZWN0IGl0IGFuZCBjb3B5IGJ5IGhhbmQiOyB9Cn07Ci8vIE9uZSByZWxheSBzZXR0aW5nLCB0aHJlZSBob25lc3QgbWVhbmluZ3M6IGF1dG9tYXRpYyAodGhlIGhlbHBlciBkZWNpZGVzLCBhbmQgaXQga25vd3MgYWJvdXQgdGhlCi8vIGJ1aWx0LWluIHJlbGF5cyksIG5ldmVyLCBvciBhIFVSTCBvZiB5b3VyIG93bi4KZnVuY3Rpb24gcmVsYXlDaG9pY2UoKXsKICBjb25zdCBtb2RlID0gJCgicmVsYXlNb2RlIikudmFsdWU7CiAgaWYgKG1vZGUgPT09ICJvZmYiKSByZXR1cm4gIm9mZiI7CiAgaWYgKG1vZGUgPT09ICJjdXN0b20iKSByZXR1cm4gJCgicmVsYXkiKS52YWx1ZS50cmltKCkgfHwgbnVsbDsKICByZXR1cm4gbnVsbDsgICAgICAgICAgICAgICAgICAgICAgICAvLyB0aGUgaGVscGVyIHJlc29sdmVzIGl0LCBwcm9iaW5nIHRoZSBidWlsdC1pbiBsaXN0Cn0KZnVuY3Rpb24gcmVsYXlNb2RlQ2hhbmdlZCgpewogIGNvbnN0IGN1c3RvbSA9ICQoInJlbGF5TW9kZSIpLnZhbHVlID09PSAiY3VzdG9tIjsKICAkKCJyZWxheUN1c3RvbVJvdyIpLnN0eWxlLmRpc3BsYXkgPSBjdXN0b20gPyAiYmxvY2siIDogIm5vbmUiOwogIGtlZXAoInJlbGF5TW9kZSIpOwogIHNob3dSZWxheUluVXNlKCk7Cn0KZnVuY3Rpb24gc2hvd1JlbGF5SW5Vc2UoKXsKICBjb25zdCBlbCA9ICQoInJlbGF5SW5Vc2UiKTsKICBpZiAoIWVsKSByZXR1cm47CiAgY29uc3QgaCA9IHN0YXRlLmhlbGxvIHx8IHt9OwogIGNvbnN0IG1vZGUgPSAkKCJyZWxheU1vZGUiKS52YWx1ZTsKICBpZiAobW9kZSA9PT0gIm9mZiIpeyBlbC50ZXh0Q29udGVudCA9ICJTZXQgdG8gY29ubmVjdCBkaXJlY3RseTogbm8gcmVsYXkgaXMgdXNlZCBhdCBhbGwuIjsgcmV0dXJuOyB9CiAgaWYgKGgucmVsYXkpIGVsLnRleHRDb250ZW50ID0gIlRoZSBoZWxwZXIgaXMgZG93bmxvYWRpbmcgdGhyb3VnaCAiICsgaC5yZWxheSArICIuIjsKICBlbHNlIGlmIChoLnJlbGF5QnVpbHRJbikKICAgIGVsLnRleHRDb250ZW50ID0gIk5vIHJlbGF5IG5lZWRlZCB5ZXQg4oCUICIgKyBoLnJlbGF5QnVpbHRJbiArCiAgICAgICAgICAgICAgICAgICAgICIgYnVpbHQtaW4gb25lKHMpIGFyZSB0aGVyZSBpZiB0aGlzIG5ldHdvcmsgYmxvY2tzIE1vamFuZyBvciBhIGdhbWUgcG9ydC4iOwogIGVsc2UgaWYgKG1vZGUgPT09ICJjdXN0b20iICYmICQoInJlbGF5IikudmFsdWUudHJpbSgpKQogICAgZWwudGV4dENvbnRlbnQgPSAiWW91ciByZWxheSBpcyB1c2VkIGZvciB0aGUgbmV4dCBsYXVuY2guIjsKICBlbHNlIGVsLnRleHRDb250ZW50ID0gIkRvd25sb2FkcyBnbyBzdHJhaWdodCB0byBNb2phbmcsIHdoaWNoIGlzIHJpZ2h0IHVubGVzcyB5b3VyIG5ldHdvcmsgYmxvY2tzIGl0LiI7Cn0KZnVuY3Rpb24gcmVsYXlVcmxUb1Rlc3QoKXsKICBjb25zdCBtb2RlID0gJCgicmVsYXlNb2RlIikudmFsdWU7CiAgaWYgKG1vZGUgPT09ICJjdXN0b20iKSByZXR1cm4gJCgicmVsYXkiKS52YWx1ZS50cmltKCkucmVwbGFjZSgvXC8kLywgIiIpOwogIGlmIChtb2RlID09PSAib2ZmIikgcmV0dXJuICIiOwogIGNvbnN0IGggPSBzdGF0ZS5oZWxsbyB8fCB7fTsKICByZXR1cm4gaC5yZWxheSA/IFN0cmluZyhoLnJlbGF5KS5yZXBsYWNlKC9cLyQvLCAiIikgOiAiIjsKfQokKCJyZWxheVRlc3QiKS5vbmNsaWNrID0gYXN5bmMgKCkgPT4gewogIGNvbnN0IGxpbmUgPSAkKCJyZWxheVN0YXRlIik7CiAgY29uc3QgdXJsID0gcmVsYXlVcmxUb1Rlc3QoKTsKICBpZiAoJCgicmVsYXlNb2RlIikudmFsdWUgPT09ICJvZmYiKXsKICAgIGxpbmUudGV4dENvbnRlbnQgPSAidGhpcyBpcyBzZXQgdG8gY29ubmVjdCBkaXJlY3RseSwgc28gdGhlcmUgaXMgbm90aGluZyB0byB0ZXN0IjsKICAgIHJldHVybjsKICB9CiAgaWYgKCF1cmwpewogICAgbGluZS50ZXh0Q29udGVudCA9ICJubyByZWxheSB0byB0ZXN0IHlldDogdGhlIGhlbHBlciBoYXMgbm90IHJlcG9ydGVkIG9uZS4gU3RhcnQgYSBzZXNzaW9uIG9uIGEgIgogICAgICAgICAgICAgICAgICAgICArICJibG9ja2VkIG5ldHdvcmssIG9yIGNob29zZSDigJxNeSBvd24gcmVsYXnigJ0gYW5kIHBhc3RlIGl0cyBhZGRyZXNzLiI7CiAgICByZXR1cm47CiAgfQogIGxpbmUudGV4dENvbnRlbnQgPSAiYXNraW5nICIgKyB1cmwgKyAi4oCmIjsKICB0cnkgewogICAgY29uc3QgciA9IGF3YWl0IGZldGNoKHVybCArICIvaGVhbHRoIiwgeyBjYWNoZToibm8tc3RvcmUiIH0pOwogICAgY29uc3QgaiA9IGF3YWl0IHIuanNvbigpOwogICAgY29uc3QgaG9zdHMgPSAoai5maWxlcyB8fCBqLnByZWZpeGVzIHx8IFtdKS5sZW5ndGg7CiAgICBsaW5lLnRleHRDb250ZW50ID0gaiAmJiBqLm9rCiAgICAgID8gIml0IGFuc3dlcnMiICsgKGhvc3RzID8gIiwgYW5kIGtub3dzICIgKyBob3N0cyArICIgaG9zdHMiIDogIiIpICsKICAgICAgICAoai50dW5uZWwgPyAiLCBhbmQgY2FycmllcyBnYW1lIGNvbm5lY3Rpb25zIiA6ICIiKSArICIuIgogICAgICA6ICJpdCBhbnN3ZXJlZCBzb21ldGhpbmcgdW5leHBlY3RlZCI7CiAgICBrZWVwKCJyZWxheSIpOwogIH0gY2F0Y2ggKGUpewogICAgbGluZS50ZXh0Q29udGVudCA9ICJubyBhbnN3ZXIgZnJvbSBpdCAoaXMgdGhlIFVSTCByaWdodCwgYW5kIGlzIGl0IGRlcGxveWVkPykiOwogIH0KfTsKJCgicmVsYXlNb2RlIikuYWRkRXZlbnRMaXN0ZW5lcigiY2hhbmdlIiwgcmVsYXlNb2RlQ2hhbmdlZCk7CiQoInJlbGF5IikuYWRkRXZlbnRMaXN0ZW5lcigiY2hhbmdlIiwgKCkgPT4geyBrZWVwKCJyZWxheSIpOyBzaG93UmVsYXlJblVzZSgpOyB9KTsKJCgic2VydmVyIikuYWRkRXZlbnRMaXN0ZW5lcigiY2hhbmdlIiwgKCkgPT4ga2VlcCgic2VydmVyIikpOwpmdW5jdGlvbiBrZWVwKGtleSl7CiAgdHJ5IHsgbG9jYWxTdG9yYWdlLnNldEl0ZW0oTFMgKyBrZXksICQoa2V5KS52YWx1ZS50cmltKCkpOyB9IGNhdGNoKGUpe30KfQokKCJzdGF5Iikub25jbGljayA9IChlKSA9PiB7CiAgZS5wcmV2ZW50RGVmYXVsdCgpOwogIHRyeSB7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKExTICsgInN0YXkiLCAiMSIpOyBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShMUyArICJyZWRpcmVjdEZhaWxlZCIpOyB9IGNhdGNoKGUyKXt9CiAgbG9nTGluZSgidGhpcyBwYWdlIHdpbGwgc3RheSBoZXJlIGZyb20gbm93IG9uIGluc3RlYWQgb2YgaGFuZGluZyB0aGUgdGFiIG92ZXIiKTsKfTsKJCgiZnhTZWxlY3QiKS5vbmNoYW5nZSA9ICgpID0+IGFwcGx5RngoJCgiZnhTZWxlY3QiKS52YWx1ZSk7CiQoIm1vdGlvblNlbGVjdCIpLm9uY2hhbmdlID0gKCkgPT4gYXBwbHlNb3Rpb24oJCgibW90aW9uU2VsZWN0IikudmFsdWUpOwokKCJwcm94eUFsbCIpLm9uY2hhbmdlID0gKCkgPT4gewogIHRyeSB7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKExTICsgInByb3h5QWxsIiwgJCgicHJveHlBbGwiKS5jaGVja2VkID8gIjEiIDogIjAiKTsgfSBjYXRjaChlKXt9CiAgbG9nTGluZSgkKCJwcm94eUFsbCIpLmNoZWNrZWQKICAgID8gInRoZSBnYW1lJ3Mgb3duIGNvbm5lY3Rpb25zIHdpbGwgZ28gdGhyb3VnaCB0aGUgcmVsYXkgKG5lZWRzIHRoZSByZWxheSBVUkwpIgogICAgOiAidGhlIGdhbWUgd2lsbCBjb25uZWN0IGRpcmVjdGx5IGFnYWluIik7Cn07CiQoInJlc3RyaWN0ZWQiKS5vbmNoYW5nZSA9ICgpID0+IHsKICB0cnkgeyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShMUyArICJyZXN0cmljdGVkIiwgJCgicmVzdHJpY3RlZCIpLmNoZWNrZWQgPyAiMSIgOiAiMCIpOyB9IGNhdGNoKGUpe30KICBsb2dMaW5lKCQoInJlc3RyaWN0ZWQiKS5jaGVja2VkCiAgICA/ICJyZXN0cmljdGVkIG1vZGU6IG91ciBvd24gSmF2YSwgZmV0Y2hlZCBpbnRvIHRoZSBzZXNzaW9uJ3MgZm9sZGVyIgogICAgOiAicmVzdHJpY3RlZCBtb2RlIG9mZjogdGhlIG1hY2hpbmUncyBKYXZhIG1heSBiZSB1c2VkIGFnYWluIik7Cn07CiQoInZlcnNpb24iKS5vbmNoYW5nZSA9ICgpID0+IHsKICBpZiAoJCgidmVyc2lvbkJpZyIpKSAkKCJ2ZXJzaW9uQmlnIikudGV4dENvbnRlbnQgPSAkKCJ2ZXJzaW9uIikudmFsdWU7Cn07CiQoImxvYWRlciIpLm9uY2hhbmdlID0gKCkgPT4gewogICQoImxvYWRlcmN1c3RvbSIpLnN0eWxlLmRpc3BsYXkgPSAkKCJsb2FkZXIiKS52YWx1ZSA9PT0gImN1c3RvbSIgPyAiIiA6ICJub25lIjsKfTsKJCgibWVtb3J5Iikub25pbnB1dCA9ICgpID0+IHsgJCgiY2hpcE1lbW9yeSIpLnRleHRDb250ZW50ID0gJCgibWVtb3J5IikudmFsdWUgfHwgIjJHIjsgfTsKJCgiYXNzZXRzIikub25jaGFuZ2UgPSAoKSA9PiB7CiAgJCgiY2hpcEFzc2V0cyIpLnRleHRDb250ZW50ID0gJCgiYXNzZXRzIikudmFsdWUgPT09ICIxIiA/ICJhc3NldHM6IGRvd25sb2FkIiA6ICJhc3NldHM6IHNraXBwZWQiOwp9OwokKCJkcm9wIikub25jbGljayA9ICgpID0+ICQoInBpY2tlciIpLmNsaWNrKCk7CiQoInBpY2tlciIpLm9uY2hhbmdlID0gKCkgPT4geyBhZGRGaWxlcyhbLi4uJCgicGlja2VyIikuZmlsZXNdKTsgJCgicGlja2VyIikudmFsdWUgPSAiIjsgfTsKZm9yIChjb25zdCBldiBvZiBbImRyYWdlbnRlciIsImRyYWdvdmVyIl0pCiAgJCgiZHJvcCIpLmFkZEV2ZW50TGlzdGVuZXIoZXYsIChlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgJCgiZHJvcCIpLmNsYXNzTGlzdC5hZGQoIm92ZXIiKTsgfSk7CmZvciAoY29uc3QgZXYgb2YgWyJkcmFnbGVhdmUiLCJkcm9wIl0pCiAgJCgiZHJvcCIpLmFkZEV2ZW50TGlzdGVuZXIoZXYsICgpID0+ICQoImRyb3AiKS5jbGFzc0xpc3QucmVtb3ZlKCJvdmVyIikpOwokKCJkcm9wIikuYWRkRXZlbnRMaXN0ZW5lcigiZHJvcCIsIChlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsKICBhZGRGaWxlcyhbLi4uKGUuZGF0YVRyYW5zZmVyID8gZS5kYXRhVHJhbnNmZXIuZmlsZXMgOiBbXSldKTsgfSk7CndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCJkcmFnb3ZlciIsIChlKSA9PiBlLnByZXZlbnREZWZhdWx0KCkpOwp3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigiZHJvcCIsIChlKSA9PiBlLnByZXZlbnREZWZhdWx0KCkpOwokKCJkb2JzZWFyY2giKS5vbmNsaWNrID0gc2VhcmNoTW9kczsKJCgic2VhcmNoIikuYWRkRXZlbnRMaXN0ZW5lcigia2V5ZG93biIsIChlKSA9PiB7IGlmIChlLmtleSA9PT0gIkVudGVyIikgc2VhcmNoTW9kcygpOyB9KTsKJCgib3BlbmxvY2FsIikub25jbGljayA9IChlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgd2luZG93Lm9wZW4oImh0dHA6Ly8xMjcuMC4wLjE6NzY0NS8iLCAiX2JsYW5rIiwgIm5vb3BlbmVyIik7IH07CiQoIm9wZW5sb2NhbDIiKS5vbmNsaWNrID0gKGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyB3aW5kb3cub3BlbigiaHR0cDovLzEyNy4wLjAuMTo3NjQ1LyIsICJfYmxhbmsiLCAibm9vcGVuZXIiKTsgfTsKCi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gc3RhcnQtdXAgKi8KKGZ1bmN0aW9uIGluaXQoKXsKICAvLyBBIGxhdW5jaGVyIHBhZ2UgaGFuZHMgaXRzIGNob2ljZXMgb3ZlciBpbiB0aGUgZnJhZ21lbnQ7IHRoaXMgcGFnZSBzdGFydHMgdGhlIGdhbWUgb24gYXJyaXZhbC4KICBjb25zdCB3YW50ZWQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKGxvY2F0aW9uLmhhc2gucmVwbGFjZSgvXiMvLCAiIikpOwogIGlmICh3YW50ZWQuZ2V0KCJwbGF5IikpewogICAgaWYgKHdhbnRlZC5nZXQoInYiKSkgJCgidmVyc2lvbiIpLmRhdGFzZXQud2FudCA9IHdhbnRlZC5nZXQoInYiKTsKICAgIGlmICh3YW50ZWQuZ2V0KCJsIikpewogICAgICBjb25zdCBsID0gd2FudGVkLmdldCgibCIpOwogICAgICBpZiAoWyJzdGFibGUiLCJsYXRlc3QiLCJub25lIl0uaW5jbHVkZXMobCkpICQoImxvYWRlciIpLnZhbHVlID0gbDsKICAgICAgZWxzZSB7ICQoImxvYWRlciIpLnZhbHVlID0gImN1c3RvbSI7ICQoImxvYWRlcmN1c3RvbSIpLnZhbHVlID0gbDsgJCgibG9hZGVyY3VzdG9tIikuc3R5bGUuZGlzcGxheSA9ICIiOyB9CiAgICB9CiAgICBpZiAod2FudGVkLmdldCgibSIpKXsKICAgICAgc3RhdGUuc2x1Z3MgPSB3YW50ZWQuZ2V0KCJtIikuc3BsaXQoIiwiKS5tYXAoeCA9PiB4LnRyaW0oKSkuZmlsdGVyKEJvb2xlYW4pOwogICAgICBzYXZlU2x1Z3MoKTsKICAgIH0KICAgIGlmICh3YW50ZWQuZ2V0KCJ1IikpICQoInVzZXJuYW1lIikudmFsdWUgPSB3YW50ZWQuZ2V0KCJ1Iik7CiAgICBpZiAod2FudGVkLmdldCgibWVtIikpeyAkKCJtZW1vcnkiKS52YWx1ZSA9IHdhbnRlZC5nZXQoIm1lbSIpOyAkKCJjaGlwTWVtb3J5IikudGV4dENvbnRlbnQgPSB3YW50ZWQuZ2V0KCJtZW0iKTsgfQogICAgaWYgKHdhbnRlZC5nZXQoInJlbGF5IikpICQoInJlbGF5IikudmFsdWUgPSB3YW50ZWQuZ2V0KCJyZWxheSIpOwogICAgc3RhdGUuYXV0b1BsYXkgPSB0cnVlOwogIH0KICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigibWVzc2FnZSIsIChlKSA9PiB7CiAgICBpZiAoZS5kYXRhICYmIGUuZGF0YS53ZWJtYyA9PT0gImhlbGxvIiAmJiBlLnNvdXJjZSkKICAgICAgZS5zb3VyY2UucG9zdE1lc3NhZ2UoeyB3ZWJtYzoiaGVsbG8tYmFjayIsIG5hbWU6IndlYm1jLWhlbHBlciIsIHZlcnNpb246IjAuMS4wIiB9LCAiKiIpOwogIH0pOwogIGxvYWRTbHVncygpOwogIHJlbmRlck1vZHMoKTsKICB0cnkgewogICAgJCgicmVsYXkiKS52YWx1ZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKExTICsgInJlbGF5IikgfHwgIiI7CiAgICAkKCJyZWxheU1vZGUiKS52YWx1ZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKExTICsgInJlbGF5TW9kZSIpIHx8ICJhdXRvIjsKICAgICQoInJlbGF5Q3VzdG9tUm93Iikuc3R5bGUuZGlzcGxheSA9ICQoInJlbGF5TW9kZSIpLnZhbHVlID09PSAiY3VzdG9tIiA/ICJibG9jayIgOiAibm9uZSI7CiAgICAkKCJzZXJ2ZXIiKS52YWx1ZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKExTICsgInNlcnZlciIpIHx8ICIiOwogICAgY29uc3QgZnggPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMUyArICJmeCIpIHx8ICJmeC1nbG93IjsKICAgIGNvbnN0IG1vdGlvbiA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKExTICsgIm1vdGlvbiIpIHx8ICJmb2xsb3ciOwogICAgJCgiZnhTZWxlY3QiKS52YWx1ZSA9IGZ4OwogICAgJCgibW90aW9uU2VsZWN0IikudmFsdWUgPSBtb3Rpb247CiAgICBhcHBseUZ4KGZ4KTsKICAgIGFwcGx5TW90aW9uKG1vdGlvbik7CiAgICAkKCJwcm94eUFsbCIpLmNoZWNrZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMUyArICJwcm94eUFsbCIpID09PSAiMSI7CiAgICAkKCJyZXN0cmljdGVkIikuY2hlY2tlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKExTICsgInJlc3RyaWN0ZWQiKSA9PT0gIjEiOwogIH0gY2F0Y2goZSl7fQogIC8vIGEgc29mdCBhcnJpdmFsIHJhdGhlciB0aGFuIGEgaGFyZCBjdXQKICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCIucGFuZWwiKS5hbmltYXRlKAogICAgW3sgb3BhY2l0eTowLCB0cmFuc2Zvcm06InRyYW5zbGF0ZVkoNnB4KSIgfSwgeyBvcGFjaXR5OjEsIHRyYW5zZm9ybToibm9uZSIgfV0sCiAgICB7IGR1cmF0aW9uOjM0MCwgZWFzaW5nOiJlYXNlLW91dCIgfSk7CiAgJCgiaGVscGVyIikudmFsdWUgPSBzdGF0ZS5oZWxwZXIgfHwgImh0dHA6Ly8xMjcuMC4wLjE6NzY0NSI7CiAgaWYgKGhvc3RlZCl7CiAgICAkKCJ6aXBkbCIpLmhyZWYgPSAiaGVscGVyL3dlYm1jLWhlbHBlci56aXAiOwogICAgJCgib3BlbmxvY2FsMiIpLnN0eWxlLmRpc3BsYXkgPSAiIjsKICAgICQoInN0YXkiKS5zdHlsZS5kaXNwbGF5ID0gIiI7CiAgfQogIGlmICgvTWFjL2kudGVzdChuYXZpZ2F0b3IudXNlckFnZW50KSl7CiAgICAkKCJzaGVsbGxpbmUiKS50ZXh0Q29udGVudCA9IFNIRUxMX0xJTkU7CiAgICAkKCJzaG9ydGN1dGJveCIpLnN0eWxlLmRpc3BsYXkgPSAiIjsKICB9CiAgY29uc3Qgd2hlcmUgPSBjb25uZWN0aW9uKCk7CiAgaWYgKHN0YXRlLmhlbHBlcil7CiAgICBzZXRDb25uKCJidXN5IiwgImNvbnRhY3RpbmfigKYiKTsKICAgIHByb2JlKGZhbHNlKS50aGVuKChvaykgPT4gewogICAgICBpZiAob2sgJiYgc3RhdGUuYXV0b1BsYXkpeyBzdGF0ZS5hdXRvUGxheSA9IGZhbHNlOyBsYXVuY2goKTsgfQogICAgfSk7CiAgfSBlbHNlIHsKICAgIHNldENvbm4oImJhZCIsICJub3QgY29ubmVjdGVkIik7CiAgICBzaG93T2ZmbGluZSgiZG93biIpOwogICAgJCgiaGVscGVyIikudmFsdWUgPSAiaHR0cDovLzEyNy4wLjAuMTo3NjQ1IjsKICB9CiAgaWYgKHdoZXJlID09PSAibm9uZSIpewogICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoImxvYWQiLCAoKSA9PiB7CiAgICAgIGlmIChjb25uZWN0aW9uKCkgIT09ICJub25lIil7ICQoImhlbHBlciIpLnZhbHVlID0gc3RhdGUuaGVscGVyOyBwcm9iZShmYWxzZSk7IH0KICAgIH0sIHsgb25jZTp0cnVlIH0pOwogIH0KICAvLyBBIGhvc3RlZCBjb3B5IGhhbmRzIHRoZSB0YWIgdG8gdGhlIGhlbHBlcidzIG93biBwYWdlIGltbWVkaWF0ZWx5LiBOb3RoaW5nIGlzIGFza2VkIGZpcnN0OiB0aGlzCiAgLy8gYnJvd3NlciB3aWxsIG5vdCBsZXQgYSBnaXRodWIuaW8gcGFnZSBmZXRjaCAxMjcuMC4wLjEsIHNvIHRoZSBsb2NhbCBwYWdlIGlzIHRoZSBvbmx5IHBsYWNlIHRoZQogIC8vIGxhdW5jaGVyIGNhbiB3b3JrLCBhbmQgbWFraW5nIHRoZSB2aXNpdG9yIHByZXNzIFBMQVkgdG8gZGlzY292ZXIgdGhhdCBpcyBhIHN0ZXAgZm9yIG5vdGhpbmcuCiAgLy8KICAvLyBMYW5kaW5nIGJhY2sgaGVyZSB3aXRoaW4gYSBmZXcgc2Vjb25kcyBtZWFucyB0aGUgcmVkaXJlY3QgZGlkIG5vdCBsYW5kIChubyBoZWxwZXIgcnVubmluZywgc28KICAvLyB0aGUgYnJvd3NlciBzaG93ZWQgaXRzIG93biBlcnJvciBwYWdlIGFuZCB0aGUgdmlzaXRvciBjYW1lIGJhY2spLCBhbmQgdGhlbiB0aGlzIHBhZ2Ugc3RvcHMKICAvLyByZWRpcmVjdGluZyBhbmQgb2ZmZXJzIHRoZSB3YXkgdG8gZ2V0IHRoZSBoZWxwZXIgaW5zdGVhZCBvZiBib3VuY2luZyB0aGVtIGFnYWluLgogIGlmIChob3N0ZWQpewogICAgbGV0IHN0YXkgPSBmYWxzZSwgZmFpbGVkID0gZmFsc2UsIHRyaWVkID0gMDsKICAgIHRyeSB7CiAgICAgIHN0YXkgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMUyArICJzdGF5IikgPT09ICIxIjsKICAgICAgZmFpbGVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oTFMgKyAicmVkaXJlY3RGYWlsZWQiKSA9PT0gIjEiOwogICAgICB0cmllZCA9IE51bWJlcihsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMUyArICJyZWRpcmVjdEF0IikgfHwgMCk7CiAgICB9IGNhdGNoKGUpe30KICAgIGlmICh0cmllZCAmJiBEYXRlLm5vdygpIC0gdHJpZWQgPCA4MDAwKXsKICAgICAgdHJ5IHsgbG9jYWxTdG9yYWdlLnNldEl0ZW0oTFMgKyAicmVkaXJlY3RGYWlsZWQiLCAiMSIpOyB9IGNhdGNoKGUpe30KICAgICAgZmFpbGVkID0gdHJ1ZTsKICAgICAgbG9nTGluZSgiW3BhZ2VdIHRoZSByZWRpcmVjdCB0byB0aGUgaGVscGVyIGRpZCBub3QgbGFuZCwgc28gdGhpcyBwYWdlIGlzIHN0YXlpbmcgcHV0Iik7CiAgICB9CiAgICBpZiAoIXN0YXkgJiYgIWZhaWxlZCl7CiAgICAgIHRyeSB7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKExTICsgInJlZGlyZWN0QXQiLCBTdHJpbmcoRGF0ZS5ub3coKSkpOyB9IGNhdGNoKGUpe30KICAgICAgbG9jYXRpb24ucmVwbGFjZSgiaHR0cDovLzEyNy4wLjAuMTo3NjQ1LyIpOwogICAgICByZXR1cm47CiAgICB9CiAgICBpZiAoZmFpbGVkKXsKICAgICAgJCgibm90cmVhZHkiKS5zdHlsZS5kaXNwbGF5ID0gIiI7CiAgICAgICQoIm5vdHJlYWR5IikuaW5uZXJIVE1MID0gJzxkaXYgY2xhc3M9ImhpbnQiPlRoZSBoZWxwZXIgZGlkIG5vdCBhbnN3ZXIgYXQgJyArCiAgICAgICAgJzxjb2RlPmh0dHA6Ly8xMjcuMC4wLjE6NzY0NS88L2NvZGU+IOKAlCBzdGFydCBpdCB3aXRoIHRoZSBTaG9ydGN1dCBvciB0aGUgZG93bmxvYWQgYmVsb3csICcgKwogICAgICAgICd0aGVuIHByZXNzIFBMQVkuPC9kaXY+JzsKICAgIH0KICB9CiAgU3RvcmUudXNhZ2UoKS50aGVuKGVzdCA9PiB7CiAgICBpZiAoZXN0LnVzZWQpIGxvZ0xpbmUoInRoaXMgYnJvd3NlciBhbHJlYWR5IGhvbGRzICIgKyBmbXQoZXN0LnVzZWQpICsgIiBmb3IgdGhpcyBwYWdlIik7CiAgfSk7CiAgSm91cm5hbC5sb2FkKCkudGhlbihhc3luYyAoaikgPT4gewogICAgaWYgKCFqKSByZXR1cm47CiAgICBjb25zdCBzdCA9IChqLm1ldGEgfHwge30pLnN0YXRlIHx8ICIiOwogICAgY29uc3Qgc3RvcmVkID0gYXdhaXQgU3RvcmUuZ2V0KCJsYXN0LXNlc3Npb24uemlwIik7CiAgICBpZiAoc3RvcmVkICYmIC9leGl0ZWR8Y2FuY2VsbGVkL2kudGVzdChzdCkpeyBhd2FpdCBKb3VybmFsLmNsZWFyKCk7IHJldHVybjsgfQogICAgaWYgKCEvZXhpdGVkfGNhbmNlbGxlZC9pLnRlc3Qoc3QpKSBzaG93UmVjb3Zlcnkoaik7CiAgfSk7Cn0pKCk7Cjwvc2NyaXB0Pgo8L2JvZHk+CjwvaHRtbD4K"
DEFAULT_MEMORY = "2G"

# Origin allowlist for the browser-side fetch. The page is either served by this
# helper, or hosted on GitHub Pages, or served by the repo's own test server.
ORIGIN_PATTERNS = [
    re.compile(r"^http://(localhost|127\.0\.0\.1)(:\d+)?$"),
    re.compile(r"^https://localhost(:\d+)?$"),
    re.compile(r"^https://[a-z0-9-]+\.github\.io$"),
    re.compile(r"^https://[a-z0-9-]+\.pages\.dev$"),
]

PROXY_CANDIDATES = [
    "socks5h://127.0.0.1:1080",
    "socks5h://127.0.0.1:1088",
    "socks5h://127.0.0.1:10808",
    "socks5h://127.0.0.1:7890",
]

ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


def log_ts():
    return time.strftime("%H:%M:%S")


# --------------------------------------------------------------------------- os facts


def os_name():
    p = sys.platform
    if p == "darwin":
        return "osx"
    if p.startswith("win"):
        return "windows"
    return "linux"


def os_arch():
    m = platform.machine().lower()
    if m in ("arm64", "aarch64"):
        return "arm64"
    if m in ("x86_64", "amd64"):
        return "x86_64"
    return m


def os_version():
    if os_name() == "osx":
        return platform.mac_ver()[0]
    return platform.release()


# --------------------------------------------------------------------------- rules

def _rule_applies(rule, features):
    """Mojang's rule predicate: os name/arch/version plus launcher features."""
    cond = rule.get("os")
    if cond:
        if "name" in cond and cond["name"] != os_name():
            return False
        if "arch" in cond:
            want = cond["arch"]
            have = os_arch()
            # Mojang says "x86" for 32-bit intel; treat it as a prefix match so a
            # rule written for x86 also matches x86_64 only when it says so.
            if want == "x86":
                if have not in ("x86", "i386", "i686"):
                    return False
            elif want != have:
                return False
        if "version" in cond:
            try:
                if not re.search(cond["version"], os_version()):
                    return False
            except re.error:
                return False
    feats = rule.get("features")
    if feats:
        for k, v in feats.items():
            if bool(features.get(k, False)) != bool(v):
                return False
    return True


def rules_allow(rules, features):
    """Empty rules mean allowed; otherwise the *last* matching rule decides."""
    if not rules:
        return True
    allow = False
    for rule in rules:
        if _rule_applies(rule, features):
            allow = (rule.get("action") == "allow")
    return allow


# --------------------------------------------------------------------------- curl

class CurlError(RuntimeError):
    pass


class Cancelled(Exception):
    """Raised when the visitor stops a launch that has not finished starting."""


class Curl:
    """Thin curl wrapper: SOCKS-aware, parallel-capable, sha1-verifying."""

    def __init__(self, proxy=None, retries=3):
        self.proxy = proxy
        self.retries = retries
        self.curl = shutil.which("curl") or "/usr/bin/curl"
        self._lock = threading.Lock()
        self.bytes_in = 0
        # Where temporary files (curl's --parallel config) are written. The session
        # points this at its own sandbox so that nothing of ours can survive outside
        # it, even if the helper dies mid-download.
        self.workdir = None
        self.relay = None
        # Running curl processes, so a cancel can kill a download in flight instead of making
        # somebody wait for 430 MB of assets when they picked the wrong version.
        self._live = set()
        self._abort = False

    def abort(self):
        """Stop every download now. Idempotent, safe to call from another thread."""
        with self._lock:
            self._abort = True
            live = list(self._live)
        for proc in live:
            try:
                proc.kill()
            except Exception:
                pass
        return len(live)

    def clear_abort(self):
        with self._lock:
            self._abort = False

    def aborted(self):
        with self._lock:
            return self._abort

    def _run_curl(self, args, timeout=None):
        """Every curl goes through here, tracked, so abort() can reach it."""
        if self.aborted():
            raise CurlError("cancelled")
        proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        with self._lock:
            self._live.add(proc)
        try:
            out, err = proc.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            out, err = proc.communicate()
        finally:
            with self._lock:
                self._live.discard(proc)
        if self.aborted():
            raise CurlError("cancelled")
        return proc.returncode, out or b"", err or b""

    def workdir_path(self):
        d = self.workdir if (self.workdir and os.path.isdir(self.workdir)) \
            else os.environ.get("TMPDIR", "/tmp")
        return os.path.join(d, "webmc-curl-%s.conf" % secrets.token_hex(6))

    def _base(self):
        args = [self.curl, "-sS", "-L", "--fail", "--connect-timeout", "20",
                "--retry", str(self.retries), "--retry-connrefused",
                "--retry-delay", "1", "--create-dirs"]
        if self.proxy:
            args += ["--proxy", self.proxy]
        return args

    def get(self, url, dest=None, sha1=None, timeout=900, headers=()):
        """Download to dest (or return bytes when dest is None)."""
        url = relayed(url, getattr(self, "relay", None))
        if dest and sha1 and os.path.exists(dest) and sha1_of(dest) == sha1:
            return dest  # already there, and correct
        args = self._base() + ["-m", str(timeout)]
        for h in headers:
            args += ["-H", h]
        if dest:
            os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
            tmp = dest + ".part"
            args += ["-o", tmp, url]
        else:
            args += [url]
        code, out, err = self._run_curl(args, timeout=timeout + 30)
        if code != 0:
            if dest and os.path.exists(dest + ".part"):
                os.unlink(dest + ".part")
            raise CurlError("curl %s -> %s: %s" % (
                url, code, err.decode("utf-8", "replace").strip()[:300]))
        if dest:
            if sha1 and sha1_of(tmp) != sha1:
                os.unlink(tmp)
                raise CurlError("sha1 mismatch for %s" % url)
            os.replace(tmp, dest)
            with self._lock:
                self.bytes_in += os.path.getsize(dest)
            return dest
        with self._lock:
            self.bytes_in += len(out)
        return out

    def json(self, url, timeout=120, headers=()):
        raw = self.get(url, dest=None, timeout=timeout, headers=headers)
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError as exc:
            raise CurlError("bad json from %s: %s" % (url, exc))

    def batch(self, items, progress=None, workers=16, headers=()):
        """items: [(url, dest, sha1|None)]. Parallel, verifies, retries stragglers.

        Large batches go through a single `curl --parallel -K config` process:
        one process for thousands of objects, rather than thousands of processes.
        """
        todo = [it for it in items if not (it[2] and os.path.exists(it[1])
                                           and sha1_of(it[1]) == it[2])]
        if not todo:
            if progress:
                progress(len(items), len(items))
            return []
        if progress:
            progress(len(items) - len(todo), len(items))
        failed = []
        if len(todo) > 24:
            failed = self._batch_parallel(todo, progress, len(items),
                                          len(items) - len(todo), workers)
        else:
            failed = self._batch_threads(todo, progress, len(items),
                                         len(items) - len(todo), workers)
            failed = self._batch_parallel(todo, progress, len(items),
                                          len(items) - len(todo), workers)
        # verify + retry, individually, so a bad file can never survive
        for attempt in range(2):
            if not failed or self.aborted():
                break
            retry, failed = failed, []
            for item in retry:
                url, dest, sha1 = item
                try:
                    self.get(url, dest=dest, sha1=sha1, headers=headers)
                except CurlError as exc:
                    failed.append(item)
                    self._last_error = str(exc)
            if progress:
                progress(len(items) - len(failed), len(items), attempt + 2)
        return failed

    def _batch_threads(self, todo, progress, total, already, workers):
        from concurrent.futures import ThreadPoolExecutor
        failed = []
        done = [already]
        lock = threading.Lock()

        def one(item):
            url, dest, sha1 = item
            try:
                self.get(url, dest=dest, sha1=sha1)
            except CurlError:
                with lock:
                    failed.append(item)
            finally:
                with lock:
                    done[0] += 1
                    if progress:
                        progress(done[0], total)

        with ThreadPoolExecutor(max_workers=workers) as pool:
            list(pool.map(one, todo))
        return failed

    def _batch_parallel(self, todo, progress, total, already, workers):
        cfg = self.workdir_path()
        failed = []
        try:
            with open(cfg, "w") as fh:
                for url, dest, _sha1 in todo:
                    fh.write('url = "%s"\noutput = "%s"\n' % (url, dest))
            args = self._base() + ["--parallel", "--parallel-max", str(workers),
                                   "-K", cfg]
            if self.proxy:
                args += ["--proxy", self.proxy]
            proc = self._run_curl(args, timeout=1800)
            err = proc[2].decode("utf-8", "replace")
            code = proc[0]
            # which ones actually arrived intact?
            done = 0
            for item in todo:
                if os.path.exists(item[1]) and (not item[2] or sha1_of(item[1]) == item[2]):
                    done += 1
                else:
                    failed.append(item)
            if self.aborted():
                # A cancel is not a failure to report: nothing should be retried.
                raise CurlError("cancelled")
            if progress:
                progress(already + done, total)
            if failed and not err.strip():
                err = "(curl --parallel reported no detail)"
            self._last_error = err.strip()[-400:] if failed else ""
        finally:
            if os.path.exists(cfg):
                os.unlink(cfg)
        return failed


def sha1_of(path, chunk=1 << 20):
    h = hashlib.sha1()
    with open(path, "rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


# --------------------------------------------------------------------------- java

VER_RE = re.compile(r'version "([^"]+)"')


def java_major(java_path):
    try:
        proc = subprocess.run([java_path, "-version"], stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, timeout=30)
    except Exception:
        return 0
    out = proc.stdout.decode("utf-8", "replace")
    m = VER_RE.search(out)
    if not m:
        return 0
    v = m.group(1)
    if v.startswith("1."):
        try:
            return int(v.split(".")[1])
        except ValueError:
            return 0
    try:
        return int(re.match(r"(\d+)", v).group(1))
    except Exception:
        return 0


def find_javas():
    """Every java on the machine, best-effort, cheapest checks first."""
    cands = []
    env = os.environ.get("WEBMC_JAVA")
    if env:
        cands.append(env)
    home = os.environ.get("JAVA_HOME")
    if home:
        cands.append(os.path.join(home, "bin", "java"))
    for base, globs in (
        (os.path.expanduser("~/.jdks"), ("*/Contents/Home/bin/java", "*/bin/java")),
        ("/Library/Java/JavaVirtualMachines", ("*/Contents/Home/bin/java",)),
        (os.path.expanduser("~/Library/Java/JavaVirtualMachines"), ("*/Contents/Home/bin/java",)),
        ("/opt/homebrew/opt", ("openjdk*/bin/java", "openjdk@*/bin/java")),
        ("/usr/local/opt", ("openjdk*/bin/java", "openjdk@*/bin/java")),
    ):
        if not os.path.isdir(base):
            continue
        for g in globs:
            import glob as _glob
            cands.extend(sorted(_glob.glob(os.path.join(base, g)), reverse=True))
    which = shutil.which("java")
    if which:
        cands.append(which)
    out = []
    for c in cands:
        if c and os.path.exists(c) and os.access(c, os.X_OK) and c not in out:
            out.append(c)
    return out


def pick_java(required, explicit=None, log=None):
    if explicit:
        if not os.path.exists(explicit):
            raise RuntimeError("--java %s does not exist" % explicit)
        return explicit, java_major(explicit)
    found = []
    for c in find_javas():
        mj = java_major(c)
        if mj:
            found.append((mj, c))
    if not found:
        return None, 0
    found.sort(key=lambda t: -t[0])
    if log:
        log("java candidates: " + ", ".join("%d @ %s" % (m, c) for m, c in found[:6]))
    best_major, best = found[0]
    if best_major < required:
        return best, best_major  # caller decides whether to fetch a JRE
    return best, best_major


def fetch_jre(major, root, curl, log):
    arch = {"arm64": "aarch64", "x86_64": "x64"}.get(os_arch(), "x64")
    plat = "mac" if os_name() == "osx" else ("windows" if os_name() == "windows" else "linux")
    ext = "zip" if plat == "windows" else "tar.gz"
    url = "%s/binary/latest/%d/ga/%s/%s/jre/hotspot/normal/eclipse" % (
        ADOPTIUM_API, major, plat, arch)
    log("no Java %d here - fetching a JRE from Adoptium (%s/%s)" % (major, plat, arch))
    dest = os.path.join(root, "jre.%s" % ext)
    curl.get(url, dest=dest, timeout=1800)
    out = os.path.join(root, "jre")
    os.makedirs(out, exist_ok=True)
    if ext == "tar.gz":
        with tarfile.open(dest) as tf:
            tf.extractall(out)
    else:
        with zipfile.ZipFile(dest) as zf:
            zf.extractall(out)
    for base, _dirs, files in os.walk(out):
        if "java" in files and os.path.basename(base) == "bin":
            cand = os.path.join(base, "java")
            if os.access(cand, os.X_OK):
                return cand, java_major(cand)
    raise RuntimeError("fetched a JRE but could not find bin/java in it")


# --------------------------------------------------------------------------- downloads

def maven_to_path(coords):
    """group:artifact:version[:classifier] -> (relative path, file name)."""
    parts = coords.split(":")
    if len(parts) < 3:
        return None, None
    group, artifact, version = parts[0], parts[1], parts[2]
    classifier = parts[3] if len(parts) > 3 else None
    name = "%s-%s%s.jar" % (artifact, version, ("-" + classifier) if classifier else "")
    return "/".join([group.replace(".", "/"), artifact, version, name]), name


def vanilla_url(group, artifact, version, classifier=None, repo="https://libraries.minecraft.net"):
    rel, name = maven_to_path(":".join([group, artifact, version] + ([classifier] if classifier else [])))
    return "%s/%s" % (repo, rel), rel


class Registry:
    """Every session this helper has run, and the mod jars they share.

    A visitor may open two windows, or launch 1.21.11 next to 1.12.2, so "a session" is a thing the
    helper has many of rather than a property of the helper itself.
    """

    def __init__(self, cfg, curl, log=print):
        self.cfg = cfg
        self.curl = curl
        # Six places in here log through the relay (the SOCKS proxy opening a connection, the
        # tunnel coming up); without this they raised instead of logging.
        self.log = log
        self.lock = threading.RLock()
        self.sessions = {}
        self.order = []
        self.mods_dir = os.path.join(tempfile.gettempdir(), "webmc-mods-%d" % os.getpid())
        os.makedirs(self.mods_dir, exist_ok=True)
        self.pending_mods = []
        self.pending_restore = None
        self.started = time.time()
        self.last_touch = self.started
        self.store = session_store_dir(cfg)
        if getattr(cfg, "store_sessions", False):
            os.makedirs(self.store, exist_ok=True)

    def launch(self, opts):
        sid = secrets.token_hex(3)
        root = os.path.join("/tmp", "webmc-%s" % secrets.token_hex(4))
        cfg = argparse.Namespace(**vars(self.cfg))
        cfg.root = root
        requested = opts.get("relay")
        if requested is None:
            requested = getattr(self.cfg, "relay", None)
        cfg.relay = resolve_relay(requested, log=self.log)
        if opts.get("restricted"):
            cfg.restricted = True
        if opts.get("tunnelEverything"):
            cfg.proxy_game = True
        session = Session(cfg, self.curl, manager=self, sid=sid)
        session.pending_restore = self.pending_restore
        if session.pending_restore:
            session.pending_restore_from = "the page"
        self.pending_restore = None
        # Nothing from the page? Then start from what the helper kept last time, so a world does
        # not depend on which origin the visitor happened to press PLAY on.
        if session.pending_restore is None and opts.get("restore", True):
            kept = self.newest_stored(opts.get("version") or DEFAULT_VERSION)
            if kept:
                session.pending_restore, name = kept
                session.pending_restore_from = "the helper's own copy (%s)" % name
        with self.lock:
            self.sessions[sid] = session
            self.order.append(sid)
            while len(self.order) > 24:            # keep the page's list bounded
                oldest = self.order.pop(0)
                self.sessions.pop(oldest, None)
        session.start(opts)
        return session

    def touch(self):
        """The idle exit asks whether anybody is still using the helper at all, which is a
        question about the helper rather than about one of its sessions."""
        with self.lock:
            self.last_touch = time.time()

    # ---- keeping a session, and starting the next one from it
    def store_session(self, session):
        """Copy a finished session's bundle where the *next* launch can find it, whichever origin
        started this one."""
        if not getattr(self.cfg, "store_sessions", False) or not session.result:
            return None
        if not os.path.exists(session.bundle_path):
            return None
        version = (session.instance or {}).get("version") or "unknown"
        safe = re.sub(r"[^A-Za-z0-9._-]", "_", "%s-%s" % (version, session.sid))
        dest = os.path.join(self.store, safe + ".zip")
        try:
            shutil.copy2(session.bundle_path, dest)
        except OSError as exc:
            session.log("could not keep the session for next time: %s" % exc)
            return None
        session.log("kept this session for next time: %s (%s)"
                    % (dest, ", ".join(session.result.get("worlds") or []) or "no world yet"))
        self.prune_store()
        return dest

    def prune_store(self):
        keep = max(1, int(getattr(self.cfg, "keep_sessions", 5) or 5))
        try:
            files = sorted((os.path.join(self.store, n) for n in os.listdir(self.store)
                            if n.endswith(".zip")), key=os.path.getmtime, reverse=True)
        except OSError:
            return
        for old in files[keep:]:
            try:
                os.unlink(old)
            except OSError:
                pass

    def newest_stored(self, version):
        """The most recent kept session for a version, for a launch that has nothing from the page."""
        if not getattr(self.cfg, "store_sessions", False):
            return None
        try:
            candidates = [os.path.join(self.store, n) for n in os.listdir(self.store)
                          if n.endswith(".zip") and n.startswith(re.sub(r"[^A-Za-z0-9._-]", "_", version) + "-")]
        except OSError:
            return None
        if not candidates:
            return None
        newest = max(candidates, key=os.path.getmtime)
        try:
            with open(newest, "rb") as fh:
                return fh.read(), os.path.basename(newest)
        except OSError:
            return None

    def pick(self, sid=None):
        with self.lock:
            if sid and sid in self.sessions:
                return self.sessions[sid]
            if not self.order:
                return None
            for candidate in reversed(self.order):
                session = self.sessions.get(candidate)
                if session and session.state in ("running", "cancelling"):
                    return session
            return self.sessions.get(self.order[-1])

    def list(self):
        with self.lock:
            return [self.sessions[sid].status() for sid in reversed(self.order)
                    if sid in self.sessions]

    def stop_all(self):
        for session in list(self.sessions.values()):
            try:
                session.stop()
            except Exception:
                pass

    def cleanup_all(self):
        for session in list(self.sessions.values()):
            try:
                session.cleanup(why="the helper is stopping")
            except Exception:
                pass
        shutil.rmtree(self.mods_dir, ignore_errors=True)

    # ---- the mods a visitor handed over, shared by every session
    def accept_mod(self, name, blob):
        keeper = Session(self.cfg, self.curl, manager=self, sid="keeper")
        return keeper.accept_mod(name, blob)

    def drop_mod(self, name):
        keeper = Session(self.cfg, self.curl, manager=self, sid="keeper")
        return keeper.drop_mod(name)

    def clear_mods(self):
        keeper = Session(self.cfg, self.curl, manager=self, sid="keeper")
        return keeper.clear_mods()

    @property
    def mods(self):
        with self.lock:
            return list(self.pending_mods)


# --------------------------------------------------------------------------- the tunnel
#
# A network that lets nothing out but HTTPS makes a Minecraft server unreachable, because the game
# dials a raw TCP port. The fix is to carry that TCP connection inside a WebSocket to a relay that
# dials the server on the visitor's behalf - which is what Cloudflare Workers can do, and what this
# project's gateway already implements.
#
# The protocol is the one documented in gateway/cloudflare-worker.js ("goldproxy.v1"), so the Worker
# that repository deploys works with this unchanged:
#
#   POST /v1/token {host,port}          -> {"token":…}
#   WS   /v1/connect  {"t":"open",…}    <- {"t":"ready",…}
#   then binary frames are raw TCP, and text frames are
#        {"t":"ack","n"} (flow control), {"t":"ping"/"pong","id"}, {"t":"error",…}, {"t":"end",…}


class WebSocketError(RuntimeError):
    pass


def ws_connect(url, timeout=20):
    """The smallest WebSocket client that can carry a byte stream: handshake, frames, ping/pong.

    Python's standard library has no WebSocket client, and this file aims to depend on nothing but
    the standard library, so it does the handshake and the framing itself.
    """
    import ssl
    parts = urllib.parse.urlsplit(url)
    secure = parts.scheme in ("wss", "https")
    host = parts.hostname
    port = parts.port or (443 if secure else 80)
    path = parts.path or "/"
    if parts.query:
        path += "?" + parts.query
    sock = socket.create_connection((host, port), timeout=timeout)
    if secure:
        sock = ssl.create_default_context().wrap_socket(sock, server_hostname=host)
    key = base64.b64encode(os.urandom(16)).decode()
    request = ("GET %s HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
               "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n"
               # the gateway speaks this dialect and refuses anything else, which is a good thing:
               # a relay that accepted any upgrade would be a browser-accessible port scanner
               "Sec-WebSocket-Protocol: goldproxy.v1\r\n\r\n"
               % (path, parts.netloc, key))
    sock.sendall(request.encode())
    # read the response headers, one byte at a time so nothing of the first frame is consumed
    head = b""
    while b"\r\n\r\n" not in head:
        chunk = sock.recv(1)
        if not chunk:
            raise WebSocketError("the relay closed the connection during the handshake")
        head += chunk
        if len(head) > 8192:
            raise WebSocketError("the relay sent no usable handshake")
    status, _, rest = head.decode("utf-8", "replace").partition("\r\n")
    if "101" not in status:
        raise WebSocketError("the relay refused the WebSocket: %s" % status.strip())
    expect = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")
                                           .encode()).digest()).decode()
    if expect.lower() not in rest.lower():
        raise WebSocketError("the relay's handshake did not match")
    return sock


def ws_send(sock, data, opcode=2):
    """One masked frame. Clients must mask; servers must not."""
    header = bytearray([0x80 | opcode])
    length = len(data)
    if length < 126:
        header.append(0x80 | length)
    elif length < (1 << 16):
        header.append(0x80 | 126)
        header += struct.pack("!H", length)
    else:
        header.append(0x80 | 127)
        header += struct.pack("!Q", length)
    mask = os.urandom(4)
    header += mask
    masked = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
    with _ws_lock_for(sock):
        sock.sendall(bytes(header) + masked)


def ws_recv(sock, timeout=None):
    """One frame: (opcode, payload). Raises on a closed connection."""
    def exact(n):
        buf = b""
        while len(buf) < n:
            chunk = sock.recv(n - len(buf))
            if not chunk:
                raise WebSocketError("closed")
            buf += chunk
        return buf
    if timeout is not None:
        sock.settimeout(timeout)
    first = exact(2)
    opcode = first[0] & 0x0F
    masked = bool(first[1] & 0x80)
    length = first[1] & 0x7F
    if length == 126:
        length = struct.unpack("!H", exact(2))[0]
    elif length == 127:
        length = struct.unpack("!Q", exact(8))[0]
    mask = exact(4) if masked else None
    payload = exact(length) if length else b""
    if mask:
        payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
    return opcode, payload


_WS_LOCKS = {}


def _ws_lock_for(sock):
    """One lock per socket, so two threads (game->relay, relay->game) never interleave frames."""
    with threading.Lock():
        lock = _WS_LOCKS.get(id(sock))
        if lock is None:
            lock = threading.Lock()
            _WS_LOCKS[id(sock)] = lock
        return lock


def bridge(client, relay, host, port, log, on_open=None, timeout=120):
    """Carry one TCP connection through the relay: the piece both the tunnel and the SOCKS proxy need.

    Returns True once the relay said it was ready, False if it could not be reached at all.
    """
    relay_host = relay.rstrip("/")
    try:
        body = json.dumps({"host": host, "port": int(port)}).encode()
        req = urllib.request.Request(
            relay_host.replace("ws://", "http://").replace("wss://", "https://") + "/v1/token",
            data=body, headers={"Content-Type": "application/json",
                                "User-Agent": "%s/%s" % (NAME, VERSION)})
        with urllib.request.urlopen(req, timeout=30) as response:
            token = json.loads(response.read().decode("utf-8", "replace")).get("token")
        if not token:
            raise WebSocketError("the relay did not issue a token")
        ws_url = relay_host.replace("https://", "wss://").replace("http://", "ws://") + "/v1/connect"
        sock = ws_connect(ws_url)
        ws_send(sock, json.dumps({"t": "open", "v": 1, "token": token, "host": host,
                                  "port": int(port)}).encode(), opcode=1)
        for _ in range(20):
            opcode, payload = ws_recv(sock)
            if opcode == 9:
                ws_send(sock, payload, opcode=10)
                continue
            if opcode == 8:
                raise WebSocketError("the relay closed the connection")
            if opcode != 1:
                continue
            message = json.loads(payload.decode("utf-8", "replace"))
            if message.get("t") == "ready":
                break
            if message.get("t") == "error":
                raise WebSocketError(message.get("message") or message.get("code") or "refused")
        else:
            raise WebSocketError("the relay never said it was ready")
    except Exception as exc:  # noqa: BLE001
        log("relay: %s:%s could not be reached: %s" % (host, port, exc))
        try:
            client.close()
        except Exception:
            pass
        return False

    if on_open:
        on_open()
    stop = threading.Event()

    def to_relay():
        try:
            while not stop.is_set():
                data = client.recv(32768)
                if not data:
                    break
                ws_send(sock, data)
        except Exception:
            pass
        finally:
            stop.set()
            try:
                ws_send(sock, b"", opcode=8)
            except Exception:
                pass

    threading.Thread(target=to_relay, daemon=True).start()
    received = 0
    try:
        while not stop.is_set():
            opcode, payload = ws_recv(sock, timeout=timeout)
            if opcode in (2, 0):
                client.sendall(payload)
                # flow control is cumulative: the relay replaces its counter with this number
                received += len(payload)
                try:
                    ws_send(sock, json.dumps({"t": "ack", "n": received}).encode(), opcode=1)
                except Exception:
                    pass
            elif opcode == 1:
                message = json.loads(payload.decode("utf-8", "replace"))
                if message.get("t") == "ping":
                    ws_send(sock, json.dumps({"t": "pong", "id": message.get("id")}).encode(), 1)
                elif message.get("t") in ("end", "error"):
                    break
            elif opcode == 9:
                ws_send(sock, payload, opcode=10)
            elif opcode == 8:
                break
    except Exception:
        pass
    finally:
        try:
            client.close()
        except Exception:
            pass
    return True


class SocksBridge:
    """A local SOCKS5 proxy whose connections are carried by the relay.

    This is the setting for a network that blocks everything but HTTPS: Java routes *every* TCP
    connection a program makes through `-DsocksProxyHost`, so pointing the game at this proxy is what
    makes joining a server, authenticating and fetching skins work - not just one server chosen in
    advance. It needs no administrator and touches nothing outside the session.
    """

    def __init__(self, relay, port=0, log=print):
        self.relay = relay
        self.port = int(port or 0)
        self.log = log
        self.server = None
        self.thread = None
        self.running = False
        self.connections = 0

    def start(self):
        self.server = socket.socket()
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind(("127.0.0.1", self.port))
        self.server.listen(16)
        self.port = self.server.getsockname()[1]
        self.running = True

        def accept():
            while self.running:
                try:
                    client, _addr = self.server.accept()
                except OSError:
                    break
                threading.Thread(target=self._handle, args=(client,), daemon=True).start()

        self.thread = threading.Thread(target=accept, daemon=True)
        self.thread.start()
        self.log("proxy: SOCKS5 on 127.0.0.1:%d, every connection carried by %s"
                 % (self.port, self.relay))
        return self.port

    def stop(self):
        self.running = False
        try:
            if self.server:
                self.server.close()
        except Exception:
            pass

    def _handle(self, client):
        try:
            greeting = client.recv(2)
            if len(greeting) < 2 or greeting[0] != 5:
                client.close()
                return
            methods = client.recv(greeting[1])
            if 0 not in methods:
                client.sendall(b"\x05\xff")      # no acceptable method
                client.close()
                return
            client.sendall(b"\x05\x00")           # no authentication
            head = client.recv(4)
            if len(head) < 4 or head[0] != 5 or head[1] != 1:
                client.close()
                return
            kind = head[3]
            if kind == 1:
                host = socket.inet_ntoa(client.recv(4))
            elif kind == 3:
                length = client.recv(1)[0]
                host = client.recv(length).decode("utf-8", "replace")
            elif kind == 4:
                host = socket.inet_ntop(socket.AF_INET6, client.recv(16))
            else:
                client.close()
                return
            port = struct.unpack("!H", client.recv(2))[0]
            # the relay does the dialling, so "success" is the relay's answer, not ours
            ok = bridge(client, self.relay, host, port, self.log,
                        on_open=lambda: self._count(host, port))
            if not ok:
                client.sendall(b"\x05\x05\x00\x01\x00\x00\x00\x00\x00\x00")
        except Exception:
            try:
                client.close()
            except Exception:
                pass

    def _count(self, host, port):
        self.connections += 1
        self.log("proxy: %s:%s is open through the relay" % (host, port))


class Tunnel:
    """One Minecraft server, reachable at 127.0.0.1:<local port> through a relay.

    The game connects to the local address as if it were the server; every connection is carried to
    the relay inside a WebSocket, and the relay dials the real server.
    """

    def __init__(self, relay, host, port, local_port=0, log=print):
        self.relay = relay.rstrip("/")
        self.host = host
        self.port = int(port)
        self.local_port = int(local_port or 0)
        self.log = log
        self.server = None
        self.thread = None
        self.running = False
        self.connections = 0

    def _token(self):
        import urllib.request
        body = json.dumps({"host": self.host, "port": self.port}).encode()
        req = urllib.request.Request(self.relay.replace("ws://", "http://").replace("wss://", "https://")
                                     + "/v1/token", data=body,
                                     headers={"Content-Type": "application/json",
                                              "User-Agent": "%s/%s" % (NAME, VERSION)})
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode("utf-8", "replace"))
        token = data.get("token")
        if not token:
            raise WebSocketError("the relay did not issue a token: %s" % data)
        return token

    def _pump(self, client):
        """One game connection: open a relay socket, then copy bytes both ways."""
        bridge(client, self.relay, self.host, self.port, self.log, on_open=self._opened)

    def _opened(self):
        self.connections += 1
        self.log("tunnel: %s:%d is open through the relay" % (self.host, self.port))

    def _pump_unused(self, client):
        try:
            token = self._token()
            ws_url = (self.relay.replace("https://", "wss://").replace("http://", "ws://")
                      .rstrip("/") + "/v1/connect")
            sock = ws_connect(ws_url)
            ws_send(sock, json.dumps({"t": "open", "v": 1, "token": token,
                                      "host": self.host, "port": self.port}).encode(), opcode=1)
            # wait for ready, ignoring anything else the relay says first
            for _ in range(20):
                opcode, payload = ws_recv(sock)
                if opcode == 9:
                    ws_send(sock, payload, opcode=10)
                    continue
                if opcode in (8,):
                    raise WebSocketError("the relay closed the connection")
                if opcode != 1:
                    continue
                message = json.loads(payload.decode("utf-8", "replace"))
                if message.get("t") == "ready":
                    break
                if message.get("t") == "error":
                    raise WebSocketError(message.get("message") or message.get("code") or "refused")
            else:
                raise WebSocketError("the relay never said it was ready")
            self.connections += 1
            self.log("tunnel: %s:%d is open through the relay" % (self.host, self.port))
            stop = threading.Event()

            def to_relay():
                try:
                    while not stop.is_set():
                        data = client.recv(32768)
                        if not data:
                            break
                        ws_send(sock, data)
                except Exception:
                    pass
                finally:
                    stop.set()
                    try:
                        ws_send(sock, b"", opcode=8)
                    except Exception:
                        pass

            up = threading.Thread(target=to_relay, daemon=True)
            up.start()
            received = 0
            while not stop.is_set():
                opcode, payload = ws_recv(sock, timeout=120)
                if opcode == 2 or opcode == 0:
                    client.sendall(payload)
                    # The relay's flow control is a *cumulative* count: it pauses the target while
                    # the client has more unacknowledged bytes than the window, and it sets its own
                    # counter from this number rather than adding to it. Sending the size of one
                    # frame here stalls a real session after a few hundred kilobytes.
                    received += len(payload)
                    try:
                        ws_send(sock, json.dumps({"t": "ack", "n": received}).encode(), opcode=1)
                    except Exception:
                        pass
                elif opcode == 1:
                    message = json.loads(payload.decode("utf-8", "replace"))
                    if message.get("t") == "ping":
                        ws_send(sock, json.dumps({"t": "pong", "id": message.get("id")}).encode(), 1)
                    elif message.get("t") in ("end", "error"):
                        break
                elif opcode == 9:
                    ws_send(sock, payload, opcode=10)
                elif opcode == 8:
                    break
        except Exception as exc:  # noqa: BLE001
            self.log("tunnel: %s:%d could not be reached through the relay: %s"
                     % (self.host, self.port, exc))
        finally:
            try:
                client.close()
            except Exception:
                pass

    def start(self):
        if not self.relay:
            raise WebSocketError("a relay URL is needed to tunnel a server (Settings → relay)")
        self.server = socket.socket()
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind(("127.0.0.1", self.local_port))
        self.server.listen(4)
        self.local_port = self.server.getsockname()[1]
        self.running = True

        def accept():
            while self.running:
                try:
                    client, _addr = self.server.accept()
                except OSError:
                    break
                threading.Thread(target=self._pump, args=(client,), daemon=True).start()

        self.thread = threading.Thread(target=accept, daemon=True)
        self.thread.start()
        self.log("tunnel: %s:%d will be reachable at 127.0.0.1:%d through %s"
                 % (self.host, self.port, self.local_port, self.relay))
        return self.local_port

    def stop(self):
        self.running = False
        try:
            if self.server:
                self.server.close()
        except Exception:
            pass


# --------------------------------------------------------------------------- session

class Session:
    """One sandbox, one game, one lifecycle.

    More than one of these can be alive at once - two windows, two versions - so each session gets
    its own Curl (its own downloads to abort) and its own sandbox, and shares only the mod jars the
    visitor handed over and the proxy/relay settings.
    """

    def __init__(self, cfg, curl, manager=None, sid=None):
        self.cfg = cfg
        # a private Curl, so stopping one session cannot abort another's downloads
        self.curl = Curl(proxy=getattr(curl, "proxy", None))
        self.curl.relay = getattr(cfg, "relay", None)
        self.manager = manager
        self.sid = sid or secrets.token_hex(3)
        self.lock = threading.RLock()
        self.lines = []
        self.state = "idle"          # idle|running|exited|cancelled|failed
        self.phase = ""
        self.phase_label = ""
        self.done = 0
        self.total = 0
        self.error = None
        self.instance = {}
        self.pid = None
        self.exit_code = None
        self.started_at = None
        self.ended_at = None
        self.result = None           # collected bundle info
        self.proc = None
        self.thread = None
        self.cleanup_deadline = None
        self.last_cleanup = None
        self.cancel_requested = False
        self.last_touch = time.time()
        self.pending_mods = []      # jars the page pushed in, waiting for a launch
        self.tunnel = None          # a server carried to us through a relay, when asked for
        self.socks = None           # a local SOCKS5 proxy the game itself is pointed at
        self.quick_play = None      # 127.0.0.1:<port>, handed to the client to join
        self.java = None
        self.java_major = 0
        self.jre_fetched = False
        self._versions_cache = None

    # ---------------------------------------------------------------- root paths
    @property
    def root(self):
        return self.cfg.root

    @property
    def game_dir(self):
        return os.path.join(self.root, "game")

    @property
    def libs_dir(self):
        return os.path.join(self.root, "libraries")

    @property
    def assets_dir(self):
        return os.path.join(self.root, "assets")

    @property
    def natives_dir(self):
        return os.path.join(self.root, "natives")

    @property
    def versions_dir(self):
        return os.path.join(self.root, "versions")

    @property
    def bundle_path(self):
        return os.path.join(self.root, "session.zip")

    def write_file(self, rel, data):
        path = os.path.join(self.root, rel)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as fh:
            fh.write(data if isinstance(data, bytes) else data.encode("utf-8"))
        return path

    # ---------------------------------------------------------------- status
    def log(self, line, echo=True):
        line = ANSI_RE.sub("", str(line)).rstrip("\n")
        if not line.strip():
            return
        with self.lock:
            self.lines.append("[%s] %s" % (log_ts(), line))
            if len(self.lines) > 4000:
                del self.lines[:1000]
        if echo:
            sys.stdout.write("  %s\n" % line)
            sys.stdout.flush()

    def set(self, **kw):
        with self.lock:
            for k, v in kw.items():
                setattr(self, k, v)

    def status(self):
        with self.lock:
            total = self.total or 0
            data = {
                "sid": self.sid,
                "state": self.state,
                "phase": self.phase,
                "phaseLabel": self.phase_label,
                "progress": {
                    "done": self.done,
                    "total": total,
                    "percent": int(100 * self.done / total) if total else None,
                },
                "instance": dict(self.instance),
                "pid": self.pid,
                "exitCode": self.exit_code,
                "startedAt": self.started_at,
                "endedAt": self.ended_at,
                "error": self.error,
                "java": self.java,
                "javaMajor": self.java_major,
                "jreFetched": self.jre_fetched,
                "downloadedBytes": self.curl.bytes_in,
                "lines": len(self.lines),
                "result": self.result,
            }
        self.refresh_cleanup_deadline()
        data["cleanupAt"] = self.cleanup_deadline
        data["lastCleanup"] = self.last_cleanup
        data["pendingMods"] = [{"name": m["name"], "bytes": m["bytes"],
                               "title": m.get("title"), "version": m.get("version")}
                              for m in self.pending_mods]
        # A second tab (or the same visitor later) must be able to tell that another page
        # has already taken this session's files and the sandbox has been deleted, rather
        # than reporting a failed download.
        if data["result"]:
            data["result"] = dict(data["result"])
            data["result"]["available"] = os.path.exists(self.bundle_path)
        return data

    def refresh_cleanup_deadline(self):
        """After the game exits and the bundle exists, the sandbox gets a timer."""
        with self.lock:
            if (self.state in ("exited", "failed") and self.result
                    and self.cleanup_deadline is None and self.cfg.autoclean):
                self.cleanup_deadline = time.time() + self.cfg.autoclean

    def lines_since(self, n):
        with self.lock:
            return self.lines[n:], len(self.lines)

    # ---------------------------------------------------------------- lifecycle
    def start(self, opts):
        with self.lock:
            if self.state == "running":
                raise RuntimeError("a session is already running")
            self.state = "running"
            self.error = None
            self.exit_code = None
            self.result = None
            self.done = 0
            self.total = 0
            self.cleanup_deadline = None
            self.cancel_requested = False
            self.started_at = time.time()
            self.ended_at = None
        self.curl.clear_abort()
        self.thread = threading.Thread(target=self._run, args=(opts,), daemon=True)
        self.thread.start()

    def touch(self):
        """Remember that somebody is still talking to us: the idle exit uses this, so a helper
        nobody is driving disappears on its own instead of lingering as a background process."""
        with self.lock:
            self.last_touch = time.time()

    def _check_cancelled(self):
        if self.cancel_requested or self.curl.aborted():
            raise Cancelled("stopped on request")

    def cancel(self, why="the page asked for it"):
        """Stop a launch that has not started yet: the downloads, then the game.

        Stop used to mean "kill the game process", which did nothing while 430 MB of assets
        were still downloading - so picking the wrong version meant waiting for it. This
        interrupts the downloads, ends the job at its next step, and still collects what the
        attempt produced so the page can keep it.
        """
        with self.lock:
            self.cancel_requested = True
            was_running = self.state == "running"
        killed = self.curl.abort()
        game = self.stop()
        self.log("stop requested: cancelling everything%s%s"
                 % (" (%d download(s) killed)" % killed if killed else "",
                    " (game killed)" if game else ""))
        with self.lock:
            if was_running and not game:
                self.state = "cancelling"
        return {"cancelled": True, "downloads": killed, "game": game,
                "why": why, "state": self.state}

    def stop(self):
        self._stop_tunnel()
        with self.lock:
            proc = self.proc
        if proc and proc.poll() is None:
            self.log("stop requested - sending SIGTERM to pid %d" % proc.pid)
            try:
                proc.terminate()
            except Exception:
                pass
            for _ in range(40):
                if proc.poll() is not None:
                    break
                time.sleep(0.25)
            if proc.poll() is None:
                self.log("still alive - SIGKILL")
                try:
                    proc.kill()
                except Exception:
                    pass
            return True
        return False

    def _progress(self, label, done, total):
        with self.lock:
            self.phase_label = label
            self.done = done
            self.total = total

    def _phase(self, name, label=None, total=0, check_cancel=True):
        # Every step of a launch goes through here, so a stop lands between steps rather
        # than at the end of them. Collecting is the exception: once a stop has been
        # honoured, what the attempt produced still has to be saved, not cancelled again.
        if check_cancel:
            self._check_cancelled()
        with self.lock:
            self.phase = name
            self.phase_label = label or name
            self.done = 0
            self.total = total
        if label:
            self.log(label)

    # ---------------------------------------------------------------- the run
    def _run(self, opts):
        try:
            self.log("sandbox: %s" % self.root)
            self._prepare_root()
            if getattr(self, "pending_restore", None):
                try:
                    self.log("putting your last session back, from %s"
                             % getattr(self, "pending_restore_from", "a saved bundle"))
                    self.restore(self.pending_restore)
                except Exception as exc:  # noqa: BLE001
                    self.log("could not put the previous session back: %s" % exc)
            self._preseed_options()
            mc_version = opts["version"]
            required = 21

            # ---- java
            self._phase("java", "looking for a Java runtime")
            if getattr(self.cfg, "restricted", False):
                # Restricted mode: never touch a Java the machine already has. The runtime comes
                # into the sandbox and dies with it, so nothing outside /tmp is read or run.
                self.log("restricted mode: a Java runtime will be fetched into the sandbox "
                         "rather than used from this machine")
                java, major = None, 0
                if self.cfg.java and java_major(self.cfg.java):
                    java, major = self.cfg.java, java_major(self.cfg.java)
            else:
                java, major = pick_java(required, explicit=self.cfg.java, log=self.log)
            if not java or major < required:
                if self.cfg.no_jre_download:
                    raise RuntimeError(
                        "no Java %d found (best: %s) and --no-jre-download was given"
                        % (required, java or "none"))
                if java:
                    self.log("best local Java is %d, this version needs %d - fetching one "
                             "into the sandbox (it dies with the sandbox)" % (major, required))
                java, major = fetch_jre(required, self.root, self.curl, self.log)
                self.jre_fetched = True
            self.java = java
            self.java_major = major
            self.log("java: %s (%d)" % (java, major))

            # ---- version metadata
            self._phase("metadata", "reading %s from Mojang" % mc_version)
            vjson, vurl = self._version_json(mc_version)
            self.log("client: %s (%d MB)" % (
                vjson["id"], vjson["downloads"]["client"]["size"] // (1 << 20)))

            # ---- vanilla files
            client_jar = self._client_jar(vjson)
            libs = self._libraries(vjson, self.curl)
            assets_ok = self._assets(vjson, opts.get("assets", True))

            # ---- fabric
            loader_kind = (opts.get("loaderKind") or "fabric").lower()
            if loader_kind in ("none", "vanilla"):
                loader_kind = "none"
            loader_ver = opts.get("loader") or "auto"
            profile, loader_ver = self._loader_profile(loader_kind, mc_version, loader_ver)
            loader_libs = self._profile_libraries(profile)
            all_libs = libs + loader_libs

            # ---- mods
            mods = self._mods(opts.get("mods") or [], mc_version, loader_ver)
            local = list(self.cfg.mod_jar or []) + list(opts.get("localMods") or [])
            local += self._pending_mod_paths()
            mods += self._local_mods(local)

            # ---- everything the game connects to, through the relay
            if opts.get("tunnelEverything") or self.cfg.proxy_game:
                if not self.cfg.relay:
                    self.log("a proxy needs a relay URL (Settings → Proxy), so it is off")
                else:
                    try:
                        self.socks = SocksBridge(self.cfg.relay, log=self.log)
                        self.socks_port = self.socks.start()
                    except Exception as exc:  # noqa: BLE001
                        self.log("could not start the proxy: %s" % exc)
                        self.socks = None

            # ---- a server through the relay, if one was asked for
            server = (opts.get("tunnelServer") or "").strip()
            if server:
                host, _sep, port = server.rpartition(":")
                if not host or not port.isdigit():
                    self.log("that server address is not host:port - ignoring %r" % server)
                else:
                    try:
                        self.tunnel = Tunnel(self.cfg.relay, host, int(port),
                                             local_port=int(opts.get("tunnelPort") or 0),
                                             log=self.log)
                        local = self.tunnel.start()
                        self.quick_play = "127.0.0.1:%d" % local
                        self.log("the game will join %s, which the relay carries to %s:%s"
                                 % (self.quick_play, host, port))
                    except Exception as exc:  # noqa: BLE001
                        self.log("could not tunnel %s: %s" % (server, exc))
                        self.tunnel = None

            # ---- command
            self._phase("launch", "starting the game")
            cmd, classpath = self._build_command(
                vjson, profile, client_jar, all_libs, mc_version, loader_ver,
                opts.get("username") or "Player", opts.get("memory") or DEFAULT_MEMORY,
                mods)
            self.write_file("launch-command.txt",
                            "\n".join(shell_quote(c) for c in cmd) + "\n")
            if self.cfg.dry_run:
                self.log("dry run: command written to %s/launch-command.txt"
                         % self.root)
                self.log("dry run: not starting the game")
                self.instance = {
                    "version": mc_version, "loader": "fabric-%s" % loader_ver,
                    "mods": [m["name"] for m in mods],
                    "username": opts.get("username") or "Player",
                    "memory": opts.get("memory") or DEFAULT_MEMORY, "offline": True,
                }
                with self.lock:
                    self.state = "exited"
                    self.exit_code = 0
                    self.phase = "dry-run"
                    self.phase_label = "dry run complete"
                    self.ended_at = time.time()
                self._collect()
                return
            self.log("classpath: %d entries" % len(classpath))
            self.log("mods: %s" % (", ".join(m["name"] for m in mods) if mods else "(none)"))
            self.log("assets: %s" % ("downloaded" if assets_ok else "SKIPPED (missing sounds/textures)"))

            logfile = open(os.path.join(self.root, "console.log"), "wb")
            self.proc = subprocess.Popen(cmd, cwd=self.game_dir, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
            self.pid = self.proc.pid
            self.instance = {
                "version": mc_version,
                "loader": ("%s-%s" % (loader_kind, loader_ver)) if loader_kind != "none" else "vanilla",
                "mods": [m["name"] for m in mods],
                "username": opts.get("username") or "Player",
                "memory": opts.get("memory") or DEFAULT_MEMORY,
                "offline": True,
            }
            self.log("pid %d - minecraft is running; close the window when you are done" % self.pid)
            with self.lock:
                self.state = "running"
            sink = threading.Thread(target=self._pump, args=(self.proc.stdout, logfile),
                                    daemon=True)
            sink.start()
            code = self.proc.wait()
            sink.join(timeout=10)
            logfile.close()
            self.exit_code = code
            self.log("game exited with code %s" % code)
            self._collect()
            with self.lock:
                self.state = "cancelled" if code not in (0, None) and code < 0 else "exited"
                self.phase = "done"
                self.phase_label = "session finished"
                self.ended_at = time.time()
        except Cancelled as exc:
            self.log("stopped: %s" % exc)
            try:
                # Even a stopped attempt keeps its log: that is the difference between
                # "it didn't work" and "it didn't work and nobody knows why".
                self._collect()
            except Exception as collect_problem:  # noqa: BLE001
                self.log("nothing could be collected: %s" % collect_problem)
            with self.lock:
                self.state = "cancelled"
                self.phase = "cancelled"
                self.phase_label = "Stopped"
                self.ended_at = time.time()
        except Exception as exc:  # noqa: BLE001 - surfaced to the page
            if isinstance(exc, CurlError) and str(exc) == "cancelled":
                with self.lock:
                    self.state = "cancelled"
                    self.phase = "cancelled"
                    self.phase_label = "Stopped"
                    self.ended_at = time.time()
                self.log("stopped on request")
                try:
                    self._collect()
                except Exception:  # noqa: BLE001
                    pass
            else:
                self.error = "%s: %s" % (type(exc).__name__, exc)
                self.log("FAILED - %s" % self.error)
                with self.lock:
                    self.state = "failed"
                    self.phase = "failed"
                    self.phase_label = "failed"
                    self.ended_at = time.time()

        finally:
            # Whatever happened, the sandbox now has a deadline: if the page never collects the
            # result, the watchdog deletes it.
            self.refresh_cleanup_deadline()

    def _pump(self, stream, logfile):
        interesting = re.compile(
            r"Loading \d+ mods|fabric-loader|KnotClient|LWJGL|Backend library|Setting user|"
            r"OpenGL|Sound engine|Started|Stopping|Exception|Error|crash|Mixin|"
            r"Preparing|Reloading|thread", re.I)
        for raw in iter(stream.readline, b""):
            logfile.write(raw)
            logfile.flush()
            text = ANSI_RE.sub("", raw.decode("utf-8", "replace"))
            if interesting.search(text):
                self.log(text, echo=False)
            else:
                with self.lock:
                    self.lines.append("[%s] %s" % (log_ts(), text.rstrip()))

    # ---------------------------------------------------------------- sandbox
    def _prepare_root(self):
        os.makedirs(self.root, mode=0o700, exist_ok=True)
        os.chmod(self.root, 0o700)
        for d in (self.game_dir, self.libs_dir, self.assets_dir,
                  os.path.join(self.assets_dir, "indexes"),
                  os.path.join(self.assets_dir, "objects"),
                  self.natives_dir, self.versions_dir,
                  os.path.join(self.game_dir, "mods"),
                  os.path.join(self.game_dir, "saves")):
            os.makedirs(d, exist_ok=True)
        self.curl.workdir = self.root
        if getattr(self.cfg, "relay", None):
            # Everything downloaded this session goes through the relay instead of straight to
            # Mojang - which is the point of it on a network that blocks Mojang.
            self.curl.relay = self.cfg.relay
            self.log("relay: every download goes through %s" % self.cfg.relay)
        self._write_owner()
        self._link_cache()

    def _write_owner(self):
        """A note to whoever finds this directory later: who made it, and when.

        If this helper is ever killed outright (SIGKILL, a crash, the machine going
        down) the sandbox is left behind with nobody to delete it. The next helper to
        start reads this, sees that the owning process is gone, and deletes it there
        and then - rather than waiting for an arbitrary age to pass.
        """
        data = {
            "pid": os.getpid(),
            "started": time.time(),
            "helper": VERSION,
            "argv": sys.argv[1:],
            "boot": _boot_id(),
        }
        try:
            with open(os.path.join(self.root, "owner.json"), "w") as fh:
                json.dump(data, fh, indent=1)
        except OSError:
            pass

    def _link_cache(self):
        """Optional: borrow Mojang's immutable files from a cache instead of
        re-downloading 450 MB every time. Off by default - the promise is that a
        session leaves nothing behind, and only the visitor can decide to trade
        that for speed. The sandbox symlinks the cache; deleting the sandbox
        unlinks them and leaves the cache alone."""
        if not self.cfg.cache:
            return
        cache = os.path.abspath(os.path.expanduser(self.cfg.cache))
        for name in ("assets", "libraries"):
            src = os.path.join(cache, name)
            dst = os.path.join(self.root, name)
            os.makedirs(os.path.join(src, "indexes"), exist_ok=True)
            os.makedirs(os.path.join(src, "objects"), exist_ok=True)
            if os.path.islink(dst):
                os.unlink(dst)
            elif os.path.isdir(dst):
                shutil.rmtree(dst, ignore_errors=True)
            elif os.path.exists(dst):
                os.unlink(dst)
            os.symlink(src, dst)
        # the client jar and the version json are immutable too, so they cache by
        # name: a second launch then needs no network for them at all
        cver = os.path.join(cache, "versions")
        os.makedirs(cver, exist_ok=True)
        for entry in os.listdir(cver):
            src = os.path.join(cver, entry)
            dst = os.path.join(self.versions_dir, entry)
            if os.path.exists(dst) or os.path.islink(dst):
                continue
            os.symlink(src, dst)
        self.log("cache: assets, libraries and the client jar are borrowed from %s" % cache)

    def _version_json(self, version):
        cache = os.path.join(self.versions_dir, "%s.json" % version)
        if os.path.exists(cache):
            with open(cache) as fh:
                data = json.load(fh)
            return data, data.get("_url", "")
        manifest = self.curl.json(MANIFEST_URL, headers=self._ua())
        rels = [v for v in manifest["versions"] if v["type"] == "release"]
        match = None
        for v in manifest["versions"]:
            if v["id"] == version:
                match = v
                break
        if not match:
            near = ", ".join(v["id"] for v in (rels or manifest["versions"])[:8])
            raise RuntimeError("version %s is not in Mojang's list (newest releases: %s)"
                               % (version, near))
        data = self.curl.json(match["url"], headers=self._ua())
        data["_url"] = match["url"]
        os.makedirs(self.versions_dir, exist_ok=True)
        with open(cache, "w") as fh:
            json.dump(data, fh)
        return data, match["url"]

    def versions(self):
        with self.lock:
            if self._versions_cache:
                return self._versions_cache
        manifest = self.curl.json(MANIFEST_URL, headers=self._ua())
        rel = [v["id"] for v in manifest["versions"] if v["type"] == "release"][:40]
        allv = [v["id"] for v in manifest["versions"]][:40]
        out = {"latest": manifest["latest"], "releases": rel, "newest": allv}
        with self.lock:
            self._versions_cache = out
        return out

    def _client_jar(self, vjson):
        dl = vjson["downloads"]["client"]
        dest = os.path.join(self.versions_dir, "%s" % dl.get("path", "client.jar"))
        if os.path.isdir(dest):
            dest = os.path.join(dest, "client.jar")
        self._phase("client", "client jar (%.0f MB)" % (dl["size"] / 1048576.0))
        self.curl.get(dl["url"], dest=dest, sha1=dl.get("sha1"), headers=self._ua())
        self._progress("client jar", 1, 1)
        return dest

    def _libraries(self, vjson, curl):
        features = self._features()
        wanted = []
        natives = []
        for lib in vjson["libraries"]:
            if not rules_allow(lib.get("rules"), features):
                continue
            art = lib.get("downloads", {}).get("artifact")
            if art:
                wanted.append((art["url"], os.path.join(self.libs_dir, art["path"]),
                               art.get("sha1"), lib.get("name", "")))
            elif lib.get("name"):
                # no explicit downloads block: build it from maven coordinates
                rel, _name = maven_to_path(lib["name"])
                if rel:
                    repo = (lib.get("url") or "https://libraries.minecraft.net").rstrip("/")
                    wanted.append(("%s/%s" % (repo, rel), os.path.join(self.libs_dir, rel),
                                   None, lib.get("name", "")))
            if lib.get("natives"):
                natives.append(lib)
        # Apple Silicon: Mojang lists both natives-macos and natives-macos-arm64 with
        # identical rules, so both would land on the classpath and LWJGL could extract
        # the x86_64 dylib. Prefer the arm64 variant and drop the plain one.
        wanted = self._prefer_arch(wanted)
        self._phase("libraries", "libraries (%d)" % len(wanted), len(wanted))
        failed = curl.batch([(u, d, s) for u, d, s, _n in wanted],
                            progress=self._progress_cb("libraries"), headers=self._ua())
        if failed:
            self.log("WARNING: %d libraries failed: %s" % (
                len(failed), "; ".join(os.path.basename(f[1]) for f in failed[:4])))
        paths = [d for _u, d, _s, _n in wanted if os.path.exists(d)]
        # classic natives (pre-1.19): extract into natives/
        for lib in natives:
            art = lib.get("downloads", {}).get("classifiers", {}) or {}
            key = lib["natives"].get(os_name())
            if key and key in art:
                entry = art[key]
                jar = os.path.join(self.libs_dir, entry["path"])
                try:
                    curl.get(entry["url"], dest=jar, sha1=entry.get("sha1"))
                    self._extract_natives(jar, self.natives_dir, lib.get("extract"))
                    paths.append(jar)
                except CurlError as exc:
                    self.log("native %s failed: %s" % (lib.get("name"), exc))
        return paths

    def _prefer_arch(self, wanted):
        if os_name() != "osx" or os_arch() != "arm64":
            return wanted
        out = []
        bases = set()
        for url, dest, sha1, name in wanted:
            if ":natives-macos-arm64" in name or "natives-macos-arm64" in url:
                bases.add(name.split(":natives-macos-arm64")[0])
        for url, dest, sha1, name in wanted:
            if "natives-macos" in name and "natives-macos-arm64" not in name:
                base = name.split(":natives-macos")[0]
                if base in bases:
                    continue  # arm64 variant exists; skip x86_64
            out.append((url, dest, sha1, name))
        return out

    def _extract_natives(self, jar, dest, extract):
        exclude = (extract or {}).get("exclude", []) or []
        with zipfile.ZipFile(jar) as zf:
            for info in zf.namelist():
                if info.endswith("/"):
                    continue
                if any(info.startswith(e) for e in exclude):
                    continue
                target = os.path.join(dest, info)
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with zf.open(info) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out)
                if info.endswith(".dylib") or info.endswith(".so") or info.endswith(".dll"):
                    os.chmod(target, 0o755)

    def _assets(self, vjson, download=True):
        idx = vjson["assetIndex"]
        idx_path = os.path.join(self.assets_dir, "indexes", "%s.json" % idx["id"])
        self._phase("assets", "asset index %s" % idx["id"])
        self.curl.get(idx["url"], dest=idx_path, sha1=idx.get("sha1"), headers=self._ua())
        if not download:
            self.log("asset download skipped on request")
            return False
        with open(idx_path) as fh:
            data = json.load(fh)
        objects = data["objects"]
        items = []
        for name, obj in objects.items():
            h = obj["hash"]
            items.append(("%s/%s/%s" % (RESOURCES_URL, h[:2], h),
                          os.path.join(self.assets_dir, "objects", h[:2], h), h))
        mb = sum(o["size"] for o in objects.values()) / 1048576.0
        self._phase("assets", "assets (%d objects, %.0f MB)" % (len(items), mb), len(items))
        t0 = time.time()
        failed = self.curl.batch(items, progress=self._progress_cb("assets"),
                                 headers=self._ua())
        if failed:
            # Missing assets are survivable: the game runs with missing textures.
            self.log("WARNING: %d assets missing (~%s). The game will still start." % (
                len(failed), "; ".join(os.path.basename(f[1]) for f in failed[:3])))
        self.log("assets done in %.0fs" % (time.time() - t0))
        return True

    def _fabric_profile(self, mc_version, loader):
        """Fabric hands a profile over directly, and it is the one loader with a stable list to
        choose from - so 'stable' means something here, where Forge and NeoForge just take the
        newest build for the version."""
        text = str(loader).lower()
        want = None if text in ("stable", "latest", "auto", "newest", "", "none") \
            else str(loader).lstrip("fabric-loader-")
        cache_file = self._loader_cache_path("fabric", mc_version, want) if (want and self.cfg.cache) else None
        if cache_file and os.path.exists(cache_file):
            with open(cache_file) as fh:
                prof = json.load(fh)
            self.log("fabric loader %s for %s (from the cache; no network needed)"
                     % (prof.get("_loader"), mc_version))
            return prof, prof.get("_loader")
        try:
            meta = self.curl.json("%s/versions/loader/%s" % (FABRIC_META, mc_version),
                                  headers=self._ua())
        except CurlError:
            if want is None:
                cached = self._newest_cached_profile("fabric", mc_version)
                if cached:
                    prof, lv = cached
                    self.log("fabric: meta.fabricmc.net is unreachable, so the cached loader %s "
                             "is being used for %s" % (lv, mc_version))
                    return prof, lv
            raise
        if not meta:
            raise RuntimeError("Fabric has no loader for Minecraft %s" % mc_version)
        if want is None:
            stable = [e for e in meta if e["loader"].get("stable")]
            pick = meta[0] if text == "latest" else (stable[0] if stable else meta[0])
        else:
            pick = None
            for entry in meta:
                if entry["loader"]["version"] == want:
                    pick = entry
                    break
            if not pick:
                raise RuntimeError("Fabric loader %s does not exist for %s (newest: %s)"
                                   % (want, mc_version,
                                      ", ".join(e["loader"]["version"] for e in meta[:5])))
        version = pick["loader"]["version"]
        self.log("fabric loader %s for %s%s" % (version, mc_version,
                 "" if pick["loader"].get("stable") else " (not marked stable)"))
        profile = self.curl.json("%s/versions/loader/%s/%s/profile/json"
                                 % (FABRIC_META, mc_version, version), headers=self._ua())
        profile["_loader"] = version
        profile["_kind"] = "fabric"
        path = self._loader_cache_path("fabric", mc_version, version)
        if path:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as fh:
                json.dump(profile, fh, indent=1)
        return profile, version

    def _newest_cached_profile(self, kind, mc_version):
        """The loader profile from the most recent cached launch of this version, so a machine
        with no network can still start what it started before."""
        if not self.cfg.cache:
            return None
        cache = os.path.abspath(os.path.expanduser(self.cfg.cache))
        directory = os.path.join(cache, kind)
        if not os.path.isdir(directory):
            return None
        best = None
        for name in os.listdir(directory):
            if not name.startswith(mc_version + "-") or not name.endswith(".json"):
                continue
            path = os.path.join(directory, name)
            try:
                with open(path) as fh:
                    prof = json.load(fh)
                stamp = os.path.getmtime(path)
            except (OSError, ValueError):
                continue
            if best is None or stamp > best[0]:
                best = (stamp, prof)
        if not best:
            return None
        prof = best[1]
        return prof, prof.get("_loader")

    def _loader_profile(self, kind, mc_version, loader):
        """Resolve a loader for a version, as a version document.

        Fabric hands one over directly; Forge and NeoForge publish the same shape inside their
        installer jar, so all three arrive here as {mainClass, libraries, arguments} and the
        rest of the launch path does not care which one it is.
        """
        if kind in ("none", "vanilla", "", None):
            return None, None
        if kind == "fabric":
            return self._fabric_profile(mc_version, loader)
        if kind not in LOADER_KINDS:
            raise RuntimeError("unknown loader %r (known: %s)" % (kind, ", ".join(LOADER_KINDS)))
        if kind not in SUPPORTED_LOADERS:
            raise RuntimeError(
                "%s is not supported yet: its build resolves and its libraries download, but the "
                "client jar it needs (client-<mc>-<stamp>-srg.jar) is produced by its own "
                "installertools patch step, which this helper does not run. Use "
                "--loader-kind fabric - which is the loader most mods are published for - or "
                "watch the repository for this." % kind)

        want = None if str(loader).lower() in ("auto", "latest", "newest", "stable", "", "none") \
            else str(loader)
        cached = self._loader_cache_path(kind, mc_version, want) if (want and self.cfg.cache) else None
        if cached and os.path.exists(cached):
            with open(cached) as fh:
                prof = json.load(fh)
            self.log("%s %s for %s (from the cache; no network needed)"
                     % (kind, prof.get("_loader"), mc_version))
            return prof, prof.get("_loader")

        try:
            versions = self._loader_versions(kind, mc_version)
        except CurlError as exc:
            if want:
                raise RuntimeError(
                    "could not ask %s which builds exist for %s (%s). With --cache and a "
                    "previous launch of this exact loader build, it can be reused offline."
                    % (kind, mc_version, exc))
            raise
        if not versions:
            raise RuntimeError("%s has no build for Minecraft %s" % (kind, mc_version))
        version = want or versions[-1]
        if want and want not in versions:
            raise RuntimeError("%s %s does not exist for %s (newest: %s)"
                               % (kind, want, mc_version, ", ".join(versions[-3:])))
        profile = self._loader_from_installer(kind, mc_version, version)
        path = self._loader_cache_path(kind, mc_version, version)
        if path:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as fh:
                json.dump(profile, fh, indent=1)
        return profile, version

    def _loader_versions(self, kind, mc_version):
        """Newest last, for this Minecraft version. NeoForge numbers itself 21.11.x for 1.21.11
        and 26.3.x for 26.3, so the mapping is not always the obvious one."""
        xml = self.curl.get(LOADER_METADATA[kind], dest=None, timeout=120).decode("utf-8", "replace")
        everything = re.findall(r"<version>([^<]+)</version>", xml)
        if kind == "forge":
            # forge is <minecraft>-<forge>
            return [v.split("-", 1)[1] for v in everything if v.startswith(mc_version + "-")]
        prefix = (".".join(mc_version.split(".")[1:]) if mc_version.startswith("1.")
                  else ".".join(mc_version.split(".")[:2])) + "."
        return [v for v in everything if v.startswith(prefix)]

    def _loader_installer_url(self, kind, mc_version, version):
        if kind == "forge":
            return "%snet/minecraftforge/forge/%s-%s/forge-%s-%s-installer.jar" % (
                LOADER_MAVEN[kind], mc_version, version, mc_version, version)
        return "%snet/neoforged/neoforge/%s/neoforge-%s-installer.jar" % (
            LOADER_MAVEN[kind], version, version)

    def _loader_from_installer(self, kind, mc_version, version):
        url = self._loader_installer_url(kind, mc_version, version)
        dest = os.path.join(self.versions_dir, "%s-installer-%s.jar" % (kind, version))
        self.log("%s %s for %s: reading its own version document" % (kind, version, mc_version))
        self.curl.get(url, dest=dest, timeout=600, headers=self._ua())
        try:
            with zipfile.ZipFile(dest) as zf:
                if "version.json" not in zf.namelist():
                    raise RuntimeError("%s %s has no version.json to read" % (kind, version))
                profile = json.loads(zf.read("version.json").decode("utf-8", "replace"))
        except zipfile.BadZipFile:
            raise RuntimeError("%s %s did not download as a jar" % (kind, version))
        profile["_loader"] = version
        profile["_kind"] = kind
        libs = profile.get("libraries") or []
        if not libs:
            raise RuntimeError("%s %s lists no libraries" % (kind, version))
        self.log("  %s %s: %s, %d libraries, %s"
                 % (kind, version, profile.get("mainClass"), len(libs),
                    "inherits " + str(profile.get("inheritsFrom"))))
        return profile

    def _loader_cache_path(self, kind, mc_version, version):
        if not self.cfg.cache or not version:
            return None
        cache = os.path.abspath(os.path.expanduser(self.cfg.cache))
        return os.path.join(cache, kind, "%s-%s.json" % (mc_version, version))

    def _profile_libraries(self, profile):
        """Every library a loader profile names, into the sandbox.

        Forge and NeoForge carry full download blocks (url + sha1 + path); Fabric carries only
        Maven coordinates, so the path is built from those. All three end up in the same place.
        """
        if not profile:
            return []
        kind = profile.get("_kind") or "fabric"
        if kind in ("forge", "neoforge"):
            # Forge and NeoForge do not ship a usable client jar: their own installer runs
            # installertools over the vanilla jar to produce client-<mc>-<stamp>-srg.jar and
            # ...-extra.jar, and their bootstrap refuses to start without them. Until the helper
            # runs that step itself, say so here rather than letting FML report a "corrupted
            # installation" twenty seconds later.
            self.log("  %s needs its own client-patching step (installertools), which this helper "
                     "does not run yet - the game will most likely refuse to start." % kind)
        out = []
        for lib in profile.get("libraries", []):
            if not rules_allow(lib.get("rules"), self._features()):
                continue
            artifact = (lib.get("downloads") or {}).get("artifact") or {}
            rel = artifact.get("path")
            url = artifact.get("url")
            sha1 = artifact.get("sha1")
            if rel and url:
                dest = os.path.join(self.libs_dir, rel)
            else:
                name = lib.get("name") or ""
                repo = (lib.get("url") or "").rstrip("/")
                if not repo:
                    if name.startswith("net.minecraftforge"):
                        repo = LOADER_MAVEN["forge"].rstrip("/")
                    elif name.startswith("net.neoforged"):
                        repo = LOADER_MAVEN["neoforge"].rstrip("/")
                    else:
                        repo = "https://libraries.minecraft.net"
                rel, _n = maven_to_path(name)
                if not rel:
                    continue
                dest = os.path.join(self.libs_dir, rel)
                url = "%s/%s" % (repo, rel)
            out.append(dest)
            if not os.path.exists(dest):
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                try:
                    self.curl.get(url, dest=dest, sha1=sha1, headers=self._ua())
                except CurlError as exc:
                    self.log("library %s could not be fetched: %s" % (os.path.basename(dest), exc))
        if out:
            self._phase(kind, "%s %s libraries" % (kind, profile.get("_loader")),
                        len(profile.get("libraries", [])))
            self._progress("%s libraries" % kind, len(out), len(out))
        return out

    def _features(self):
        return {
            "is_demo_user": False,
            "has_custom_resolution": False,
            "has_quick_plays_support": False,
            "is_quick_play_singleplayer": False,
            "is_quick_play_multiplayer": False,
            "is_quick_play_realms": False,
        }

    def _local_mods(self, paths):
        """Jars already on this machine, copied into the sandbox's mods folder.
        These are deleted with everything else when the session ends."""
        out = []
        mods_dir = os.path.join(self.game_dir, "mods")
        for p in paths:
            src = os.path.abspath(os.path.expanduser(p))
            if not os.path.exists(src):
                self.log("mod jar %s does not exist - skipped" % src)
                continue
            if not src.endswith(".jar"):
                self.log("mod jar %s is not a .jar - skipped" % src)
                continue
            dest = os.path.join(mods_dir, os.path.basename(src))
            shutil.copy2(src, dest)
            self.log("mod %s (local file, copied into the sandbox)" % os.path.basename(src))
            out.append({"name": os.path.basename(src), "slug": "local",
                        "version": "local file", "file": os.path.basename(src),
                        "path": dest})
        return out

    def _mods(self, slugs, mc_version, loader_ver):
        out = []
        if not slugs:
            return out
        self._phase("mods", "mods from Modrinth (%d)" % len(slugs), len(slugs))
        mods_dir = os.path.join(self.game_dir, "mods")
        for i, slug in enumerate(slugs):
            try:
                q = urllib.parse.urlencode({
                    "loaders": json.dumps(["fabric"]),
                    "game_versions": json.dumps([mc_version]),
                })
                versions = self.curl.json("%s/project/%s/version?%s" % (MODRINTH_API, slug, q),
                                          headers=self._ua())
                if not versions:
                    self.log("mod %s has no Fabric build for %s - skipped" % (slug, mc_version))
                    self._progress("mods", i + 1, len(slugs))
                    continue
                v = versions[0]
                files = [f for f in v["files"] if f.get("primary")] or v["files"]
                f = files[0]
                dest = os.path.join(mods_dir, f["filename"])
                self.curl.get(f["url"], dest=dest, headers=self._ua())
                self.log("mod %s %s -> %s" % (v.get("name") or slug, v["version_number"],
                                              f["filename"]))
                out.append({"name": v.get("name") or slug, "slug": slug,
                            "version": v["version_number"], "file": f["filename"],
                            "path": dest})
            except CurlError as exc:
                self.log("mod %s could not be fetched: %s" % (slug, exc))
            self._progress("mods", i + 1, len(slugs))
        return out

    def _build_command(self, vjson, profile, client_jar, libs, mc_version, loader_ver,
                       username, memory, mods):
        features = self._features()
        if profile:
            main_class = profile.get("mainClass") or vjson["mainClass"]
            version_name = profile.get("id") or ("fabric-loader-%s-%s" % (loader_ver, mc_version))
            jvm_args = list(vjson["arguments"]["jvm"])
            for a in profile.get("arguments", {}).get("jvm", []) or []:
                if isinstance(a, str) or rules_allow(a.get("rules"), features):
                    jvm_args.append(a)
            game_args = profile.get("arguments", {}).get("game") or vjson["arguments"]["game"]
            version_type = "Fabric"
        else:
            main_class = vjson["mainClass"]
            version_name = vjson["id"]
            jvm_args = list(vjson["arguments"]["jvm"])
            game_args = vjson["arguments"]["game"]
            version_type = vjson.get("type", "release")

        classpath = list(libs)
        if client_jar not in classpath:
            classpath.append(client_jar)
        cp = os.pathsep.join(classpath)
        offline_uuid = offline_uuid_for(username)
        sub = {
            "auth_player_name": username,
            "version_name": version_name,
            "game_directory": self.game_dir,
            "assets_root": self.assets_dir,
            "assets_index_name": vjson["assetIndex"]["id"],
            "auth_uuid": offline_uuid,
            "auth_access_token": "0",
            "auth_session": "0",
            "user_type": "legacy",
            "version_type": version_type,
            "user_properties": "{}",
            "clientid": "",
            "auth_xuid": "",
            "launcher_name": NAME,
            "launcher_version": VERSION,
            "natives_directory": self.natives_dir,
            "library_directory": self.libs_dir,
            "classpath": cp,
            "classpath_separator": os.pathsep,
            "resolution_width": "1280",
            "resolution_height": "720",
            "quickPlayPath": "",
            "quickPlaySingleplayer": "",
            "quickPlayMultiplayer": "",
            "quickPlayRealms": "",
        }
        cmd = [self.java, "-Xmx%s" % memory]
        if getattr(self, "socks", None):
            # Java routes every TCP connection a program makes through these, so the game's own
            # multiplayer, authentication and skin fetching all travel inside the relay
            cmd += ["-DsocksProxyHost=127.0.0.1", "-DsocksProxyPort=%d" % self.socks_port,
                    "-Djava.net.useSystemProxies=false"]
        if os_name() == "osx":
            cmd += ["-Dapple.awt.application.appearance=system"]
        cmd += ["-Dfabric.gameJarPath=%s" % client_jar]
        cmd += materialise(jvm_args, sub, features)
        cmd += [main_class]
        cmd += materialise(game_args, sub, features)
        if self.quick_play:
            # 1.20 and later can join straight away: the difference between "connect to
            # 127.0.0.1:35565 yourself" and pressing PLAY and already being in the server
            cmd += ["--quickPlayMultiplayer", self.quick_play]
        return cmd, classpath

    def _preseed_options(self):
        """A brand new session has no options.txt, and Minecraft's title screen then asks whether to
        turn the narrator on - every single time, for somebody who never wanted it. One line fixes
        that; anything restored from a previous session still wins, because this writes only when
        there is nothing there."""
        path = os.path.join(self.game_dir, "options.txt")
        if os.path.exists(path):
            return
        try:
            with open(path, "w") as fh:
                fh.write("narrator:0\n")
            self.log("wrote a starter options.txt (narrator off, so the title screen does not ask)")
        except OSError:
            pass

    def _collect(self):
        self._phase("collect", "collecting what the session wrote", check_cancel=False)
        wanted = ["saves", "logs", "crash-reports", "screenshots", "config",
                  "options.txt", "servers.dat", "usercache.json", "realms_persistence.json"]
        files = []
        with zipfile.ZipFile(self.bundle_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for rel in wanted:
                src = os.path.join(self.game_dir, rel)
                if not os.path.exists(src):
                    continue
                if os.path.isfile(src):
                    zf.write(src, rel)
                    files.append({"path": rel, "size": os.path.getsize(src)})
                    continue
                for base, _dirs, names in os.walk(src):
                    for n in names:
                        full = os.path.join(base, n)
                        arc = os.path.relpath(full, self.game_dir)
                        try:
                            zf.write(full, arc)
                            files.append({"path": arc, "size": os.path.getsize(full)})
                        except OSError:
                            pass
            # the console log is ours, and it is the thing that explains a crash
            console = os.path.join(self.root, "console.log")
            if os.path.exists(console):
                zf.write(console, "console.log")
                files.append({"path": "console.log", "size": os.path.getsize(console)})
            # The helper's own account of the attempt, always. A launch that was stopped (or that
            # died) before the game started has no console.log at all, and this is then the only
            # record of what it was doing - which is the whole difference between "it didn't work"
            # and "it didn't work and nobody knows why".
            with self.lock:
                helper_lines = list(self.lines)
            if helper_lines:
                payload = ("\n".join(helper_lines) + "\n").encode("utf-8")
                zf.writestr("helper.log", payload)
                files.append({"path": "helper.log", "size": len(payload)})
            launch = os.path.join(self.root, "launch-command.txt")
            if os.path.exists(launch):
                zf.write(launch, "launch-command.txt")
                files.append({"path": "launch-command.txt", "size": os.path.getsize(launch)})
        total = os.path.getsize(self.bundle_path)
        worlds = sorted({f["path"].split("/")[1] for f in files
                         if f["path"].startswith("saves/") and len(f["path"].split("/")) > 2})
        self.result = {
            "bundle": "session.zip",
            "bytes": total,
            "files": len(files),
            "worlds": worlds,
            "hasCrash": any(f["path"].startswith("crash-reports/") for f in files),
            "exitCode": self.exit_code,
            "collectedAt": time.time(),
        }
        if self.manager:
            try:
                self.manager.store_session(self)
            except Exception as exc:  # noqa: BLE001 - keeping it is best-effort
                self.log("could not keep this session for next time: %s" % exc)
        self.log("collected %d files (%.1f MB) into session.zip%s" % (
            len(files), total / 1048576.0,
            " - worlds: " + ", ".join(worlds) if worlds else ""))
        return self.result



    def _stop_tunnel(self):
        if getattr(self, "socks", None):
            try:
                self.socks.stop()
            except Exception:
                pass
            self.socks = None
        if self.tunnel:
            try:
                self.tunnel.stop()
            except Exception:
                pass
            self.tunnel = None

    def cleanup(self, why="the page asked for it"):
        """Delete the sandbox. This is the promise the whole design rests on."""
        if not os.path.isdir(self.root):
            receipt = {"removed": 0, "path": self.root, "already": True, "why": why}
            with self.lock:
                self.last_cleanup = receipt
            return receipt
        if self.cfg.keep:
            return {"removed": 0, "path": self.root, "kept": True, "why": why,
                    "note": "--keep was given, nothing deleted"}
        size = 0
        files = 0
        leftovers = []
        for base, _dirs, names in os.walk(self.root):
            for n in names:
                full = os.path.join(base, n)
                try:
                    if os.path.islink(full):
                        continue          # borrowed from the cache: not ours to count
                    size += os.path.getsize(full)
                    files += 1
                except OSError:
                    pass
        self._stop_tunnel()
        shutil.rmtree(self.root, ignore_errors=True)
        with self.lock:
            self.cleanup_deadline = None
        # Anything of ours that a crash could have scattered outside the sandbox.
        for pattern in ("webmc-curl-*.conf", "webmc-*.part"):
            import glob as _glob
            for stray in _glob.glob(os.path.join(os.environ.get("TMPDIR", "/tmp"), pattern)):
                try:
                    size += os.path.getsize(stray)
                    os.unlink(stray)
                    leftovers.append(stray)
                except OSError:
                    pass
        gone = not os.path.exists(self.root)
        receipt = {"removed": size, "files": files, "path": self.root, "gone": gone,
                   "why": why, "strays": leftovers, "at": time.time()}
        with self.lock:
            self.last_cleanup = receipt
        self.log("deleted %s (%s files, %.1f MB freed)%s"
                 % (self.root, files, size / 1048576.0,
                    "" if gone else " -- SOMETHING IS STILL THERE"))
        return receipt

    def restore(self, blob):
        """Put a previous session's bundle back into the game dir before launch.

        The page calls this *after* cleanup has deleted the sandbox, so the whole
        tree has to be rebuilt first - on a warm cache that costs nothing.
        """
        self._prepare_root()
        tmp = os.path.join(self.root, "restore-%s.zip" % secrets.token_hex(4))
        with open(tmp, "wb") as fh:
            fh.write(blob)
        count = 0
        with zipfile.ZipFile(tmp) as zf:
            for info in zf.namelist():
                if info.startswith("/") or ".." in info.split("/"):
                    continue
                zf.extract(info, self.game_dir)
                count += 1
        os.unlink(tmp)
        self.log("restored %d files from the browser into the sandbox" % count)
        return {"restored": count}

    # ---------------------------------------------------------------- pushed mods
    @property
    def local_mods_dir(self):
        """Where the jars the visitor handed over live. Shared by every session, because a mod
        list belongs to the visitor rather than to one launch."""
        if self.manager:
            return self.manager.mods_dir
        return os.path.join(self.root, "localmods")

    def _pending_mod_paths(self):
        directory = self.local_mods_dir
        if not os.path.isdir(directory):
            return []
        return [os.path.join(directory, n) for n in sorted(os.listdir(directory))
                if n.endswith(".jar")]

    def accept_mod(self, name, blob):
        """Take a jar from the browser.

        It lives inside the sandbox and is deleted with it; the page keeps its own
        copy, so a visitor's mods travel with the browser rather than with the
        computer - which is the same promise the rest of this makes.
        """
        safe = re.sub(r"[^A-Za-z0-9._+ -]", "_", os.path.basename(name or "mod.jar"))
        if not safe.lower().endswith(".jar"):
            safe += ".jar"
        if not blob:
            raise ValueError("empty file")
        if len(blob) > 64 * 1024 * 1024:
            raise ValueError("that jar is larger than 64 MB")
        if blob[:2] != b"PK":
            raise ValueError("that is not a jar (a jar is a zip, and this does not start like one)")
        try:
            with zipfile.ZipFile(io.BytesIO(blob)) as zf:
                names = zf.namelist()
                is_mod = any(n == "fabric.mod.json" or n.endswith("/fabric.mod.json")
                             or n == "META-INF/mods.toml" or n == "mcmod.info" for n in names)
                title = version = None
                if "fabric.mod.json" in names:
                    meta = json.loads(zf.read("fabric.mod.json").decode("utf-8", "replace"))
                    title = meta.get("name") or meta.get("id")
                    version = meta.get("version")
        except (zipfile.BadZipFile, ValueError, KeyError):
            raise ValueError("that jar could not be read")
        if not is_mod:
            raise ValueError("no fabric.mod.json, META-INF/mods.toml or mcmod.info inside, "
                             "so this is a library or a plain zip rather than a mod")
        os.makedirs(self.local_mods_dir, exist_ok=True)
        dest = os.path.join(self.local_mods_dir, safe)
        with open(dest, "wb") as fh:
            fh.write(blob)
        entry = {"name": safe, "bytes": len(blob), "title": title, "version": version}
        with self.lock:
            self.pending_mods = [m for m in self.pending_mods if m["name"] != safe] + [entry]
        self.log("mod %s taken from the browser (%s, %.1f MB)%s"
                 % (safe, title or "unnamed", len(blob) / 1048576.0,
                    "" if version is None else " " + str(version)))
        return entry

    def drop_mod(self, name):
        safe = re.sub(r"[^A-Za-z0-9._+ -]", "_", os.path.basename(name or ""))
        path = os.path.join(self.local_mods_dir, safe)
        if os.path.exists(path):
            os.unlink(path)
        with self.lock:
            self.pending_mods = [m for m in self.pending_mods if m["name"] != safe]
        return {"dropped": safe}

    def clear_mods(self):
        dropped = 0
        if os.path.isdir(self.local_mods_dir):
            for n in os.listdir(self.local_mods_dir):
                try:
                    os.unlink(os.path.join(self.local_mods_dir, n))
                    dropped += 1
                except OSError:
                    pass
        with self.lock:
            self.pending_mods = []
        return {"dropped": dropped}

    def search_mods(self, query, mc_version=None, limit=12):
        """Modrinth search, done here rather than in the page: the helper can reach it
        through the visitor's proxy on a network where the browser cannot."""
        q = urllib.parse.urlencode({
            "query": query, "limit": limit,
            "facets": json.dumps([["project_type:mod"], ["categories:fabric"]]
                                 + ([["versions:%s" % mc_version]] if mc_version else [])),
        })
        data = self.curl.json("%s/search?%s" % (MODRINTH_API, q), headers=self._ua())
        out = []
        for hit in data.get("hits", []):
            out.append({
                "slug": hit.get("slug"), "title": hit.get("title"),
                "description": (hit.get("description") or "")[:200],
                "downloads": hit.get("downloads"), "author": hit.get("author"),
                "icon": hit.get("icon_url"), "versions": (hit.get("versions") or [])[-4:],
            })
        return {"results": out, "query": query}

    # ---------------------------------------------------------------- helpers
    def _ua(self):
        return ("User-Agent: %s/%s (+https://github.com/derek/webmc)" % (NAME, VERSION),)

    def _progress_cb(self, label):
        def cb(done, total, _round=None):
            self._progress(label, done, total)
        return cb


def materialise(args, sub, features):
    """Flatten and substitute Mojang's argument list."""
    out = []
    for a in args:
        if isinstance(a, str):
            out.append(a)
            continue
        if not rules_allow(a.get("rules"), features):
            continue
        val = a.get("value")
        if isinstance(val, list):
            out.extend(val)
        elif val is not None:
            out.append(val)
    return [substitute(x, sub) for x in out]


PLACEHOLDER = re.compile(r"\$\{([a-zA-Z0-9_]+)\}")


def substitute(text, sub):
    return PLACEHOLDER.sub(lambda m: str(sub.get(m.group(1), "")), text)


def offline_uuid_for(name):
    digest = bytearray(hashlib.md5(("OfflinePlayer:" + name).encode("utf-8")).digest())
    digest[6] = (digest[6] & 0x0F) | 0x30
    digest[8] = (digest[8] & 0x3F) | 0x80
    return str(uuidlib.UUID(bytes=bytes(digest)))


def shell_quote(s):
    if re.match(r"^[A-Za-z0-9_@%+=:,./-]+$", s or ""):
        return s
    return "'" + (s or "").replace("'", "'\\''") + "'"


def port_open(host, port, timeout=0.25):
    s = socket.socket()
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def detect_proxy(explicit, curl_log):
    if explicit in ("none", "direct", ""):
        return None
    if explicit:
        return explicit
    for cand in PROXY_CANDIDATES:
        host_port = cand.split("://", 1)[1]
        host, port = host_port.split(":")
        if not port_open(host, int(port)):
            continue
        try:
            probe = Curl(proxy=cand)
            probe.get(MANIFEST_URL, dest=None, timeout=25)
            curl_log("proxy: %s (Mojang reachable through it)" % cand)
            return cand
        except CurlError as exc:
            curl_log("proxy candidate %s could not reach Mojang: %s" % (cand, exc))
    return None


# --------------------------------------------------------------------------- page

PAGE_SUFFIX = """
<script>
window.__WEBMC__ = { helper: "http://127.0.0.1:%(port)d", token: "%(token)s",
                     served: "helper" };
</script>
"""


# --------------------------------------------------------------------------- http

class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "%s/%s" % (NAME, VERSION)
    protocol_version = "HTTP/1.1"

    # ---- plumbing
    def log_message(self, fmt, *args):
        if self.server.verbose:
            sys.stderr.write("http %s\n" % (fmt % args))

    def _cors(self):
        origin = self.headers.get("Origin")
        allowed = None
        if origin:
            if origin in self.server.extra_origins or any(p.match(origin) for p in ORIGIN_PATTERNS):
                allowed = origin
        if allowed:
            self.send_header("Access-Control-Allow-Origin", allowed)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers",
                         "content-type, x-webmc-token, access-control-request-private-network")
        # Chrome 142+ gates public -> loopback behind Local Network Access. Answering
        # the preflight with this header is what keeps the bridge usable where an
        # admin has not blocked it outright.
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Cache-Control", "no-store")

    def _send(self, code, body=b"", ctype="application/json", extra=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code, obj):
        self._send(code, json.dumps(obj, indent=1))

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return b""
        return self.rfile.read(n)

    def _json_body(self):
        raw = self._body()
        if not raw:
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError:
            return {}

    def _authed(self):
        if self.path.split("?")[0] in ("/api/hello", "/", "/go", "/favicon.ico"):
            return True
        return self.headers.get("X-WebMC-Token") == self.server.token

    def _guard(self):
        if self._authed():
            return True
        self._json(403, {"error": "bad or missing X-WebMC-Token"})
        return False

    # ---- routes
    def do_OPTIONS(self):
        self._send(204)

    def do_HEAD(self):
        self.do_GET()

    def _session(self, query):
        """The session a request is about: ?id=… , or the newest one still working."""
        sid = (query.get("id") or [None])[0]
        return self.server.registry.pick(sid)

    def do_GET(self):
        parts = urllib.parse.urlsplit(self.path)
        path, query = parts.path, urllib.parse.parse_qs(parts.query)
        reg = self.server.registry
        s = self._session(query)
        if s:
            s.touch()
        else:
            reg.touch()
        if path == "/favicon.ico":
            return self._send(204)
        if path == "/":
            return self._page()
        if path == "/go":
            return self._go(query)
        if path == "/api/hello":
            return self._json(200, {
                "ok": True, "name": NAME, "version": VERSION,
                "platform": {"os": os_name(), "arch": os_arch(), "version": os_version()},
                "sandbox": (s.root if s else reg.cfg.root),
                "sessions": len(reg.sessions),
                "store": {"dir": reg.store,
                          "kept": len([n for n in os.listdir(reg.store) if n.endswith(".zip")])
                                  if os.path.isdir(reg.store) else 0},
                "proxy": self.server.curl.proxy or "direct",
                "relay": (s.cfg.relay if s else reg.cfg.relay) or None,
                "relayBuiltIn": len(DEFAULT_RELAYS),
                "relayMode": ("custom" if (s.cfg.relay if s else reg.cfg.relay)
                              and (s.cfg.relay if s else reg.cfg.relay) not in DEFAULT_RELAYS
                              else "auto" if (s.cfg.relay if s else reg.cfg.relay) else "off"),
                "downloads": self.server.curl.bytes_in,
                "autocleanSeconds": (s.cfg.autoclean if s else reg.cfg.autoclean),
                "features": ["fabric", "real-jvm", "opfs-bundle", "restore", "modrinth",
                             "local-mods", "mod-search", "audit"],
            })
        if not self._guard():
            return
        if path == "/api/sessions":
            return self._json(200, {"sessions": reg.list()})
        if path == "/api/status":
            if not s:
                return self._json(200, {"state": "idle", "phase": "idle", "phaseLabel": "Ready",
                                        "progress": {"done": 0, "total": 0, "percent": None},
                                        "instance": {}, "pid": None, "exitCode": None,
                                        "result": None})
            return self._json(200, s.status())
        if path == "/api/search":
            q = (query.get("q") or [""])[0].strip()
            if not q:
                return self._json(400, {"error": "give me something to search for (?q=sodium)"})
            try:
                return self._json(200, s.search_mods(q, (query.get("mc") or [None])[0]))
            except CurlError as exc:
                return self._json(502, {"error": str(exc)})
        if path == "/api/localmods":
            return self._json(200, {"mods": [{"name": m["name"], "bytes": m["bytes"],
                                              "title": m.get("title"),
                                              "version": m.get("version")}
                                             for m in reg.mods],
                                    "dir": reg.mods_dir})
        if path == "/api/versions":
            try:
                return self._json(200, s.versions())
            except CurlError as exc:
                return self._json(502, {"error": str(exc)})
        if path == "/api/log":
            since = int((query.get("since") or ["0"])[0] or 0)
            if not s:
                return self._json(200, {"lines": [], "next": since})
            lines, nxt = s.lines_since(since)
            return self._json(200, {"lines": lines, "next": nxt})
        if path == "/api/result":
            if not s:
                return self._json(404, {"error": "no session"})
            return self._json(200, {"result": s.result, "state": s.state,
                                    "exitCode": s.exit_code, "error": s.error})
        if path == "/api/bundle.zip":
            if not s or not s.result or not os.path.exists(s.bundle_path):
                return self._json(404, {"error": "no bundle yet"})
            with open(s.bundle_path, "rb") as fh:
                blob = fh.read()
            return self._send(200, blob, "application/zip", {
                "Content-Disposition": 'attachment; filename="webmc-session.zip"'})
        return self._json(404, {"error": "no such endpoint", "path": path})

    def do_POST(self):
        parts = urllib.parse.urlsplit(self.path)
        path, query = parts.path, urllib.parse.parse_qs(parts.query)
        reg = self.server.registry
        s = self._session(query)
        if s:
            s.touch()
        else:
            reg.touch()
        if not self._guard():
            return
        # ---- the mods a visitor brings with them
        if path == "/api/localmods":
            if (query.get("clear") or [""])[0]:
                return self._json(200, reg.clear_mods())
            drop = (query.get("drop") or [""])[0]
            if drop:
                return self._json(200, reg.drop_mod(drop))
            name = self.headers.get("X-WebMC-Mod-Name") or "mod.jar"
            try:
                return self._json(200, reg.accept_mod(name, self._body()))
            except ValueError as exc:
                return self._json(400, {"error": str(exc), "name": name})
        if path == "/api/launch":
            body = self._json_body()
            opts = {
                "version": body.get("version") or DEFAULT_VERSION,
                "loader": body.get("loader") or "auto",
                "loaderKind": body.get("loaderKind") or "fabric",
                "relay": body.get("relay") or self.server.registry.cfg.relay,
                "tunnelServer": body.get("tunnelServer"),
                "tunnelPort": body.get("tunnelPort"),
                "tunnelEverything": bool(body.get("tunnelEverything")),
                "restricted": bool(body.get("restricted")),
                "mods": body.get("mods") or [],
                "username": body.get("username") or "Player",
                "memory": body.get("memory") or DEFAULT_MEMORY,
                "assets": body.get("assets", True),
            }
            try:
                # Every launch is its own session, so a second window - or another version - can
                # run while the first is still playing.
                started = reg.launch(opts)
            except Exception as exc:  # noqa: BLE001
                return self._json(400, {"error": str(exc)})
            return self._json(202, {"started": True, "id": started.sid, "instance": opts})
        if path == "/api/stop":
            # One button, whichever state a session is in: mid-download it cancels, running it
            # kills the game. With no session named it stops the newest one that is working.
            if not s:
                return self._json(200, {"cancelled": False, "note": "nothing is running"})
            return self._json(200, s.cancel())
        if path == "/api/restore":
            blob = self._body()
            if not s:
                # The page restores before it launches, so keep the bundle until then: the next
                # launch unpacks it into its own sandbox before the game starts.
                reg.pending_restore = blob
                return self._json(200, {"queued": len(blob)})
            if not blob:
                return self._json(400, {"error": "empty body"})
            try:
                return self._json(200, s.restore(blob))
            except Exception as exc:  # noqa: BLE001
                return self._json(400, {"error": "not a usable bundle: %s" % exc})
        if path == "/api/cleanup":
            if not s:
                return self._json(200, {"removed": 0, "gone": True, "already": True})
            return self._json(200, s.cleanup())
        return self._json(404, {"error": "no such endpoint", "path": path})

    # ---- the helper's own copy of the page
    def _page(self):
        page = self.server.page_path
        if (not page or not os.path.exists(page)) and _EMBEDDED_PAGE:
            # Self-healing: the sandbox (and the page written into it) is deleted when a session
            # ends, and the page has to come back for the next visit.
            page = materialise_embedded_page(os.environ.get("WEBMC_CLEANUP_DIR")
                                             or os.path.dirname(self.server.registry.cfg.root)) or page
            self.server.page_path = page
        if not page or not os.path.exists(page):
            return self._json(200, {
                "name": NAME, "version": VERSION,
                "note": "page not found next to the helper; use /api/* or pass --page",
                "hint": "http://127.0.0.1:%d/api/hello" % self.server.server_address[1],
            })
        with open(page, "rb") as fh:
            html = fh.read().decode("utf-8")
        inject = PAGE_SUFFIX % {"port": self.server.server_address[1],
                                "token": self.server.token}
        # This has to land before the page's own script runs, or the page cannot see the
        # token it was just handed. Injecting it at the end made a helper-served page
        # say "not connected" while talking to the helper that served it.
        placed = False
        for marker, before in (("<head>", False), ("</head>", True), ("</body>", True)):
            if marker in html:
                html = html.replace(marker, (inject + marker) if before else (marker + inject), 1)
                placed = True
                break
        if not placed:
            html = inject + html
        self._send(200, html, "text/html; charset=utf-8")

    def _go(self, query):
        """Hand the token to a hosted copy of the page, via the URL fragment."""
        target = (query.get("to") or [""])[0]
        if not target:
            return self._send(400, "missing ?to=", "text/plain")
        parsed = urllib.parse.urlsplit(target)
        ok = (parsed.scheme in ("http", "https") and (
            any(p.match("%s://%s" % (parsed.scheme, parsed.netloc)) for p in ORIGIN_PATTERNS)
            or parsed.netloc.endswith("github.io")))
        if not ok:
            return self._send(400, "refusing to redirect to %s" % target, "text/plain")
        frag = "helper=http://127.0.0.1:%d&t=%s" % (self.server.server_address[1],
                                                    self.server.token)
        sep = "&" if "#" in target else "#"
        loc = target + sep + frag
        self.send_response(302)
        self._cors()
        self.send_header("Location", loc)
        self.send_header("Content-Length", "0")
        self.end_headers()


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, addr, handler, registry, curl, token, page_path, origins, verbose):
        self.registry = registry
        self.curl = curl
        self.token = token
        self.page_path = page_path
        self.extra_origins = set(origins)
        self.verbose = verbose
        super().__init__(addr, handler)


# --------------------------------------------------------------------------- cli

def default_page(root):
    """Where the launcher page is, when it is not given.

    One file has to be able to serve its own page, so an embedded copy is written out next to the
    sandbox's files. That copy has to be re-creatable, not written once: the sandbox is deleted
    when a session ends, and the page used to be deleted with it, so after the first session the
    helper answered "/" with "page not found next to the helper".
    """
    if _EMBEDDED_PAGE:
        return materialise_embedded_page(root)
    here = globals().get("__file__")
    if not here:
        return None
    guess = os.path.join(os.path.dirname(os.path.abspath(here)), os.pardir, "page", "index.html")
    return os.path.abspath(guess) if os.path.exists(guess) else None


def materialise_embedded_page(root):
    import base64
    path = os.path.join(root, "page.html")
    try:
        if os.path.exists(path) and os.path.getsize(path) > 0:
            return path
        os.makedirs(root, exist_ok=True)
        with open(path, "wb") as fh:
            fh.write(base64.b64decode(_EMBEDDED_PAGE))
        return path
    except Exception:
        return None


def default_root():
    return os.path.join("/tmp", "webmc-%s" % secrets.token_hex(4))


def sweep_stale_sandboxes(older_than=6 * 3600, keep=None, log=print):
    """A helper that was killed hard (or a machine that went down) leaves its
    sandbox behind. /tmp is emptied on reboot anyway, but the promise is that
    nothing survives a session, so clear out anything old enough that it cannot
    belong to a session still in progress."""
    removed = 0
    freed = 0
    now = time.time()
    try:
        names = os.listdir("/tmp")
    except OSError:
        return 0, 0
    for name in names:
        if not name.startswith("webmc-"):
            continue
        path = os.path.join("/tmp", name)
        if keep and os.path.abspath(path) == os.path.abspath(keep):
            continue
        if not os.path.isdir(path):
            continue
        # Ours means: the default naming (webmc-<8 hex>) or a directory that carries
        # our owner.json (which also covers a custom --root). A directory someone else
        # named webmc-something is not ours to delete.
        owner = read_owner(path)
        if not re.fullmatch(r"webmc-[0-9a-f]{8}", name) and owner is None:
            continue
        abandoned = owner is not None and not pid_alive(owner.get("pid"))
        try:
            age = now - os.path.getmtime(path)
        except OSError:
            continue
        # Two reasons to delete: the helper that owned it is gone (so nobody will ever
        # clean it), or it is simply old. The first one is why this is fast: a sandbox
        # left by a crash is removed on the next run, not six hours later.
        if not abandoned and age < older_than:
            continue
        try:
            for base, _dirs, files in os.walk(path):
                for f in files:
                    full = os.path.join(base, f)
                    try:
                        if not os.path.islink(full):
                            freed += os.path.getsize(full)
                    except OSError:
                        pass
            shutil.rmtree(path, ignore_errors=True)
            removed += 1
            log("cleared leftover sandbox %s (%s)"
                % (path, "its helper is gone" if abandoned else "older than %.0fh" % (older_than / 3600.0)))
        except OSError:
            pass
    import glob as _glob
    for stray in _glob.glob(os.path.join(os.environ.get("TMPDIR", "/tmp"), "webmc-curl-*.conf")):
        try:
            freed += os.path.getsize(stray)
            os.unlink(stray)
            removed += 1
        except OSError:
            pass
    if removed:
        log("cleared %d leftover item(s) from earlier runs (%.0f MB)"
            % (removed, freed / 1048576.0))
    return removed, freed


def read_owner(path):
    try:
        with open(os.path.join(path, "owner.json")) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def pid_alive(pid):
    """Is that pid still a live process of ours? Unknown counts as alive, so the
    sweep never deletes a sandbox it cannot be sure about."""
    if not pid:
        return True
    try:
        os.kill(int(pid), 0)
        return True
    except ProcessLookupError:
        return False
    except (PermissionError, ValueError, OSError):
        return True


def _boot_id():
    """Distinguishes 'this pid is gone' from 'this pid was reused after a reboot'."""
    try:
        return "%.0f" % time.time()
    except Exception:
        return ""


AGENT_LABEL = "dev.amphibian.webmc-helper"
INSTALLED_DIR = "~/Library/Application Support/webmc"
AGENT_PLIST = "~/Library/LaunchAgents/dev.amphibian.webmc-helper.plist"
LOG_FILE = "~/Library/Logs/webmc-helper.log"
SHIPPED = (("helper/webmc_helper.py", 0o755),
           ("helper/start-helper.command", 0o755),
           ("page/index.html", 0o644))


def session_store_dir(cfg=None):
    """Where a finished session is kept so the next launch can start from it.

    Your world has to live somewhere between sessions, and the browser is the wrong only place for
    it: storage belongs to an origin, and this launcher legitimately runs on two of them (the helper's
    own page at 127.0.0.1:7645, and a hosted copy on github.io). A session saved by one is invisible
    to the other, which is exactly how worlds and options come to reset. So the helper keeps a copy
    of each session's bundle as well, and restores from it when the page has nothing to offer.
    """
    if cfg is not None and getattr(cfg, "store", None):
        return os.path.abspath(os.path.expanduser(cfg.store))
    if os_name() == "osx":
        base = "~/Library/Application Support/webmc"
    elif os_name() == "windows":
        base = os.path.join(os.environ.get("LOCALAPPDATA") or "~", "webmc")
    else:
        base = os.path.join(os.environ.get("XDG_DATA_HOME") or "~/.local/share", "webmc")
    return os.path.expanduser(os.path.join(base, "sessions"))


def installed_paths():
    return {"dir": os.path.expanduser(INSTALLED_DIR),
            "plist": os.path.expanduser(AGENT_PLIST),
            "log": os.path.expanduser(LOG_FILE)}


def agent_plist_text(python, helper, page_url, port):
    def esc(text):
        return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
    args = [python, helper, "--server-only", "--port", str(port)]
    if page_url:
        args += ["--page-url", page_url]
    return """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>%s</string>
  <key>ProgramArguments</key>
  <array>%s</array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><false/>
  <key>WorkingDirectory</key><string>%s</string>
  <key>StandardOutPath</key><string>%s</string>
  <key>StandardErrorPath</key><string>%s</string>
</dict>
</plist>
""" % (AGENT_LABEL,
       "".join("<string>%s</string>" % esc(a) for a in args),
       esc(os.path.dirname(helper)),
       esc(os.path.expanduser(LOG_FILE)), esc(os.path.expanduser(LOG_FILE)))


def install(source_py, page_url=None, port=7645, log=print, open_page=True):
    """Install for a Mac with no terminal in the way.

    macOS runs a user's own launch agents without an administrator, so this needs no
    privilege: it copies the helper into the user's Application Support, writes one plist
    into the user's LaunchAgents, and asks launchd to start it now and at every login. The
    point is that nobody has to open Terminal or keep a window alive - the page finds a
    helper already running.

    It still keeps nothing of the game: the sandbox under /tmp is deleted as usual, and
    `--uninstall` removes both files in one step.
    """
    if os_name() != "osx":
        log("  --install is the macOS path; elsewhere run it however you start things")
        return 1
    paths = installed_paths()
    # Already up (a second double-click, or an opened file again): do not start a second one on
    # the same port and report it as a failure.
    if already_running("127.0.0.1", port):
        log("  a helper is already running on 127.0.0.1:%d - nothing to do" % port)
        if open_page:
            url = "http://127.0.0.1:%d/" % port
            if page_url:
                url = "%sgo?to=%s" % (url, urllib.parse.quote(page_url, safe=""))
            threading.Timer(0.8, lambda: subprocess.run(["open", url])).start()
        return 0
    os.makedirs(os.path.join(paths["dir"], "helper"), exist_ok=True)
    if not source_py or not os.path.exists(source_py):
        log("  cannot find the helper to install (%s)" % source_py)
        return 2
    import re as _re
    text = open(source_py, "rb").read()
    if b"_EMBEDDED_PAGE = \"\"" in text:
        # A copy from the repository cannot serve its own page; the single-file build can, because
        # the page is inside it. Installing the repository copy is still fine (it keeps whatever
        # page sits next to it), so only the missing-page case is worth a word.
        log("  note: this copy has no page inside it; install the downloadable file instead if "
            "you want the helper to serve its own page")
    helper = os.path.join(paths["dir"], "helper", "webmc_helper.py")
    with open(helper, "wb") as fh:
        fh.write(text)
    os.chmod(helper, 0o755)
    log("  installed the helper to %s" % helper)
    plist = agent_plist_text(sys.executable or "/usr/bin/python3", helper,
                             page_url, port)
    os.makedirs(os.path.dirname(paths["plist"]), exist_ok=True)
    with open(paths["plist"], "w") as fh:
        fh.write(plist)
    log("  wrote a launch agent: %s" % paths["plist"])

    uid = os.getuid()
    target = "gui/%d" % uid
    subprocess.run(["launchctl", "bootout", "%s/%s" % (target, AGENT_LABEL)],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    started = subprocess.run(["launchctl", "bootstrap", target, paths["plist"]],
                             capture_output=True, text=True)
    if started.returncode != 0:
        log("  launchctl could not start it: %s" % (started.stderr or started.stdout).strip())
        log("  the page still works if you start it by hand; see --help")
    else:
        # bootstrap already launches it (RunAtLoad). Asking again with kickstart -k kills the
        # instance that just came up - which is exactly the "installed but nothing is
        # listening" symptom this had before.
        for _ in range(20):
            if already_running("127.0.0.1", port):
                break
            time.sleep(0.5)
        if not already_running("127.0.0.1", port):
            subprocess.run(["launchctl", "kickstart", "%s/%s" % (target, AGENT_LABEL)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            time.sleep(1.5)
        if already_running("127.0.0.1", port):
            log("  launchd started it, and starts it again at every login")
        else:
            log("  launchd has it, but nothing is answering yet - the page will say so; "
                "see %s" % paths["log"])
    log("  log: %s" % paths["log"])
    log("  remove it again with: python3 '%s' --uninstall" % helper)

    if open_page:
        url = "http://127.0.0.1:%d/" % port
        if page_url:
            url = "%sgo?to=%s" % (url, urllib.parse.quote(page_url, safe=""))
        threading.Timer(1.2, lambda: subprocess.run(["open", url])).start()
    return 0


def uninstall(log=print):
    paths = installed_paths()
    uid = os.getuid()
    subprocess.run(["launchctl", "bootout", "gui/%d/%s" % (uid, AGENT_LABEL)],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    removed = []
    for key in ("plist", "dir"):
        path = paths[key]
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
            removed.append(path)
        elif os.path.exists(path):
            os.unlink(path)
            removed.append(path)
    cleared, freed = sweep_stale_sandboxes(older_than=0, keep=None, log=lambda *_: None)
    log("  removed: %s" % (", ".join(removed) if removed else "nothing (it was not installed)"))
    if cleared:
        # sweep_stale_sandboxes returns (how many, how many bytes). Getting that order wrong once
        # printed five million "items" for 5.5 MB of sandboxes, which is a good way to frighten
        # somebody who is about to read the output of an uninstaller.
        log("  and cleared %d leftover sandbox(es), %.1f MB" % (cleared, freed / 1048576.0))
    log("  the log is left behind on purpose: %s" % paths["log"])
    return 0


def audit(root=None, cache=None, clean=False, log=print):
    """Say what *this helper* has on the machine, and optionally remove it.

    Written for the question the whole design is about: "did it leave anything
    behind?" Only things this helper creates are claimed here - a sandbox
    (webmc-<8 hex>), or a stray curl config. Other webmc-* entries in the temp
    directory belong to other parts of the project and are reported as a count, never
    touched.
    """
    import glob as _glob
    tmp = os.environ.get("TMPDIR", "/tmp")
    mine = []
    theirs = 0

    def size_of(path):
        total = 0
        if os.path.isdir(path):
            for base, _dirs, files in os.walk(path):
                for f in files:
                    full = os.path.join(base, f)
                    try:
                        if not os.path.islink(full):
                            total += os.path.getsize(full)
                    except OSError:
                        pass
        else:
            try:
                total = os.path.getsize(path)
            except OSError:
                pass
        return total

    seen = set()
    for pattern in ("webmc-*",):
        for base in (tmp, "/tmp"):
            for path in _glob.glob(os.path.join(base, pattern)):
                if path in seen:
                    continue
                is_dir = os.path.isdir(path)
                owner = read_owner(path) if is_dir else None
                ours = (is_dir and (owner is not None
                                    or re.fullmatch(r"webmc-[0-9a-f]{8}", os.path.basename(path)))) \
                    or (not is_dir and re.match(r"webmc-(curl-.*\.conf|.*\.part)$",
                                                os.path.basename(path)))
                if not ours:
                    continue
                seen.add(path)
                mine.append({"path": path,
                             "kind": "sandbox" if is_dir else "stray file",
                             "bytes": size_of(path), "owner": owner,
                             "abandoned": bool(owner and not pid_alive(owner.get("pid")))})
    for base in (tmp, "/tmp"):
        for path in _glob.glob(os.path.join(base, "webmc-*")):
            if path in seen:
                continue
            if cache and path == os.path.abspath(os.path.expanduser(cache)):
                continue
            theirs += 1
    if root and os.path.isdir(root) and os.path.abspath(root) not in seen:
        mine.append({"path": root, "kind": "this session's sandbox", "bytes": size_of(root),
                     "owner": read_owner(root), "abandoned": False})

    log("")
    log("  %s %s - what is on this machine" % (NAME, VERSION))
    log("  " + "-" * 58)
    if not mine:
        log("  nothing: no sandbox, no stray file. /tmp has none of ours.")
    for item in mine:
        log("  %-20s %s" % (item["kind"], item["path"]))
        if item["owner"]:
            log("  %-20s started %s by pid %s%s"
                % ("", time.strftime("%H:%M:%S", time.localtime(item["owner"].get("started", 0))),
                   item["owner"].get("pid"),
                   " - that process is gone, so this is litter" if item["abandoned"]
                   else " - running now"))
        log("  %-20s %.1f MB" % ("", item["bytes"] / 1048576.0))
    store = session_store_dir()
    if os.path.isdir(store):
        kept = sorted(n for n in os.listdir(store) if n.endswith(".zip"))
        log("  %-20s %s" % ("kept sessions", store))
        log("  %-20s %d session(s), %.1f MB - your worlds and options, so the next launch does not "
            % ("", len(kept), size_of(store) / 1048576.0))
        log("  %-20s start empty (--forget-sessions removes them)" % "")
    if cache:
        path = os.path.abspath(os.path.expanduser(cache))
        size = size_of(path) if os.path.isdir(path) else 0
        log("  %-20s %s" % ("cache", path))
        log("  %-20s %.1f MB %s" % ("", size / 1048576.0,
              "- kept on purpose, only ever used with --cache" if size else "- not present"))
    paths = installed_paths()
    if os.path.exists(paths["plist"]) or os.path.isdir(paths["dir"]):
        log("  %-20s %s" % ("installed", paths["dir"]))
        log("  %-20s %s" % ("", paths["plist"]))
        log("  %-20s installed on purpose so the page always finds a helper; remove both"
            % "")
        log("  %-20s with --uninstall (no administrator needed)" % "")
    if theirs:
        log("  %-20s %d other webmc-* entries in the temp directory that this helper"
            % ("not ours", theirs))
        log("  %-20s did not create (the test suite's webmc-site-* and friends)." % "")
    log("  %-20s %s" % ("writes to", (root or "/tmp/webmc-<random>/") +
                                        " - and nothing else; that path is deleted when "
                                        "the session ends"))
    log("  %-20s %s" % ("privileges", "none: no sudo, no administrator, no installer, no write "
                                      "outside /tmp and your own home; it listens on "
                                      "127.0.0.1 only"))
    log("")
    if clean:
        removed = 0
        freed = 0
        for item in mine:
            if item["kind"] == "this session's sandbox":
                continue
            try:
                if os.path.isdir(item["path"]):
                    shutil.rmtree(item["path"], ignore_errors=True)
                else:
                    os.unlink(item["path"])
                removed += 1
                freed += item["bytes"]
            except OSError:
                pass
        log("  removed %d of ours (%.1f MB); nothing else was touched"
            % (removed, freed / 1048576.0))
        log("")
    return mine


def install_signal_handlers(log=print):
    """Closing the terminal window, or any ordinary kill, has to run the cleanup
    that deletes the sandbox. Without this a double-clicked .command that the
    visitor closes would leave 600 MB under /tmp."""
    def bye(signum, _frame):
        try:
            name = signal.Signals(signum).name
        except Exception:
            name = str(signum)
        log("\n  received %s - cleaning up" % name)
        raise SystemExit(0)
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGQUIT):
        try:
            signal.signal(sig, bye)
        except (ValueError, OSError, AttributeError):
            pass


def parse_args(argv):
    ap = argparse.ArgumentParser(
        prog=NAME,
        description="Run real Minecraft + Fabric locally from a web page, keep nothing.")
    ap.add_argument("--port", type=int, default=7645)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--root", default=None,
                    help="sandbox directory (default /tmp/webmc-<random>)")
    ap.add_argument("--allow-origin", action="append", default=[], metavar="ORIGIN",
                    help="extra page origin allowed to talk to this helper")
    ap.add_argument("--page", default=None, help="path to the launcher page to serve at /")
    ap.add_argument("--page-url", default=None,
                    help="hosted page to hand the token to when /go is used")
    ap.add_argument("--open", action="store_true", help="open the browser at / (or /go)")
    ap.add_argument("--java", default=None, help="java executable to use")
    ap.add_argument("--proxy", default=None,
                    help="SOCKS/HTTP proxy for downloads, or 'none' (default: auto)")
    ap.add_argument("--proxy-game", action="store_true",
                    help="also send the game's own connections through the relay: a local SOCKS5"
                         " proxy, with the JVM pointed at it, so servers, sign-in and skins work"
                         " on a network that blocks everything but HTTPS")
    ap.add_argument("--restricted", action="store_true",
                    help="restricted mode: use only the Java runtime in the sandbox, never a"
                         " system one, and never look outside /tmp (for machines where Java is"
                         " present but blocked, or policies watch what runs)")
    ap.add_argument("--relay", default=os.environ.get("WEBMC_RELAY") or None, metavar="URL",
                    help="fetch everything through this relay instead of directly (the Cloudflare "
                         "Worker in relay/ does this), for networks where Mojang is blocked. "
                         "\"auto\" (the default) uses the built-in relay when there is one, and "
                         "\"off\" never uses one")
    ap.add_argument("--no-jre-download", action="store_true",
                    help="never fetch a JRE; fail instead")
    ap.add_argument("--keep", action="store_true",
                    help="do not delete the sandbox at the end (debugging)")
    ap.add_argument("--cache", default=os.environ.get("WEBMC_CACHE_DIR") or None,
                    help="reuse assets and libraries from this directory instead of "
                         "downloading them again (off by default: a session normally "
                         "downloads everything into its sandbox)")
    ap.add_argument("--autoclean", type=int, default=900,
                    help="seconds after the session ends before the sandbox is deleted "
                         "(0 disables; default 900)")
    ap.add_argument("--server-only", action="store_true",
                    help="start idle: no game is launched until the page asks")
    ap.add_argument("--launch", action="store_true",
                    help="launch immediately instead of waiting for the page")
    ap.add_argument("--version", default=DEFAULT_VERSION,
                    help="Minecraft version (default %s)" % DEFAULT_VERSION)
    ap.add_argument("--loader-kind", default="fabric",
                    help="which loader: fabric (default) or none for vanilla. Forge and NeoForge "
                         "are refused until their client-patching step is implemented")
    ap.add_argument("--loader", default="auto",
                    help="loader version, or 'auto'/'stable'/'latest' for the newest suitable "
                         "build of the chosen kind")
    ap.add_argument("--server", default=None, metavar="HOST:PORT",
                    help="a Minecraft server to reach through the relay, for networks that "
                         "block game ports: the client joins it automatically")
    ap.add_argument("--tunnel-port", type=int, default=0, metavar="PORT",
                    help="the local port that receives that server (default: any free one)")
    ap.add_argument("--mods", default="",
                    help="comma-separated Modrinth slugs, e.g. fabric-api,modmenu")
    ap.add_argument("--mod-jar", action="append", default=[], metavar="PATH",
                    help="a Fabric mod jar on this machine to copy into the sandbox "
                         "(repeatable). It is deleted with the sandbox afterwards.")
    ap.add_argument("--username", default="Player")
    ap.add_argument("--memory", default=DEFAULT_MEMORY)
    ap.add_argument("--no-assets", action="store_true",
                    help="skip the ~450 MB of sounds and textures")
    ap.add_argument("--dry-run", action="store_true",
                    help="download everything, build the command, do not start the game")
    ap.add_argument("--install", action="store_true",
                    help="macOS: keep this helper in Application Support and let launchd start it "
                         "now and at every login, so nothing has to be run by hand (no admin)")
    ap.add_argument("--install-source", default=None, metavar="PATH",
                    help="with --install: the file to install (default: this one)")
    ap.add_argument("--uninstall", action="store_true",
                    help="remove what --install put there (and any leftover sandbox)")
    ap.add_argument("--audit", action="store_true",
                    help="say what this project has left on the machine, then exit")
    ap.add_argument("--audit-clean", action="store_true",
                    help="with --audit: remove every leftover (never a running session)")
    ap.add_argument("--store", default=os.environ.get("WEBMC_STORE") or None, metavar="DIR",
                    help="where finished sessions are kept, when keeping them is asked for "
                         "(off by default: a session belongs in the browser, and the helper "
                         "deletes the rest)")
    ap.add_argument("--keep-sessions", type=int, default=5, metavar="N",
                    help="how many finished sessions to keep, when a store is in use")
    ap.add_argument("--store-sessions", action="store_true",
                    help="keep finished sessions on disk too (the browser is the only place one is kept otherwise)")
    ap.add_argument("--forget-sessions", action="store_true",
                    help="delete the kept sessions (your worlds and options) and exit")
    ap.add_argument("--idle-exit", type=int, default=0, metavar="SECONDS",
                    help="shut down after this long with nobody using the page (0 = never; the "
                         "background launcher passes 1800 so a backgrounded helper does not "
                         "outlive its usefulness)")
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--print-token", action="store_true")
    return ap.parse_args(argv)


def enforce_deadlines(registry, stop, log=print, every=10.0):
    """The safety net, actually enforced.

    Two jobs, both about a helper that is still running when nobody is watching:

    * the page normally deletes the sandbox as soon as it has the session's files. If it never
      comes back - tab closed, browser crashed, visitor walked away - the helper has to do it
      itself, or the whole promise quietly fails.
    * a helper started in the background has to end when its page is gone, or "nothing left
      behind" would be true of the game and false of the thing that ran it.
    """
    while not stop.is_set():
        stop.wait(every)
        if stop.is_set():
            break
        for session in list(registry.sessions.values()):
            with session.lock:
                deadline = session.cleanup_deadline
                state = session.state
            if deadline and time.time() >= deadline and state != "running":
                log("  the page has not collected session %s by %s - deleting its sandbox"
                    % (session.sid, time.strftime("%H:%M:%S", time.localtime(deadline))))
                session.cleanup(why="nobody collected it before the deadline")
        with registry.lock:
            newest = registry.pick()
        label = newest.last_touch if newest else registry.last_touch
        idle_for = time.time() - label
        idle_limit = getattr(registry.cfg, "idle_exit", 0) or 0
        busy = any(s.state == "running" for s in list(registry.sessions.values()))
        if idle_limit and not busy and idle_for > idle_limit:
            log("  nothing has asked anything for %s - shutting down and leaving nothing behind"
                % (("%.0f minutes" % (idle_for / 60.0)) if idle_for >= 120
                   else ("%.0f seconds" % idle_for)))
            for each in list(registry.sessions.values()):
                each.cleanup(why="the helper was idle")
            # Reuse the ordinary shutdown path so the sandbox is deleted exactly once and the
            # process disappears instead of becoming a stray background process.
            os.kill(os.getpid(), signal.SIGTERM)
            return


def already_running(host, port):
    """Is the thing on that port one of ours? Asked politely, without curl."""
    import urllib.request
    try:
        with urllib.request.urlopen("http://%s:%d/api/hello" % (host, port), timeout=3) as r:
            return json.loads(r.read().decode("utf-8", "replace")).get("name") == NAME
    except Exception:
        return False


def main(argv=None):
    args = parse_args(argv if argv is not None else sys.argv[1:])
    cfg = argparse.Namespace(**vars(args))
    if not cfg.root:
        cfg.root = default_root()
    cfg.root = os.path.abspath(os.path.expanduser(cfg.root))
    install_signal_handlers()

    # The single-file .command writes the helper out of a heredoc to a temp file. Once python has
    # read it, that copy has no reason to exist: delete it, so "it leaves nothing behind" is true
    # of the helper as well as of the game.
    _self = os.environ.get("WEBMC_SELF_DELETE")
    if _self and not args.install:
        try:
            os.unlink(_self)
        except OSError:
            pass

    if args.audit:
        audit(root=cfg.root if os.path.isdir(cfg.root) else None,
              cache=cfg.cache, clean=args.audit_clean)
        return 0

    if args.forget_sessions:
        store = session_store_dir(cfg)
        freed = 0
        kept = 0
        if os.path.isdir(store):
            for name in os.listdir(store):
                path = os.path.join(store, name)
                try:
                    freed += os.path.getsize(path)
                    os.unlink(path)
                    kept += 1
                except OSError:
                    pass
        print("  removed %d kept session(s) from %s (%.1f MB)" % (kept, store, freed / 1048576.0))
        return 0

    if args.uninstall:
        uninstall()
        return 0

    if args.install:
        source = args.install_source or globals().get("__file__")
        return install(source, page_url=args.page_url, port=args.port)

    print("")
    print("  %s %s" % (NAME, VERSION))
    print("  " + "-" * 62)
    sweep_stale_sandboxes(keep=cfg.root)

    curl = Curl()
    if args.restricted and not args.proxy:
        # in restricted mode even the proxy hunt is skipped: it is a network probe of the local
        # machine, and someone asking for this wants as little of that as possible
        proxy = None
        print("  restricted mode: not probing for a local proxy")
    else:
        proxy = detect_proxy(args.proxy, lambda m: print("  " + m))
    curl.proxy = proxy
    if not proxy:
        print("  proxy: none (using the network directly)")

    # which proxy did we end up with, and does it work at all?
    try:
        curl.get(MANIFEST_URL, dest=None, timeout=20)
        print("  network: Mojang reachable")
    except CurlError as exc:
        print("  network: NOT reachable - %s" % exc)
        print("  hint: if this machine needs a SOCKS tunnel, run it on 127.0.0.1:1080")
        print("        or pass --proxy socks5h://host:port")

    registry = Registry(cfg, curl)
    registry.started = time.time()
    page = args.page or default_page(cfg.root)
    token = secrets.token_hex(16)
    try:
        httpd = Server((args.host, args.port), Handler, registry, curl, token, page,
                       args.allow_origin, args.verbose)
    except OSError as exc:
        if exc.errno in (errno.EADDRINUSE, errno.EACCES):
            # Being already started is not an error: it is what happens when somebody opens the
            # launcher twice, or double-clicks it again after using it earlier.
            if already_running(args.host, args.port):
                url = "http://%s:%d/" % (args.host, args.port)
                print("  a helper is already running there - opening its page instead of "
                      "starting a second one")
                target = url
                if args.page_url:
                    target = "%sgo?to=%s" % (url, urllib.parse.quote(args.page_url, safe=""))
                opener = "open" if os_name() == "osx" else ("start" if os_name() == "windows"
                                                           else "xdg-open")
                try:
                    subprocess.run([opener, target])
                except Exception:
                    print("  open %s yourself" % target)
                return 0
            print("  ERROR: cannot listen on %s:%d - %s" % (args.host, args.port, exc))
            print("  hint: something else is on that port; use --port 7646")
            return 2
        raise
    port = httpd.server_address[1]
    url = "http://%s:%d/" % (args.host, port)
    print("  page:   %s" % url)
    if page and os.path.exists(page):
        print("  serving %s" % page)
    if args.page_url:
        print("  hosted: %s/go?to=%s" % (url, urllib.parse.quote(args.page_url, safe="")))
    if args.print_token:
        print("  token:  %s" % token)

    if args.open:
        opener = "open" if os_name() == "osx" else ("start" if os_name() == "windows" else "xdg-open")
        target = url
        if args.page_url:
            target = "%sgo?to=%s" % (url, urllib.parse.quote(args.page_url, safe=""))
        threading.Timer(0.6, lambda: subprocess.run([opener, target])).start()

    if args.launch:
        opts = {
            "tunnelServer": args.server,
            "tunnelPort": args.tunnel_port,
            "version": args.version,
            "loader": args.loader,
            "loaderKind": args.loader_kind,
            "relay": args.relay,
            "tunnelEverything": args.proxy_game,
            "restricted": args.restricted,
            "mods": [m.strip() for m in (args.mods or "").split(",") if m.strip()],
            "localMods": list(args.mod_jar or []),
            "username": args.username,
            "memory": args.memory,
            "assets": not args.no_assets,
        }
        print("  launching %s%s with %s" % (
            opts["version"],
            " + " + opts["loaderKind"] if opts["loaderKind"] not in ("none", "") else " vanilla",
            ", ".join(opts["mods"]) or "no mods"))
        print("")
        registry.launch(opts)

    if not args.server_only:
        print("")
        print("  Play is a button on the page; this process only listens.")
        print("  Everything is written under %s and deleted after" % cfg.root)
        print("  the session's files have been saved. Ctrl-C to quit.")
    print("")
    try:
        stop_watchdog = threading.Event()
        watchdog = threading.Thread(
            target=enforce_deadlines, args=(registry, stop_watchdog), daemon=True)
        watchdog.start()
        httpd.serve_forever()
    except (KeyboardInterrupt, SystemExit):
        print("\n  shutting down")
    finally:
        stop_watchdog.set()
        registry.stop_all()
        if not cfg.keep:
            registry.cleanup_all()
        else:
            print("  --keep was given: %s is still there" % cfg.root)
        httpd.server_close()
        # A transient run (started by a Shortcut, say) is staged in /tmp by the file that launched
        # it. Deleting that staging directory here is what makes "nothing left behind" include the
        # helper as well as the game.
        staging = os.environ.get("WEBMC_CLEANUP_DIR")
        here = os.path.abspath(staging) if staging else None
        tempdirs = {os.path.abspath(os.environ.get("TMPDIR", "/tmp")), "/tmp", "/private/tmp",
                    os.path.abspath(tempfile.gettempdir())}
        # Only ever remove a directory this helper's own launcher made: a direct child of a temp
        # directory, named webmc.<something>. The first version of this checked for a "/tmp/" prefix
        # and therefore never fired on macOS, where the staging directory is under /var/folders.
        remove_staging = bool(here and os.path.basename(here).startswith("webmc.")
                              and os.path.dirname(here) in tempdirs and os.path.isdir(here))
        if remove_staging:
            size = 0
            for base, _dirs, files in os.walk(here):
                for f in files:
                    try:
                        size += os.path.getsize(os.path.join(base, f))
                    except OSError:
                        pass
            shutil.rmtree(here, ignore_errors=True)
            print("  removed the staging directory %s (%.1f MB)" % (here, size / 1048576.0))
    return 0


if __name__ == "__main__":
    sys.exit(main())
WEBMC_HELPER_SOURCE

PAGE="${WEBMC_PAGE_URL-https://amphibiandev.github.io/webmc-launcher/local.html}"
LOGFILE="$STAGE/run.log"

if [ "${1:-}" = "--uninstall" ]; then
  "$PY" -u "$SOURCE" --uninstall "${@:2}"
  STATUS=$?
  rm -rf "$STAGE"
  exit $STATUS
fi

if [ "${WEBMC_FOREGROUND:-0}" != "0" ]; then
  export WEBMC_SELF_DELETE="$SOURCE"
  if [ -n "$PAGE" ]; then
    exec "$PY" -u "$SOURCE" --open --page-url "$PAGE" "$@"
  fi
  exec "$PY" -u "$SOURCE" --open "$@"
fi

# Transient: run out of the staging directory, leave nothing at all behind. This is the mode a
# Shortcut uses, so a session costs the machine nothing permanent - no install, no staging
# directory, no sandbox. Everything, including a fetched Python, goes when the helper exits.
if [ "${WEBMC_TRANSIENT:-0}" != "0" ]; then
  export WEBMC_SELF_DELETE="$SOURCE"
  CACHEARG=""
  [ "${WEBMC_CACHE:-0}" != "0" ] && CACHEARG="$HOME/Library/Caches/webmc"
  if [ -n "$PAGE" ] && [ -n "$CACHEARG" ]; then
    nohup "$PY" -u "$SOURCE" --server-only --idle-exit 1800 --port 7645 --page-url "$PAGE" --cache "$CACHEARG" >>"$LOGFILE" 2>&1 &
  elif [ -n "$PAGE" ]; then
    nohup "$PY" -u "$SOURCE" --server-only --idle-exit 1800 --port 7645 --page-url "$PAGE" >>"$LOGFILE" 2>&1 &
  elif [ -n "$CACHEARG" ]; then
    nohup "$PY" -u "$SOURCE" --server-only --idle-exit 1800 --port 7645 --cache "$CACHEARG" >>"$LOGFILE" 2>&1 &
  else
    nohup "$PY" -u "$SOURCE" --server-only --idle-exit 1800 --port 7645 >>"$LOGFILE" 2>&1 &
  fi
  # Wait for it properly: fetching a Python and starting a JVM-less HTTP server takes a moment,
  # and reporting "did not come up" while it is coming up is how a working helper looks broken.
  READY=0
  WAITED=0
  while [ "$WAITED" -lt 30 ]; do
    if [ -n "$(curl -s -m 2 http://127.0.0.1:7645/api/hello 2>/dev/null)" ]; then READY=1; break; fi
    sleep 1
    WAITED=$((WAITED + 1))
  done
  if [ "$READY" = "1" ]; then
    echo "webmc-helper is running from $STAGE - nothing here survives the session."
    exit 0
  fi
  echo "The helper did not come up. What it said:"
  tail -10 "$LOGFILE" 2>/dev/null
  read -r -p "press return to close " _
  exit 1
fi

# Install: keep a copy in Application Support and let launchd start it now and at every login.
if [ -n "$PAGE" ]; then
  "$PY" -u "$SOURCE" --install --install-source "$SOURCE" --port 7645 --page-url "$PAGE" >>"$LOGFILE" 2>&1
else
  "$PY" -u "$SOURCE" --install --install-source "$SOURCE" --port 7645 >>"$LOGFILE" 2>&1
fi
STATUS=$?

if [ "$STATUS" = "0" ]; then
  echo "WebMC Helper is installed and running - this window closes itself."
  echo
  echo "From now on it starts by itself at every login: press Play on the launcher page"
  echo "and Minecraft starts on this computer. You can delete this downloaded file."
  echo
  echo "To remove it completely later:"
  echo "    "$HOME/Library/Application Support/webmc/helper/webmc_helper.py" --uninstall"
  echo "    (or run this downloaded file again with --uninstall)"
else
  echo "It did not finish. What it said:"
  tail -20 "$LOGFILE" 2>/dev/null
  read -r -p "press return to close " _
  exit 1
fi
exit 0
