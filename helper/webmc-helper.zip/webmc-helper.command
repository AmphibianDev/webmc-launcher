#!/bin/bash
# webmc-helper - one file, and nothing installed.
#
# Double-click it. It makes one staging directory under /tmp, puts everything it needs in there
# (a Python runtime if this machine has none, the helper itself, the game, the Java runtime), and
# deletes the whole directory when the session ends.
#
#   press Play at:   https://amphibiandev.github.io/webmc-launcher/local.html
#   stop it with:    pkill -f webmc_helper        (or let it exit by itself when idle)
#   watch it work:   WEBMC_FOREGROUND=1 ./webmc-helper.command
#   uninstall:       ./webmc-helper.command --uninstall
#
# WHAT IT NEEDS FROM THE MACHINE: bash, curl and tar. That is all - all three ship with macOS and
# with Windows 10+, and nothing here needs Xcode command line tools, Homebrew, or Java installed.
set -u

STAGE="$(mktemp -d "${TMPDIR:-/tmp}/webmc.XXXXXX")" || exit 1
SOURCE="$STAGE/webmc_helper.py"
export WEBMC_CLEANUP_DIR="$STAGE"

PY=""
if [ "${WEBMC_FORCE_FETCH:-0}" = "0" ] && command -v python3 >/dev/null 2>&1; then
  if python3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 8) else 1)' 2>/dev/null; then
    PY="$(command -v python3)"
  fi
fi

if [ -z "$PY" ]; then
  case "$(uname -s)-$(uname -m)" in
    Darwin-arm64)  PBSTARGET="aarch64-apple-darwin" ;;
    Darwin-x86_64) PBSTARGET="x86_64-apple-darwin" ;;
    Linux-x86_64)  PBSTARGET="x86_64-unknown-linux-gnu" ;;
    Linux-aarch64) PBSTARGET="aarch64-unknown-linux-gnu" ;;
    *) echo "webmc-helper: unsupported system $(uname -s) $(uname -m)"; exit 1 ;;
  esac
  PBSURL="https://github.com/astral-sh/python-build-standalone/releases/download/20261013/cpython-3.11.17+20261013-${PBSTARGET}-install_only.tar.gz"
  echo "This machine has no Python 3, so webmc-helper is fetching one into its own folder:"
  echo "    $STAGE"
  echo "Nothing is installed, and it is deleted with the rest when the session ends."
  if ! curl -fsSL --retry 2 -m 600 "$PBSURL" -o "$STAGE/python.tar.gz"; then
    echo "Could not fetch the Python runtime. Check this machine can reach github.com."
    curl -s -o /dev/null -m 5 https://github.com || echo "  (github.com is unreachable from here)"
    rm -rf "$STAGE"
    read -r -p "press return to close " _
    exit 1
  fi
  mkdir -p "$STAGE/py" && tar -xzf "$STAGE/python.tar.gz" -C "$STAGE/py" || { rm -rf "$STAGE"; exit 1; }
  rm -f "$STAGE/python.tar.gz"
  PY="$STAGE/py/python/bin/python3"
  if [ ! -x "$PY" ]; then
    echo "The fetched runtime did not unpack where expected. Nothing was left behind; giving up."
    rm -rf "$STAGE"
    read -r -p "press return to close " _
    exit 1
  fi
fi

cat > "$SOURCE" <<'WEBMC_HELPER_SOURCE'
#!/usr/bin/env python3
"""
webmc-helper - run real Minecraft + Fabric on this machine, keep nothing.

The contract, in the words of the design it implements:

    the page only launches Minecraft; Minecraft still runs on your computer,
    just ... temporarily.

So every byte this helper writes goes into one sandbox directory under /tmp
(`/tmp/webmc-<nonce>`), and the whole thing is deleted when the session's files
have been handed to the page - or after `--autoclean` seconds, whichever is
first. Nothing is installed, no service is registered, nothing is left behind.

    page (github.io or this helper's own /)  ──HTTP──▶  127.0.0.1:7645
                                                            │
                                          downloads ────────┤ Mojang / Fabric / Modrinth
                                          (through the     │
                                           SOCKS tunnel    │
                                           when direct     │
                                           is blocked)     │
                                                            ▼
                                          /tmp/webmc-XXXX/  ──▶ java ... KnotClient
                                                            │
                                          saves + logs ─────┤ zip
                                                            ▼
                                                    page stores it (OPFS)
                                                            │
                                                    POST /api/cleanup ──▶ rm -rf

Endpoints (all JSON):
    GET  /                  the page, with this helper's own token baked in
    GET  /go?to=<page-url>  redirect to a hosted page with the token in the fragment    GET  /api/hello         identity + capability probe (no token needed)
    GET  /api/versions      Mojang's release list (cached, fetched lazily)
    GET  /api/search?q=&mc= Modrinth search, run here so it works behind a filtered network
    GET  /api/status        phase, progress, instance, pid, exit code, cleanup receipt
    GET  /api/log?since=N   log lines after index N
    GET  /api/localmods     the mod jars the page has handed over for this session
    POST /api/launch        {version, loader, mods, username, memory, assets}
    POST /api/stop          kill the game
    POST /api/localmods     body = one .jar, name in X-WebMC-Mod-Name (?clear=1, ?drop=name)
    POST /api/restore       body = a bundle zip from a previous session
    GET  /api/result        exit code, collected files, bundle size
    GET  /api/bundle.zip    the collected saves/logs/screenshot bundle
    POST /api/cleanup       delete the sandbox

Only Python 3.9's standard library is used. Downloads shell out to `curl`,
because curl speaks SOCKS5 with remote DNS (`socks5h://`) and does parallel
transfers, which is exactly what a poisoned resolver needs.
"""

import argparse
import base64
import errno
import hashlib
import http.server
import io
import json
import os
import platform
import re
import secrets
import shutil
import signal
import socket
import socketserver
import struct
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import uuid as uuidlib
import zipfile

VERSION = "0.1.0"
NAME = "webmc-helper"

MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
RESOURCES_URL = "https://resources.download.minecraft.net"
FABRIC_META = "https://meta.fabricmc.net/v2"
# Forge and NeoForge publish a version document *inside their installer jar*, which is what a
# launcher needs - no installation step, no patching by hand. Reading it out is what makes the
# other two loaders the same shape as Fabric here.
LOADER_MAVEN = {
    "forge": "https://maven.minecraftforge.net/",
    "neoforge": "https://maven.neoforged.net/releases/",
}
LOADER_METADATA = {
    "forge": "https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml",
    "neoforge": "https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml",
}
LOADER_KINDS = ("fabric", "forge", "neoforge", "none")

# When Mojang (or Fabric, or Modrinth) is unreachable from the visitor's network, everything can
# be fetched through one relay instead: it maps straight onto the upstream URLs, so nothing else in
# this file has to know. See relay/ for the Cloudflare Worker that does it.
RELAY_PREFIXES = (
    ("https://piston-meta.mojang.com", "piston-meta"),
    ("https://piston-data.mojang.com", "piston-data"),
    ("https://resources.download.minecraft.net", "resources"),
    ("https://libraries.minecraft.net", "libraries"),
    ("https://maven.fabricmc.net", "fabric-maven"),
    ("https://meta.fabricmc.net", "fabric-meta"),
    ("https://maven.minecraftforge.net", "forge-maven"),
    ("https://maven.neoforged.net/releases", "neoforge-maven"),
    ("https://api.modrinth.com", "modrinth"),
    ("https://api.adoptium.net", "adoptium"),
)


# The relays this helper will use when the page (or the command line) does not name one. Deploying a
# Worker once and putting its URL here is what turns "everybody deploys their own" into "it works".
# Order matters: the first that answers /health wins, so list a spare. An empty tuple means the
# helper simply downloads directly, which is what most networks want anyway.
DEFAULT_RELAYS = (
    # Relays this project deployed for everyone, on two different Cloudflare hostnames: one hostname
    # can always be blocked, and a second is what makes "nobody has to deploy one" hold for more than
    # one network. The helper probes them in order and uses the first that answers /health; if none
    # does (a network that blocks Cloudflare entirely) it downloads directly, or through the
    # visitor's own proxy when there is one. Add any URL here and it joins the list.
    "https://webmc-relay.webmc-helper.workers.dev",
    "https://webmc-relay-pages.pages.dev",
)

_RELAY_CHOICE = {"probed": False, "url": None, "via": None}
OFF = ("off", "none", "no", "direct", "-")


def relay_reachable(url, timeout=5):
    """Does this relay answer /health? Cheap, and it is the only thing that decides."""
    try:
        request = urllib.request.Request(url.rstrip("/") + "/health",
                                        headers={"User-Agent": "webmc-helper"})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status == 200
    except Exception:
        return False


def dns_query(name, qtype, timeout=5):
    """One DNS question, answered by hand.

    Python's standard library can resolve A records and nothing else, and Minecraft servers are
    usually reached through an SRV record: play.example.net is a signpost, not an address. Asking the
    question directly is the only way to follow that signpost without adding a dependency.
    """
    import random
    labels = b"".join(bytes([len(part)]) + part.encode() for part in name.rstrip(".").split("."))
    packet = (struct.pack("!HHHHHH", random.randrange(65535), 0x0100, 1, 0, 0, 0)
              + labels + b"\x00" + struct.pack("!HH", qtype, 1))
    for server in dns_servers():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.settimeout(timeout)
            sock.sendto(packet, (server, 53))
            data, _ = sock.recvfrom(4096)
        except Exception:
            continue
        finally:
            sock.close()
        return parse_dns_answers(data)
    return []


def dns_servers():
    """Whatever this machine would ask, in order."""
    servers = []
    try:
        with open("/etc/resolv.conf") as fh:
            for line in fh:
                if line.startswith("nameserver"):
                    servers.append(line.split()[1])
    except Exception:
        pass
    for fallback in ("1.1.1.1", "8.8.8.8"):
        if fallback not in servers:
            servers.append(fallback)
    return servers


def parse_dns_answers(data):
    """(name, port, priority, weight) for every SRV record in a reply, best first."""
    if len(data) < 12:
        return []
    _id, _flags, qd, an, _ns, _ar = struct.unpack("!HHHHHH", data[:12])
    offset = 12

    def skip_name(at):
        while at < len(data):
            length = data[at]
            if length == 0:
                return at + 1
            if length & 0xC0:
                return at + 2
            at += 1 + length
        return at

    for _ in range(qd):
        offset = skip_name(offset) + 4
    answers = []
    for _ in range(an):
        if offset >= len(data):
            break
        offset = skip_name(offset)
        if offset + 10 > len(data):
            break
        rtype, _rclass, _ttl, length = struct.unpack("!HHIH", data[offset:offset + 10])
        offset += 10
        body = data[offset:offset + length]
        offset += length
        if rtype != 33 or len(body) < 7:
            continue
        priority, weight, port = struct.unpack("!HHH", body[:6])
        target = []
        at = 6
        while at < len(body) and body[at]:
            size = body[at]
            target.append(body[at + 1:at + 1 + size].decode("utf-8", "replace"))
            at += 1 + size
        answers.append((".".join(target), port, priority, weight))
    answers.sort(key=lambda item: (item[2], -item[3]))
    return answers


def minecraft_srv(host, via_proxy=None, log=None):
    """Where a Minecraft server really lives, or None if there is no signpost.

    A filtered network poisons the resolver, so a local answer is not an answer: when the machine's
    own DNS says nothing, the same question goes to a public resolver over HTTPS — through the proxy
    or relay this session is already using, so it is asked over a connection the network cannot edit.
    """
    try:
        for name, port, _priority, _weight in dns_query("_minecraft._tcp." + host, 33):
            if name and not name.startswith("0.0.0.0"):
                return name, int(port)
    except Exception:
        pass
    for endpoint in ("https://cloudflare-dns.com/dns-query?name=_minecraft._tcp.%s&type=SRV" % host,
                     "https://dns.google/resolve?name=_minecraft._tcp.%s&type=SRV" % host):
        try:
            answer = http_json(endpoint, via_proxy=via_proxy, timeout=15)
        except Exception:
            continue
        for record in answer.get("Answer", []):
            if record.get("type") != 33:
                continue
            parts = str(record.get("data", "")).split()
            if len(parts) >= 4 and parts[3] not in (".", "", "0.0.0.0"):
                if log:
                    log("srv: %s is really %s:%s (a public resolver said so)" % (host, parts[3].rstrip("."), parts[2]))
                return parts[3].rstrip("."), int(parts[2])
    return None


def http_json(url, body=None, via_proxy=None, timeout=10):
    """GET a URL and parse JSON, through a SOCKS5 proxy when one is given.

    The relay has to be probed the same way it will be used: on a network that blocks the relay's
    hostname, the direct probe fails while the proxied one succeeds, and only the second answer is
    the truth.
    """
    import ssl
    parts = urllib.parse.urlsplit(url)
    secure = parts.scheme in ("https", "wss")
    host = parts.hostname
    port = parts.port or (443 if secure else 80)
    path = parts.path or "/"
    if parts.query:
        path += "?" + parts.query
    if via_proxy:
        sock = socks5_connect(via_proxy, host, port, timeout=timeout)
    else:
        sock = socket.create_connection((host, port), timeout=timeout)
    try:
        if secure:
            sock = ssl.create_default_context().wrap_socket(sock, server_hostname=host)
        payload = json.dumps(body).encode() if body is not None else None
        head = ("%s %s HTTP/1.1\r\nHost: %s\r\nAccept: application/json\r\n"
                "User-Agent: %s/%s\r\nConnection: close\r\n"
                % ("POST" if payload is not None else "GET", path, parts.netloc, NAME, VERSION))
        if payload is not None:
            head += "Content-Type: application/json\r\nContent-Length: %d\r\n" % len(payload)
        sock.sendall((head + "\r\n").encode() + (payload or b""))
        chunks = b""
        while True:
            data = sock.recv(65536)
            if not data:
                break
            chunks += data
            if len(chunks) > 2000000:
                break
    finally:
        try:
            sock.close()
        except Exception:
            pass
    head, _sep, body = chunks.partition(b"\r\n\r\n")
    status = int(head.split(b" ")[1]) if b" " in head.split(b"\r\n")[0] else 0
    if status != 200:
        raise OSError("HTTP %s from %s" % (status, url))
    if b"transfer-encoding: chunked" in head.lower():
        # Nobody sends a Content-Length any more, and a chunk header in the middle of JSON reads as
        # "Extra data: line 2" three layers up. Undo it here, once.
        out, rest = b"", body
        while True:
            line, _sep2, rest = rest.partition(b"\r\n")
            try:
                size = int(line.split(b";")[0], 16)
            except ValueError:
                break
            if size == 0:
                break
            out += rest[:size]
            rest = rest[size + 2:]
        body = out
    return json.loads(body.decode("utf-8", "replace"))


def http_get_json(url, via_proxy=None, timeout=10):
    return http_json(url, via_proxy=via_proxy, timeout=timeout)


def relay_reachable_via(url, via_proxy, timeout=10):
    return bool(http_get_json(url.rstrip("/") + "/health", via_proxy=via_proxy, timeout=timeout).get("ok"))


def resolve_relay(requested, log=None, timeout=5, via_proxy=None):
    """Decide which relay to use. "off" means none, a URL means that one, and nothing means the
    built-in list — probed once per helper, so a launch never pays for it twice."""
    if requested and str(requested).strip().lower() in OFF:
        return None
    if requested and str(requested).strip():
        return str(requested).strip().rstrip("/")
    if _RELAY_CHOICE["probed"]:
        return _RELAY_CHOICE["url"]
    _RELAY_CHOICE["probed"] = True
    for candidate in DEFAULT_RELAYS:
        if relay_reachable(candidate, timeout=timeout):
            _RELAY_CHOICE["url"] = candidate.rstrip("/")
            if log:
                log("relay: using the built-in relay %s (say \"off\" to download directly)"
                    % _RELAY_CHOICE["url"])
            return _RELAY_CHOICE["url"]
    # The relay's own hostname can be blocked while a proxy on this machine works. Then the relay is
    # still the right answer: it resolves names out there, which is exactly what a poisoned DNS
    # cannot do here. Ask it through the proxy before giving up on it.
    for candidate in DEFAULT_RELAYS:
        if via_proxy:
            try:
                if relay_reachable_via(candidate, via_proxy, timeout=max(timeout * 2, 12)):
                    _RELAY_CHOICE["url"] = candidate.rstrip("/")
                    _RELAY_CHOICE["via"] = via_proxy
                    if log:
                        log("relay: %s is not reachable from here, but it answers through %s, so that "
                            "is what this session will use" % (candidate, via_proxy))
                    return _RELAY_CHOICE["url"]
            except Exception:
                pass
    if DEFAULT_RELAYS and log:
        log("relay: none of the %d built-in relays answered, directly or through a proxy; "
            "downloading directly" % len(DEFAULT_RELAYS))
    return None


def relayed(url, relay):
    """Rewrite an upstream URL to go through the relay, if one is configured."""
    if not relay:
        return url
    base = relay.rstrip("/")
    for upstream, prefix in RELAY_PREFIXES:
        if url.startswith(upstream):
            return "%s/%s%s" % (base, prefix, url[len(upstream):])
    return url
# What this helper will actually launch. Forge and NeoForge are resolved, downloaded and merged
# below - that part works and was verified as far as their bootstrap - but neither ships a usable
# client jar: their own installer runs installertools over the vanilla jar to produce
# client-<mc>-<stamp>-srg.jar and ...-extra.jar, and the bootstrap refuses to start without them.
# Until that patch step is implemented, they are refused up front rather than half-launched.
SUPPORTED_LOADERS = ("fabric", "none")
MODRINTH_API = "https://api.modrinth.com/v2"
ADOPTIUM_API = "https://api.adoptium.net/v3"

DEFAULT_VERSION = "1.21.11"

# The single-file build (tools/publish-helper.py) puts the launcher page in here as base64, so
# one downloadable .command can serve its own page without a folder of files next to it. In the
# repository this is empty and the page is read from page/index.html as usual.
_EMBEDDED_PAGE = "PCFET0NUWVBFIGh0bWw+CjxodG1sIGxhbmc9ImVuIj4KPGhlYWQ+CjxtZXRhIGNoYXJzZXQ9InV0Zi04IiAvPgo8bWV0YSBuYW1lPSJ2aWV3cG9ydCIgY29udGVudD0id2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEiIC8+Cjx0aXRsZT5XZWJNQzwvdGl0bGU+CjwhLS0KICBBIGxhdW5jaGVyIHdob3NlIGludGVyZmFjZSBpcyBhIHdlYiBwYWdlLCBhbmQgd2hpY2gga2VlcHMgbm90aGluZyBvZiB0aGUgZ2FtZSBvbiB0aGUgbWFjaGluZS4KCiAgVGhlIGxvb2ssIHRoaXJkIGF0dGVtcHQ6IG9uZSBmbG9hdGluZyBmcmFtZSBpbnN0ZWFkIG9mIGEgZnVsbC1ibGVlZCBzaGVsbCwgYSBnYXRlIGZvciBhIG1hcmssIGFuCiAgYXVyb3JhIGFjY2VudCBpbnN0ZWFkIG9mIE1pbmVjcmFmdCBncmVlbiwgc2V0dGluZ3MgYXMgcm93cyByYXRoZXIgdGhhbiBhIGdyaWQgb2YgY2FyZHMsIGFuZCB0aGUgbG9nCiAgYXMgYSBiYXIgaW5zaWRlIHRoZSBmcmFtZSB0aGF0IG9wZW5zIGluIHBsYWNlLgoKICBUaGUgcGFnZSBjYW5ub3Qgc3RhcnQgYSBwcm9ncmFtLCByZWFkIGEgZmlsZSwgb3Igc2VlIC90bXAuIEEgaGVscGVyIG9uIHRoaXMgbWFjaGluZSBkb2VzIHRoYXQ7IHRoaXMKICBpcyB0aGUgaW50ZXJmYWNlIHRvIGl0LgotLT4KPHN0eWxlPgogIDpyb290ewogICAgLS1iZzojMDcwODBiOyAtLWZyYW1lOiMwZDBmMTU7IC0tY2FyZDojMTExNDFiOyAtLWNhcmQyOiMwZjEyMTg7CiAgICAtLWluazojZWVmMWY3OyAtLW11dGVkOiM5YWEzYjQ7IC0tZGltOiM2YjczODY7CiAgICAtLWxpbmU6I2ZmZmZmZjEyOyAtLWxpbmUyOiNmZmZmZmYyNDsKICAgIC0tbWludDojNWVmMmE4OyAtLWN5YW46IzM5YzhmZjsgLS12aW9sZXQ6IzlhOGNmZjsgLS1hbWJlcjojZmZjNDZiOyAtLXJlZDojZmY4YTdhOwogICAgLS1yOjI2cHg7IC0tcjI6MThweDsgLS1yMzoxMnB4OyAtLXBpbGw6OTk5cHg7CiAgICAtLXNoYWRvdzowIDMwcHggODBweCAjMDAwMDAwYTY7CiAgICAtLWF1cm9yYTpsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLHZhcigtLW1pbnQpLHZhcigtLWN5YW4pKTsKICB9CiAgKntib3gtc2l6aW5nOmJvcmRlci1ib3h9CiAgaHRtbCxib2R5e2hlaWdodDoxMDAlfQogIGJvZHl7bWFyZ2luOjA7YmFja2dyb3VuZDp2YXIoLS1iZyk7Y29sb3I6dmFyKC0taW5rKTtvdmVyZmxvdzpoaWRkZW47CiAgICAgICBmb250OjE1cHgvMS42IC1hcHBsZS1zeXN0ZW0sQmxpbmtNYWNTeXN0ZW1Gb250LCJTZWdvZSBVSSIsUm9ib3RvLEhlbHZldGljYSxBcmlhbCxzYW5zLXNlcmlmOwogICAgICAgbGV0dGVyLXNwYWNpbmc6LjAwMmVtOy13ZWJraXQtZm9udC1zbW9vdGhpbmc6YW50aWFsaWFzZWR9CiAgYXtjb2xvcjp2YXIoLS1jeWFuKTt0ZXh0LWRlY29yYXRpb246bm9uZX0gYTpob3Zlcnt0ZXh0LWRlY29yYXRpb246dW5kZXJsaW5lfQogIGNvZGV7Zm9udDoxMi41cHgvMS41IHVpLW1vbm9zcGFjZSxTRk1vbm8tUmVndWxhcixNZW5sbyxtb25vc3BhY2U7Y29sb3I6I2NmZThmZjtiYWNrZ3JvdW5kOiNmZmZmZmYwZDsKICAgICAgIGJvcmRlcjoxcHggc29saWQgdmFyKC0tbGluZSk7Ym9yZGVyLXJhZGl1czo2cHg7cGFkZGluZzoxcHggNnB4fQogIDo6LXdlYmtpdC1zY3JvbGxiYXJ7d2lkdGg6MTFweDtoZWlnaHQ6MTFweH0KICA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1ie2JhY2tncm91bmQ6I2ZmZmZmZjFmO2JvcmRlcjo0cHggc29saWQgdHJhbnNwYXJlbnQ7Ym9yZGVyLXJhZGl1czo5OXB4OwogICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jbGlwOmNvbnRlbnQtYm94fQogIHN2Z3tkaXNwbGF5OmJsb2NrfQoKICAvKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIGF0bW9zcGhlcmUgKi8KICAuZ2xvd3twb3NpdGlvbjpmaXhlZDtpbnNldDowO3otaW5kZXg6MDtwb2ludGVyLWV2ZW50czpub25lO292ZXJmbG93OmhpZGRlbn0KICAuZ2xvdyBpe3Bvc2l0aW9uOmFic29sdXRlO2Rpc3BsYXk6YmxvY2s7Ym9yZGVyLXJhZGl1czo1MCU7ZmlsdGVyOmJsdXIoOTBweCk7b3BhY2l0eTouNX0KICAuZ2xvdyBpOm50aC1jaGlsZCgxKXt3aWR0aDo1MnJlbTtoZWlnaHQ6NTJyZW07bGVmdDotMTJyZW07dG9wOi0xOHJlbTsKICAgIGJhY2tncm91bmQ6cmFkaWFsLWdyYWRpZW50KGNpcmNsZSwjNWVmMmE4MzYsdHJhbnNwYXJlbnQgNjIlKTthbmltYXRpb246ZHJpZnQxIDQ0cyBlYXNlLWluLW91dCBpbmZpbml0ZX0KICAuZ2xvdyBpOm50aC1jaGlsZCgyKXt3aWR0aDo0NHJlbTtoZWlnaHQ6NDRyZW07cmlnaHQ6LTE0cmVtO3RvcDoxOHJlbTsKICAgIGJhY2tncm91bmQ6cmFkaWFsLWdyYWRpZW50KGNpcmNsZSwjOWE4Y2ZmMmIsdHJhbnNwYXJlbnQgNjIlKTthbmltYXRpb246ZHJpZnQyIDU2cyBlYXNlLWluLW91dCBpbmZpbml0ZX0KICBAa2V5ZnJhbWVzIGRyaWZ0MXs1MCV7dHJhbnNmb3JtOnRyYW5zbGF0ZTNkKDZyZW0sNHJlbSwwKX19CiAgQGtleWZyYW1lcyBkcmlmdDJ7NTAle3RyYW5zZm9ybTp0cmFuc2xhdGUzZCgtNXJlbSwtM3JlbSwwKX19CiAgLyogdGhlIHBvaW50ZXIgbW92ZXMgdGhlIHdob2xlIGxheWVyIGEgbGl0dGxlOiBjaGVhcCwgYW5kIGl0IHJlYWRzIGFzIGRlcHRoIHJhdGhlciB0aGFuIGFzIGEgdG95ICovCiAgI2Jne3RyYW5zaXRpb246dHJhbnNmb3JtIC41cyBjdWJpYy1iZXppZXIoLjIyLC42MSwuMzYsMSl9CiAgYm9keS5tb3Rpb24tZm9sbG93ICNiZ3t0cmFuc2Zvcm06dHJhbnNsYXRlM2QoY2FsYygodmFyKC0tbXgsNTAlKSAtIDUwJSkgKiAuMDUpLAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FsYygodmFyKC0tbXksNDIlKSAtIDUwJSkgKiAuMDUpLCAwKX0KICAjZnh7cG9zaXRpb246Zml4ZWQ7aW5zZXQ6MDt6LWluZGV4OjE7cG9pbnRlci1ldmVudHM6bm9uZX0KICBib2R5LmZ4LWdsb3cgI2Z4e2JveC1zaGFkb3c6aW5zZXQgMCAwIDI0MHB4ICMwMDAwMDA5ZX0KICBib2R5LmZ4LWdyaWQgI2Z4e2JhY2tncm91bmQtaW1hZ2U6bGluZWFyLWdyYWRpZW50KCNmZmZmZmYwYSAxcHgsdHJhbnNwYXJlbnQgMXB4KSwKICAgICAgICAgICAgICAgICAgIGxpbmVhci1ncmFkaWVudCg5MGRlZywjZmZmZmZmMGEgMXB4LHRyYW5zcGFyZW50IDFweCk7YmFja2dyb3VuZC1zaXplOjUycHggNTJweDsKICAgICAgICAgICAgICAgICAgIG1hc2staW1hZ2U6cmFkaWFsLWdyYWRpZW50KDgwJSA2MCUgYXQgNTAlIDAlLCMwMDAgOCUsdHJhbnNwYXJlbnQgNzIlKX0KICBib2R5LmZ4LXNjYW4gI2Z4e2JhY2tncm91bmQ6cmVwZWF0aW5nLWxpbmVhci1ncmFkaWVudCgjZmZmZmZmMDcgMCAxcHgsdHJhbnNwYXJlbnQgMXB4IDVweCl9CiAgYm9keS5meC1zY2FuICNmeDphZnRlcntjb250ZW50OiIiO3Bvc2l0aW9uOmFic29sdXRlO2luc2V0OjA7YmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQoIzAwMDAsI2ZmZmZmZjBkLCMwMDAwKTsKICAgICAgICAgICAgICAgICAgICAgICAgIGFuaW1hdGlvbjpzd2VlcCAxMXMgbGluZWFyIGluZmluaXRlfQogIEBrZXlmcmFtZXMgc3dlZXB7MCV7dHJhbnNmb3JtOnRyYW5zbGF0ZVkoLTYwJSl9MTAwJXt0cmFuc2Zvcm06dHJhbnNsYXRlWSg2MCUpfX0KCiAgLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSB0aGUgZnJhbWUgKi8KICAuZnJhbWV7cG9zaXRpb246cmVsYXRpdmU7ei1pbmRleDoyO2hlaWdodDoxMDB2aDttYXgtd2lkdGg6MTI4MHB4O21hcmdpbjowIGF1dG87ZGlzcGxheTpmbGV4OwogICAgICAgICBmbGV4LWRpcmVjdGlvbjpjb2x1bW47YmFja2dyb3VuZDp2YXIoLS1mcmFtZSk7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKTsKICAgICAgICAgYm9yZGVyLXJhZGl1czp2YXIoLS1yKTtib3gtc2hhZG93OnZhcigtLXNoYWRvdyk7b3ZlcmZsb3c6aGlkZGVufQogIC5mcmFtZTpiZWZvcmV7Y29udGVudDoiIjtwb3NpdGlvbjphYnNvbHV0ZTtpbnNldDowO2JvcmRlci1yYWRpdXM6dmFyKC0tcik7cGFkZGluZzoxcHg7cG9pbnRlci1ldmVudHM6bm9uZTsKICAgIGJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KDE1MGRlZywjNWVmMmE4M2QsI2ZmZmZmZjAwIDQwJSwjOWE4Y2ZmMzMpOwogICAgLXdlYmtpdC1tYXNrOmxpbmVhci1ncmFkaWVudCgjMDAwIDAgMCkgY29udGVudC1ib3gsbGluZWFyLWdyYWRpZW50KCMwMDAgMCAwKTsKICAgIC13ZWJraXQtbWFzay1jb21wb3NpdGU6eG9yO21hc2stY29tcG9zaXRlOmV4Y2x1ZGV9CgogIC50b3B7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6MThweDtwYWRkaW5nOjIwcHggMjZweCAxNHB4O2ZsZXg6bm9uZX0KICAuYnJhbmR7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6MTFweH0KICAuYnJhbmQgc3Zne3dpZHRoOjM4cHg7aGVpZ2h0OjM4cHg7ZmxleDpub25lO2ZpbHRlcjpkcm9wLXNoYWRvdygwIDZweCAxOHB4ICM1ZWYyYTgzZCl9CiAgLmJyYW5kIGJ7ZGlzcGxheTpibG9jaztmb250LXNpemU6MTdweDtsZXR0ZXItc3BhY2luZzotLjAyZW07Zm9udC13ZWlnaHQ6NjQwO2xpbmUtaGVpZ2h0OjEuMTV9CiAgLmJyYW5kIHNwYW57ZGlzcGxheTpibG9jaztmb250LXNpemU6OS41cHg7bGV0dGVyLXNwYWNpbmc6LjI4ZW07dGV4dC10cmFuc2Zvcm06dXBwZXJjYXNlO2NvbG9yOnZhcigtLWRpbSl9CiAgbmF2e2Rpc3BsYXk6ZmxleDtnYXA6MnB4O21hcmdpbi1sZWZ0OjEwcHg7ZmxleDoxfQogIG5hdiBidXR0b257YmFja2dyb3VuZDpub25lO2JvcmRlcjowO2NvbG9yOnZhcigtLW11dGVkKTtmb250OmluaGVyaXQ7Zm9udC1zaXplOjE0cHg7cGFkZGluZzo5cHggMTRweCAxMXB4OwogICAgICAgICAgICAgcG9zaXRpb246cmVsYXRpdmU7Y3Vyc29yOnBvaW50ZXI7Ym9yZGVyLXJhZGl1czoxMHB4IDEwcHggMCAwfQogIG5hdiBidXR0b246aG92ZXJ7Y29sb3I6dmFyKC0taW5rKX0KICBuYXYgYnV0dG9uLm9ue2NvbG9yOnZhcigtLWluayl9CiAgbmF2IGJ1dHRvbi5vbjphZnRlcntjb250ZW50OiIiO3Bvc2l0aW9uOmFic29sdXRlO2xlZnQ6MTJweDtyaWdodDoxMnB4O2JvdHRvbTotMXB4O2hlaWdodDoycHg7CiAgICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOjJweDtiYWNrZ3JvdW5kOnZhcigtLWF1cm9yYSl9CiAgLnBpbGx7ZGlzcGxheTppbmxpbmUtZmxleDthbGlnbi1pdGVtczpjZW50ZXI7Z2FwOjhweDtmb250LXNpemU6MTJweDtjb2xvcjp2YXIoLS1tdXRlZCk7CiAgICAgICAgYm9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKTtib3JkZXItcmFkaXVzOnZhcigtLXBpbGwpO3BhZGRpbmc6N3B4IDEzcHg7YmFja2dyb3VuZDojZmZmZmZmMDg7CiAgICAgICAgd2hpdGUtc3BhY2U6bm93cmFwO2JhY2tkcm9wLWZpbHRlcjpibHVyKDEycHgpfQogIC5kb3R7d2lkdGg6N3B4O2hlaWdodDo3cHg7Ym9yZGVyLXJhZGl1czo1MCU7YmFja2dyb3VuZDp2YXIoLS1kaW0pO2ZsZXg6bm9uZX0KICAuZG90Lm9re2JhY2tncm91bmQ6dmFyKC0tbWludCk7Ym94LXNoYWRvdzowIDAgMTJweCB2YXIoLS1taW50KX0KICAuZG90LmJhZHtiYWNrZ3JvdW5kOnZhcigtLXJlZCl9CiAgLmRvdC5idXN5e2JhY2tncm91bmQ6dmFyKC0tYW1iZXIpO2FuaW1hdGlvbjpibGluayAxLjFzIGVhc2UtaW4tb3V0IGluZmluaXRlfQogIEBrZXlmcmFtZXMgYmxpbmt7NTAle29wYWNpdHk6LjI1fX0KICAuaGFpcmxpbmV7aGVpZ2h0OjFweDtiYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCg5MGRlZyx0cmFuc3BhcmVudCx2YXIoLS1saW5lMiksdHJhbnNwYXJlbnQpO2ZsZXg6bm9uZX0KCiAgLmJvZHl7ZmxleDoxO21pbi1oZWlnaHQ6MDtvdmVyZmxvdzphdXRvO3BhZGRpbmc6MjJweCAyNnB4IDI2cHh9CiAgLnZpZXd7ZGlzcGxheTpub25lfQogIC52aWV3Lm9ue2Rpc3BsYXk6YmxvY2s7YW5pbWF0aW9uOmluIC4zMnMgY3ViaWMtYmV6aWVyKC4yMiwuNjEsLjM2LDEpfQogIEBrZXlmcmFtZXMgaW57ZnJvbXtvcGFjaXR5OjA7dHJhbnNmb3JtOnRyYW5zbGF0ZVkoOHB4KX10b3tvcGFjaXR5OjE7dHJhbnNmb3JtOm5vbmV9fQoKICAuc3BsaXR7ZGlzcGxheTpncmlkO2dyaWQtdGVtcGxhdGUtY29sdW1uczoxLjVmciAxZnI7Z2FwOjE4cHg7YWxpZ24taXRlbXM6c3RyZXRjaH0KICAuY2FyZHtiYWNrZ3JvdW5kOnZhcigtLWNhcmQpO2JvcmRlcjoxcHggc29saWQgdmFyKC0tbGluZSk7Ym9yZGVyLXJhZGl1czp2YXIoLS1yMik7cGFkZGluZzoyNHB4IDI2cHg7CiAgICAgICAgcG9zaXRpb246cmVsYXRpdmU7b3ZlcmZsb3c6aGlkZGVufQogIC5jYXJkOmJlZm9yZXtjb250ZW50OiIiO3Bvc2l0aW9uOmFic29sdXRlO2luc2V0OjA7Ym9yZGVyLXJhZGl1czp2YXIoLS1yMik7cGFkZGluZzoxcHg7cG9pbnRlci1ldmVudHM6bm9uZTsKICAgIGJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KDE4MGRlZywjZmZmZmZmMTQsdHJhbnNwYXJlbnQgNjAlKTsKICAgIC13ZWJraXQtbWFzazpsaW5lYXItZ3JhZGllbnQoIzAwMCAwIDApIGNvbnRlbnQtYm94LGxpbmVhci1ncmFkaWVudCgjMDAwIDAgMCk7CiAgICAtd2Via2l0LW1hc2stY29tcG9zaXRlOnhvcjttYXNrLWNvbXBvc2l0ZTpleGNsdWRlfQogIC5jYXJkLmhlcm97ZGlzcGxheTpmbGV4O2ZsZXgtZGlyZWN0aW9uOmNvbHVtbjtqdXN0aWZ5LWNvbnRlbnQ6c3BhY2UtYmV0d2VlbjsKICAgICAgICAgICAgIGJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KDE2MGRlZywjMTQxOTIyLCMwZjEyMTkgNzAlKX0KICAuY2FyZC5oZXJvOmFmdGVye2NvbnRlbnQ6IiI7cG9zaXRpb246YWJzb2x1dGU7cmlnaHQ6LTExMHB4O3RvcDotMTMwcHg7d2lkdGg6MzQwcHg7aGVpZ2h0OjM0MHB4OwogICAgYm9yZGVyLXJhZGl1czo1MCU7YmFja2dyb3VuZDpyYWRpYWwtZ3JhZGllbnQoY2lyY2xlLCM1ZWYyYTgyZSx0cmFuc3BhcmVudCA2NSUpfQogIC5leWVicm93e2ZvbnQtc2l6ZToxMC41cHg7bGV0dGVyLXNwYWNpbmc6LjNlbTt0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7Y29sb3I6dmFyKC0tZGltKTsKICAgICAgICAgICBkaXNwbGF5OmZsZXg7YWxpZ24taXRlbXM6Y2VudGVyO2dhcDo5cHh9CiAgLmV5ZWJyb3c6YmVmb3Jle2NvbnRlbnQ6IiI7d2lkdGg6MTZweDtoZWlnaHQ6MXB4O2JhY2tncm91bmQ6dmFyKC0tbGluZTIpfQogIGgxLmJpZ3ttYXJnaW46MTRweCAwIDA7Zm9udC1zaXplOmNsYW1wKDUycHgsOC40dncsOTZweCk7bGluZS1oZWlnaHQ6Ljk7bGV0dGVyLXNwYWNpbmc6LS4wNWVtOwogICAgICAgICBmb250LXdlaWdodDo3MjA7CiAgICAgICAgIGJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KDEwNWRlZywjZmZmZmZmLCNiZmY3ZGQgNTIlLCM1ZWYyYTgpOwogICAgICAgICAtd2Via2l0LWJhY2tncm91bmQtY2xpcDp0ZXh0O2JhY2tncm91bmQtY2xpcDp0ZXh0Oy13ZWJraXQtdGV4dC1maWxsLWNvbG9yOnRyYW5zcGFyZW50fQogIC5sZWRle2NvbG9yOnZhcigtLW11dGVkKTtmb250LXNpemU6MTRweDttYXgtd2lkdGg6NTZjaDttYXJnaW46MTZweCAwIDB9CiAgLmNoaXBze2Rpc3BsYXk6ZmxleDtmbGV4LXdyYXA6d3JhcDtnYXA6OHB4O21hcmdpbi10b3A6MjBweH0KICAuY2hpcHtmb250LXNpemU6MTEuNXB4O3BhZGRpbmc6NXB4IDEycHg7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKTtib3JkZXItcmFkaXVzOnZhcigtLXBpbGwpOwogICAgICAgIGNvbG9yOnZhcigtLW11dGVkKTtiYWNrZ3JvdW5kOiNmZmZmZmYwN30KICAuY2hpcC5saXZle2NvbG9yOiNjOGZmZTQ7Ym9yZGVyLWNvbG9yOiMyZjZkNTE7YmFja2dyb3VuZDojMGYyNDE5fQogIC5maWVsZHN7ZGlzcGxheTpncmlkO2dyaWQtdGVtcGxhdGUtY29sdW1uczoxZnIgMWZyO2dhcDoxNHB4O21hcmdpbi10b3A6MjRweH0KCiAgbGFiZWx7ZGlzcGxheTpibG9jaztmb250LXNpemU6MTFweDtsZXR0ZXItc3BhY2luZzouMTRlbTt0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7Y29sb3I6dmFyKC0tZGltKTsKICAgICAgICBtYXJnaW46MCAwIDdweH0KICBzZWxlY3QsaW5wdXRbdHlwZT10ZXh0XSxpbnB1dFt0eXBlPXBhc3N3b3JkXSxpbnB1dDpub3QoW3R5cGVdKXt3aWR0aDoxMDAlO2JhY2tncm91bmQ6IzBhMGMxMTsKICAgICAgICBib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpO2JvcmRlci1yYWRpdXM6dmFyKC0tcjMpO3BhZGRpbmc6MTJweCAxM3B4O2ZvbnQ6aW5oZXJpdDtmb250LXNpemU6MTRweDsKICAgICAgICBjb2xvcjp2YXIoLS1pbmspO2FwcGVhcmFuY2U6bm9uZTt0cmFuc2l0aW9uOmJvcmRlci1jb2xvciAuMTVzLGJveC1zaGFkb3cgLjE1c30KICBzZWxlY3R7YmFja2dyb3VuZC1pbWFnZTpsaW5lYXItZ3JhZGllbnQoNDVkZWcsdHJhbnNwYXJlbnQgNTAlLHZhcigtLWRpbSkgNTAlKSwKICAgICAgICAgICAgICAgICAgICAgICAgICBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLHZhcigtLWRpbSkgNTAlLHRyYW5zcGFyZW50IDUwJSk7CiAgICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246Y2FsYygxMDAlIC0gMTlweCkgNTAlLGNhbGMoMTAwJSAtIDE0cHgpIDUwJTsKICAgICAgICAgYmFja2dyb3VuZC1zaXplOjVweCA1cHgsNXB4IDVweDtiYWNrZ3JvdW5kLXJlcGVhdDpuby1yZXBlYXQ7cGFkZGluZy1yaWdodDozNHB4fQogIGlucHV0OmZvY3VzLHNlbGVjdDpmb2N1c3tvdXRsaW5lOm5vbmU7Ym9yZGVyLWNvbG9yOiM1ZWYyYTg4MDtib3gtc2hhZG93OjAgMCAwIDRweCAjNWVmMmE4MTd9CiAgYnV0dG9ue2ZvbnQ6aW5oZXJpdDtjdXJzb3I6cG9pbnRlcjtib3JkZXItcmFkaXVzOnZhcigtLXIzKTtib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpOwogICAgICAgICBiYWNrZ3JvdW5kOiNmZmZmZmYwZDtjb2xvcjp2YXIoLS1pbmspO3BhZGRpbmc6MTFweCAxN3B4O2ZvbnQtc2l6ZToxNHB4OwogICAgICAgICBkaXNwbGF5OmlubGluZS1mbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6OXB4O2p1c3RpZnktY29udGVudDpjZW50ZXI7CiAgICAgICAgIHRyYW5zaXRpb246dHJhbnNmb3JtIC4xMnMsYmFja2dyb3VuZCAuMTZzLGJvcmRlci1jb2xvciAuMTZzfQogIGJ1dHRvbjpob3Zlcjpub3QoOmRpc2FibGVkKXtiYWNrZ3JvdW5kOiNmZmZmZmYxODtib3JkZXItY29sb3I6dmFyKC0tbGluZTIpO3RyYW5zZm9ybTp0cmFuc2xhdGVZKC0xcHgpfQogIGJ1dHRvbjpkaXNhYmxlZHtvcGFjaXR5Oi4zNTtjdXJzb3I6bm90LWFsbG93ZWR9CiAgYnV0dG9uLnRpbnl7cGFkZGluZzo2cHggMTJweDtmb250LXNpemU6MTIuNXB4fQogIGJ1dHRvbi5naG9zdHtiYWNrZ3JvdW5kOm5vbmV9CiAgYnV0dG9uLmRhbmdlcntiYWNrZ3JvdW5kOiMyYTE1MTI7Ym9yZGVyLWNvbG9yOiM1YzJmMjg7Y29sb3I6I2ZmYjRhOH0KICAuZ297cG9zaXRpb246cmVsYXRpdmU7d2lkdGg6MTAwJTttYXJnaW4tdG9wOjE4cHg7aGVpZ2h0Ojc0cHg7Zm9udC1zaXplOjIycHg7Zm9udC13ZWlnaHQ6NzAwOwogICAgICBsZXR0ZXItc3BhY2luZzouMTRlbTtib3JkZXI6MDtib3JkZXItcmFkaXVzOnZhcigtLXIzKTtjb2xvcjojMDQxNDBjO292ZXJmbG93OmhpZGRlbjsKICAgICAgYmFja2dyb3VuZDp2YXIoLS1hdXJvcmEpO2JveC1zaGFkb3c6MCAyMHB4IDUwcHggIzJmOGY2YTRkLGluc2V0IDAgMXB4IDAgI2ZmZmZmZjZifQogIC5nbzphZnRlcntjb250ZW50OiIiO3Bvc2l0aW9uOmFic29sdXRlO3RvcDowO2JvdHRvbTowO3dpZHRoOjM4JTtsZWZ0Oi00MCU7CiAgICAgICAgICAgIGJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KDEwMGRlZyx0cmFuc3BhcmVudCwjZmZmZmZmNWMsdHJhbnNwYXJlbnQpOwogICAgICAgICAgICBhbmltYXRpb246c2hlZW4gNC42cyBlYXNlLWluLW91dCBpbmZpbml0ZX0KICBAa2V5ZnJhbWVzIHNoZWVuezAlLDcyJXtsZWZ0Oi00MCV9ODYlLDEwMCV7bGVmdDoxMjAlfX0KICAuZ286ZGlzYWJsZWR7YmFja2dyb3VuZDojMTkxZDI2O2NvbG9yOnZhcigtLWRpbSk7Ym94LXNoYWRvdzpub25lfQogIC5nbzpkaXNhYmxlZDphZnRlcntkaXNwbGF5Om5vbmV9CiAgLmhhbHR7d2lkdGg6MTAwJTttYXJnaW4tdG9wOjE4cHg7aGVpZ2h0Ojc0cHg7Ym9yZGVyLXJhZGl1czp2YXIoLS1yMyk7Zm9udC1zaXplOjE2cHg7Zm9udC13ZWlnaHQ6NjUwOwogICAgICAgIGJhY2tncm91bmQ6IzJhMTUxMjtib3JkZXI6MXB4IHNvbGlkICM1YzJmMjg7Y29sb3I6I2ZmYjRhOH0KCiAgLyogdGhlIGZhY3RzLCBhcyBhIGxpc3QgcmF0aGVyIHRoYW4gdGlsZXMgKi8KICAuZmFjdHN7bGlzdC1zdHlsZTpub25lO21hcmdpbjowO3BhZGRpbmc6MH0KICAuZmFjdHMgbGl7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmJhc2VsaW5lO2dhcDoxNHB4O3BhZGRpbmc6MTNweCAwO2JvcmRlci1ib3R0b206MXB4IHNvbGlkIHZhcigtLWxpbmUpfQogIC5mYWN0cyBsaTpsYXN0LWNoaWxke2JvcmRlci1ib3R0b206MH0KICAuZmFjdHMgLmt7Zm9udC1zaXplOjExcHg7bGV0dGVyLXNwYWNpbmc6LjE4ZW07dGV4dC10cmFuc2Zvcm06dXBwZXJjYXNlO2NvbG9yOnZhcigtLWRpbSk7ZmxleDpub25lOwogICAgICAgICAgICB3aWR0aDo5LjVyZW19CiAgLmZhY3RzIC52e2ZvbnQtc2l6ZToxNXB4O2ZvbnQtd2VpZ2h0OjYwMDtsZXR0ZXItc3BhY2luZzotLjAxZW07bWFyZ2luLWxlZnQ6YXV0bzt0ZXh0LWFsaWduOnJpZ2h0OwogICAgICAgICAgICBtaW4td2lkdGg6MDtvdmVyZmxvdzpoaWRkZW47dGV4dC1vdmVyZmxvdzplbGxpcHNpczt3aGl0ZS1zcGFjZTpub3dyYXB9CiAgLmZhY3RzIC5ze2Rpc3BsYXk6YmxvY2s7Zm9udC1zaXplOjExLjVweDtjb2xvcjp2YXIoLS1kaW0pO2ZvbnQtd2VpZ2h0OjQwMDttYXJnaW4tdG9wOjJweH0KCiAgLnN0YXR1c3ttYXJnaW4tdG9wOjE4cHg7YmFja2dyb3VuZDp2YXIoLS1jYXJkKTtib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpO2JvcmRlci1yYWRpdXM6dmFyKC0tcjIpOwogICAgICAgICAgcGFkZGluZzoxOHB4IDIycHh9CiAgLnN0YXR1c2xpbmV7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6MTRweDtmb250LXNpemU6MTNweDtjb2xvcjp2YXIoLS1tdXRlZCl9CiAgLnJhaWx7ZmxleDoxO2hlaWdodDo1cHg7Ym9yZGVyLXJhZGl1czo5OXB4O2JhY2tncm91bmQ6I2ZmZmZmZjEyO292ZXJmbG93OmhpZGRlbn0KICAucmFpbCBpe2Rpc3BsYXk6YmxvY2s7aGVpZ2h0OjEwMCU7d2lkdGg6MDtiYWNrZ3JvdW5kOnZhcigtLWF1cm9yYSk7dHJhbnNpdGlvbjp3aWR0aCAuNDVzfQogIC5yYWlsLndhaXQgaXt3aWR0aDozMiU7YW5pbWF0aW9uOnNsaWRlIDEuMzVzIGVhc2UtaW4tb3V0IGluZmluaXRlfQogIEBrZXlmcmFtZXMgc2xpZGV7MCV7bWFyZ2luLWxlZnQ6LTMyJX0xMDAle21hcmdpbi1sZWZ0OjEwMCV9fQogIC5jb2xze2Rpc3BsYXk6Z3JpZDtncmlkLXRlbXBsYXRlLWNvbHVtbnM6MWZyIDFmcjtnYXA6MThweH0KICAuc3RhY2s+Kisqe21hcmdpbi10b3A6MThweH0KICAubm90ZXtmb250LXNpemU6MTIuNXB4O2NvbG9yOnZhcigtLW11dGVkKTtsaW5lLWhlaWdodDoxLjc1fQogIC53YXJuYm94e2JvcmRlcjoxcHggc29saWQgIzZhNTIyMDtiYWNrZ3JvdW5kOiMyMjFiMGU7Y29sb3I6I2YwZDQ5NDtwYWRkaW5nOjE0cHggMTZweDtib3JkZXItcmFkaXVzOnZhcigtLXIzKTsKICAgICAgICAgICBmb250LXNpemU6MTNweDtsaW5lLWhlaWdodDoxLjd9CiAgLmJhZGJveHtib3JkZXI6MXB4IHNvbGlkICM1YzJmMjg7YmFja2dyb3VuZDojMjQxMzExO2NvbG9yOiNmZmI0YTg7cGFkZGluZzoxNHB4IDE2cHg7Ym9yZGVyLXJhZGl1czp2YXIoLS1yMyk7CiAgICAgICAgICBmb250LXNpemU6MTNweDtsaW5lLWhlaWdodDoxLjd9CiAgLnN0ZXBze21hcmdpbjoxMHB4IDAgMDtwYWRkaW5nLWxlZnQ6MjBweDtmb250LXNpemU6MTNweDtjb2xvcjp2YXIoLS1tdXRlZCk7bGluZS1oZWlnaHQ6MS45NX0KICAucm93bGluZXtkaXNwbGF5OmZsZXg7YWxpZ24taXRlbXM6Y2VudGVyO2dhcDoxOHB4O3BhZGRpbmc6MTVweCAwO2JvcmRlci1ib3R0b206MXB4IHNvbGlkIHZhcigtLWxpbmUpfQogIC5yb3dsaW5lOmxhc3QtY2hpbGR7Ym9yZGVyLWJvdHRvbTowfQogIC5yb3dsaW5lIC5ybHtmbGV4OjE7bWluLXdpZHRoOjB9CiAgLnJvd2xpbmUgLnJsIGJ7ZGlzcGxheTpibG9jaztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo1NjB9CiAgLnJvd2xpbmUgLnJsIHNwYW57ZGlzcGxheTpibG9jaztmb250LXNpemU6MTIuNXB4O2NvbG9yOnZhcigtLWRpbSk7bWFyZ2luLXRvcDozcHh9CiAgLnJvd2xpbmUgLnJje2ZsZXg6MCAwIGF1dG87ZGlzcGxheTpmbGV4O2dhcDoxMHB4O2FsaWduLWl0ZW1zOmNlbnRlcn0KICAucm93bGluZSAucmMud2lkZXtmbGV4LWJhc2lzOjM0MHB4fQogIC5jaGVja3tkaXNwbGF5OmZsZXg7Z2FwOjEycHg7YWxpZ24taXRlbXM6ZmxleC1zdGFydDtmb250LXNpemU6MTRweDtjb2xvcjp2YXIoLS1pbmspfQogIC5jaGVjayBpbnB1dHt3aWR0aDphdXRvO2ZsZXg6bm9uZTttYXJnaW4tdG9wOjVweH0KICAuZHJvcHtib3JkZXI6MS41cHggZGFzaGVkIHZhcigtLWxpbmUyKTtib3JkZXItcmFkaXVzOnZhcigtLXIzKTtwYWRkaW5nOjI2cHg7dGV4dC1hbGlnbjpjZW50ZXI7CiAgICAgICAgY29sb3I6dmFyKC0tbXV0ZWQpO2ZvbnQtc2l6ZToxMy41cHg7Y3Vyc29yOnBvaW50ZXI7dHJhbnNpdGlvbjouMTZzfQogIC5kcm9wOmhvdmVyLC5kcm9wLm92ZXJ7Ym9yZGVyLWNvbG9yOnZhcigtLW1pbnQpO2NvbG9yOnZhcigtLWluayk7YmFja2dyb3VuZDojNWVmMmE4MGZ9CiAgLm1vZHN7bGlzdC1zdHlsZTpub25lO21hcmdpbjoxNnB4IDAgMDtwYWRkaW5nOjA7Zm9udC1zaXplOjEzLjVweH0KICAubW9kcyBsaXtkaXNwbGF5OmZsZXg7YWxpZ24taXRlbXM6Y2VudGVyO2dhcDoxMnB4O3BhZGRpbmc6MTFweCAxM3B4O2JvcmRlcjoxcHggc29saWQgdmFyKC0tbGluZSk7CiAgICAgICAgICAgYm9yZGVyLXJhZGl1czp2YXIoLS1yMyk7bWFyZ2luLWJvdHRvbTo4cHg7YmFja2dyb3VuZDojZmZmZmZmMDZ9CiAgLm1vZHMgLm5te2ZsZXg6MTttaW4td2lkdGg6MDtvdmVyZmxvdzpoaWRkZW47dGV4dC1vdmVyZmxvdzplbGxpcHNpczt3aGl0ZS1zcGFjZTpub3dyYXB9CiAgLnRhZ3tmb250LXNpemU6OS41cHg7bGV0dGVyLXNwYWNpbmc6LjE0ZW07dGV4dC10cmFuc2Zvcm06dXBwZXJjYXNlO2NvbG9yOnZhcigtLWRpbSk7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKTsKICAgICAgIGJvcmRlci1yYWRpdXM6dmFyKC0tcGlsbCk7cGFkZGluZzoycHggOXB4O2ZsZXg6bm9uZX0KICAudGFnLm1pbmV7Y29sb3I6I2I5ZjZkNjtib3JkZXItY29sb3I6IzJmNmQ1MX0KICAudGFnLmh1Yntjb2xvcjojY2FkNmZmO2JvcmRlci1jb2xvcjojM2I0NDc4fQogIC5yZXN1bHRze2xpc3Qtc3R5bGU6bm9uZTttYXJnaW46MTZweCAwIDA7cGFkZGluZzowO21heC1oZWlnaHQ6MzMwcHg7b3ZlcmZsb3c6YXV0bztmb250LXNpemU6MTMuNXB4fQogIC5yZXN1bHRzIGxpe2Rpc3BsYXk6ZmxleDtnYXA6MTJweDthbGlnbi1pdGVtczpjZW50ZXI7cGFkZGluZzoxMXB4IDJweDtib3JkZXItYm90dG9tOjFweCBzb2xpZCB2YXIoLS1saW5lKX0KICAucmVzdWx0cyAubm17ZmxleDoxO21pbi13aWR0aDowfQogIC5yZXN1bHRzIC5ubSBie2ZvbnQtd2VpZ2h0OjU2MH0KICAucmVzdWx0cyAubm0gZGl2e2NvbG9yOnZhcigtLWRpbSk7Zm9udC1zaXplOjEycHg7d2hpdGUtc3BhY2U6bm93cmFwO292ZXJmbG93OmhpZGRlbjt0ZXh0LW92ZXJmbG93OmVsbGlwc2lzfQoKICAvKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIHRoZSBsb2cgYmFyICovCiAgLmxvZ2JhcntmbGV4Om5vbmU7Ym9yZGVyLXRvcDoxcHggc29saWQgdmFyKC0tbGluZSk7YmFja2dyb3VuZDojMGEwYzExY2M7YmFja2Ryb3AtZmlsdGVyOmJsdXIoMjBweCk7CiAgICAgICAgICB0cmFuc2l0aW9uOmhlaWdodCAuMjZzIGN1YmljLWJlemllciguNCwwLC4yLDEpO2hlaWdodDo1NHB4O2Rpc3BsYXk6ZmxleDtmbGV4LWRpcmVjdGlvbjpjb2x1bW59CiAgYm9keS5kcmF3ZXItb3BlbiAubG9nYmFye2hlaWdodDo0NHZofQogIC5zdHJpcGxpbmV7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6MTRweDtwYWRkaW5nOjAgMjZweDtoZWlnaHQ6NTRweDtmbGV4Om5vbmU7Y3Vyc29yOnBvaW50ZXJ9CiAgLnN0cmlwbGluZSBie2ZvbnQtc2l6ZToxMC41cHg7bGV0dGVyLXNwYWNpbmc6LjI2ZW07dGV4dC10cmFuc2Zvcm06dXBwZXJjYXNlO2NvbG9yOnZhcigtLWRpbSl9CiAgLnN0cmlwbGluZSAucGhhc2V7Zm9udC1zaXplOjEzcHg7Y29sb3I6dmFyKC0tbXV0ZWQpO21pbi13aWR0aDoxNWNofQogIC5zdHJpcGxpbmUgLnBjdHtmb250LXNpemU6MTJweDtjb2xvcjp2YXIoLS1kaW0pO21pbi13aWR0aDo4Y2g7dGV4dC1hbGlnbjpyaWdodH0KICAuc3RyaXBsaW5lIC50b2dnbGV7Zm9udC1zaXplOjExLjVweDtjb2xvcjp2YXIoLS1tdXRlZCk7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKTtib3JkZXItcmFkaXVzOnZhcigtLXBpbGwpOwogICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOjVweCAxM3B4O2JhY2tncm91bmQ6I2ZmZmZmZjA4fQogIC5sb2dib2R5e2ZsZXg6MTttaW4taGVpZ2h0OjA7ZGlzcGxheTpub25lO2JvcmRlci10b3A6MXB4IHNvbGlkIHZhcigtLWxpbmUpO2ZsZXgtZGlyZWN0aW9uOmNvbHVtbn0KICBib2R5LmRyYXdlci1vcGVuIC5sb2dib2R5e2Rpc3BsYXk6ZmxleH0KICAubG9ndG9vbHN7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6MTJweDtwYWRkaW5nOjExcHggMjZweDtmbGV4Om5vbmU7Ym9yZGVyLWJvdHRvbToxcHggc29saWQgdmFyKC0tbGluZSl9CiAgLmxvZ3Rvb2xzIGJ7Zm9udC1zaXplOjEwLjVweDtsZXR0ZXItc3BhY2luZzouMjZlbTt0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2U7Y29sb3I6dmFyKC0tZGltKX0KICAucmVjZWlwdHtkaXNwbGF5Om5vbmU7cGFkZGluZzoxNnB4IDI2cHg7YmFja2dyb3VuZDojMGYyMTE4Y2M7Zm9udC1zaXplOjEzcHg7bGluZS1oZWlnaHQ6MS44O21heC1oZWlnaHQ6MzglOwogICAgICAgICAgIG92ZXJmbG93OmF1dG87Ym9yZGVyLWJvdHRvbToxcHggc29saWQgdmFyKC0tbGluZSl9CiAgLnJlY2VpcHQgaDN7bWFyZ2luOjAgMCA4cHg7Zm9udC1zaXplOjEzcHg7Y29sb3I6I2I5ZjZkNn0KICAuY29uc29sZXtmbGV4OjE7bWluLWhlaWdodDowO292ZXJmbG93OmF1dG87cGFkZGluZzoxNnB4IDI2cHg7Zm9udDoxMi41cHgvMS44NSB1aS1tb25vc3BhY2UsU0ZNb25vLVJlZ3VsYXIsTWVubG8sbW9ub3NwYWNlOwogICAgICAgICAgIHdoaXRlLXNwYWNlOnByZS13cmFwO3dvcmQtYnJlYWs6YnJlYWstd29yZDtjb2xvcjojYzZjYmQ2fQogIC5jb25zb2xlIC5le2NvbG9yOiNmZjlkOTB9IC5jb25zb2xlIC5ne2NvbG9yOiM5ZmYwYzR9IC5jb25zb2xlIC5ke2NvbG9yOnZhcigtLWRpbSl9CgogIC8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gZG9jcyAqLwogIC5kb2N3cmFwe2Rpc3BsYXk6Z3JpZDtncmlkLXRlbXBsYXRlLWNvbHVtbnM6MWZyIDIwOHB4O2dhcDozMnB4O2FsaWduLWl0ZW1zOnN0YXJ0fQogIC5kb2N7bWF4LXdpZHRoOjc4Y2h9CiAgLmRvYyBoM3tmb250LXNpemU6MjBweDttYXJnaW46MzRweCAwIDEwcHg7Zm9udC13ZWlnaHQ6NjIwO2xldHRlci1zcGFjaW5nOi0uMDJlbX0KICAuZG9jIGgzOmZpcnN0LW9mLXR5cGV7bWFyZ2luLXRvcDowfQogIC5kb2MgcCwuZG9jIGxpe2NvbG9yOiNjOWNlZGI7Zm9udC1zaXplOjE0LjJweH0KICAuZG9jIC5sZWFke2ZvbnQtc2l6ZToxNnB4O2NvbG9yOnZhcigtLW11dGVkKX0KICAuZG9jIHRhYmxle2JvcmRlci1jb2xsYXBzZTpjb2xsYXBzZTt3aWR0aDoxMDAlO21hcmdpbjoxOHB4IDA7Zm9udC1zaXplOjEzLjRweH0KICAuZG9jIHRoLC5kb2MgdGR7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKTtwYWRkaW5nOjEwcHggMTNweDt0ZXh0LWFsaWduOmxlZnQ7dmVydGljYWwtYWxpZ246dG9wfQogIC5kb2MgdGh7YmFja2dyb3VuZDojZmZmZmZmMDg7Y29sb3I6dmFyKC0tZGltKTtmb250LXdlaWdodDo2MDA7Zm9udC1zaXplOjEwLjVweDtsZXR0ZXItc3BhY2luZzouMTZlbTsKICAgICAgICAgIHRleHQtdHJhbnNmb3JtOnVwcGVyY2FzZX0KICAuZG9jIGhye2JvcmRlcjowO2JvcmRlci10b3A6MXB4IHNvbGlkIHZhcigtLWxpbmUpO21hcmdpbjozMHB4IDB9CiAgLnRvY3twb3NpdGlvbjpzdGlja3k7dG9wOjB9CiAgLnRvYyBhe2Rpc3BsYXk6YmxvY2s7Zm9udC1zaXplOjEyLjVweDtjb2xvcjp2YXIoLS1tdXRlZCk7cGFkZGluZzo3cHggMDtib3JkZXItYm90dG9tOjFweCBzb2xpZCB2YXIoLS1saW5lKX0KICAudG9jIGE6aG92ZXJ7Y29sb3I6dmFyKC0taW5rKTt0ZXh0LWRlY29yYXRpb246bm9uZX0KICBkaWFsb2d7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKTtiYWNrZ3JvdW5kOiMxMDEzMTlmMjtiYWNrZHJvcC1maWx0ZXI6Ymx1cigyNHB4KTtjb2xvcjp2YXIoLS1pbmspOwogICAgICAgICBib3JkZXItcmFkaXVzOnZhcigtLXIyKTttYXgtd2lkdGg6NjYwcHg7cGFkZGluZzowO2JveC1zaGFkb3c6dmFyKC0tc2hhZG93KX0KICBkaWFsb2c6OmJhY2tkcm9we2JhY2tncm91bmQ6IzAwMDAwMGI4fQogIGRpYWxvZyAuaW5uZXJ7cGFkZGluZzoyNnB4IDI4cHh9CiAgZGlhbG9nIGgze21hcmdpbjowIDAgMTJweDtmb250LXNpemU6MThweH0KICBkaWFsb2cgcHtmb250LXNpemU6MTMuNXB4O2NvbG9yOnZhcigtLW11dGVkKTtsaW5lLWhlaWdodDoxLjh9CiAgQG1lZGlhIChtYXgtd2lkdGg6MTA4MHB4KXsuc3BsaXQsLmNvbHMsLmRvY3dyYXB7Z3JpZC10ZW1wbGF0ZS1jb2x1bW5zOjFmcn0udG9je2Rpc3BsYXk6bm9uZX19CiAgQG1lZGlhIChwcmVmZXJzLXJlZHVjZWQtbW90aW9uOnJlZHVjZSl7KnthbmltYXRpb246bm9uZSFpbXBvcnRhbnQ7dHJhbnNpdGlvbjpub25lIWltcG9ydGFudH19Cjwvc3R5bGU+CjwvaGVhZD4KPGJvZHkgY2xhc3M9ImZ4LWdsb3ciPgo8ZGl2IGNsYXNzPSJnbG93IiBpZD0iYmciIGFyaWEtaGlkZGVuPSJ0cnVlIj48aT48L2k+PGk+PC9pPjwvZGl2Pgo8ZGl2IGlkPSJmeCIgYXJpYS1oaWRkZW49InRydWUiPjwvZGl2Pgo8aW5wdXQgdHlwZT0iY2hlY2tib3giIGlkPSJwcm94eUFsbCIgaGlkZGVuIC8+PGlucHV0IHR5cGU9ImNoZWNrYm94IiBpZD0icmVzdHJpY3RlZCIgaGlkZGVuIC8+Cgo8ZGl2IGNsYXNzPSJmcmFtZSIgaWQ9ImFwcCI+CiAgPGhlYWRlciBjbGFzcz0idG9wIj4KICAgIDxkaXYgY2xhc3M9ImJyYW5kIj4KICAgICAgPHN2ZyB2aWV3Qm94PSIwIDAgNDAgNDAiIGFyaWEtaGlkZGVuPSJ0cnVlIj4KICAgICAgICA8ZGVmcz4KICAgICAgICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iYXVyIiB4MT0iMCIgeTE9IjAiIHgyPSIxIiB5Mj0iMSI+CiAgICAgICAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iIzVlZjJhOCIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzM5YzhmZiIvPgogICAgICAgICAgPC9saW5lYXJHcmFkaWVudD4KICAgICAgICA8L2RlZnM+CiAgICAgICAgPHJlY3QgeD0iMS40IiB5PSIxLjQiIHdpZHRoPSIzNy4yIiBoZWlnaHQ9IjM3LjIiIHJ4PSIxMS42IiBmaWxsPSIjNWVmMmE4MWEiCiAgICAgICAgICAgICAgc3Ryb2tlPSJ1cmwoI2F1cikiIHN0cm9rZS13aWR0aD0iMS42Ii8+CiAgICAgICAgPHBhdGggZD0iTTExLjUgMjguNVYxNS41YTguNSA4LjUgMCAwIDEgMTcgMHYxMyIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJ1cmwoI2F1cikiCiAgICAgICAgICAgICAgc3Ryb2tlLXdpZHRoPSIzLjQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgogICAgICAgIDxwYXRoIGQ9Ik0yMCA4LjV2MTEuNSIgc3Ryb2tlPSIjMDcwODBiIiBzdHJva2Utd2lkdGg9IjMuNCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+CiAgICAgICAgPGNpcmNsZSBjeD0iMjAiIGN5PSIyNS42IiByPSIyLjciIGZpbGw9InVybCgjYXVyKSIvPgogICAgICA8L3N2Zz4KICAgICAgPGRpdj48Yj5XZWJNQzwvYj48c3Bhbj5sYXVuY2hlcjwvc3Bhbj48L2Rpdj4KICAgIDwvZGl2PgogICAgPG5hdj4KICAgICAgPGJ1dHRvbiBpZD0ibmF2UGxheSIgY2xhc3M9Im9uIj5QbGF5PC9idXR0b24+CiAgICAgIDxidXR0b24gaWQ9Im5hdk1vZHMiPk1vZHM8L2J1dHRvbj4KICAgICAgPGJ1dHRvbiBpZD0ibmF2U2V0dGluZ3MiPlNldHRpbmdzPC9idXR0b24+CiAgICAgIDxidXR0b24gaWQ9Im5hdkRvYyI+RG9jdW1lbnRhdGlvbjwvYnV0dG9uPgogICAgPC9uYXY+CiAgICA8c3BhbiBpZD0idmlld1RpdGxlIiBoaWRkZW4+PC9zcGFuPgogICAgPHNwYW4gY2xhc3M9InBpbGwiIGlkPSJjb25uIj48aSBjbGFzcz0iZG90IiBpZD0iY2QiPjwvaT48c3BhbiBpZD0iY3QiPmNvbm5lY3RpbmfigKY8L3NwYW4+PC9zcGFuPgogICAgPHNwYW4gY2xhc3M9InBpbGwiIGlkPSJ3aGVyZSI+4oCUPC9zcGFuPgogICAgPGEgY2xhc3M9InBpbGwiIGhyZWY9IiMiIGlkPSJvcGVubG9jYWwyIiBzdHlsZT0iZGlzcGxheTpub25lIj5oZWxwZXIncyBwYWdlPC9hPgogICAgPGEgY2xhc3M9InBpbGwiIGhyZWY9IiMiIGlkPSJzdGF5IiBzdHlsZT0iZGlzcGxheTpub25lIj5zdGF5IGhlcmU8L2E+CiAgPC9oZWFkZXI+CiAgPGRpdiBjbGFzcz0iaGFpcmxpbmUiPjwvZGl2PgoKICA8ZGl2IGNsYXNzPSJib2R5Ij4KICAgIDxzZWN0aW9uIGNsYXNzPSJ2aWV3IG9uIiBpZD0idmlld1BsYXkiPgogICAgICA8ZGl2IGNsYXNzPSJzcGxpdCI+CiAgICAgICAgPGRpdiBjbGFzcz0iY2FyZCBoZXJvIj4KICAgICAgICAgIDxkaXY+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9ImV5ZWJyb3ciIGlkPSJ2aWV3U3ViIj5yZWFsIE1pbmVjcmFmdCwga2VwdCBub3doZXJlPC9kaXY+CiAgICAgICAgICAgIDxoMSBjbGFzcz0iYmlnIiBpZD0idmVyc2lvbkJpZyI+MS4yMS4xMTwvaDE+CiAgICAgICAgICAgIDxwIGNsYXNzPSJsZWRlIj5UaGUgcmVhbCBKYXZhIGNsaWVudCB3aXRoIEZhYnJpYywgcnVubmluZyBvbiB0aGlzIGNvbXB1dGVyIGZyb20gb25lIGZvbGRlcgogICAgICAgICAgICAgIHVuZGVyIDxjb2RlPi90bXA8L2NvZGU+IHRoYXQgaXMgZGVsZXRlZCB0aGUgbW9tZW50IHlvdSBjbG9zZSBpdC4gWW91ciB3b3JsZCwgeW91ciBtb2RzIGFuZAogICAgICAgICAgICAgIHlvdXIgc2V0dGluZ3Mgc3RheSBpbiB0aGlzIGJyb3dzZXIg4oCUIG5vdGhpbmcgbmVzdHMgb24gdGhlIG1hY2hpbmUuPC9wPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJjaGlwcyI+CiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9ImNoaXAiIGlkPSJjaGlwUnVubmluZyI+aWRsZTwvc3Bhbj4KICAgICAgICAgICAgICA8c3BhbiBjbGFzcz0iY2hpcCIgaWQ9ImNoaXBNb2RzIj5ubyBtb2RzPC9zcGFuPgogICAgICAgICAgICAgIDxzcGFuIGNsYXNzPSJjaGlwIiBpZD0iY2hpcE1lbW9yeSI+Mkc8L3NwYW4+CiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9ImNoaXAiIGlkPSJjaGlwQXNzZXRzIj5hc3NldHM6IGRvd25sb2FkPC9zcGFuPgogICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgPGRpdiBjbGFzcz0iZmllbGRzIj4KICAgICAgICAgICAgICA8ZGl2PjxsYWJlbCBmb3I9InZlcnNpb24iPk1pbmVjcmFmdCB2ZXJzaW9uPC9sYWJlbD48c2VsZWN0IGlkPSJ2ZXJzaW9uIj48L3NlbGVjdD48L2Rpdj4KICAgICAgICAgICAgICA8ZGl2PjxsYWJlbCBmb3I9ImxvYWRlciI+TW9kIGxvYWRlcjwvbGFiZWw+CiAgICAgICAgICAgICAgICA8c2VsZWN0IGlkPSJsb2FkZXIiPgogICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPSJzdGFibGUiIHNlbGVjdGVkPkZhYnJpYyDigJQgbmV3ZXN0IHN0YWJsZTwvb3B0aW9uPgogICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPSJsYXRlc3QiPkZhYnJpYyDigJQgbmV3ZXN0PC9vcHRpb24+CiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ImN1c3RvbSI+RmFicmljIOKAlCBhIHNwZWNpZmljIHZlcnNpb27igKY8L29wdGlvbj4KICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT0ibm9uZSI+VmFuaWxsYSDigJQgbm8gRmFicmljPC9vcHRpb24+CiAgICAgICAgICAgICAgICA8L3NlbGVjdD4KICAgICAgICAgICAgICAgIDxpbnB1dCBpZD0ibG9hZGVyY3VzdG9tIiBwbGFjZWhvbGRlcj0iZS5nLiAwLjE5LjUiIHN0eWxlPSJkaXNwbGF5Om5vbmU7bWFyZ2luLXRvcDo4cHgiIC8+CiAgICAgICAgICAgICAgPC9kaXY+CiAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8ZGl2PgogICAgICAgICAgICA8YnV0dG9uIGNsYXNzPSJnbyIgaWQ9InBsYXkiIGRpc2FibGVkPlBMQVk8L2J1dHRvbj4KICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz0iaGFsdCIgaWQ9InN0b3AiIHN0eWxlPSJkaXNwbGF5Om5vbmUiPlNUT1A8L2J1dHRvbj4KICAgICAgICAgIDwvZGl2PgogICAgICAgIDwvZGl2PgoKICAgICAgICA8ZGl2IGNsYXNzPSJjYXJkIj4KICAgICAgICAgIDxkaXYgY2xhc3M9ImV5ZWJyb3ciPnRoaXMgbWFjaGluZTwvZGl2PgogICAgICAgICAgPHVsIGNsYXNzPSJmYWN0cyI+CiAgICAgICAgICAgIDxsaT48c3BhbiBjbGFzcz0iayI+SmF2YTwvc3Bhbj48c3BhbiBjbGFzcz0idiIgaWQ9ImZhY3RKYXZhIj5ub3QgbG9va2VkIGZvciB5ZXQ8L3NwYW4+PC9saT4KICAgICAgICAgICAgPGxpPjxzcGFuIGNsYXNzPSJrIj5TYW5kYm94PC9zcGFuPjxzcGFuIGNsYXNzPSJ2IiBpZD0iZmFjdFNhbmRib3giPuKAlDwvc3Bhbj4KICAgICAgICAgICAgICA8c3BhbiBjbGFzcz0icyIgaWQ9ImZhY3RTYW5kYm94U3ViIj5kZWxldGVkIHdoZW4gdGhlIHNlc3Npb24gZW5kczwvc3Bhbj48L2xpPgogICAgICAgICAgICA8bGk+PHNwYW4gY2xhc3M9ImsiPlN0b3JhZ2U8L3NwYW4+PHNwYW4gY2xhc3M9InYiIGlkPSJmYWN0U3RvcmFnZSI+4oCUPC9zcGFuPgogICAgICAgICAgICAgIDxzcGFuIGNsYXNzPSJzIiBpZD0iZmFjdFN0b3JhZ2VTdWIiPmluIHRoaXMgYnJvd3NlciwgbmV2ZXIgdXBsb2FkZWQ8L3NwYW4+PC9saT4KICAgICAgICAgICAgPGxpPjxzcGFuIGNsYXNzPSJrIj5TZXNzaW9uczwvc3Bhbj48c3BhbiBjbGFzcz0idiIgaWQ9ImZhY3RTZXNzaW9ucyI+bm9uZSB5ZXQ8L3NwYW4+CiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9InMiPm1vcmUgdGhhbiBvbmUgY2FuIHJ1biBhdCBvbmNlPC9zcGFuPjwvbGk+CiAgICAgICAgICA8L3VsPgogICAgICAgICAgPGRpdiBjbGFzcz0ibm90ZSIgaWQ9ImZhY3RKYXZhU3ViIiBzdHlsZT0ibWFyZ2luLXRvcDoxMnB4Ij48L2Rpdj4KICAgICAgICA8L2Rpdj4KICAgICAgPC9kaXY+CgogICAgICA8ZGl2IGNsYXNzPSJzdGF0dXMiPgogICAgICAgIDxkaXYgY2xhc3M9InN0YXR1c2xpbmUiPgogICAgICAgICAgPHN0cm9uZyBpZD0icGhhc2UiIHN0eWxlPSJjb2xvcjp2YXIoLS1pbmspO2ZvbnQtd2VpZ2h0OjYwMCI+UmVhZHk8L3N0cm9uZz4KICAgICAgICAgIDxzcGFuIGlkPSJpbnN0YW5jZSI+PC9zcGFuPgogICAgICAgICAgPHNwYW4gY2xhc3M9InJhaWwiIGlkPSJiYXIiPjxpPjwvaT48L3NwYW4+CiAgICAgICAgICA8c3BhbiBpZD0icGN0IiBzdHlsZT0ibWluLXdpZHRoOjdjaDt0ZXh0LWFsaWduOnJpZ2h0Ij48L3NwYW4+CiAgICAgICAgPC9kaXY+CiAgICAgICAgPGRpdiBjbGFzcz0ibm90ZSIgaWQ9Im5ldHN0YXQiIHN0eWxlPSJtYXJnaW4tdG9wOjEwcHgiPjwvZGl2PgogICAgICAgIDxkaXYgaWQ9Im5vdHJlYWR5IiBzdHlsZT0iZGlzcGxheTpub25lO21hcmdpbi10b3A6MTRweCI+PC9kaXY+CiAgICAgICAgPGRpdiBpZD0ib2ZmbGluZSIgc3R5bGU9ImRpc3BsYXk6bm9uZTttYXJnaW4tdG9wOjE2cHgiPgogICAgICAgICAgPGRpdiBjbGFzcz0iYmFkYm94IiBpZD0ib2ZmbGluZXRleHQiPjwvZGl2PgogICAgICAgICAgPGRpdiBpZD0ic2hvcnRjdXRib3giIHN0eWxlPSJkaXNwbGF5Om5vbmUiPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJub3RlIiBzdHlsZT0iY29sb3I6dmFyKC0taW5rKTttYXJnaW4tdG9wOjE2cHgiPgogICAgICAgICAgICAgIDxiPm1hY09TOiBzdGFydCB0aGUgaGVscGVyIGZvciBtZS48L2I+IFRoZSBTaG9ydGN1dCBmZXRjaGVzIGl0IGludG8gPGNvZGU+L3RtcDwvY29kZT4sIHJ1bnMKICAgICAgICAgICAgICBpdCB0aGVyZSwgYW5kIHdoZW4gdGhlIHNlc3Npb24gZW5kcyB0aGUgaGVscGVyIGRlbGV0ZXMgaXRzZWxmIGFuZCBpdHMgZm9sZGVyLiBOb3RoaW5nIGlzCiAgICAgICAgICAgICAgaW5zdGFsbGVkLCBhbmQgbm90aGluZyBzdXJ2aXZlcy4KICAgICAgICAgICAgPC9kaXY+CiAgICAgICAgICAgIDxidXR0b24gaWQ9ImtpY2toZWxwZXIiIHN0eWxlPSJtYXJnaW4tdG9wOjExcHgiPlN0YXJ0IHRoZSBoZWxwZXIgZm9yIG1lPC9idXR0b24+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9Im5vdGUiIGlkPSJraWNrcyIgc3R5bGU9Im1hcmdpbi10b3A6OXB4Ij48L2Rpdj4KICAgICAgICAgICAgPGRldGFpbHMgc3R5bGU9Im1hcmdpbi10b3A6MTRweCI+CiAgICAgICAgICAgICAgPHN1bW1hcnkgY2xhc3M9Im5vdGUiIHN0eWxlPSJjdXJzb3I6cG9pbnRlciI+T25lLXRpbWU6IG1ha2UgdGhhdCBTaG9ydGN1dCAoNCBzdGVwcyk8L3N1bW1hcnk+CiAgICAgICAgICAgICAgPG9sIGNsYXNzPSJzdGVwcyI+CiAgICAgICAgICAgICAgICA8bGk+T3BlbiA8Yj5TaG9ydGN1dHM8L2I+LCBwcmVzcyA8Yj4rPC9iPi48L2xpPgogICAgICAgICAgICAgICAgPGxpPkFkZCB0aGUgYWN0aW9uIDxiPlJ1biBTaGVsbCBTY3JpcHQ8L2I+LjwvbGk+CiAgICAgICAgICAgICAgICA8bGk+U2V0IDxiPlBhc3MgSW5wdXQ8L2I+IHRvIDxiPnRvIHN0ZGluPC9iPiwgcGFzdGUgdGhpczo8L2xpPgogICAgICAgICAgICAgIDwvb2w+CiAgICAgICAgICAgICAgPGNvZGUgaWQ9InNoZWxsbGluZSIgc3R5bGU9ImRpc3BsYXk6YmxvY2s7cGFkZGluZzoxMXB4O21hcmdpbi10b3A6OHB4O3doaXRlLXNwYWNlOnByZS13cmFwO3dvcmQtYnJlYWs6YnJlYWstYWxsIj48L2NvZGU+CiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz0idGlueSIgaWQ9ImNvcHlsaW5lIiBzdHlsZT0ibWFyZ2luLXRvcDoxMHB4Ij5Db3B5IHRoZSBsaW5lPC9idXR0b24+CiAgICAgICAgICAgICAgPGRpdiBjbGFzcz0ibm90ZSIgaWQ9ImNvcHlvayIgc3R5bGU9Im1hcmdpbi10b3A6OHB4Ij48L2Rpdj4KICAgICAgICAgICAgICA8b2wgY2xhc3M9InN0ZXBzIiBzdGFydD0iNCI+CiAgICAgICAgICAgICAgICA8bGk+TmFtZSBpdCBleGFjdGx5IDxiPldlYk1DIEhlbHBlcjwvYj4gYW5kIHNhdmUuCiAgICAgICAgICAgICAgICAgIDxiPlNob3J0Y3V0cyDihpIgU2V0dGluZ3Mg4oaSIEFkdmFuY2VkIOKGkiBBbGxvdyBSdW5uaW5nIFNjcmlwdHM8L2I+IG9uY2UuPC9saT4KICAgICAgICAgICAgICA8L29sPgogICAgICAgICAgICA8L2RldGFpbHM+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDxkaXYgaWQ9ImdldGhlbHBlciIgc3R5bGU9ImRpc3BsYXk6bm9uZSI+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9Im5vdGUiIHN0eWxlPSJjb2xvcjp2YXIoLS1pbmspO21hcmdpbi10b3A6MTZweCI+PGI+U3RhcnQgaXQgb25jZSDigJQgbm8gdGVybWluYWwsCiAgICAgICAgICAgICAgbm8gdHlwaW5nLjwvYj4gT24gYSBNYWMsIGRvd25sb2FkIHRoaXMgYW5kIGRvdWJsZS1jbGljayBpdCBpbiBEb3dubG9hZHMsIGFuZCB5b3UgYXJlIGRvbmU6CiAgICAgICAgICAgICAgaXQgaW5zdGFsbHMgdHdvIHNtYWxsIGZpbGVzIGFuZCBvbmUgbG9naW4gaXRlbSwgc28gZnJvbSB0aGVuIG9uIGl0IGlzIHNpbXBseSBhbHdheXMgdGhlcmUuCiAgICAgICAgICAgICAgSXQgY29tZXMgYmFjayBieSBpdHNlbGYgaWYgaXQgZXZlciBzdG9wcywgYW5kIDxiPkxlYXZlIG5vdGhpbmc8L2I+IHJlbW92ZXMgYWxsIG9mIGl0IGFnYWluLjwvZGl2PgogICAgICAgICAgICA8ZGl2IHN0eWxlPSJtYXJnaW4tdG9wOjEycHg7ZGlzcGxheTpmbGV4O2dhcDoxMXB4O2ZsZXgtd3JhcDp3cmFwO2FsaWduLWl0ZW1zOmNlbnRlciI+CiAgICAgICAgICAgICAgPGEgaWQ9ImFwcGRsIiBocmVmPSJoZWxwZXIvV2ViTUMtSGVscGVyLW1hYy56aXAiIGRvd25sb2FkCiAgICAgICAgICAgICAgICAgc3R5bGU9ImRpc3BsYXk6aW5saW5lLWZsZXg7YWxpZ24taXRlbXM6Y2VudGVyO2dhcDo5cHg7cGFkZGluZzoxMnB4IDE4cHg7Ym9yZGVyLXJhZGl1czoxMnB4OwogICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCgxMzVkZWcsdmFyKC0tbWludCksdmFyKC0tY3lhbikpO2NvbG9yOiMwNDE0MGM7CiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OjY1MCI+RG93bmxvYWQgV2ViTUMgSGVscGVyIChtYWNPUyk8L2E+CiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9Im5vdGUiPlRoZW4gZG91YmxlLWNsaWNrIHdoYXQgbGFuZHMgaW4gRG93bmxvYWRzLjwvc3Bhbj4KICAgICAgICAgICAgPC9kaXY+CiAgICAgICAgICAgIDxkZXRhaWxzIHN0eWxlPSJtYXJnaW4tdG9wOjE0cHgiPgogICAgICAgICAgICAgIDxzdW1tYXJ5IGNsYXNzPSJub3RlIiBzdHlsZT0iY3Vyc29yOnBvaW50ZXIiPldpbmRvd3MsIExpbnV4LCBvciB5b3Ugd291bGQgcmF0aGVyIHNlZSB0aGUgcGllY2VzPC9zdW1tYXJ5PgogICAgICAgICAgICAgIDxvbCBjbGFzcz0ic3RlcHMiPgogICAgICAgICAgICAgICAgPGxpPjxhIGlkPSJ6aXBkbCIgaHJlZj0iaGVscGVyL3dlYm1jLWhlbHBlci56aXAiIGRvd25sb2FkPkRvd25sb2FkIHdlYm1jLWhlbHBlci56aXA8L2E+IGFuZAogICAgICAgICAgICAgICAgICBkb3VibGUtY2xpY2sgaXQuPC9saT4KICAgICAgICAgICAgICAgIDxsaT5Eb3VibGUtY2xpY2sgPGNvZGU+d2VibWMtaGVscGVyLmNvbW1hbmQ8L2NvZGU+OiBpdCBpbnN0YWxscyBpdHNlbGYgYW5kIHN0YXJ0cyBhdCBldmVyeQogICAgICAgICAgICAgICAgICBsb2dpbi4gVGhpcyBvbmUgZG9lcyBvcGVuIGEgVGVybWluYWwgd2luZG93IHdoaWxlIGl0IHdvcmtzLjwvbGk+CiAgICAgICAgICAgICAgICA8bGk+Q29tZSBiYWNrIGFuZCBwcmVzcyBQTEFZLjwvbGk+CiAgICAgICAgICAgICAgPC9vbD4KICAgICAgICAgICAgPC9kZXRhaWxzPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJub3RlIiBzdHlsZT0ibWFyZ2luLXRvcDoxMHB4Ij5BbHJlYWR5IHJ1bm5pbmc/CiAgICAgICAgICAgICAgPGEgaHJlZj0iIyIgaWQ9Im9wZW5sb2NhbCI+T3BlbiB0aGUgaGVscGVyJ3MgcGFnZTwvYT4uPC9kaXY+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICA8L2Rpdj4KICAgICAgPC9kaXY+CiAgICA8L3NlY3Rpb24+CgogICAgPHNlY3Rpb24gY2xhc3M9InZpZXciIGlkPSJ2aWV3TW9kcyI+CiAgICAgIDxkaXYgY2xhc3M9ImNvbHMiPgogICAgICAgIDxkaXYgY2xhc3M9ImNhcmQiPgogICAgICAgICAgPGRpdiBjbGFzcz0iZXllYnJvdyI+eW91ciBtb2RzPHNwYW4gaWQ9Im1vZGNvdW50IiBjbGFzcz0idGFnIiBzdHlsZT0ibWFyZ2luLWxlZnQ6MTBweCI+PC9zcGFuPjwvZGl2PgogICAgICAgICAgPGRpdiBjbGFzcz0iZHJvcCIgaWQ9ImRyb3AiIHN0eWxlPSJtYXJnaW4tdG9wOjE2cHgiPgogICAgICAgICAgICA8Yj5Ecm9wIG1vZCAuamFyIGZpbGVzIGhlcmU8L2I+PGJyIC8+b3IgY2xpY2sgdG8gY2hvb3NlIHRoZW0KICAgICAgICAgICAgPGRpdiBjbGFzcz0ibm90ZSIgc3R5bGU9Im1hcmdpbi10b3A6OHB4Ij5LZXB0IGluIHRoaXMgYnJvd3NlciwgbmV2ZXIgb24gdGhlIGNvbXB1dGVyLCBhbmQKICAgICAgICAgICAgICBoYW5kZWQgdG8gdGhlIGhlbHBlciBiZWZvcmUgZWFjaCBsYXVuY2guPC9kaXY+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDxpbnB1dCB0eXBlPSJmaWxlIiBpZD0icGlja2VyIiBhY2NlcHQ9Ii5qYXIiIG11bHRpcGxlIHN0eWxlPSJkaXNwbGF5Om5vbmUiIC8+CiAgICAgICAgICA8dWwgY2xhc3M9Im1vZHMiIGlkPSJtb2RsaXN0Ij48L3VsPgogICAgICAgICAgPGRpdiBjbGFzcz0ibm90ZSIgaWQ9Im1vZGhpbnQiPjwvZGl2PgogICAgICAgIDwvZGl2PgogICAgICAgIDxkaXYgY2xhc3M9ImNhcmQiPgogICAgICAgICAgPGRpdiBjbGFzcz0iZXllYnJvdyI+ZnJvbSBNb2RyaW50aDwvZGl2PgogICAgICAgICAgPGRpdiBzdHlsZT0iZGlzcGxheTpmbGV4O2dhcDoxMHB4O21hcmdpbi10b3A6MTZweCI+CiAgICAgICAgICAgIDxpbnB1dCBpZD0ic2VhcmNoIiBwbGFjZWhvbGRlcj0ic29kaXVtLCBsaXRoaXVtLCBpcmlz4oCmIiAvPgogICAgICAgICAgICA8YnV0dG9uIGlkPSJkb2JzZWFyY2giPlNlYXJjaDwvYnV0dG9uPgogICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8dWwgY2xhc3M9InJlc3VsdHMiIGlkPSJyZXN1bHRzIj48L3VsPgogICAgICAgICAgPGRpdiBjbGFzcz0ibm90ZSIgaWQ9InNlYXJjaGhpbnQiIHN0eWxlPSJtYXJnaW4tdG9wOjEycHgiPlNlYXJjaGVkIGJ5IHRoZSBoZWxwZXIsIHNvIGl0IHdvcmtzCiAgICAgICAgICAgIGV2ZW4gb24gYSBuZXR3b3JrIHdoZXJlIHRoaXMgYnJvd3NlciBjYW5ub3QgcmVhY2ggTW9kcmludGguPC9kaXY+CiAgICAgICAgPC9kaXY+CiAgICAgIDwvZGl2PgogICAgPC9zZWN0aW9uPgoKICAgIDxzZWN0aW9uIGNsYXNzPSJ2aWV3IiBpZD0idmlld1NldHRpbmdzIj4KICAgICAgPGRpdiBjbGFzcz0ic3RhY2siPgogICAgICAgIDxkaXYgY2xhc3M9ImNhcmQiPgogICAgICAgICAgPGRpdiBjbGFzcz0iZXllYnJvdyI+dGhlIGdhbWU8L2Rpdj4KICAgICAgICAgIDxkaXYgY2xhc3M9InJvd2xpbmUiIHN0eWxlPSJtYXJnaW4tdG9wOjhweCI+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9InJsIj48Yj5Vc2VybmFtZTwvYj48c3Bhbj5PZmZsaW5lIG5hbWUsIGFzIHNlcnZlcnMgYWNjZXB0IGl0PC9zcGFuPjwvZGl2PgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJyYyB3aWRlIj48aW5wdXQgaWQ9InVzZXJuYW1lIiB2YWx1ZT0iUGxheWVyIiBtYXhsZW5ndGg9IjE2IiAvPjwvZGl2PgogICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJyb3dsaW5lIj4KICAgICAgICAgICAgPGRpdiBjbGFzcz0icmwiPjxiPk1lbW9yeTwvYj48c3Bhbj5Ib3cgbXVjaCB0aGUgZ2FtZSBtYXkgdXNlPC9zcGFuPjwvZGl2PgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJyYyB3aWRlIj48aW5wdXQgaWQ9Im1lbW9yeSIgdmFsdWU9IjJHIiAvPjwvZGl2PgogICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJyb3dsaW5lIj4KICAgICAgICAgICAgPGRpdiBjbGFzcz0icmwiPjxiPlNvdW5kcyBhbmQgdGV4dHVyZXM8L2I+CiAgICAgICAgICAgICAgPHNwYW4+NDMwIE1CIG9mIGFzc2V0czsgdGhleSBtYWtlIHRoZSBnYW1lIGxvb2sgYW5kIHNvdW5kIGxpa2UgaXRzZWxmPC9zcGFuPjwvZGl2PgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJyYyB3aWRlIj48c2VsZWN0IGlkPSJhc3NldHMiPgogICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9IjEiIHNlbGVjdGVkPkRvd25sb2FkIHRoZW0gKH40MzAgTUIsIG9uY2UgYSBzZXNzaW9uKTwvb3B0aW9uPgogICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9IjAiPlNraXAgdGhlbSDigJQgZmFzdCwgYW5kIHRoZSBnYW1lIHdpbGwgbG9vayBicm9rZW48L29wdGlvbj4KICAgICAgICAgICAgPC9zZWxlY3Q+PC9kaXY+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDxkaXYgY2xhc3M9InJvd2xpbmUiPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJybCI+PGI+UHV0IHRoaXMgYnJvd3NlcidzIGxhc3Qgc2Vzc2lvbiBiYWNrPC9iPgogICAgICAgICAgICAgIDxzcGFuPldvcmxkcywgb3B0aW9ucyBhbmQgc2NyZWVuc2hvdHMgbGl2ZSBpbiB0aGlzIGJyb3dzZXIuIE5vdGhpbmcgaXMgdXBsb2FkZWQuPC9zcGFuPjwvZGl2PgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJyYyI+PGlucHV0IHR5cGU9ImNoZWNrYm94IiBpZD0icmVzdG9yZSIgY2hlY2tlZCAvPjwvZGl2PgogICAgICAgICAgPC9kaXY+CiAgICAgICAgPC9kaXY+CgogICAgICAgIDxkaXYgY2xhc3M9ImNhcmQiPgogICAgICAgICAgPGRpdiBjbGFzcz0iZXllYnJvdyI+YXBwZWFyYW5jZTwvZGl2PgogICAgICAgICAgPGRpdiBjbGFzcz0icm93bGluZSIgc3R5bGU9Im1hcmdpbi10b3A6OHB4Ij4KICAgICAgICAgICAgPGRpdiBjbGFzcz0icmwiPjxiPlNjcmVlbiBlZmZlY3Q8L2I+PHNwYW4+VGhlIGxheWVyIG92ZXIgdGhlIHdob2xlIHdpbmRvdzwvc3Bhbj48L2Rpdj4KICAgICAgICAgICAgPGRpdiBjbGFzcz0icmMgd2lkZSI+PHNlbGVjdCBpZD0iZnhTZWxlY3QiPgogICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ImZ4LWdsb3ciPkRlcHRoIOKAlCBhIHNvZnQgdmlnbmV0dGU8L29wdGlvbj4KICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPSJmeC1ncmlkIj5HcmlkIOKAlCBhIGZhaW50IGxhdHRpY2U8L29wdGlvbj4KICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPSJmeC1zY2FuIj5TY2FubGluZXMg4oCUIGEgc2xvdyBzd2VlcDwvb3B0aW9uPgogICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9Im5vbmUiPk5vbmUg4oCUIGZsYXQgYW5kIGZhc3Q8L29wdGlvbj4KICAgICAgICAgICAgPC9zZWxlY3Q+PC9kaXY+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDxkaXYgY2xhc3M9InJvd2xpbmUiPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJybCI+PGI+QmFja2dyb3VuZDwvYj48c3Bhbj5Ud28gYmxvYnMsIGRyaWZ0aW5nIHNsb3dseTwvc3Bhbj48L2Rpdj4KICAgICAgICAgICAgPGRpdiBjbGFzcz0icmMgd2lkZSI+PHNlbGVjdCBpZD0ibW90aW9uU2VsZWN0Ij4KICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPSJmb2xsb3ciPkZvbGxvd3MgdGhlIHBvaW50ZXI8L29wdGlvbj4KICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPSJzdGlsbCI+U3RpbGw8L29wdGlvbj4KICAgICAgICAgICAgPC9zZWxlY3Q+PC9kaXY+CiAgICAgICAgICA8L2Rpdj4KICAgICAgICA8L2Rpdj4KCiAgICAgICAgPGRpdiBjbGFzcz0iY2FyZCI+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJleWVicm93Ij5pZiBhIG5ldHdvcmsgYmxvY2tzIHRoaW5nczwvZGl2PgogICAgICAgICAgPHAgY2xhc3M9Im5vdGUiIHN0eWxlPSJtYXJnaW46MTJweCAwIDRweCI+CiAgICAgICAgICAgIDxiIHN0eWxlPSJjb2xvcjp2YXIoLS1pbmspIj5PbmUgc2V0dGluZywgZXZlcnl0aGluZyB1c2VzIGl0LjwvYj4gV2hlbiBhIHJlbGF5IGlzIGluIHBsYXkgaXQKICAgICAgICAgICAgY2FycmllcyB0aGUgZG93bmxvYWRzIDxpPmFuZDwvaT4gdGhlIGdhbWUncyBvd24gY29ubmVjdGlvbnMg4oCUIGpvaW5pbmcsIGF1dGhlbnRpY2F0aW5nLCBza2lucy4KICAgICAgICAgICAgQ2hvb3NlIDxiPk5ldmVyPC9iPiB0byBvcHQgb3V0IGNvbXBsZXRlbHkuCiAgICAgICAgICA8L3A+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJyb3dsaW5lIj4KICAgICAgICAgICAgPGRpdiBjbGFzcz0icmwiPjxiPlJlbGF5PC9iPjxzcGFuIGlkPSJyZWxheUluVXNlIj7igJQ8L3NwYW4+PC9kaXY+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9InJjIHdpZGUiPjxzZWxlY3QgaWQ9InJlbGF5TW9kZSI+CiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT0iYXV0byIgc2VsZWN0ZWQ+QXV0b21hdGljIOKAlCB1c2UgdGhlIGJ1aWx0LWluIG9uZSBpZiB0aGVyZSBpcyBvbmU8L29wdGlvbj4KICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPSJvZmYiPk5ldmVyIOKAlCBjb25uZWN0IGRpcmVjdGx5LCBldmVuIGlmIGEgbmV0d29yayBibG9ja3MgaXQ8L29wdGlvbj4KICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPSJjdXN0b20iPk15IG93biByZWxheeKApjwvb3B0aW9uPgogICAgICAgICAgICA8L3NlbGVjdD48L2Rpdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgICAgPGRpdiBjbGFzcz0icm93bGluZSIgaWQ9InJlbGF5Q3VzdG9tUm93IiBzdHlsZT0iZGlzcGxheTpub25lIj4KICAgICAgICAgICAgPGRpdiBjbGFzcz0icmwiPjxiPllvdXIgcmVsYXkncyBhZGRyZXNzPC9iPjxzcGFuPkFueW9uZSBjYW4gcnVuIG9uZTsgc2VlIERvY3VtZW50YXRpb248L3NwYW4+PC9kaXY+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9InJjIHdpZGUiPjxpbnB1dCBpZD0icmVsYXkiIHBsYWNlaG9sZGVyPSJodHRwczovL3dlYm1jLXJlbGF5LnlvdS53b3JrZXJzLmRldiIgLz48L2Rpdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgICAgPGRpdiBjbGFzcz0icm93bGluZSI+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9InJsIj48Yj5Kb2luIHRoaXMgc2VydmVyIHN0cmFpZ2h0IGF3YXk8L2I+CiAgICAgICAgICAgICAgPHNwYW4+U1JWIHJlY29yZHMgYXJlIGZvbGxvd2VkLiBPcHRpb25hbC48L3NwYW4+PC9kaXY+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9InJjIHdpZGUiPjxpbnB1dCBpZD0ic2VydmVyIiBwbGFjZWhvbGRlcj0icGxheS5leGFtcGxlLm5ldDoyNTU2NSIgLz48L2Rpdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgICAgPGRpdiBjbGFzcz0icm93bGluZSI+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9InJsIj48Yj5DaGVjayBpdDwvYj48c3BhbiBpZD0icmVsYXlTdGF0ZSI+Tm90aGluZyB0ZXN0ZWQgeWV0Ljwvc3Bhbj48L2Rpdj4KICAgICAgICAgICAgPGRpdiBjbGFzcz0icmMiPjxidXR0b24gaWQ9InJlbGF5VGVzdCI+VGVzdCB0aGUgcmVsYXk8L2J1dHRvbj48L2Rpdj4KICAgICAgICAgIDwvZGl2PgogICAgICAgIDwvZGl2PgoKICAgICAgICA8ZGl2IGNsYXNzPSJjYXJkIj4KICAgICAgICAgIDxkaXYgY2xhc3M9ImV5ZWJyb3ciPnRoZSBoZWxwZXIgb24gdGhpcyBtYWNoaW5lPC9kaXY+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJyb3dsaW5lIiBzdHlsZT0ibWFyZ2luLXRvcDo4cHgiPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJybCI+PGI+QWRkcmVzczwvYj48c3BhbiBpZD0iY29ubmhpbnQiPuKAlDwvc3Bhbj48L2Rpdj4KICAgICAgICAgICAgPGRpdiBjbGFzcz0icmMgd2lkZSI+PGlucHV0IGlkPSJoZWxwZXIiIHBsYWNlaG9sZGVyPSJodHRwOi8vMTI3LjAuMC4xOjc2NDUiIC8+CiAgICAgICAgICAgICAgPGJ1dHRvbiBpZD0iY29ubmVjdCI+Q29ubmVjdDwvYnV0dG9uPjwvZGl2PgogICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJyb3dsaW5lIj4KICAgICAgICAgICAgPGRpdiBjbGFzcz0icmwiPjxiPldoYXQgaXMgb24gdGhpcyBtYWNoaW5lPC9iPjxzcGFuIGlkPSJtYWNoaW5lU3RhdGUiPmNoZWNraW5n4oCmPC9zcGFuPjwvZGl2PgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJyYyI+CiAgICAgICAgICAgICAgPGJ1dHRvbiBpZD0iY29weWRpYWciPkNvcHkgZGlhZ25vc3RpY3M8L2J1dHRvbj4KICAgICAgICAgICAgICA8YnV0dG9uIGlkPSJoZWxwIj5Ib3cgdGhpcyB3b3JrczwvYnV0dG9uPgogICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9ImRhbmdlciIgaWQ9InB1cmdlIj5MZWF2ZSBub3RoaW5nPC9idXR0b24+CiAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJub3RlIiBpZD0iZGlhZ3N0YXRlIiBzdHlsZT0ibWFyZ2luLXRvcDoxMHB4Ij48L2Rpdj4KICAgICAgICAgIDxkaXYgY2xhc3M9Im5vdGUiIGlkPSJwdXJnZVN0YXRlIiBzdHlsZT0ibWFyZ2luLXRvcDo2cHgiPjwvZGl2PgogICAgICAgIDwvZGl2PgogICAgICA8L2Rpdj4KICAgIDwvc2VjdGlvbj4KCiAgICA8c2VjdGlvbiBjbGFzcz0idmlldyIgaWQ9InZpZXdEb2MiPgogICAgICA8ZGl2IGNsYXNzPSJkb2N3cmFwIj4KICAgICAgICA8ZGl2IGNsYXNzPSJkb2MiPgogICAgICAgICAgPHAgY2xhc3M9ImxlYWQiPldlYk1DIGlzIGEgTWluZWNyYWZ0IGxhdW5jaGVyIHdob3NlIGludGVyZmFjZSBpcyBhIHdlYiBwYWdlLCBhbmQgd2hvc2UgcHJvbWlzZQogICAgICAgICAgICBpcyB0aGF0IHRoZSBjb21wdXRlciBpdCBydW5zIG9uIGlzIGJvcnJvd2VkIHJhdGhlciB0aGFuIHVzZWQ6IHRoZSBnYW1lLCB0aGUgSmF2YSBydW50aW1lCiAgICAgICAgICAgIGFuZCB0aGUgaGVscGVyIGFyZSBhbGwgZGVsZXRlZCB3aGVuIHRoZSBzZXNzaW9uIGVuZHMuPC9wPgogICAgICAgICAgPGgzIGlkPSJkMSI+V2h5IHRoZSBwYWdlIGNhbm5vdCBsYXVuY2ggYW55dGhpbmc8L2gzPgogICAgICAgICAgPHA+QSB3ZWIgcGFnZSBjYW5ub3Qgc3RhcnQgYSBwcm9ncmFtLCByZWFkIGEgZmlsZSwgb3IgbG9vayBpbnNpZGUgPGNvZGU+L3RtcDwvY29kZT4uIFRoZXJlIGlzCiAgICAgICAgICAgIG5vIEFQSSBmb3IgaXQ6IFdlYkFzc2VtYmx5IGFuZCBhbiBpbi1wYWdlIEpWTSBhcmUgc2FuZGJveGVkLCA8Y29kZT5maWxlOi8vPC9jb2RlPiBnaXZlcyBhbgogICAgICAgICAgICBvcGFxdWUgb3JpZ2luIHRoYXQgY2Fubm90IGV2ZW4gcmVhY2ggPGNvZGU+MTI3LjAuMC4xPC9jb2RlPiwgYSBjdXN0b20gcHJvdG9jb2wgaGFuZGxlciBhbmQgYQogICAgICAgICAgICBicm93c2VyIGV4dGVuc2lvbiBib3RoIG5lZWQgYW4gaW5zdGFsbGVyIGZpcnN0LCBhbmQgYSBwYWdlIGhhcyBuZXZlciBiZWVuIGFsbG93ZWQgdG8gcnVuIGEKICAgICAgICAgICAgZmlsZSBpdCBkb3dubG9hZGVkLjwvcD4KICAgICAgICAgIDxwPlRoYXQgaXMgbm90IGFuIG92ZXJzaWdodC4gVGhlIGZlYXR1cmVzIHRoYXQgb25jZSBkaWQgYWxsb3cgaXQg4oCUIEFjdGl2ZVggY29udHJvbHMsIEphdmEKICAgICAgICAgICAgYXBwbGV0cywgTmV0c2NhcGUgcGx1Z2lucywgRmxhc2gg4oCUIHdlcmUgYWxsIHJlbW92ZWQgcHJlY2lzZWx5IGJlY2F1c2UgYSBwYWdlIGJlaW5nIGFibGUgdG8KICAgICAgICAgICAgcnVuIG5hdGl2ZSBjb2RlIGlzIGEgc2VjdXJpdHkgaG9sZSByYXRoZXIgdGhhbiBhIGZlYXR1cmUuPC9wPgogICAgICAgICAgPHA+TG9jYWwgTmV0d29yayBBY2Nlc3MsIGluIGN1cnJlbnQgQ2hyb21pdW0sIG1ha2VzIHRoZSBib3VuZGFyeSBleHBsaWNpdC4gTWVhc3VyZWQgZnJvbSBhCiAgICAgICAgICAgIHB1YmxpYyBwYWdlICh0aGlzIGxhdW5jaGVyIG9uIEdpdEh1YiBQYWdlcykgdG8gdGhlIGhlbHBlciBvbiA8Y29kZT4xMjcuMC4wLjE8L2NvZGU+OjwvcD4KICAgICAgICAgIDx0YWJsZT4KICAgICAgICAgICAgPHRyPjx0aD5Sb3V0ZTwvdGg+PHRoPlJlc3VsdDwvdGg+PC90cj4KICAgICAgICAgICAgPHRyPjx0ZD48Y29kZT5mZXRjaCgpPC9jb2RlPjwvdGQ+PHRkPlJlZnVzZWQsIG9yIGEgcGVybWlzc2lvbiBwcm9tcHQg4oCUIOKAnFBlcm1pc3Npb24gd2FzIGRlbmllZAogICAgICAgICAgICAgIGZvciB0aGlzIHJlcXVlc3QgdG8gYWNjZXNzIHRoZSA8Y29kZT5sb29wYmFjazwvY29kZT4gYWRkcmVzcyBzcGFjZS7igJ08L3RkPjwvdHI+CiAgICAgICAgICAgIDx0cj48dGQ+YW4gPGNvZGU+Jmx0O2lmcmFtZSZndDs8L2NvZGU+PC90ZD48dGQ+UmVmdXNlZDogdGhlIGZyYW1lIHRyZWUgY29tZXMgYmFjayB3aXRoIG5vIGNoaWxkCiAgICAgICAgICAgICAgZnJhbWUgYXQgYWxsLiBBIGJsb2NrZWQgZnJhbWUgc3RpbGwgZmlyZXMgPGNvZGU+bG9hZDwvY29kZT4sIHNvIHRoYXQgZXZlbnQgcHJvdmVzIG5vdGhpbmcuPC90ZD48L3RyPgogICAgICAgICAgICA8dHI+PHRkPmEgdG9wLWxldmVsIG5hdmlnYXRpb248L3RkPjx0ZD48Yj5BbGxvd2VkPC9iPiwgd2l0aCBubyBwcm9tcHQgYW5kIG5vIGNvbnNvbGUgZXJyb3IuPC90ZD48L3RyPgogICAgICAgICAgPC90YWJsZT4KICAgICAgICAgIDxwPlR3byB0aGluZ3MgYXJlIHdvcnRoIHRlbGxpbmcgYW4gYWRtaW5pc3RyYXRvciwgYmVjYXVzZSB0aGV5IGRlY2lkZSB3aGV0aGVyIGFueSBvZiB0aGlzIHdvcmtzCiAgICAgICAgICAgIG9uIGEgbWFuYWdlZCBtYWNoaW5lOiB0aGUgcGVybWlzc2lvbiBpcyBjYWxsZWQgPGI+TG9jYWwgTmV0d29yayBBY2Nlc3M8L2I+IGluIENocm9taXVtJ3Mgc2l0ZQogICAgICAgICAgICBzZXR0aW5ncywgYW5kIG9uZSBwb2xpY3kgY2FuIHJlZnVzZSBpdCBvdXRyaWdodCDigJQgPGNvZGU+TG9jYWxOZXR3b3JrQWNjZXNzQmxvY2tlZEZvclVybHM8L2NvZGU+LgogICAgICAgICAgICBXaGVyZSB0aGF0IHBvbGljeSBpcyBzZXQsIG5vdGhpbmcgb24gYSBwYWdlIGNhbiByZWFjaCBhIGxvY2FsIGhlbHBlciBhdCBhbGwsIGFuZCB0aGUgaGVscGVyJ3MKICAgICAgICAgICAgb3duIHBhZ2UgaXMgdGhlIG9ubHkgcm91dGUgbGVmdC48L3A+CiAgICAgICAgICA8cD5UaGF0IGxhc3Qgcm93IGlzIHdoeSB0aGlzIGxhdW5jaGVyIGJlaGF2ZXMgdGhlIHdheSBpdCBkb2VzOiB0aGUgR2l0SHViIHBhZ2UgY2Fubm90CiAgICAgICAgICAgIDxpPmRyaXZlPC9pPiB0aGUgaGVscGVyLCBzbyBpdCBoYW5kcyB0aGUgdGFiIHRvIHRoZSBoZWxwZXIncyBvd24gcGFnZSB0aGUgbW9tZW50IGl0IGxvYWRzLAogICAgICAgICAgICB3aGljaCBpcyBhbGxvd2VkIHRvIHRhbGsgdG8gaXQg4oCUIHNhbWUgb3JpZ2luLCBubyBwcm9tcHQuPC9wPgoKICAgICAgICAgIDxoMyBpZD0iZDIiPldoYXQgdGhlIGhlbHBlciBkb2VzLCBzdGVwIGJ5IHN0ZXA8L2gzPgogICAgICAgICAgPG9sPgogICAgICAgICAgICA8bGk+PGI+T25lIHN0YWdpbmcgZGlyZWN0b3J5LjwvYj4gRXZlcnl0aGluZyBnb2VzIHRoZXJlIGFuZCBub3doZXJlIGVsc2U6IGEgUHl0aG9uIHJ1bnRpbWUgaWYKICAgICAgICAgICAgICB0aGUgbWFjaGluZSBoYXMgbm9uZSwgdGhlIGhlbHBlciwgYW5kIGxhdGVyIHRoZSBnYW1lLjwvbGk+CiAgICAgICAgICAgIDxsaT48Yj5BIEphdmEgcnVudGltZSwgZm91bmQgb3IgZmV0Y2hlZC48L2I+IFRoZSB2ZXJzaW9uJ3Mgb3duIG1ldGFkYXRhIHNheXMgd2hpY2ggSmF2YSBpdAogICAgICAgICAgICAgIG5lZWRzICg8Y29kZT5qYXZhVmVyc2lvbi5tYWpvclZlcnNpb248L2NvZGU+KSwgYW5kIGlmIHRoaXMgbWFjaGluZSBoYXMgbm90aGluZyBzdWl0YWJsZSB0aGUKICAgICAgICAgICAgICBydW50aW1lIGlzIGZldGNoZWQgaW50byB0aGUgc3RhZ2luZyBkaXJlY3RvcnkgYW5kIGRpZXMgd2l0aCBpdC48L2xpPgogICAgICAgICAgICA8bGk+PGI+VGhlIGdhbWUsIGZyb20gTW9qYW5nLjwvYj4gQ2xpZW50LCB0aGUgdmVyc2lvbidzIG93biBsaWJyYXJpZXMgYW5kIHRoZSBhc3NldHMsIGV2ZXJ5CiAgICAgICAgICAgICAgZmlsZSB2ZXJpZmllZCBhZ2FpbnN0IGl0cyBwdWJsaXNoZWQgU0hBLTEsIGRvd25sb2FkZWQgaW4gcGFyYWxsZWwuPC9saT4KICAgICAgICAgICAgPGxpPjxiPlRoZSBsb2FkZXIgYW5kIHlvdXIgbW9kcy48L2I+IEZhYnJpYydzIHByb2ZpbGUgZnJvbSBGYWJyaWMncyBvd24gbWV0YWRhdGE7IHlvdXIgamFycwogICAgICAgICAgICAgIGZyb20gdGhpcyBicm93c2VyJ3Mgc3RvcmFnZSwgb3IgZmV0Y2hlZCBmcm9tIE1vZHJpbnRoIGZvciB0aGUgdmVyc2lvbiB5b3UgcGlja2VkLjwvbGk+CiAgICAgICAgICAgIDxsaT48Yj5UaGUgcmVhbCBjbGllbnQgc3RhcnRzLjwvYj4gQW4gb3JkaW5hcnkgPGNvZGU+amF2YSDigKZLbm90Q2xpZW50PC9jb2RlPiBwcm9jZXNzLCB3aXRoIGEKICAgICAgICAgICAgICBub3JtYWwgd2luZG93LCBleGFjdGx5IGFzIGFueSBsYXVuY2hlciB3b3VsZCBydW4gaXQuPC9saT4KICAgICAgICAgICAgPGxpPjxiPllvdSB3YXRjaCBpdCBoZXJlLjwvYj4gVGhlIGNsaWVudCdzIG93biBvdXRwdXQsIHN0cmVhbWVkIGxpdmUgaW50byB0aGUgbG9nIGF0IHRoZQogICAgICAgICAgICAgIGJvdHRvbSBvZiB0aGUgd2luZG93IOKAlCB3aGljaCBpcyB3aHkgYSBjcmFzaCBpcyByZWFkYWJsZSBpbnN0ZWFkIG9mIG15c3RlcmlvdXMuPC9saT4KICAgICAgICAgICAgPGxpPjxiPldoZW4gaXQgZXhpdHM8L2I+IOKAlCBjbG9zZWQsIGNyYXNoZWQsIG9yIHN0b3BwZWQgZnJvbSBoZXJlIOKAlCB0aGUgaGVscGVyIGNvbGxlY3RzIHNhdmVzLAogICAgICAgICAgICAgIGxvZ3MsIHNjcmVlbnNob3RzLCBjb25maWd1cmF0aW9uIGFuZCBjcmFzaCByZXBvcnRzIGludG8gb25lIHppcC48L2xpPgogICAgICAgICAgICA8bGk+PGI+VGhpcyBwYWdlIHRha2VzIHRoYXQgemlwPC9iPiBpbnRvIGJyb3dzZXIgc3RvcmFnZSwgYW5kIHRlbGxzIHRoZSBoZWxwZXIgdG8gZGVsZXRlIHRoZQogICAgICAgICAgICAgIHNhbmRib3guIE5vYm9keSBoYXMgdG8gcHJlc3MgYW55dGhpbmc6IHNhdmluZyBpcyBhdXRvbWF0aWMuPC9saT4KICAgICAgICAgICAgPGxpPjxiPk5vdGhpbmcgaXMgbGVmdCBmb3IgeW91IHRvIHRpZHkgdXAuPC9iPiBJZiB0aGUgcGFnZSBuZXZlciBjb21lcyBiYWNrIHRoZSBoZWxwZXIKICAgICAgICAgICAgICBkZWxldGVzIHRoZSBzYW5kYm94IGl0c2VsZiBhZnRlciBhIGRlYWRsaW5lOyBpZiB0aGUgaGVscGVyIGlzIGtpbGxlZCBvdXRyaWdodCB0aGUgbmV4dCBvbmUKICAgICAgICAgICAgICBmaW5kcyB0aGUgbGVmdG92ZXIgYnkgaXRzIG93bmVyIGZpbGU7IGlmIHRoZSBtYWNoaW5lIHJlYm9vdHMgdGhlIE9TIGNsZWFycyBpdHMgb3duIHRlbXAKICAgICAgICAgICAgICBkaXJlY3RvcnkuIDxiPlNldHRpbmdzIOKGkiBXaGF0IGlzIG9uIHRoaXMgbWFjaGluZTwvYj4gc2hvd3MgdGhlIGludmVudG9yeSwgYW5kCiAgICAgICAgICAgICAgPGI+TGVhdmUgbm90aGluZzwvYj4gcmVtb3ZlcyBhbGwgb2YgaXQuPC9saT4KICAgICAgICAgIDwvb2w+CgogICAgICAgICAgPGgzIGlkPSJkMyI+V2hhdCBpcyBsZWZ0IGFmdGVyd2FyZHM8L2gzPgogICAgICAgICAgPHRhYmxlPgogICAgICAgICAgICA8dHI+PHRoPkhvdyB5b3Ugc3RhcnQgaXQ8L3RoPjx0aD5XaGF0IHJlbWFpbnMgd2hlbiB0aGUgc2Vzc2lvbiBlbmRzPC90aD48L3RyPgogICAgICAgICAgICA8dHI+PHRkPjxiPlRyYW5zaWVudDwvYj4g4oCUIHRoZSBtYWNPUyBTaG9ydGN1dDwvdGQ+CiAgICAgICAgICAgICAgPHRkPjxiPk5vdGhpbmcgYXQgYWxsLjwvYj4gVGhlIHN0YWdpbmcgZGlyZWN0b3J5IGdvZXMgdG9vOiB0aGUgUHl0aG9uIHJ1bnRpbWUsIHRoZSBoZWxwZXIsCiAgICAgICAgICAgICAgICB0aGUgSmF2YSBydW50aW1lLCB0aGUgZ2FtZSwgdGhlIHNhbmRib3guPC90ZD48L3RyPgogICAgICAgICAgICA8dHI+PHRkPjxiPkluc3RhbGxlZDwvYj4g4oCUIHRoZSBkb3VibGUtY2xpY2sgZmlsZTwvdGQ+CiAgICAgICAgICAgICAgPHRkPjxiPlR3byBzbWFsbCBmaWxlczwvYj46IG9uZSBQeXRob24gZmlsZSBpbiBBcHBsaWNhdGlvbiBTdXBwb3J0LCBvbmUgbGF1bmNoIGFnZW50IHNvIGl0CiAgICAgICAgICAgICAgICBzdGFydHMgYXQgZXZlcnkgbG9naW4uIFRoZSBnYW1lIGlzIHN0aWxsIGRlbGV0ZWQgZXZlcnkgc2Vzc2lvbiwgYW5kCiAgICAgICAgICAgICAgICA8Yj5MZWF2ZSBub3RoaW5nPC9iPiByZW1vdmVzIGJvdGguPC90ZD48L3RyPgogICAgICAgICAgICA8dHI+PHRkPjxiPkRvd25sb2FkcywgaWYgeW91IGFzayBmb3IgdGhlbSB0byBiZSBrZXB0PC9iPjwvdGQ+CiAgICAgICAgICAgICAgPHRkPkEgY2FjaGUgZGlyZWN0b3J5IG9mIE1vamFuZydzIGZpbGVzLCBzbyB0aGUgbmV4dCBsYXVuY2ggZG9lcyBub3QgZG93bmxvYWQgdGhlbSBhZ2Fpbi4KICAgICAgICAgICAgICAgIEl0IGlzIG9mZiB1bmxlc3MgeW91IHR1cm4gaXQgb24sIGFuZCBpdCBpcyBuYW1lZCBpbiB0aGUgaW52ZW50b3J5IGFib3ZlLjwvdGQ+PC90cj4KICAgICAgICAgICAgPHRyPjx0ZD48Yj5Ccm93c2VyIHN0b3JhZ2U8L2I+PC90ZD4KICAgICAgICAgICAgICA8dGQ+WW91ciB3b3JsZCwgeW91ciBtb2RzIGFuZCB5b3VyIHNldHRpbmdzLCBpbiB0aGlzIG9yaWdpbidzIG93biBzdG9yYWdlLiBUaGF0IGlzIHRoZSBvbmUKICAgICAgICAgICAgICAgIHRoaW5nIHdoaWNoIHBlcnNpc3RzIG9uIHB1cnBvc2Ug4oCUIGl0IGlzIHdoYXQgbWFrZXMgdGhlIGdhbWUgZGlzcG9zYWJsZS48L3RkPjwvdHI+CiAgICAgICAgICA8L3RhYmxlPgoKICAgICAgICAgIDxoMyBpZD0iZDQiPldoZXJlIHlvdXIgd29ybGQgbGl2ZXM8L2gzPgogICAgICAgICAgPHA+SW4gdGhpcyBicm93c2VyLCB1bmRlciB0aGlzIHBhZ2UncyBvcmlnaW4uIEl0IGlzIG5ldmVyIHVwbG9hZGVkLCBhbmQgdGhlcmUgaXMgbm8gYWNjb3VudC4KICAgICAgICAgICAgVGhlIGNvbnNlcXVlbmNlIHdvcnRoIGtub3dpbmc6IHN0b3JhZ2UgYmVsb25ncyB0byBhbiA8aT5vcmlnaW48L2k+LCBzbyB0aGUgaG9zdGVkIHBhZ2UgYW5kIHRoZQogICAgICAgICAgICBoZWxwZXIncyBwYWdlIGFyZSBkaWZmZXJlbnQgc3RvcmVzLiBUaGF0IGlzIGV4YWN0bHkgd2h5IHRoZSBob3N0ZWQgcGFnZSBoYW5kcyB0aGUgdGFiIG92ZXIgb24KICAgICAgICAgICAgYXJyaXZhbCBpbnN0ZWFkIG9mIHJ1bm5pbmcgYSBzZXNzaW9uIGl0c2VsZiDigJQgb25lIG9yaWdpbiwgb25lIHdvcmxkLCBubyBzdXJwcmlzZXMuPC9wPgoKICAgICAgICAgIDxoMyBpZD0iZDUiPk5ldHdvcmtzIHRoYXQgYmxvY2sgdGhpbmdzPC9oMz4KICAgICAgICAgIDxwPjxiPlRoZSByZWxheSBpcyBvbmUgc2V0dGluZyBhbmQgaXQgY2FycmllcyBldmVyeXRoaW5nLjwvYj4gU3dpdGNoZWQgb24sIGV2ZXJ5IGRvd25sb2FkIGFuZAogICAgICAgICAgICBldmVyeSBjb25uZWN0aW9uIHRoZSBnYW1lIGl0c2VsZiBtYWtlcyDigJQgam9pbmluZyBhIHNlcnZlciwgYXV0aGVudGljYXRpbmcsIGZldGNoaW5nIHNraW5zIOKAlAogICAgICAgICAgICB0cmF2ZWxzIGluc2lkZSBvcmRpbmFyeSBIVFRQUyB0byB0aGUgcmVsYXksIHdoaWNoIGRvZXMgdGhlIGZldGNoaW5nIGFuZCB0aGUgZGlhbGxpbmcgZnJvbQogICAgICAgICAgICBvdXRzaWRlIHRoZSBuZXR3b3JrIHRoYXQgaXMgYmxvY2tpbmcgeW91LiBJdCBpcyBhIENsb3VkZmxhcmUgV29ya2VyOyB0d28gb2YgdGhlbSBhcmUKICAgICAgICAgICAgZGVwbG95ZWQgYW5kIGJ1aWx0IGludG8gdGhlIGhlbHBlciwgc28gbm9ib2R5IGhhcyB0byBydW4gYSBjb21tYW5kIG9yIG1ha2UgYW4gYWNjb3VudC48L3A+CiAgICAgICAgICA8dGFibGU+CiAgICAgICAgICAgIDx0cj48dGg+V2hhdCBpcyBibG9ja2VkPC90aD48dGg+V2hhdCB0byBkbzwvdGg+PC90cj4KICAgICAgICAgICAgPHRyPjx0ZD5Nb2phbmcgaXMgdW5yZWFjaGFibGU8L3RkPgogICAgICAgICAgICAgIDx0ZD5Ob3RoaW5nOiBvbiA8Yj5BdXRvbWF0aWM8L2I+IHRoZSByZWxheSBmZXRjaGVzIGZvciB5b3Ugb3ZlciBvcmRpbmFyeSBIVFRQUyBhbmQgY2FjaGVzCiAgICAgICAgICAgICAgICB3aGF0IGl0IGZldGNoZWQgYXQgdGhlIGVkZ2UuIEEgbmV0d29yayB0aGF0IGJsb2NrcyBNb2phbmcgaXMgZXhhY3RseSB3aGF0IGl0IGV4aXN0cyBmb3IuPC90ZD48L3RyPgogICAgICAgICAgICA8dHI+PHRkPk1pbmVjcmFmdCBzZXJ2ZXJzIGFyZSB1bnJlYWNoYWJsZSAob25seSA0NDMgZ2V0cyBvdXQpPC90ZD4KICAgICAgICAgICAgICA8dGQ+QWxzbyBub3RoaW5nLCBmb3IgdGhlIHNhbWUgcmVhc29uOiB0aGUgZ2FtZSdzIGNvbm5lY3Rpb25zIHJpZGUgaW5zaWRlIHRoZSByZWxheSB0b28uCiAgICAgICAgICAgICAgICBQdXQgdGhlIHNlcnZlciBpbiA8Yj5Kb2luIHRoaXMgc2VydmVyPC9iPiBhbmQgdGhlIGNsaWVudCBqb2lucyBpdCBhdXRvbWF0aWNhbGx5LiBUaGUgcmVsYXkKICAgICAgICAgICAgICAgIHJlZnVzZXMgYW55IHNlc3Npb24gdGhhdCBkb2VzIG5vdCBiZWdpbiB3aXRoIGEgTWluZWNyYWZ0IGhhbmRzaGFrZSwgYmVjYXVzZSBhIHJlbGF5IHRoYXQKICAgICAgICAgICAgICAgIGRpYWxsZWQgYW55IHBvcnQgZm9yIGFueSBieXRlcyB3b3VsZCBiZSBhIHBvcnQgc2Nhbm5lci48L3RkPjwvdHI+CiAgICAgICAgICAgIDx0cj48dGQ+VGhlIHJlbGF5J3Mgb3duIGhvc3RuYW1lIGlzIGJsb2NrZWQ8L3RkPgogICAgICAgICAgICAgIDx0ZD5JdCBpcyBhc2tlZCBmb3IgdGhyb3VnaCBhIHByb3h5IHlvdSBhbHJlYWR5IHJ1biwgaWYgdGhlcmUgaXMgb25lLCBhbmQgdGhlcmUgYXJlIHR3bwogICAgICAgICAgICAgICAgaG9zdG5hbWVzIHRvIHRyeS4gSWYgbmVpdGhlciBhbnN3ZXJzIHlvdSBnZXQgYSBkaXJlY3QgY29ubmVjdGlvbiByYXRoZXIgdGhhbiBhbiBlcnJvci48L3RkPjwvdHI+CiAgICAgICAgICAgIDx0cj48dGQ+U2VydmVycyB0aGF0IHJlZnVzZSBkYXRhY2VudGVyIGFkZHJlc3NlczwvdGQ+CiAgICAgICAgICAgICAgPHRkPlRoZSByZWxheSBkaWFscyBmcm9tIGEgZGF0YWNlbnRlciwgYW5kIHNvbWUgc2VydmVycyByZWZ1c2UgdGhvc2UuIFRoYXQgaXMgdGhlIHNlcnZlcidzCiAgICAgICAgICAgICAgICBjaG9pY2UgYW5kIG5vIHJlbGF5IGNhbiBjaGFuZ2UgaXQg4oCUIHRyeSBhbm90aGVyIHNlcnZlciwgb3IgPGI+TmV2ZXI8L2I+IGFuZCBhIHByb3h5IG9mCiAgICAgICAgICAgICAgICB5b3VyIG93bi48L3RkPjwvdHI+CiAgICAgICAgICAgIDx0cj48dGQ+QSBwcm9ncmFtIHlvdSBkaWQgbm90IHdyaXRlIGlzIGJsb2NrZWQ8L3RkPgogICAgICAgICAgICAgIDx0ZD5Ob3RoaW5nIGhlcmUgY2hhbmdlcyB0aGF0LiBBcHBMb2NrZXIsIFdEQUMsIE1ETSwgc2NyZWVuLXRpbWUgYW5kIHBhcmVudGFsIGNvbnRyb2xzIGFyZQogICAgICAgICAgICAgICAgZW5mb3JjZWQgYnkgdGhlIG9wZXJhdGluZyBzeXN0ZW0sIGFuZCBubyBsYXVuY2hlciBjYW4gZ2V0IGFyb3VuZCB0aGVtLiBPbiBzdWNoIGEgbWFjaGluZQogICAgICAgICAgICAgICAgdGhlIG9ubHkgdGhpbmcgdGhhdCBydW5zIGlzIGEgbGF1bmNoZXIgdGhhdCBpbnN0YWxscyBub3RoaW5nIGF0IGFsbDogdGhlIGJyb3dzZXIgdGllci48L3RkPjwvdHI+CiAgICAgICAgICA8L3RhYmxlPgoKICAgICAgICAgIDxoMyBpZD0iZDYiPk1vcmUgdGhhbiBvbmUgd2luZG93PC9oMz4KICAgICAgICAgIDxwPkV2ZXJ5IFBMQVkgaXMgaXRzIG93biBzZXNzaW9uLCB3aXRoIGl0cyBvd24gc2FuZGJveCwgaXRzIG93biBKYXZhIHByb2Nlc3MgYW5kIGl0cyBvd24gbG9nLgogICAgICAgICAgICBUd28gd2luZG93cyBjYW4gcnVuIGF0IG9uY2UsIGluY2x1ZGluZyB0d28gZGlmZmVyZW50IHZlcnNpb25zLCBhbmQgc3RvcHBpbmcgb25lIGRvZXMgbm90IHRvdWNoCiAgICAgICAgICAgIHRoZSBvdGhlci4gRWFjaCBmaW5pc2hlZCBzZXNzaW9uIGlzIHN0b3JlZCBhbmQgZWFjaCBkZWxldGVzIGl0cyBvd24gc2FuZGJveC48L3A+CgogICAgICAgICAgPGgzIGlkPSJkNyI+TW9kIGxvYWRlcnM8L2gzPgogICAgICAgICAgPHRhYmxlPgogICAgICAgICAgICA8dHI+PHRoPkxvYWRlcjwvdGg+PHRoPlN0YXRlPC90aD48L3RyPgogICAgICAgICAgICA8dHI+PHRkPjxiPkZhYnJpYzwvYj48L3RkPjx0ZD5Xb3JrcywgZm9yIGFueSB2ZXJzaW9uIEZhYnJpYyBzdXBwb3J0czogbW9kcyBhcmUgbG9hZGVkIGF0IHBsYXkKICAgICAgICAgICAgICB0aW1lIGJ5IGEgcmVhbCBKVk0sIGZyb20gamFycyB5b3UgZHJvcHBlZCBoZXJlIG9yIGZyb20gTW9kcmludGguPC90ZD48L3RyPgogICAgICAgICAgICA8dHI+PHRkPkZvcmdlLCBOZW9Gb3JnZTwvdGQ+PHRkPk5vdCBzdXBwb3J0ZWQgeWV0OiB0aGVpciBidWlsZHMgcmVzb2x2ZSBhbmQgdGhlaXIgbGlicmFyaWVzCiAgICAgICAgICAgICAgZG93bmxvYWQsIGJ1dCBuZWl0aGVyIHNoaXBzIGEgdXNhYmxlIGNsaWVudCBqYXIg4oCUIHRoZWlyIGluc3RhbGxlciBydW5zIGEgcGF0Y2hpbmcgc3RlcCBvdmVyCiAgICAgICAgICAgICAgTW9qYW5nJ3MgamFyIGFuZCB0aGVpciBib290c3RyYXAgcmVmdXNlcyB0byBzdGFydCB3aXRob3V0IGl0LiBBc2tpbmcgZm9yIG9uZSBpcyByZWZ1c2VkIHdpdGgKICAgICAgICAgICAgICB0aGF0IGV4cGxhbmF0aW9uIHJhdGhlciB0aGFuIGhhbGYtbGF1bmNoZWQuPC90ZD48L3RyPgogICAgICAgICAgPC90YWJsZT4KCiAgICAgICAgICA8aDMgaWQ9ImQ4Ij5XaGVuIHNvbWV0aGluZyBnb2VzIHdyb25nPC9oMz4KICAgICAgICAgIDx0YWJsZT4KICAgICAgICAgICAgPHRyPjx0aD5TeW1wdG9tPC90aD48dGg+Q2F1c2UgYW5kIGFuc3dlcjwvdGg+PC90cj4KICAgICAgICAgICAgPHRyPjx0ZD5Ob3RoaW5nIGhhcHBlbnMgd2hlbiB5b3UgcHJlc3MgUExBWTwvdGQ+CiAgICAgICAgICAgICAgPHRkPk5vIGhlbHBlciBpcyBydW5uaW5nLiBUaGUgc3RhdHVzIHBhbmVsIG9mZmVycyB0aGUgU2hvcnRjdXQsIHRoZSBkb3dubG9hZCwgb3IgdGhlIGxpbmsgdG8KICAgICAgICAgICAgICAgIHRoZSBoZWxwZXIncyBvd24gcGFnZS48L3RkPjwvdHI+CiAgICAgICAgICAgIDx0cj48dGQ+4oCcbm8gaGVscGVy4oCdIGFsdGhvdWdoIGl0IGlzIHJ1bm5pbmc8L3RkPgogICAgICAgICAgICAgIDx0ZD5UaGlzIGJyb3dzZXIgYmxvY2tlZCB0aGUgcmVxdWVzdDogdXNlIHRoZSBoZWxwZXIncyBvd24gcGFnZSwgb3IgYWxsb3cgTG9jYWwgTmV0d29yawogICAgICAgICAgICAgICAgQWNjZXNzIGZvciB0aGlzIHNpdGUuPC90ZD48L3RyPgogICAgICAgICAgICA8dHI+PHRkPkEgbGF1bmNoIGZhaWxzIHdpdGggPGNvZGU+RmFpbGVkIHRvIGNvbm5lY3Q8L2NvZGU+IHRvIE1vamFuZzwvdGQ+CiAgICAgICAgICAgICAgPHRkPlRoZSBuZXR3b3JrIGJsb2NrcyBpdC4gTGVhdmUgdGhlIHJlbGF5IG9uIEF1dG9tYXRpYy48L3RkPjwvdHI+CiAgICAgICAgICAgIDx0cj48dGQ+VGhlIGdhbWUgc3RhcnRzIHNpbGVudCBhbmQgdGV4dHVyZWxlc3M8L3RkPgogICAgICAgICAgICAgIDx0ZD5Bc3NldHMgd2VyZSBza2lwcGVkOyAyNi54IHdpbGwgbm90IGV2ZW4gc3RhcnQgd2l0aG91dCB0aGVtLiBUdXJuIHRoZW0gYmFjayBvbi48L3RkPjwvdHI+CiAgICAgICAgICAgIDx0cj48dGQ+QSBjcmFzaDwvdGQ+CiAgICAgICAgICAgICAgPHRkPlJlYWQgdGhlIGxvZywgb3IgdGFrZSB0aGUgc2Vzc2lvbiB6aXA6IGl0IGhvbGRzIHRoZSBjbGllbnQncyBvd24gbG9nIGFuZCBhbnkgY3Jhc2gKICAgICAgICAgICAgICAgIHJlcG9ydC4gPGI+Q29weSBkaWFnbm9zdGljczwvYj4gcHV0cyBldmVyeXRoaW5nIHdvcnRoIHBhc3Rpbmcgb24geW91ciBjbGlwYm9hcmQuPC90ZD48L3RyPgogICAgICAgICAgPC90YWJsZT4KICAgICAgICAgIDxocj4KICAgICAgICAgIDxwIGNsYXNzPSJub3RlIj5UaGUgcHJvbWlzZSBpbiBvbmUgc2VudGVuY2U6IHRoZSBnYW1lIHJ1bnMgb24geW91ciBjb21wdXRlciwgZnJvbSBhIGRpcmVjdG9yeQogICAgICAgICAgICB1bmRlciA8Y29kZT4vdG1wPC9jb2RlPiB0aGF0IGlzIGRlbGV0ZWQgd2hlbiBpdCBlbmRzLCB3aGlsZSB5b3VyIHdvcmxkIGFuZCB5b3VyIG1vZHMgbGl2ZSBpbgogICAgICAgICAgICB5b3VyIGJyb3dzZXIg4oCUIHNvIHRoZSBtYWNoaW5lIGlzIGJvcnJvd2VkIGZvciBhbiBob3VyIHJhdGhlciB0aGFuIGNoYW5nZWQuPC9wPgogICAgICAgIDwvZGl2PgogICAgICAgIDxkaXYgY2xhc3M9InRvYyI+CiAgICAgICAgICA8YSBocmVmPSIjZDEiPldoeSB0aGUgcGFnZSBjYW5ub3QgbGF1bmNoIGFueXRoaW5nPC9hPgogICAgICAgICAgPGEgaHJlZj0iI2QyIj5XaGF0IHRoZSBoZWxwZXIgZG9lczwvYT4KICAgICAgICAgIDxhIGhyZWY9IiNkMyI+V2hhdCBpcyBsZWZ0IGFmdGVyd2FyZHM8L2E+CiAgICAgICAgICA8YSBocmVmPSIjZDQiPldoZXJlIHlvdXIgd29ybGQgbGl2ZXM8L2E+CiAgICAgICAgICA8YSBocmVmPSIjZDUiPk5ldHdvcmtzIHRoYXQgYmxvY2sgdGhpbmdzPC9hPgogICAgICAgICAgPGEgaHJlZj0iI2Q2Ij5Nb3JlIHRoYW4gb25lIHdpbmRvdzwvYT4KICAgICAgICAgIDxhIGhyZWY9IiNkNyI+TW9kIGxvYWRlcnM8L2E+CiAgICAgICAgICA8YSBocmVmPSIjZDgiPldoZW4gc29tZXRoaW5nIGdvZXMgd3Jvbmc8L2E+CiAgICAgICAgPC9kaXY+CiAgICAgIDwvZGl2PgogICAgPC9zZWN0aW9uPgogIDwvZGl2PgoKICA8ZGl2IGNsYXNzPSJsb2diYXIiPgogICAgPGRpdiBjbGFzcz0ic3RyaXBsaW5lIiBpZD0iZHJhd2VyU3RyaXBSb3ciPgogICAgICA8aSBjbGFzcz0iZG90IiBpZD0iY2RvdDIiPjwvaT4KICAgICAgPGI+QWN0aXZpdHk8L2I+CiAgICAgIDxzcGFuIGNsYXNzPSJwaGFzZSIgaWQ9ImxvZ1N0YXRlIj53YWl0aW5nPC9zcGFuPgogICAgICA8c3BhbiBjbGFzcz0icmFpbCIgaWQ9ImRyYXdlclRyYWNrIj48aT48L2k+PC9zcGFuPgogICAgICA8c3BhbiBjbGFzcz0icGN0IiBpZD0iZHJhd2VyUGN0Ij48L3NwYW4+CiAgICAgIDxidXR0b24gY2xhc3M9InRvZ2dsZSIgaWQ9ImxvZ0hpZGUiPlNob3cgbG9nPC9idXR0b24+CiAgICA8L2Rpdj4KICAgIDxkaXYgY2xhc3M9ImxvZ2JvZHkiPgogICAgICA8ZGl2IGNsYXNzPSJsb2d0b29scyI+CiAgICAgICAgPGI+TG9nPC9iPjxzcGFuIGNsYXNzPSJub3RlIiBpZD0ibG9nRm9yIj5ubyBzZXNzaW9uPC9zcGFuPjxzcGFuIHN0eWxlPSJmbGV4OjEiPjwvc3Bhbj4KICAgICAgICA8YnV0dG9uIGNsYXNzPSJ0aW55IGdob3N0IiBpZD0ibG9nQ2xlYXIiPkNsZWFyIHRoZSB2aWV3PC9idXR0b24+CiAgICAgIDwvZGl2PgogICAgICA8ZGl2IGNsYXNzPSJyZWNlaXB0IiBpZD0icmVjZWlwdCI+PC9kaXY+CiAgICAgIDxkaXYgY2xhc3M9ImNvbnNvbGUiIGlkPSJsb2ciPjxzcGFuIGNsYXNzPSJkIj5UaGUgaGVscGVyJ3MgbG9nIGFwcGVhcnMgaGVyZSDigJQgaW5jbHVkaW5nCk1pbmVjcmFmdCdzIG93biwgc28gYSBjcmFzaCBpcyByZWFkYWJsZSBpbnN0ZWFkIG9mIG15c3RlcmlvdXMuPC9zcGFuPjwvZGl2PgogICAgPC9kaXY+CiAgPC9kaXY+CjwvZGl2PgoKPGRpYWxvZyBpZD0iYWJvdXQiPgogIDxkaXYgY2xhc3M9ImlubmVyIj4KICAgIDxoMz5Ib3cgdGhpcyB3b3JrczwvaDM+CiAgICA8cD5NaW5lY3JhZnQgbmV2ZXIgYmVjb21lcyBhIHdlYiBhcHAgaGVyZS4gQSBoZWxwZXIgb24gdGhpcyBtYWNoaW5lIGRvd25sb2FkcyB0aGUgcmVhbCBjbGllbnQgYW5kIHRoZQogICAgICBKYXZhIHJ1bnRpbWUgaW50byBvbmUgZGlyZWN0b3J5IHVuZGVyIDxjb2RlPi90bXA8L2NvZGU+LCBzdGFydHMgaXQgd2l0aCBGYWJyaWMsIGFuZCB3aGVuIHRoZSBzZXNzaW9uCiAgICAgIGVuZHMgaXQgaGFuZHMgdGhlIHNhdmVzIHRvIHlvdXIgYnJvd3NlciBhbmQgZGVsZXRlcyB0aGUgZGlyZWN0b3J5LjwvcD4KICAgIDxwPlRoaXMgcGFnZSBjYW5ub3Qgc3RhcnQgYSBwcm9ncmFtLCByZWFkIGEgZmlsZSwgb3Igc2VlIDxjb2RlPi90bXA8L2NvZGU+IOKAlCB0aGUgaGVscGVyIGRvZXMgdGhhdAogICAgICBwYXJ0LiA8Yj5Eb2N1bWVudGF0aW9uPC9iPiBpbiB0aGUgdGFicyBhYm92ZSBoYXMgdGhlIGxvbmcgdmVyc2lvbi48L3A+CiAgICA8ZGl2IGNsYXNzPSJub3RlIiBpZD0iYWJvdXRrdnMiIHN0eWxlPSJtYXJnaW4tdG9wOjEzcHgiPjwvZGl2PgogICAgPGRpdiBzdHlsZT0ibWFyZ2luLXRvcDoxOHB4O3RleHQtYWxpZ246cmlnaHQiPjxidXR0b24gaWQ9ImFib3V0Y2xvc2UiPkNsb3NlPC9idXR0b24+PC9kaXY+CiAgPC9kaXY+CjwvZGlhbG9nPgoKPHNjcmlwdD4KCiJ1c2Ugc3RyaWN0IjsKY29uc3QgJCA9IChpZCkgPT4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpOwpjb25zdCBMUyA9ICJ3ZWJtYy5sb2NhbC4iOwpjb25zdCBzdGF0ZSA9IHsgaGVscGVyOm51bGwsIHRva2VuOm51bGwsIG9ubGluZTpmYWxzZSwgc2Vzc2lvbnM6W10sIHNlbGVjdGVkOm51bGwsCiAgICAgICAgICAgICAgICBzaW5jZTp7fSwgc2x1Z3M6W10sIHNsdWdzTWV0YTp7fSwgcmVzdWx0Om51bGwsIHNlZW46e30sIHRpbWVyOm51bGwgfTsKCi8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IHZpZXdzICovCmNvbnN0IFZJRVdTID0gewogIHZpZXdQbGF5OiAgICAgWyJQbGF5IiwgInBpY2sgYSB2ZXJzaW9uIGFuZCBwcmVzcyBQTEFZIOKAlCBtb3JlIHRoYW4gb25lIGNhbiBydW4gYXQgb25jZSJdLAogIHZpZXdNb2RzOiAgICAgWyJNb2RzIiwgImphcnMgZnJvbSB0aGlzIGJyb3dzZXIsIG9yIGZyb20gTW9kcmludGgiXSwKICB2aWV3U2V0dGluZ3M6IFsiU2V0dGluZ3MiLCAidGhpcyBpbnN0YWxsYXRpb24sIGFuZCB0aGUgaGVscGVyIl0sCiAgdmlld0RvYzogICAgICBbIkRvY3VtZW50YXRpb24iLCAiaG93IGFsbCBvZiB0aGlzIHdvcmtzLCBhbmQgd2hhdCBpdCBsZWF2ZXMgYmVoaW5kIl0sCn07CmZ1bmN0aW9uIHNob3codmlldyl7CiAgZm9yIChjb25zdCBpZCBvZiBPYmplY3Qua2V5cyhWSUVXUykpICQoaWQpLmNsYXNzTGlzdC50b2dnbGUoIm9uIiwgaWQgPT09IHZpZXcpOwogIGZvciAoY29uc3QgW2J0biwgdl0gb2YgW1sibmF2UGxheSIsInZpZXdQbGF5Il0sWyJuYXZNb2RzIiwidmlld01vZHMiXSwKICAgICAgICAgICAgICAgICAgICAgICAgICBbIm5hdlNldHRpbmdzIiwidmlld1NldHRpbmdzIl0sWyJuYXZEb2MiLCJ2aWV3RG9jIl1dKQogICAgJChidG4pLmNsYXNzTGlzdC50b2dnbGUoIm9uIiwgdiA9PT0gdmlldyk7CiAgaWYgKCQoInZpZXdUaXRsZSIpKSBpZiAoJCgidmlld1RpdGxlIikpICQoInZpZXdUaXRsZSIpLnRleHRDb250ZW50ID0gVklFV1Nbdmlld11bMF07CiAgJCgidmlld1N1YiIpLnRleHRDb250ZW50ID0gVklFV1Nbdmlld11bMV07Cn0KJCgibmF2UGxheSIpLm9uY2xpY2sgPSAoKSA9PiBzaG93KCJ2aWV3UGxheSIpOwokKCJuYXZNb2RzIikub25jbGljayA9ICgpID0+IHNob3coInZpZXdNb2RzIik7CiQoIm5hdlNldHRpbmdzIikub25jbGljayA9ICgpID0+IHNob3coInZpZXdTZXR0aW5ncyIpOwokKCJuYXZEb2MiKS5vbmNsaWNrID0gKCkgPT4gc2hvdygidmlld0RvYyIpOwoKLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gc3RvcmFnZSAqLwpjb25zdCBTdG9yZSA9ICgoKSA9PiB7CiAgY29uc3QgREJOID0gIndlYm1jLWxvY2FsIiwgTE9HID0gInNlc3Npb24iLCBNT0RTID0gIm1vZHMiOwogIGZ1bmN0aW9uIGlkYigpewogICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXMsIHJlaikgPT4gewogICAgICBjb25zdCByID0gaW5kZXhlZERCLm9wZW4oREJOLCAyKTsKICAgICAgci5vbnVwZ3JhZGVuZWVkZWQgPSAoKSA9PiB7CiAgICAgICAgY29uc3QgZGIgPSByLnJlc3VsdDsKICAgICAgICBpZiAoIWRiLm9iamVjdFN0b3JlTmFtZXMuY29udGFpbnMoTE9HKSkgZGIuY3JlYXRlT2JqZWN0U3RvcmUoTE9HKTsKICAgICAgICBpZiAoIWRiLm9iamVjdFN0b3JlTmFtZXMuY29udGFpbnMoTU9EUykpIGRiLmNyZWF0ZU9iamVjdFN0b3JlKE1PRFMpOwogICAgICB9OwogICAgICByLm9uc3VjY2VzcyA9ICgpID0+IHJlcyhyLnJlc3VsdCk7IHIub25lcnJvciA9ICgpID0+IHJlaihyLmVycm9yKTsKICAgIH0pOwogIH0KICBmdW5jdGlvbiBpZGJPcChzdG9yZSwgbW9kZSwgZm4pewogICAgcmV0dXJuIGlkYigpLnRoZW4oZGIgPT4gbmV3IFByb21pc2UoKHJlcywgcmVqKSA9PiB7CiAgICAgIGNvbnN0IHQgPSBkYi50cmFuc2FjdGlvbihzdG9yZSwgbW9kZSk7CiAgICAgIGNvbnN0IHJlcSA9IGZuKHQub2JqZWN0U3RvcmUoc3RvcmUpKTsKICAgICAgdC5vbmNvbXBsZXRlID0gKCkgPT4gcmVzKHJlcSAmJiByZXEucmVzdWx0KTsgdC5vbmVycm9yID0gKCkgPT4gcmVqKHQuZXJyb3IpOwogICAgfSkpOwogIH0KICBjb25zdCBvcGZzID0gISEobmF2aWdhdG9yLnN0b3JhZ2UgJiYgbmF2aWdhdG9yLnN0b3JhZ2UuZ2V0RGlyZWN0b3J5KTsKICBhc3luYyBmdW5jdGlvbiBkaXIobmFtZSwgY3JlYXRlKXsKICAgIGNvbnN0IHJvb3QgPSBhd2FpdCBuYXZpZ2F0b3Iuc3RvcmFnZS5nZXREaXJlY3RvcnkoKTsKICAgIHJldHVybiByb290LmdldERpcmVjdG9yeUhhbmRsZShuYW1lLCB7IGNyZWF0ZTogISFjcmVhdGUgfSk7CiAgfQogIHJldHVybiB7CiAgICBraW5kOiBvcGZzID8gIk9QRlMiIDogIkluZGV4ZWREQiIsCiAgICBhc3luYyBwdXQoa2V5LCBibG9iKXsgcmV0dXJuIHRoaXMucHV0SW4oTE9HLCBrZXksIGJsb2IpOyB9LAogICAgYXN5bmMgcHV0SW4oc3RvcmUsIGtleSwgYmxvYil7CiAgICAgIGlmIChvcGZzKXsKICAgICAgICBjb25zdCBkID0gYXdhaXQgZGlyKHN0b3JlLCB0cnVlKTsKICAgICAgICBjb25zdCBmaCA9IGF3YWl0IGQuZ2V0RmlsZUhhbmRsZShrZXksIHsgY3JlYXRlOnRydWUgfSk7CiAgICAgICAgY29uc3QgdyA9IGF3YWl0IGZoLmNyZWF0ZVdyaXRhYmxlKCk7IGF3YWl0IHcud3JpdGUoYmxvYik7IGF3YWl0IHcuY2xvc2UoKTsgcmV0dXJuOwogICAgICB9CiAgICAgIGF3YWl0IGlkYk9wKHN0b3JlLCAicmVhZHdyaXRlIiwgcyA9PiBzLnB1dChibG9iLCBrZXkpKTsKICAgIH0sCiAgICBhc3luYyBnZXQoa2V5KXsgcmV0dXJuIHRoaXMuZ2V0RnJvbShMT0csIGtleSk7IH0sCiAgICBhc3luYyBnZXRGcm9tKHN0b3JlLCBrZXkpewogICAgICBpZiAob3Bmcyl7CiAgICAgICAgdHJ5IHsgY29uc3QgZCA9IGF3YWl0IGRpcihzdG9yZSwgZmFsc2UpOyBjb25zdCBmaCA9IGF3YWl0IGQuZ2V0RmlsZUhhbmRsZShrZXkpOwogICAgICAgICAgICAgIHJldHVybiBhd2FpdCBmaC5nZXRGaWxlKCk7IH0gY2F0Y2goZSl7IHJldHVybiBudWxsOyB9CiAgICAgIH0KICAgICAgcmV0dXJuIChhd2FpdCBpZGJPcChzdG9yZSwgInJlYWRvbmx5IiwgcyA9PiBzLmdldChrZXkpKSkgfHwgbnVsbDsKICAgIH0sCiAgICBhc3luYyBsaXN0KHN0b3JlKXsKICAgICAgaWYgKG9wZnMpewogICAgICAgIGNvbnN0IG91dCA9IFtdOwogICAgICAgIHRyeSB7CiAgICAgICAgICBjb25zdCBkID0gYXdhaXQgZGlyKHN0b3JlLCBmYWxzZSk7CiAgICAgICAgICBmb3IgYXdhaXQgKGNvbnN0IFtuYW1lLCBoYW5kbGVdIG9mIGQuZW50cmllcygpKXsKICAgICAgICAgICAgaWYgKGhhbmRsZS5raW5kICE9PSAiZmlsZSIpIGNvbnRpbnVlOwogICAgICAgICAgICBvdXQucHVzaCh7IG5hbWUsIHNpemU6IChhd2FpdCBoYW5kbGUuZ2V0RmlsZSgpKS5zaXplIH0pOwogICAgICAgICAgfQogICAgICAgIH0gY2F0Y2goZSl7fQogICAgICAgIHJldHVybiBvdXQuc29ydCgoYSxiKSA9PiBhLm5hbWUubG9jYWxlQ29tcGFyZShiLm5hbWUpKTsKICAgICAgfQogICAgICBjb25zdCBrZXlzID0gKGF3YWl0IGlkYk9wKHN0b3JlLCAicmVhZG9ubHkiLCBzID0+IHMuZ2V0QWxsS2V5cygpKSkgfHwgW107CiAgICAgIHJldHVybiBrZXlzLm1hcChuYW1lID0+ICh7IG5hbWUsIHNpemU6MCB9KSkuc29ydCgoYSxiKSA9PiBhLm5hbWUubG9jYWxlQ29tcGFyZShiLm5hbWUpKTsKICAgIH0sCiAgICBhc3luYyByZW1vdmUoc3RvcmUsIGtleSl7CiAgICAgIGlmIChvcGZzKXsgdHJ5IHsgY29uc3QgZCA9IGF3YWl0IGRpcihzdG9yZSwgZmFsc2UpOyBhd2FpdCBkLnJlbW92ZUVudHJ5KGtleSk7IH0gY2F0Y2goZSl7fSByZXR1cm47IH0KICAgICAgYXdhaXQgaWRiT3Aoc3RvcmUsICJyZWFkd3JpdGUiLCBzID0+IHMuZGVsZXRlKGtleSkpOwogICAgfSwKICAgIGFzeW5jIHBlcnNpc3QoKXsgdHJ5IHsgcmV0dXJuIG5hdmlnYXRvci5zdG9yYWdlICYmIG5hdmlnYXRvci5zdG9yYWdlLnBlcnNpc3QKICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYXdhaXQgbmF2aWdhdG9yLnN0b3JhZ2UucGVyc2lzdCgpIDogZmFsc2U7IH0gY2F0Y2goZSl7IHJldHVybiBmYWxzZTsgfSB9LAogICAgYXN5bmMgdXNhZ2UoKXsgdHJ5IHsgY29uc3QgZSA9IGF3YWl0IG5hdmlnYXRvci5zdG9yYWdlLmVzdGltYXRlKCk7CiAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyB1c2VkOmUudXNhZ2V8fDAsIHF1b3RhOmUucXVvdGF8fDAgfTsgfSBjYXRjaChlKXsgcmV0dXJuIHt1c2VkOjAscXVvdGE6MH07IH0gfQogIH07Cn0pKCk7CmNvbnN0IGZtdCA9IChiKSA9PiB7CiAgaWYgKCFiKSByZXR1cm4gIjAgQiI7CiAgY29uc3QgdSA9IFsiQiIsIktCIiwiTUIiLCJHQiJdOyBsZXQgaSA9IDA7CiAgd2hpbGUgKGIgPj0gMTAyNCAmJiBpIDwgdS5sZW5ndGgtMSl7IGIgLz0gMTAyNDsgaSsrOyB9CiAgcmV0dXJuIGIudG9GaXhlZChiIDwgMTAgJiYgaSA+IDAgPyAxIDogMCkgKyAiICIgKyB1W2ldOwp9Owpjb25zdCBhZ28gPSAodCkgPT4gewogIGlmICghdCkgcmV0dXJuICIiOwogIGNvbnN0IHMgPSBNYXRoLm1heCgwLCBNYXRoLmZsb29yKChEYXRlLm5vdygpIC0gdCAqIDEwMDApIC8gMTAwMCkpOwogIGlmIChzIDwgNjApIHJldHVybiBzICsgInMiOwogIGlmIChzIDwgMzYwMCkgcmV0dXJuIE1hdGguZmxvb3IocyAvIDYwKSArICJtICIgKyAocyAlIDYwKSArICJzIjsKICByZXR1cm4gTWF0aC5mbG9vcihzIC8gMzYwMCkgKyAiaCAiICsgTWF0aC5mbG9vcigocyAlIDM2MDApIC8gNjApICsgIm0iOwp9OwoKLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gam91cm5hbCAqLwpjb25zdCBKb3VybmFsID0gewogIGxpbmVzOiBbXSwgbWV0YToge30sIGxhc3RXcml0ZTogMCwgZGlydHk6IGZhbHNlLCBLRVk6ICJqb3VybmFsLmpzb24iLAogIG5vdGUobGluZSl7CiAgICB0aGlzLmxpbmVzLnB1c2gobGluZSk7CiAgICBpZiAodGhpcy5saW5lcy5sZW5ndGggPiAzMDAwKSB0aGlzLmxpbmVzLnNwbGljZSgwLCB0aGlzLmxpbmVzLmxlbmd0aCAtIDMwMDApOwogICAgdGhpcy5kaXJ0eSA9IHRydWU7CiAgfSwKICB1cGRhdGUoZil7IE9iamVjdC5hc3NpZ24odGhpcy5tZXRhLCBmKTsgdGhpcy5kaXJ0eSA9IHRydWU7IH0sCiAgYXN5bmMgZmx1c2goZm9yY2UpewogICAgaWYgKCF0aGlzLmRpcnR5KSByZXR1cm47CiAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpOwogICAgaWYgKCFmb3JjZSAmJiBub3cgLSB0aGlzLmxhc3RXcml0ZSA8IDI1MDApIHJldHVybjsKICAgIHRoaXMubGFzdFdyaXRlID0gbm93OyB0aGlzLmRpcnR5ID0gZmFsc2U7CiAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW0pTT04uc3RyaW5naWZ5KHsgbWV0YTogdGhpcy5tZXRhLCBsaW5lczogdGhpcy5saW5lcyB9KV0sCiAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0eXBlOiJhcHBsaWNhdGlvbi9qc29uIiB9KTsKICAgIHRyeSB7IGF3YWl0IFN0b3JlLnB1dEluKCJzZXNzaW9uIiwgdGhpcy5LRVksIGJsb2IpOyB9IGNhdGNoKGUpe30KICB9LAogIGFzeW5jIGxvYWQoKXsKICAgIHRyeSB7CiAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCBTdG9yZS5nZXRGcm9tKCJzZXNzaW9uIiwgdGhpcy5LRVkpOwogICAgICBpZiAoIWJsb2IpIHJldHVybiBudWxsOwogICAgICBjb25zdCBkYXRhID0gSlNPTi5wYXJzZShhd2FpdCBibG9iLnRleHQoKSk7CiAgICAgIHJldHVybiAoZGF0YSAmJiBkYXRhLmxpbmVzICYmIGRhdGEubGluZXMubGVuZ3RoKSA/IGRhdGEgOiBudWxsOwogICAgfSBjYXRjaChlKXsgcmV0dXJuIG51bGw7IH0KICB9LAogIGFzeW5jIGNsZWFyKCl7IHRyeSB7IGF3YWl0IFN0b3JlLnJlbW92ZSgic2Vzc2lvbiIsIHRoaXMuS0VZKTsgfSBjYXRjaChlKXt9IH0sCiAgc3VtbWFyeSgpeyBjb25zdCBtID0gdGhpcy5tZXRhIHx8IHt9OwogICAgICAgICAgICAgcmV0dXJuIChtLnBoYXNlIHx8ICI/IikgKyAobS5zdGFydGVkQXQgPyAiIMK3IHN0YXJ0ZWQgIiArIG5ldyBEYXRlKG0uc3RhcnRlZEF0KS50b0xvY2FsZVN0cmluZygpIDogIiIpOyB9Cn07CgovKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBjb25uZWN0aW9uICovCmNvbnN0IGhvc3RlZCA9ICEvXigxMjdcLjBcLjBcLjF8bG9jYWxob3N0fFxbOjoxXF0pJC8udGVzdChsb2NhdGlvbi5ob3N0bmFtZSk7CmZ1bmN0aW9uIGxzR2V0KGspeyB0cnkgeyByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oTFMrayk7IH0gY2F0Y2goZSl7IHJldHVybiBudWxsOyB9IH0KZnVuY3Rpb24gbHNTZXQoaywgdil7IHRyeSB7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKExTK2ssIHYpOyB9IGNhdGNoKGUpe30gfQpmdW5jdGlvbiBsc0RlbChrKXsgdHJ5IHsgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oTFMrayk7IH0gY2F0Y2goZSl7fSB9CgpmdW5jdGlvbiBhZG9wdEZyYWdtZW50KCl7CiAgY29uc3QgZiA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobG9jYXRpb24uaGFzaC5yZXBsYWNlKC9eIy8sICIiKSk7CiAgaWYgKGYuZ2V0KCJoZWxwZXIiKSkgc3RhdGUuaGVscGVyID0gZi5nZXQoImhlbHBlciIpLnJlcGxhY2UoL1wvJC8sICIiKTsKICBpZiAoZi5nZXQoInQiKSkgc3RhdGUudG9rZW4gPSBmLmdldCgidCIpOwogIGlmIChmLmdldCgiaGVscGVyIikpewogICAgaGlzdG9yeS5yZXBsYWNlU3RhdGUobnVsbCwgIiIsIGxvY2F0aW9uLnBhdGhuYW1lICsgbG9jYXRpb24uc2VhcmNoKTsKICAgIHJlbWVtYmVyKCk7CiAgfQp9CmZ1bmN0aW9uIHJlbWVtYmVyKCl7CiAgaWYgKCFzdGF0ZS5oZWxwZXIpIHJldHVybjsKICBsc1NldCgiaGVscGVyIiwgc3RhdGUuaGVscGVyKTsKICBpZiAoc3RhdGUudG9rZW4pIGxzU2V0KCJ0b2tlbiIsIHN0YXRlLnRva2VuKTsKfQpmdW5jdGlvbiBjb25uZWN0aW9uKCl7CiAgaWYgKHdpbmRvdy5fX1dFQk1DX18gJiYgd2luZG93Ll9fV0VCTUNfXy5oZWxwZXIpewogICAgc3RhdGUuaGVscGVyID0gd2luZG93Ll9fV0VCTUNfXy5oZWxwZXI7CiAgICBzdGF0ZS50b2tlbiA9IHdpbmRvdy5fX1dFQk1DX18udG9rZW47CiAgICByZXR1cm4gImhlbHBlciI7CiAgfQogIGFkb3B0RnJhZ21lbnQoKTsKICBpZiAoIXN0YXRlLmhlbHBlcil7IHN0YXRlLmhlbHBlciA9IGxzR2V0KCJoZWxwZXIiKTsgc3RhdGUudG9rZW4gPSBsc0dldCgidG9rZW4iKTsgfQogIGlmICghc3RhdGUuaGVscGVyICYmIC9eKDEyN1wuMFwuMFwuMXxsb2NhbGhvc3R8XFs6OjFcXSkkLy50ZXN0KGxvY2F0aW9uLmhvc3RuYW1lKSAmJiBsb2NhdGlvbi5wb3J0KXsKICAgIHN0YXRlLmhlbHBlciA9IGxvY2F0aW9uLm9yaWdpbjsKICAgIHJldHVybiAib3JpZ2luIjsKICB9CiAgcmV0dXJuIHN0YXRlLmhlbHBlciA/ICJzdG9yZWQiIDogIm5vbmUiOwp9CmFzeW5jIGZ1bmN0aW9uIGFwaShwYXRoLCBvcHRzKXsKICBjb25zdCBvID0gT2JqZWN0LmFzc2lnbih7IGNhY2hlOiJuby1zdG9yZSIgfSwgb3B0cyB8fCB7fSk7CiAgby5oZWFkZXJzID0gT2JqZWN0LmFzc2lnbih7fSwgby5oZWFkZXJzKTsKICBpZiAoc3RhdGUudG9rZW4pIG8uaGVhZGVyc1siWC1XZWJNQy1Ub2tlbiJdID0gc3RhdGUudG9rZW47CiAgaWYgKG8uYm9keSAmJiB0eXBlb2Ygby5ib2R5ID09PSAic3RyaW5nIikgby5oZWFkZXJzWyJDb250ZW50LVR5cGUiXSA9ICJhcHBsaWNhdGlvbi9qc29uIjsKICBpZiAoby50aW1lb3V0KXsgY29uc3QgYWMgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7IG8uc2lnbmFsID0gYWMuc2lnbmFsOwogICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGFjLmFib3J0KCksIG8udGltZW91dCk7IH0KICBjb25zdCByID0gYXdhaXQgZmV0Y2goc3RhdGUuaGVscGVyLnJlcGxhY2UoL1wvJC8sICIiKSArIHBhdGgsIG8pOwogIGlmICghci5vayl7CiAgICBsZXQgZGV0YWlsID0gci5zdGF0dXMgKyAiICIgKyByLnN0YXR1c1RleHQ7CiAgICB0cnkgeyBjb25zdCBqID0gYXdhaXQgci5qc29uKCk7IGlmIChqLmVycm9yKSBkZXRhaWwgPSBqLmVycm9yOyB9IGNhdGNoKGUpe30KICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcihkZXRhaWwpOyBlcnIuc3RhdHVzID0gci5zdGF0dXM7IHRocm93IGVycjsKICB9CiAgcmV0dXJuIHI7Cn0KY29uc3QgamdldCA9IGFzeW5jIChwLCB0KSA9PiAoYXdhaXQgYXBpKHAsIHsgdGltZW91dDogdCB9KSkuanNvbigpOwpmdW5jdGlvbiBzZXRDb25uKGtpbmQsIHRleHQpeyAkKCJjZCIpLmNsYXNzTmFtZSA9ICJjZG90ICIgKyBraW5kOyAkKCJjZG90MiIpLmNsYXNzTmFtZSA9ICJjZG90ICIgKyBraW5kOwogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAkKCJjdCIpLnRleHRDb250ZW50ID0gdGV4dDsgfQoKLyogaGFuZGluZyBvdmVyOiBhIHB1YmxpYyBwYWdlIG1heSBub3QgZmV0Y2ggb3IgZnJhbWUgMTI3LjAuMC4xLCBidXQgaXQgbWF5IG5hdmlnYXRlIHRvIGl0ICovCmZ1bmN0aW9uIGhhbmRPdmVyKCl7CiAgY29uc3QgbG9hZGVyID0gJCgibG9hZGVyIikudmFsdWUgPT09ICJjdXN0b20iCiAgICA/ICgkKCJsb2FkZXJjdXN0b20iKS52YWx1ZS50cmltKCkgfHwgInN0YWJsZSIpIDogJCgibG9hZGVyIikudmFsdWU7CiAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyh7IHBsYXk6IjEiLCB2OiAkKCJ2ZXJzaW9uIikudmFsdWUgfHwgIjEuMjEuMTEiLCBsOiBsb2FkZXIsCiAgICBtOiAoc3RhdGUuc2x1Z3MgfHwgW10pLmpvaW4oIiwiKSwgdTogJCgidXNlcm5hbWUiKS52YWx1ZS50cmltKCkgfHwgIlBsYXllciIsCiAgICBtZW06ICQoIm1lbW9yeSIpLnZhbHVlLnRyaW0oKSB8fCAiMkciIH0pOwogIGlmICgkKCJyZWxheSIpLnZhbHVlLnRyaW0oKSkgcGFyYW1zLnNldCgicmVsYXkiLCAkKCJyZWxheSIpLnZhbHVlLnRyaW0oKSk7CiAgbG9jYXRpb24uaHJlZiA9ICJodHRwOi8vMTI3LjAuMC4xOjc2NDUvIyIgKyBwYXJhbXMudG9TdHJpbmcoKTsKfQpmdW5jdGlvbiBzaG93T2ZmbGluZShraW5kKXsKICAkKCJwbGF5IikuZGlzYWJsZWQgPSBmYWxzZTsKICAkKCJvZmZsaW5lIikuc3R5bGUuZGlzcGxheSA9ICIiOwogIGNvbnN0IHQgPSAkKCJvZmZsaW5ldGV4dCIpOwogIGlmIChraW5kID09PSAidG9rZW4iKXsKICAgIHQuY2xhc3NOYW1lID0gImJhZCI7CiAgICB0LmlubmVySFRNTCA9ICJBIGhlbHBlciBpcyBsaXN0ZW5pbmcgdGhlcmUgYnV0IHJlamVjdGVkIHRoaXMgcGFnZSdzIHRva2VuIOKAlCBpdCB3YXMgc3RhcnRlZCBieSBhbiAiICsKICAgICAgImVhcmxpZXIgcnVuLiBTdG9wIGl0LCBzdGFydCBpdCBhZ2FpbiwgYW5kIHVzZSB0aGUgbGluayBpdCBvcGVucy4iOwogIH0gZWxzZSB7CiAgICB0LmNsYXNzTmFtZSA9ICJ3YXJuIjsKICAgIHQuaW5uZXJIVE1MID0gIk5vIGhlbHBlciBhbnN3ZXJlZCBvbiA8Y29kZT4iICsgKHN0YXRlLmhlbHBlciB8fCAidGhlIGhlbHBlciBhZGRyZXNzIikgKyAiPC9jb2RlPi4gIiArCiAgICAgICJFaXRoZXIgbm9uZSBpcyBydW5uaW5nLCBvciB0aGlzIGJyb3dzZXIgYmxvY2tlZCBsb2NhbCBuZXR3b3JrIGFjY2VzcyBmb3IgdGhpcyBzaXRlLiI7CiAgfQogICQoImdldGhlbHBlciIpLnN0eWxlLmRpc3BsYXkgPSBob3N0ZWQgPyAiIiA6ICJub25lIjsKICAkKCJ3aGVyZSIpLnRleHRDb250ZW50ID0gaG9zdGVkID8gImhvc3RlZCBwYWdlIMK3IGhlbHBlciBvbiB0aGlzIG1hY2hpbmUiIDogIuKAlCI7Cn0KYXN5bmMgZnVuY3Rpb24gcHJvYmUoZXhwbGljaXQpewogIGlmICghc3RhdGUuaGVscGVyKXsgc2V0Q29ubigiYmFkIiwgIm5vIGhlbHBlciBzZXQiKTsgc2hvd09mZmxpbmUoImRvd24iKTsgcmV0dXJuIGZhbHNlOyB9CiAgaWYgKGV4cGxpY2l0KSBzZXRDb25uKCJidXN5IiwgImNvbnRhY3RpbmfigKYiKTsKICB0cnkgewogICAgY29uc3QgaGVsbG8gPSBhd2FpdCBqZ2V0KCIvYXBpL2hlbGxvIiwgMjUwMCk7CiAgICBzdGF0ZS5vbmxpbmUgPSB0cnVlOyBzdGF0ZS5oZWxsbyA9IGhlbGxvOwogICAgaWYgKHR5cGVvZiBzaG93TWFjaGluZVN0YXRlID09PSAiZnVuY3Rpb24iKSBzaG93TWFjaGluZVN0YXRlKCk7CiAgICBpZiAodHlwZW9mIHNob3dSZWxheUluVXNlID09PSAiZnVuY3Rpb24iKSBzaG93UmVsYXlJblVzZSgpOwogICAgc2V0Q29ubigib2siLCAiaGVscGVyICIgKyBoZWxsby52ZXJzaW9uKTsKICAgICQoIm9mZmxpbmUiKS5zdHlsZS5kaXNwbGF5ID0gIm5vbmUiOwogICAgJCgid2hlcmUiKS50ZXh0Q29udGVudCA9IGhlbGxvLnBsYXRmb3JtLm9zICsgIi8iICsgaGVsbG8ucGxhdGZvcm0uYXJjaCArICIgwrcgIiArIFN0b3JlLmtpbmQgKwogICAgICAiIMK3ICIgKyAoaGVsbG8uc2Vzc2lvbnMgfHwgMCkgKyAiIHNlc3Npb24ocykiOwogICAgJCgiY29ubmhpbnQiKS5pbm5lckhUTUwgPSAiQ29ubmVjdGVkLiBEb3dubG9hZHMgIiArCiAgICAgIChoZWxsby5wcm94eSA9PT0gImRpcmVjdCIgPyAiZ28gc3RyYWlnaHQgb3V0IiA6ICJnbyB0aHJvdWdoIDxjb2RlPiIgKyBoZWxsby5wcm94eSArICI8L2NvZGU+IikgKwogICAgICAoaGVsbG8ucmVsYXkgPyAiIMK3IHJlbGF5IDxjb2RlPiIgKyBoZWxsby5yZWxheSArICI8L2NvZGU+IiA6ICIiKSArCiAgICAgICIgwrcgc2FuZGJveCA8Y29kZT4iICsgaGVsbG8uc2FuZGJveCArICI8L2NvZGU+LiI7CiAgICAkKCJhYm91dGt2cyIpLmlubmVySFRNTCA9ICJoZWxwZXIgIiArIGhlbGxvLnZlcnNpb24gKyAiIMK3ICIgKyBoZWxsby5wbGF0Zm9ybS5vcyArICIgIiArCiAgICAgIGhlbGxvLnBsYXRmb3JtLmFyY2ggKyAiIMK3IHByb3h5ICIgKyBoZWxsby5wcm94eSArICIgwrcgc3RvcmFnZSAiICsgU3RvcmUua2luZDsKICAgIGxzU2V0KCJzZWVuSGVscGVyIiwgIjEiKTsKICAgIHJlbWVtYmVyKCk7CiAgICAkKCJwbGF5IikuZGlzYWJsZWQgPSBmYWxzZTsKICAgIGxvYWRWZXJzaW9ucygpOwogICAgcmVmcmVzaCgpOwogICAgdXBkYXRlRmFjdHMoKTsKICAgIHJldHVybiB0cnVlOwogIH0gY2F0Y2ggKGUpewogICAgc3RhdGUub25saW5lID0gZmFsc2U7CiAgICBzZXRDb25uKCJiYWQiLCAoZSAmJiBlLnN0YXR1cyA9PT0gNDAzKSA/ICJ0b2tlbiByZWplY3RlZCIgOiAibm8gaGVscGVyIik7CiAgICAkKCJwbGF5IikuZGlzYWJsZWQgPSBmYWxzZTsKICAgICQoImNvbm5oaW50IikuaW5uZXJIVE1MID0gIkxhc3QgZXJyb3I6IDxjb2RlPiIgKyAoZS5tZXNzYWdlIHx8IGUpICsgIjwvY29kZT4iOwogICAgc2hvd09mZmxpbmUoKGUgJiYgZS5zdGF0dXMgPT09IDQwMykgPyAidG9rZW4iIDogImJsb2NrZWQiKTsKICAgIHJldHVybiBmYWxzZTsKICB9Cn0KCi8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IHZlcnNpb25zICovCmxldCB2ZXJzaW9uc0xvYWRlZCA9IGZhbHNlOwphc3luYyBmdW5jdGlvbiBsb2FkVmVyc2lvbnMoKXsKICBpZiAodmVyc2lvbnNMb2FkZWQgfHwgIXN0YXRlLm9ubGluZSkgcmV0dXJuOwogIGNvbnN0IHNlbCA9ICQoInZlcnNpb24iKTsKICB0cnkgewogICAgY29uc3QgaiA9IGF3YWl0IGpnZXQoIi9hcGkvdmVyc2lvbnMiLCAzMDAwMCk7CiAgICBjb25zdCB3YW50ID0gc2VsLmRhdGFzZXQud2FudCB8fCAiMS4yMS4xMSI7CiAgICBzZWwuaW5uZXJIVE1MID0gIiI7CiAgICBmb3IgKGNvbnN0IGlkIG9mIGoucmVsZWFzZXMuc2xpY2UoMCwgMzApKXsKICAgICAgY29uc3QgbyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoIm9wdGlvbiIpOyBvLnZhbHVlID0gaWQ7IG8udGV4dENvbnRlbnQgPSBpZDsKICAgICAgc2VsLmFwcGVuZENoaWxkKG8pOwogICAgfQogICAgc2VsLnZhbHVlID0gWy4uLnNlbC5vcHRpb25zXS5zb21lKG8gPT4gby52YWx1ZSA9PT0gd2FudCkgPyB3YW50IDogKHNlbC5vcHRpb25zWzBdIHx8IHt9KS52YWx1ZTsKICAgIHZlcnNpb25zTG9hZGVkID0gdHJ1ZTsKICB9IGNhdGNoIChlKXsKICAgIHNlbC5pbm5lckhUTUwgPSAnPG9wdGlvbiB2YWx1ZT0iMS4yMS4xMSI+MS4yMS4xMSAodGhlIGxpc3QgY291bGQgbm90IGJlIHJlYWQpPC9vcHRpb24+JzsKICB9Cn0KCi8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IHNlc3Npb25zICovCmZ1bmN0aW9uIG5vdGVQcm9ncmVzcyhzKXsKICAvLyBPbmUgbGluZSBvZiBwbGFpbiBsYW5ndWFnZSBmb3Igd2hhdGV2ZXIgdGhlIG5ld2VzdCBzZXNzaW9uIGlzIGRvaW5nLiBUaGVyZSBpcyBubyBsaXN0OiBhCiAgLy8gc2Vzc2lvbiBpcyBzYXZlZCBmb3IgeW91IHdoZW4gaXQgZW5kcywgc28gdGhlcmUgaXMgbm90aGluZyB0byBwcmVzcy4KICBpZiAoIXMpeyAkKCJwaGFzZSIpLnRleHRDb250ZW50ID0gIlJlYWR5IjsgJCgiaW5zdGFuY2UiKS50ZXh0Q29udGVudCA9ICIiOyByZXR1cm47IH0KICBjb25zdCBpbnN0ID0gcy5pbnN0YW5jZSB8fCB7fTsKICBjb25zdCBwID0gcy5wcm9ncmVzcyB8fCB7fTsKICBjb25zdCBiYXIgPSAkKCJiYXIiKTsKICAkKCJwaGFzZSIpLnRleHRDb250ZW50ID0gcy5waGFzZUxhYmVsIHx8IHMucGhhc2UgfHwgcy5zdGF0ZTsKICBjb25zdCBwZXJjZW50ID0gKHAucGVyY2VudCA9PT0gbnVsbCB8fCBwLnBlcmNlbnQgPT09IHVuZGVmaW5lZCkgPyBudWxsIDogcC5wZXJjZW50OwogIGlmIChzLnN0YXRlID09PSAicnVubmluZyIgJiYgcGVyY2VudCA9PT0gbnVsbCl7CiAgICBiYXIuY2xhc3NOYW1lID0gImJhciBpbmRldCI7CiAgICAkKCJwY3QiKS50ZXh0Q29udGVudCA9IHAudG90YWwgPyAocC5kb25lICsgIiAvICIgKyBwLnRvdGFsKSA6ICIiOwogIH0gZWxzZSB7CiAgICBiYXIuY2xhc3NOYW1lID0gImJhciI7CiAgICBiYXIuZmlyc3RDaGlsZC5zdHlsZS53aWR0aCA9IChwZXJjZW50IHx8IChzLnN0YXRlID09PSAicnVubmluZyIgPyAwIDogMTAwKSkgKyAiJSI7CiAgICAkKCJwY3QiKS50ZXh0Q29udGVudCA9IHBlcmNlbnQgPT09IG51bGwgPyAiIiA6IHBlcmNlbnQgKyAiJSAgKCIgKyBwLmRvbmUgKyAiIC8gIiArIHAudG90YWwgKyAiKSI7CiAgfQogICQoImluc3RhbmNlIikudGV4dENvbnRlbnQgPSBpbnN0LnZlcnNpb24KICAgID8gIiDCtyAiICsgaW5zdC52ZXJzaW9uICsgIiDCtyAiICsgKGluc3QubG9hZGVyIHx8ICJ2YW5pbGxhIikgKwogICAgICAoaW5zdC5tb2RzICYmIGluc3QubW9kcy5sZW5ndGggPyAiIMK3ICIgKyBpbnN0Lm1vZHMubGVuZ3RoICsgIiBtb2QocykiIDogIiIpCiAgICA6ICIiOwogICQoIm5ldHN0YXQiKS50ZXh0Q29udGVudCA9IHMuZG93bmxvYWRlZEJ5dGVzID8gImRvd25sb2FkZWQgIiArIGZtdChzLmRvd25sb2FkZWRCeXRlcykgOiAiIjsKICAkKCJjaGlwUnVubmluZyIpLnRleHRDb250ZW50ID0gcy5zdGF0ZSA9PT0gInJ1bm5pbmciID8gInJ1bm5pbmciIDogKHMuc2lkID8gImxhc3Qgc2Vzc2lvbiIgOiAiaWRsZSIpOwogICQoImNoaXBSdW5uaW5nIikuY2xhc3NOYW1lID0gImNoaXAiICsgKHMuc3RhdGUgPT09ICJydW5uaW5nIiA/ICIgb24iIDogIiIpOwp9CgovKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBtb2RzICovCmFzeW5jIGZ1bmN0aW9uIHJlbmRlck1vZHMoKXsKICBjb25zdCBpdGVtcyA9IGF3YWl0IFN0b3JlLmxpc3QoIm1vZHMiKTsKICBjb25zdCBsaXN0ID0gJCgibW9kbGlzdCIpOwogIGxpc3QuaW5uZXJIVE1MID0gIiI7CiAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKXsKICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgibGkiKTsKICAgIGxpLmlubmVySFRNTCA9ICc8c3BhbiBjbGFzcz0ibm0iPicgKyBpdGVtLm5hbWUgKyAnPC9zcGFuPjxzcGFuIGNsYXNzPSJ0YWcgbWluZSI+bWluZTwvc3Bhbj4nICsKICAgICAgICAgICAgICAgICAgICc8c3BhbiBjbGFzcz0ibWV0YSI+JyArIChpdGVtLnNpemUgPyBmbXQoaXRlbS5zaXplKSA6ICIiKSArICI8L3NwYW4+IjsKICAgIGNvbnN0IGRlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoImJ1dHRvbiIpOyBkZWwuY2xhc3NOYW1lID0gInRpbnkiOyBkZWwudGV4dENvbnRlbnQgPSAicmVtb3ZlIjsKICAgIGRlbC5vbmNsaWNrID0gYXN5bmMgKCkgPT4gewogICAgICBhd2FpdCBTdG9yZS5yZW1vdmUoIm1vZHMiLCBpdGVtLm5hbWUpOwogICAgICBpZiAoc3RhdGUub25saW5lKXsgdHJ5IHsgYXdhaXQgYXBpKCIvYXBpL2xvY2FsbW9kcz9kcm9wPSIgKyBlbmNvZGVVUklDb21wb25lbnQoaXRlbS5uYW1lKSwge21ldGhvZDoiUE9TVCJ9KTsgfSBjYXRjaChlKXt9IH0KICAgICAgbG9nTGluZSgicmVtb3ZlZCAiICsgaXRlbS5uYW1lICsgIiBmcm9tIHRoaXMgYnJvd3NlciIpOwogICAgICByZW5kZXJNb2RzKCk7CiAgICB9OwogICAgbGkuYXBwZW5kQ2hpbGQoZGVsKTsKICAgIGxpc3QuYXBwZW5kQ2hpbGQobGkpOwogIH0KICBmb3IgKGNvbnN0IHNsdWcgb2Ygc3RhdGUuc2x1Z3MpewogICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCJsaSIpOwogICAgbGkuaW5uZXJIVE1MID0gJzxzcGFuIGNsYXNzPSJubSI+JyArIChzdGF0ZS5zbHVnc01ldGFbc2x1Z10gfHwgc2x1ZykgKyAnPC9zcGFuPicgKwogICAgICAgICAgICAgICAgICAgJzxzcGFuIGNsYXNzPSJ0YWcgaHViIj5tb2RyaW50aDwvc3Bhbj4nOwogICAgY29uc3QgZGVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgiYnV0dG9uIik7IGRlbC5jbGFzc05hbWUgPSAidGlueSI7IGRlbC50ZXh0Q29udGVudCA9ICJyZW1vdmUiOwogICAgZGVsLm9uY2xpY2sgPSAoKSA9PiB7IHN0YXRlLnNsdWdzID0gc3RhdGUuc2x1Z3MuZmlsdGVyKHMgPT4gcyAhPT0gc2x1Zyk7IHNhdmVTbHVncygpOyByZW5kZXJNb2RzKCk7IH07CiAgICBsaS5hcHBlbmRDaGlsZChkZWwpOwogICAgbGlzdC5hcHBlbmRDaGlsZChsaSk7CiAgfQogIGNvbnN0IHRvdGFsID0gaXRlbXMubGVuZ3RoICsgc3RhdGUuc2x1Z3MubGVuZ3RoOwogICQoIm1vZGNvdW50IikudGV4dENvbnRlbnQgPSB0b3RhbCA/IHRvdGFsICsgIiBhZGRlZCIgOiAibm9uZSB5ZXQiOwogICQoImNoaXBNb2RzIikudGV4dENvbnRlbnQgPSB0b3RhbCA/IHRvdGFsICsgIiBtb2QocykiIDogIm5vIG1vZHMiOwogICQoIm1vZGhpbnQiKS50ZXh0Q29udGVudCA9IHRvdGFsCiAgICA/ICJZb3VyIGphcnMgYXJlIHN0b3JlZCBpbiB0aGlzIGJyb3dzZXIgYW5kIGhhbmRlZCB0byB0aGUgaGVscGVyIGJlZm9yZSBlYWNoIGxhdW5jaC4iIDogIiI7Cn0KZnVuY3Rpb24gc2F2ZVNsdWdzKCl7CiAgbHNTZXQoInNsdWdzIiwgSlNPTi5zdHJpbmdpZnkoc3RhdGUuc2x1Z3MpKTsKICBsc1NldCgic2x1Z3NNZXRhIiwgSlNPTi5zdHJpbmdpZnkoc3RhdGUuc2x1Z3NNZXRhKSk7Cn0KZnVuY3Rpb24gbG9hZFNsdWdzKCl7CiAgdHJ5IHsKICAgIHN0YXRlLnNsdWdzID0gSlNPTi5wYXJzZShsc0dldCgic2x1Z3MiKSB8fCAiW10iKTsKICAgIHN0YXRlLnNsdWdzTWV0YSA9IEpTT04ucGFyc2UobHNHZXQoInNsdWdzTWV0YSIpIHx8ICJ7fSIpOwogIH0gY2F0Y2goZSl7IHN0YXRlLnNsdWdzID0gW107IHN0YXRlLnNsdWdzTWV0YSA9IHt9OyB9Cn0KYXN5bmMgZnVuY3Rpb24gYWRkRmlsZXMoZmlsZXMpewogIGZvciAoY29uc3QgZmlsZSBvZiBmaWxlcyl7CiAgICBpZiAoIS9cLmphciQvaS50ZXN0KGZpbGUubmFtZSkpeyBsb2dMaW5lKCJza2lwcGVkICIgKyBmaWxlLm5hbWUgKyAiIOKAlCBub3QgYSAuamFyIiwgImUiKTsgY29udGludWU7IH0KICAgIGlmIChmaWxlLnNpemUgPiA2NCoxMDI0KjEwMjQpeyBsb2dMaW5lKCJza2lwcGVkICIgKyBmaWxlLm5hbWUgKyAiIOKAlCBsYXJnZXIgdGhhbiA2NCBNQiIsICJlIik7IGNvbnRpbnVlOyB9CiAgICBhd2FpdCBTdG9yZS5wdXRJbigibW9kcyIsIGZpbGUubmFtZSwgZmlsZSk7CiAgICBsb2dMaW5lKCJrZXB0ICIgKyBmaWxlLm5hbWUgKyAiICgiICsgZm10KGZpbGUuc2l6ZSkgKyAiKSBpbiB0aGlzIGJyb3dzZXIiKTsKICAgIGlmIChzdGF0ZS5vbmxpbmUpewogICAgICB0cnkgewogICAgICAgIGNvbnN0IHIgPSBhd2FpdCAoYXdhaXQgYXBpKCIvYXBpL2xvY2FsbW9kcyIsIHsgbWV0aG9kOiJQT1NUIiwKICAgICAgICAgIGhlYWRlcnM6eyAiWC1XZWJNQy1Nb2QtTmFtZSI6IGZpbGUubmFtZSB9LCBib2R5OiBmaWxlLCB0aW1lb3V0OjYwMDAwIH0pKS5qc29uKCk7CiAgICAgICAgbG9nTGluZSgiaGVscGVyIGFjY2VwdGVkICIgKyByLm5hbWUgKyAoci50aXRsZSA/ICIgKCIgKyByLnRpdGxlICsgIiAiICsgKHIudmVyc2lvbnx8IiIpICsgIikiIDogIiIpLCAiZyIpOwogICAgICB9IGNhdGNoIChlKXsKICAgICAgICBsb2dMaW5lKCJoZWxwZXIgcmVmdXNlZCAiICsgZmlsZS5uYW1lICsgIjogIiArIGUubWVzc2FnZSwgImUiKTsKICAgICAgICBhd2FpdCBTdG9yZS5yZW1vdmUoIm1vZHMiLCBmaWxlLm5hbWUpOwogICAgICB9CiAgICB9CiAgfQogIGF3YWl0IFN0b3JlLnBlcnNpc3QoKTsKICByZW5kZXJNb2RzKCk7Cn0KYXN5bmMgZnVuY3Rpb24gcHVzaE1vZHMoKXsKICBjb25zdCBpdGVtcyA9IGF3YWl0IFN0b3JlLmxpc3QoIm1vZHMiKTsKICBsZXQgcHVzaGVkID0gMDsKICBmb3IgKGNvbnN0IGl0ZW0gb2YgaXRlbXMpewogICAgY29uc3QgYmxvYiA9IGF3YWl0IFN0b3JlLmdldEZyb20oIm1vZHMiLCBpdGVtLm5hbWUpOwogICAgaWYgKCFibG9iKSBjb250aW51ZTsKICAgIHRyeSB7CiAgICAgIGF3YWl0IGFwaSgiL2FwaS9sb2NhbG1vZHMiLCB7IG1ldGhvZDoiUE9TVCIsIGhlYWRlcnM6eyAiWC1XZWJNQy1Nb2QtTmFtZSI6IGl0ZW0ubmFtZSB9LAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib2R5OiBibG9iLCB0aW1lb3V0OjYwMDAwIH0pOwogICAgICBwdXNoZWQrKzsKICAgIH0gY2F0Y2ggKGUpeyBsb2dMaW5lKCJjb3VsZCBub3QgaGFuZCAiICsgaXRlbS5uYW1lICsgIiB0byB0aGUgaGVscGVyOiAiICsgZS5tZXNzYWdlLCAiZSIpOyB9CiAgfQogIGlmIChwdXNoZWQpIGxvZ0xpbmUoImhhbmRlZCAiICsgcHVzaGVkICsgIiBvZiB5b3VyIG1vZCBqYXIocykgdG8gdGhlIGhlbHBlciIsICJnIik7CiAgcmV0dXJuIHB1c2hlZDsKfQphc3luYyBmdW5jdGlvbiBzZWFyY2hNb2RzKCl7CiAgY29uc3QgcSA9ICQoInNlYXJjaCIpLnZhbHVlLnRyaW0oKTsKICBpZiAoIXEpeyAkKCJzZWFyY2hoaW50IikudGV4dENvbnRlbnQgPSAiVHlwZSBzb21ldGhpbmcgdG8gc2VhcmNoIGZvci4iOyByZXR1cm47IH0KICAkKCJyZXN1bHRzIikuaW5uZXJIVE1MID0gIiI7CiAgJCgic2VhcmNoaGludCIpLmNsYXNzTmFtZSA9ICJoaW50IjsgJCgic2VhcmNoaGludCIpLnRleHRDb250ZW50ID0gInNlYXJjaGluZ+KApiI7CiAgY29uc3QgbWMgPSAkKCJ2ZXJzaW9uIikudmFsdWUgfHwgIjEuMjEuMTEiOwogIHRyeSB7CiAgICBjb25zdCBqID0gYXdhaXQgamdldCgiL2FwaS9zZWFyY2g/cT0iICsgZW5jb2RlVVJJQ29tcG9uZW50KHEpICsgIiZtYz0iICsgZW5jb2RlVVJJQ29tcG9uZW50KG1jKSwgNDUwMDApOwogICAgaWYgKCFqLnJlc3VsdHMubGVuZ3RoKXsgJCgic2VhcmNoaGludCIpLnRleHRDb250ZW50ID0gIm5vdGhpbmcgbWF0Y2hlZC4iOyByZXR1cm47IH0KICAgICQoInNlYXJjaGhpbnQiKS50ZXh0Q29udGVudCA9IGoucmVzdWx0cy5sZW5ndGggKyAiIHJlc3VsdHMgZnJvbSBNb2RyaW50aCAoRmFicmljLCAiICsgbWMgKyAiKSI7CiAgICBmb3IgKGNvbnN0IHIgb2Ygai5yZXN1bHRzKXsKICAgICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCJsaSIpOwogICAgICBsaS5pbm5lckhUTUwgPSAnPGRpdiBjbGFzcz0ibm0iPjxiPicgKyByLnRpdGxlICsgIjwvYj48ZGl2PiIgKyByLmRlc2NyaXB0aW9uICsgIjwvZGl2PjwvZGl2PiI7CiAgICAgIGNvbnN0IGFkZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoImJ1dHRvbiIpOwogICAgICBhZGQuY2xhc3NOYW1lID0gInRpbnkiOwogICAgICBhZGQudGV4dENvbnRlbnQgPSBzdGF0ZS5zbHVncy5pbmNsdWRlcyhyLnNsdWcpID8gImFkZGVkIiA6ICJhZGQiOwogICAgICBhZGQuZGlzYWJsZWQgPSBzdGF0ZS5zbHVncy5pbmNsdWRlcyhyLnNsdWcpOwogICAgICBhZGQub25jbGljayA9ICgpID0+IHsKICAgICAgICBzdGF0ZS5zbHVncy5wdXNoKHIuc2x1Zyk7IHN0YXRlLnNsdWdzTWV0YVtyLnNsdWddID0gci50aXRsZTsKICAgICAgICBzYXZlU2x1Z3MoKTsgcmVuZGVyTW9kcygpOwogICAgICAgIGFkZC50ZXh0Q29udGVudCA9ICJhZGRlZCI7IGFkZC5kaXNhYmxlZCA9IHRydWU7CiAgICAgICAgbG9nTGluZSgid2lsbCBmZXRjaCAiICsgci50aXRsZSArICIgZnJvbSBNb2RyaW50aCB3aGVuIHlvdSBwbGF5Iik7CiAgICAgIH07CiAgICAgIGxpLmFwcGVuZENoaWxkKGFkZCk7CiAgICAgICQoInJlc3VsdHMiKS5hcHBlbmRDaGlsZChsaSk7CiAgICB9CiAgfSBjYXRjaCAoZSl7CiAgICAkKCJzZWFyY2hoaW50IikuY2xhc3NOYW1lID0gIndhcm4iOwogICAgJCgic2VhcmNoaGludCIpLnRleHRDb250ZW50ID0gInNlYXJjaCBmYWlsZWQ6ICIgKyBlLm1lc3NhZ2U7CiAgfQp9CgovKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBzdGF0dXMgKyBsb2cgKi8KZnVuY3Rpb24gbG9nTGluZSh0ZXh0LCBjbHMpewogIGNvbnN0IGVsID0gJCgibG9nIik7CiAgY29uc3QgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgiZGl2Iik7CiAgaWYgKGNscykgZGl2LmNsYXNzTmFtZSA9IGNsczsKICBlbHNlIGlmICgvXGJFUlJPUlxifEV4Y2VwdGlvbnxGQUlMRUR8Y3Jhc2gvaS50ZXN0KHRleHQpKSBkaXYuY2xhc3NOYW1lID0gImUiOwogIGVsc2UgaWYgKC9mYWJyaWN8TG9hZGluZyBcZCsgbW9kc3xpcyBydW5uaW5nfGFjY2VwdGVkfHJlc3RvcmVkfGRlbGV0ZWR8a2VwdCAvaS50ZXN0KHRleHQpKSBkaXYuY2xhc3NOYW1lID0gImciOwogIGVsc2UgaWYgKC9eXFtwYWdlXF0vLnRlc3QodGV4dCkpIGRpdi5jbGFzc05hbWUgPSAiZCI7CiAgZGl2LnRleHRDb250ZW50ID0gdGV4dDsKICBlbC5hcHBlbmRDaGlsZChkaXYpOwogIHdoaWxlIChlbC5jaGlsZE5vZGVzLmxlbmd0aCA+IDEyMDApIGVsLnJlbW92ZUNoaWxkKGVsLmZpcnN0Q2hpbGQpOwogIGVsLnNjcm9sbFRvcCA9IGVsLnNjcm9sbEhlaWdodDsKfQoKYXN5bmMgZnVuY3Rpb24gcmVmcmVzaCgpewogIGlmICghc3RhdGUub25saW5lKSByZXR1cm47CiAgbGV0IGRhdGE7CiAgdHJ5IHsgZGF0YSA9IGF3YWl0IGpnZXQoIi9hcGkvc2Vzc2lvbnMiLCA4MDAwKTsgfSBjYXRjaChlKXsgcmV0dXJuOyB9CiAgY29uc3QgcHJldmlvdXMgPSBzdGF0ZS5zZXNzaW9ucyB8fCBbXTsKICBzdGF0ZS5zZXNzaW9ucyA9IGRhdGEuc2Vzc2lvbnMgfHwgW107CiAgY29uc3QgcnVubmluZyA9IHN0YXRlLnNlc3Npb25zLmZpbHRlcihzID0+IHMuc3RhdGUgPT09ICJydW5uaW5nIik7CiAgY29uc3QgbmV3ZXN0ID0gc3RhdGUuc2Vzc2lvbnNbMF0gfHwgbnVsbDsKICBpZiAobmV3ZXN0KSBzdGF0ZS5zZWxlY3RlZCA9IG5ld2VzdC5zaWQ7CiAgbm90ZVByb2dyZXNzKG5ld2VzdCk7CiAgJCgibG9nU3RhdGUiKS50ZXh0Q29udGVudCA9IHJ1bm5pbmcubGVuZ3RoCiAgICA/IHJ1bm5pbmcubGVuZ3RoICsgKHJ1bm5pbmcubGVuZ3RoID09PSAxID8gIiBydW5uaW5nIiA6ICIgcnVubmluZyIpIDogImlkbGUiOwogIEpvdXJuYWwudXBkYXRlKHsgcGhhc2U6ICQoInBoYXNlIikudGV4dENvbnRlbnQsIHN0YXRlOiBydW5uaW5nLmxlbmd0aCA/ICJydW5uaW5nIiA6ICJpZGxlIiwKICAgICAgICAgICAgICAgICAgIHN0YXJ0ZWRBdDogbmV3ZXN0ICYmIG5ld2VzdC5zdGFydGVkQXQgPyBuZXdlc3Quc3RhcnRlZEF0ICogMTAwMCA6IG51bGwgfSk7CiAgSm91cm5hbC5mbHVzaCgpOwogIHVwZGF0ZUZhY3RzKCk7CiAgLy8gQSBzZXNzaW9uIHRoYXQgZW5kZWQgd2hpbGUgd2Ugd2VyZSB3YXRjaGluZzogaXRzIGZpbGVzIGFyZSB0YWtlbiBhbmQgc3RvcmVkIGhlcmUsIHRoZW4gdGhlCiAgLy8gaGVscGVyIGlzIHRvbGQgdG8gZGVsZXRlIHRoZSBzYW5kYm94LiBOb2JvZHkgaGFzIHRvIHByZXNzIGFueXRoaW5nLgogIGZvciAoY29uc3QgcyBvZiBzdGF0ZS5zZXNzaW9ucyl7CiAgICBjb25zdCB3YXMgPSBwcmV2aW91cy5maW5kKHggPT4geC5zaWQgPT09IHMuc2lkKSB8fCB7fTsKICAgIGlmICh3YXMuc3RhdGUgPT09ICJydW5uaW5nIiAmJiBzLnN0YXRlICE9PSAicnVubmluZyIpIGF3YWl0IHNlc3Npb25FbmRlZChzKTsKICB9CiAgcG9sbExvZygpOwp9Cgphc3luYyBmdW5jdGlvbiBwb2xsTG9nKCl7CiAgaWYgKCFzdGF0ZS5vbmxpbmUgfHwgIXN0YXRlLnNlbGVjdGVkKSByZXR1cm47CiAgY29uc3Qgc2lkID0gc3RhdGUuc2VsZWN0ZWQ7CiAgY29uc3Qgc2luY2UgPSBzdGF0ZS5zaW5jZVtzaWRdIHx8IDA7CiAgdHJ5IHsKICAgIGNvbnN0IGogPSBhd2FpdCBqZ2V0KCIvYXBpL2xvZz9pZD0iICsgZW5jb2RlVVJJQ29tcG9uZW50KHNpZCkgKyAiJnNpbmNlPSIgKyBzaW5jZSwgODAwMCk7CiAgICBpZiAoc2lkID09PSBzdGF0ZS5zZWxlY3RlZCl7CiAgICAgIGZvciAoY29uc3QgbGluZSBvZiBqLmxpbmVzKXsgbG9nTGluZShsaW5lKTsgSm91cm5hbC5ub3RlKGxpbmUpOyB9CiAgICB9CiAgICBzdGF0ZS5zaW5jZVtzaWRdID0gai5uZXh0OwogICAgYXdhaXQgSm91cm5hbC5mbHVzaCgpOwogIH0gY2F0Y2goZSl7fQp9Cgphc3luYyBmdW5jdGlvbiBzZXNzaW9uRW5kZWQocyl7CiAgY29uc3QgcmVzID0gcy5yZXN1bHQ7CiAgaWYgKCFyZXMpIHJldHVybjsKICBsb2dMaW5lKCJzZXNzaW9uICIgKyBzLnNpZCArICIgZmluaXNoZWQg4oCUICIgKyByZXMuZmlsZXMgKyAiIGZpbGUocyksICIgKyBmbXQocmVzLmJ5dGVzKSArCiAgICAgICAgICAocmVzLndvcmxkcyAmJiByZXMud29ybGRzLmxlbmd0aCA/ICIsIHdvcmxkKHMpOiAiICsgcmVzLndvcmxkcy5qb2luKCIsICIpIDogIiIpLCAiZyIpOwogIGxldCBjbGVhbnVwID0gbnVsbDsKICB0cnkgewogICAgY29uc3QgYmxvYiA9IGF3YWl0IChhd2FpdCBhcGkoIi9hcGkvYnVuZGxlLnppcD9pZD0iICsgZW5jb2RlVVJJQ29tcG9uZW50KHMuc2lkKSwKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdGltZW91dDoxODAwMDAgfSkpLmJsb2IoKTsKICAgIC8vIHNhdmVkIGhlcmUsIGluIHRoaXMgYnJvd3Nlciwgd2l0aG91dCBiZWluZyBhc2tlZDogdGhlIHdvcmxkIGNvbWVzIGJhY2sgb24gdGhlIG5leHQgUExBWQogICAgYXdhaXQgU3RvcmUucHV0KCJsYXN0LXNlc3Npb24uemlwIiwgYmxvYik7CiAgICBhd2FpdCBTdG9yZS5wZXJzaXN0KCk7CiAgICBsb2dMaW5lKCJzdG9yZWQgIiArIGZtdChibG9iLnNpemUpICsgIiBpbiAiICsgU3RvcmUua2luZCwgImciKTsKICB9IGNhdGNoIChlKXsKICAgIGlmIChlICYmIGUuc3RhdHVzID09PSA0MDQpIGxvZ0xpbmUoInRoYXQgc2Vzc2lvbidzIGZpbGVzIHdlcmUgYWxyZWFkeSBjb2xsZWN0ZWQiLCAiZyIpOwogICAgZWxzZSBsb2dMaW5lKCJjb3VsZCBub3Qgc3RvcmUgdGhlIHNlc3Npb246ICIgKyBlLm1lc3NhZ2UsICJlIik7CiAgfQogIHRyeSB7CiAgICBjbGVhbnVwID0gYXdhaXQgKGF3YWl0IGFwaSgiL2FwaS9jbGVhbnVwP2lkPSIgKyBlbmNvZGVVUklDb21wb25lbnQocy5zaWQpLAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBtZXRob2Q6IlBPU1QiLCB0aW1lb3V0OjYwMDAwIH0pKS5qc29uKCk7CiAgICBsb2dMaW5lKCJoZWxwZXIgZGVsZXRlZCAiICsgY2xlYW51cC5wYXRoICsKICAgICAgICAgICAgKGNsZWFudXAucmVtb3ZlZCA/ICIgKCIgKyBmbXQoY2xlYW51cC5yZW1vdmVkKSArICIgZnJlZWQpIiA6ICIiKSwgImciKTsKICB9IGNhdGNoIChlKXsgbG9nTGluZSgiY291bGQgbm90IGFzayB0aGUgaGVscGVyIHRvIGNsZWFuIHVwOiAiICsgZS5tZXNzYWdlLCAiZSIpOyB9CiAgc2hvd1JlY2VpcHQocmVzLCBjbGVhbnVwLCBzLnNpZCk7Cn0KCmZ1bmN0aW9uIHNob3dSZWNlaXB0KHJlcywgY2xlYW51cCwgc2lkKXsKICBpZiAoIXJlcyAmJiAhY2xlYW51cCkgcmV0dXJuOwogIGNvbnN0IGJveCA9ICQoInJlY2VpcHQiKTsKICBib3guc3R5bGUuZGlzcGxheSA9ICIiOyBib3guaW5uZXJIVE1MID0gIiI7CiAgY29uc3QgaCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoImgzIik7CiAgaC50ZXh0Q29udGVudCA9ICJTZXNzaW9uIGZpbmlzaGVkIOKAlCBub3RoaW5nIGxlZnQgb24gdGhpcyBjb21wdXRlciI7CiAgYm94LmFwcGVuZENoaWxkKGgpOwogIGNvbnN0IGxpbmVzID0gW107CiAgaWYgKHJlcyl7CiAgICBsaW5lcy5wdXNoKChyZXMud29ybGRzICYmIHJlcy53b3JsZHMubGVuZ3RoKQogICAgICA/ICI8Yj4iICsgcmVzLndvcmxkcy5sZW5ndGggKyAiIHdvcmxkKHMpPC9iPiBzYXZlZCB0byB0aGlzIGJyb3dzZXI6ICIgKyByZXMud29ybGRzLmpvaW4oIiwgIikKICAgICAgOiAiTm8gd29ybGQgd2FzIGNyZWF0ZWQgaW4gdGhpcyBzZXNzaW9uLiIpOwogICAgbGluZXMucHVzaCgiPGI+IiArIHJlcy5maWxlcyArICIgZmlsZXM8L2I+ICgiICsgZm10KHJlcy5ieXRlcykgKyAiKSBrZXB0IGluIHRoaXMgYnJvd3NlciBhbmQgYnkgIiArCiAgICAgICAgICAgICAgICJ0aGUgaGVscGVyLCBzbyB0aGUgbmV4dCBsYXVuY2ggc3RhcnRzIGZyb20gdGhlbSB3aGljaGV2ZXIgcGFnZSB5b3UgdXNlLiIpOwogICAgaWYgKHJlcy5oYXNDcmFzaCkgbGluZXMucHVzaCgiQSBjcmFzaCByZXBvcnQgd2FzIGluY2x1ZGVkIOKAlCBpdCBpcyBpbiB0aGUgemlwIGJlbG93LiIpOwogIH0KICBpZiAoY2xlYW51cCAmJiBjbGVhbnVwLmdvbmUpCiAgICBsaW5lcy5wdXNoKCJUaGUgaGVscGVyIGRlbGV0ZWQgPGI+IiArIGNsZWFudXAucGF0aCArICI8L2I+IiArCiAgICAgICAgICAgICAgIChjbGVhbnVwLnJlbW92ZWQgPyAiICgiICsgZm10KGNsZWFudXAucmVtb3ZlZCkgKyAiIGZyZWVkKSIgOiAiIikgKyAiLiIpOwogIGNvbnN0IGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoImRpdiIpOwogIGRpdi5jbGFzc05hbWUgPSAibGluZSI7CiAgZGl2LmlubmVySFRNTCA9IGxpbmVzLm1hcChsID0+ICLinJQgIiArIGwpLmpvaW4oIjxicj4iKTsKICBib3guYXBwZW5kQ2hpbGQoZGl2KTsKICBjb25zdCBhY3RzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgiZGl2Iik7CiAgYWN0cy5zdHlsZS5tYXJnaW5Ub3AgPSAiMTFweCI7CiAgYWN0cy5pbm5lckhUTUwgPSAnPGEgaHJlZj0iIyIgaWQ9ImRsemlwIj5kb3dubG9hZCB0aGUgc2Vzc2lvbiB6aXA8L2E+ICZuYnNwO8K3Jm5ic3A7ICcgKwogICAgICAgICAgICAgICAgICAgJzxhIGhyZWY9IiMiIGlkPSJkZWxzZXNzaW9uIj5mb3JnZXQgZXZlcnl0aGluZyB0aGlzIHBhZ2Ugc3RvcmVkPC9hPic7CiAgYm94LmFwcGVuZENoaWxkKGFjdHMpOwogICQoImRsemlwIikub25jbGljayA9IGFzeW5jIChlKSA9PiB7CiAgICBlLnByZXZlbnREZWZhdWx0KCk7CiAgICBjb25zdCBibG9iID0gYXdhaXQgU3RvcmUuZ2V0KHNpZCA/ICJzZXNzaW9uLSIgKyBzaWQgKyAiLnppcCIgOiAibGFzdC1zZXNzaW9uLnppcCIpOwogICAgaWYgKCFibG9iKSByZXR1cm47CiAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgiYSIpOwogICAgYS5ocmVmID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTsgYS5kb3dubG9hZCA9ICJ3ZWJtYy1zZXNzaW9uLnppcCI7IGEuY2xpY2soKTsKICB9OwogICQoImRlbHNlc3Npb24iKS5vbmNsaWNrID0gYXN5bmMgKGUpID0+IHsKICAgIGUucHJldmVudERlZmF1bHQoKTsKICAgIGF3YWl0IFN0b3JlLnJlbW92ZSgic2Vzc2lvbiIsICJsYXN0LXNlc3Npb24uemlwIik7CiAgICBmb3IgKGNvbnN0IG0gb2YgYXdhaXQgU3RvcmUubGlzdCgibW9kcyIpKSBhd2FpdCBTdG9yZS5yZW1vdmUoIm1vZHMiLCBtLm5hbWUpOwogICAgc3RhdGUuc2x1Z3MgPSBbXTsgc2F2ZVNsdWdzKCk7CiAgICBib3guc3R5bGUuZGlzcGxheSA9ICJub25lIjsgcmVuZGVyTW9kcygpOwogICAgbG9nTGluZSgiY2xlYXJlZCBldmVyeXRoaW5nIHRoaXMgcGFnZSBoYWQgc3RvcmVkIGluIHRoZSBicm93c2VyIiwgImciKTsKICB9Owp9CmZ1bmN0aW9uIHNob3dSZWNvdmVyeShqKXsKICBjb25zdCBib3ggPSAkKCJyZWNlaXB0Iik7CiAgYm94LnN0eWxlLmRpc3BsYXkgPSAiIjsgYm94LmlubmVySFRNTCA9ICIiOwogIGJveC5pbm5lckhUTUwgPSAiPGgzPkFuIGVhcmxpZXIgc2Vzc2lvbiBzdG9wcGVkIGJlZm9yZSB0aGlzIGJyb3dzZXIgc2F2ZWQgaXQ8L2gzPiIgKwogICAgJzxkaXYgY2xhc3M9ImxpbmUiPkl0cyBsb2cgc3Vydml2ZWQgaGVyZTogPGI+JyArIEpvdXJuYWwuc3VtbWFyeSgpICsgIjwvYj48L2Rpdj4iICsKICAgICc8ZGl2IGNsYXNzPSJjb25zb2xlIiBzdHlsZT0ibWF4LWhlaWdodDoxNzBweDttYXJnaW4tdG9wOjlweDtib3JkZXI6MXB4IHNvbGlkIHZhcigtLWVkZ2UpOycgKwogICAgJ2JvcmRlci1yYWRpdXM6NnB4Ij4nICsgai5saW5lcy5zbGljZSgtMTQpLmpvaW4oIjxicj4iKSArICI8L2Rpdj4iICsKICAgICc8ZGl2IHN0eWxlPSJtYXJnaW4tdG9wOjExcHgiPjxhIGhyZWY9IiMiIGlkPSJmb3JnZXRqb3VybmFsIj5mb3JnZXQgaXQ8L2E+PC9kaXY+JzsKICAkKCJmb3JnZXRqb3VybmFsIikub25jbGljayA9IGFzeW5jIChlKSA9PiB7CiAgICBlLnByZXZlbnREZWZhdWx0KCk7IGF3YWl0IEpvdXJuYWwuY2xlYXIoKTsgYm94LnN0eWxlLmRpc3BsYXkgPSAibm9uZSI7CiAgfTsKfQoKLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gbGF1bmNoICovCmFzeW5jIGZ1bmN0aW9uIGxhdW5jaCgpewogIGlmICghc3RhdGUub25saW5lKXsgaGFuZE92ZXIoKTsgcmV0dXJuOyB9CiAgY29uc3QgbG9hZGVyID0gJCgibG9hZGVyIikudmFsdWUgPT09ICJjdXN0b20iCiAgICA/ICgkKCJsb2FkZXJjdXN0b20iKS52YWx1ZS50cmltKCkgfHwgInN0YWJsZSIpIDogJCgibG9hZGVyIikudmFsdWU7CiAgJCgibG9nIikuaW5uZXJIVE1MID0gIiI7CiAgbG9nTGluZSgiW3BhZ2VdIGFza2luZyBmb3IgIiArICgkKCJ2ZXJzaW9uIikudmFsdWUgfHwgIjEuMjEuMTEiKSArCiAgICAgICAgICAobG9hZGVyID09PSAibm9uZSIgPyAiICh2YW5pbGxhKSIgOiAiIHdpdGggRmFicmljICIgKyBsb2FkZXIpKTsKICB0cnkgewogICAgYXdhaXQgcHVzaE1vZHMoKTsKICAgIGlmICgkKCJyZXN0b3JlIikuY2hlY2tlZCl7CiAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCBTdG9yZS5nZXQoImxhc3Qtc2Vzc2lvbi56aXAiKTsKICAgICAgaWYgKGJsb2IgJiYgYmxvYi5zaXplKXsKICAgICAgICBsb2dMaW5lKCJwdXR0aW5nIHRoaXMgYnJvd3NlcidzIGxhc3Qgc2Vzc2lvbiBiYWNrICgiICsgZm10KGJsb2Iuc2l6ZSkgKyAiKSIpOwogICAgICAgIHRyeSB7IGF3YWl0IGFwaSgiL2FwaS9yZXN0b3JlIiwgeyBtZXRob2Q6IlBPU1QiLCBib2R5OiBibG9iLCB0aW1lb3V0OjEyMDAwMCB9KTsgfQogICAgICAgIGNhdGNoIChlKXsgbG9nTGluZSgiY291bGQgbm90IHJlc3RvcmUgKGEgc2Vzc2lvbiBtdXN0IGV4aXN0IGZpcnN0KTogIiArIGUubWVzc2FnZSk7IH0KICAgICAgfQogICAgfQogICAgY29uc3QgciA9IGF3YWl0IChhd2FpdCBhcGkoIi9hcGkvbGF1bmNoIiwgeyBtZXRob2Q6IlBPU1QiLCBib2R5OiBKU09OLnN0cmluZ2lmeSh7CiAgICAgIHZlcnNpb246ICQoInZlcnNpb24iKS52YWx1ZSB8fCAiMS4yMS4xMSIsCiAgICAgIGxvYWRlcktpbmQ6ICJmYWJyaWMiLAogICAgICBsb2FkZXI6IGxvYWRlciwKICAgICAgbW9kczogc3RhdGUuc2x1Z3MsCiAgICAgIHVzZXJuYW1lOiAkKCJ1c2VybmFtZSIpLnZhbHVlLnRyaW0oKSB8fCAiUGxheWVyIiwKICAgICAgbWVtb3J5OiAkKCJtZW1vcnkiKS52YWx1ZS50cmltKCkgfHwgIjJHIiwKICAgICAgYXNzZXRzOiAkKCJhc3NldHMiKS52YWx1ZSA9PT0gIjEiLAogICAgICByZWxheTogcmVsYXlDaG9pY2UoKSwKICAgICAgdHVubmVsU2VydmVyOiAkKCJzZXJ2ZXIiKS52YWx1ZS50cmltKCkgfHwgbnVsbCwKICAgICAgdHVubmVsRXZlcnl0aGluZzogJCgicmVsYXlNb2RlIikudmFsdWUgIT09ICJvZmYiLAogICAgICByZXN0cmljdGVkOiBmYWxzZSwKICAgICAgLy8gdGhlIGhlbHBlciBrZWVwcyBpdHMgb3duIGNvcHkgb2YgdGhlIGxhc3Qgc2Vzc2lvbiwgc28gInJlc3RvcmUiIGFsc28gZGVjaWRlcyB3aGV0aGVyIHRvCiAgICAgIC8vIHN0YXJ0IGZyb20gdGhhdCB3aGVuIHRoaXMgYnJvd3NlciBoYXMgbm90aGluZyAoYSBkaWZmZXJlbnQgb3JpZ2luIGRvZXMgZXhhY3RseSB0aGF0KQogICAgICByZXN0b3JlOiAkKCJyZXN0b3JlIikuY2hlY2tlZAogICAgfSl9KSkuanNvbigpOwogICAgc3RhdGUucmVzdWx0ID0gbnVsbDsKICAgIGxvZ0xpbmUoIltwYWdlXSBzZXNzaW9uICIgKyByLmlkICsgIiBzdGFydGVkIiwgImciKTsKICAgIHN0YXRlLnNlbGVjdGVkID0gci5pZDsKICAgIHN0YXRlLnNpbmNlW3IuaWRdID0gMDsKICAgIGlmICghc3RhdGUudGltZXIpIHN0YXRlLnRpbWVyID0gc2V0SW50ZXJ2YWwocmVmcmVzaCwgMTAwMCk7CiAgICByZWZyZXNoKCk7CiAgfSBjYXRjaCAoZSl7CiAgICBsb2dMaW5lKCJjb3VsZCBub3Qgc3RhcnQ6ICIgKyBlLm1lc3NhZ2UsICJlIik7CiAgICAkKCJwaGFzZSIpLnRleHRDb250ZW50ID0gIkNvdWxkIG5vdCBzdGFydCI7CiAgfQp9CgovKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSB0aGUgZmFjdHMgcm93ICovCmFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUZhY3RzKCl7CiAgY29uc3QgaCA9IHN0YXRlLmhlbGxvIHx8IHt9OwogIGNvbnN0IGVzdCA9IGF3YWl0IFN0b3JlLnVzYWdlKCk7CiAgY29uc3QgcnVudGltZSA9IGguanJlRmV0Y2hlZCA/ICJmZXRjaGVkIGludG8gdGhlIHNhbmRib3giCiAgICAgICAgICAgICAgICA6IChoLmphdmEgPyBTdHJpbmcoaC5qYXZhKS5zcGxpdCgiLyIpLnNsaWNlKC0zLCAtMilbMF0gfHwgIm9uIHRoaXMgbWFjaGluZSIgOiAi4oCUIik7CiAgaWYgKCQoImZhY3RKYXZhIikpICQoImZhY3RKYXZhIikudGV4dENvbnRlbnQgPSBoLmphdmEgPyAoaC5qYXZhTWFqb3IgPyAiSmF2YSAiICsgaC5qYXZhTWFqb3IgOiAiamF2YSIpIDogIm5vdCBsb29rZWQgZm9yIHlldCI7CiAgaWYgKCQoImZhY3RKYXZhU3ViIikpICQoImZhY3RKYXZhU3ViIikudGV4dENvbnRlbnQgPSBydW50aW1lOwogIGlmICgkKCJmYWN0U2FuZGJveCIpKSAkKCJmYWN0U2FuZGJveCIpLnRleHRDb250ZW50ID0gaC5zYW5kYm94ID8gaC5zYW5kYm94LnJlcGxhY2UoL14uKlwvLywgIiIpIDogIuKAlCI7CiAgaWYgKCQoImZhY3RTYW5kYm94U3ViIikpICQoImZhY3RTYW5kYm94U3ViIikudGV4dENvbnRlbnQgPSAiZGVsZXRlZCB3aGVuIHRoZSBzZXNzaW9uIGVuZHMiOwogIGlmICgkKCJmYWN0U3RvcmFnZSIpKSAkKCJmYWN0U3RvcmFnZSIpLnRleHRDb250ZW50ID0gZm10KGVzdC51c2VkKTsKICBpZiAoJCgiZmFjdFN0b3JhZ2VTdWIiKSkgJCgiZmFjdFN0b3JhZ2VTdWIiKS50ZXh0Q29udGVudCA9IFN0b3JlLmtpbmQgKyAiIGluIHRoaXMgYnJvd3NlciI7CiAgaWYgKHR5cGVvZiBzaG93UmVsYXlJblVzZSA9PT0gImZ1bmN0aW9uIikgc2hvd1JlbGF5SW5Vc2UoKTsKICBpZiAoJCgiZmFjdFNlc3Npb25zIikpICQoImZhY3RTZXNzaW9ucyIpLnRleHRDb250ZW50ID0gKHN0YXRlLnNlc3Npb25zIHx8IFtdKS5sZW5ndGgKICAgID8gKHN0YXRlLnNlc3Npb25zIHx8IFtdKS5sZW5ndGggKyAiIHRoaXMgdmlzaXQiIDogIm5vbmUgeWV0IjsKfQoKLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gZGlhZ25vc3RpY3MgKi8KYXN5bmMgZnVuY3Rpb24gZGlhZ25vc3RpY3MoKXsKICBjb25zdCBoID0gc3RhdGUuaGVsbG8gfHwge30sIHBsYXRmb3JtID0gaC5wbGF0Zm9ybSB8fCB7fTsKICBjb25zdCBlc3QgPSBhd2FpdCBTdG9yZS51c2FnZSgpOwogIGNvbnN0IG1vZHMgPSBhd2FpdCBTdG9yZS5saXN0KCJtb2RzIik7CiAgY29uc3QgbG9nID0gJCgibG9nIikudGV4dENvbnRlbnQudHJpbSgpLnNwbGl0KCJcbiIpOwogIGNvbnN0IHRleHQgPSBbCiAgICAid2VibWMtaGVscGVyIGRpYWdub3N0aWNzIiwKICAgICJoZWxwZXIgICAgIDogIiArIChoLnZlcnNpb24gfHwgIm5vdCBjb25uZWN0ZWQiKSArCiAgICAgIChwbGF0Zm9ybS5vcyA/ICIgICgiICsgcGxhdGZvcm0ub3MgKyAiICIgKyBwbGF0Zm9ybS52ZXJzaW9uICsgIiwgIiArIHBsYXRmb3JtLmFyY2ggKyAiKSIgOiAiIiksCiAgICAicGFnZSAgICAgICA6ICIgKyAoaG9zdGVkID8gImhvc3RlZCBjb3B5IGF0ICIgKyBsb2NhdGlvbi5ob3N0IDogInNlcnZlZCBieSB0aGUgaGVscGVyIiksCiAgICAiaGVscGVyIHVybCA6ICIgKyAoc3RhdGUuaGVscGVyIHx8ICIobm9uZSkiKSArICIgIHRva2VuOiAiICsgKHN0YXRlLnRva2VuID8gInN0b3JlZCIgOiAibm9uZSIpLAogICAgImRvd25sb2FkcyAgOiAiICsgKGgucHJveHkgfHwgIj8iKSArIChoLnJlbGF5ID8gIiAgcmVsYXk6ICIgKyBoLnJlbGF5IDogIiIpLAogICAgInNlc3Npb25zICAgOiAiICsgKHN0YXRlLnNlc3Npb25zIHx8IFtdKS5tYXAocyA9PiBzLnNpZCArICI9IiArIHMuc3RhdGUpLmpvaW4oIiwgIiksCiAgICAiYnJvd3NlciBzdG86ICIgKyBTdG9yZS5raW5kICsgIiwgIiArIGZtdChlc3QudXNlZCkgKyAiIG9mICIgKyBmbXQoZXN0LnF1b3RhKSwKICAgICJteSBtb2RzICAgIDogIiArIChtb2RzLmxlbmd0aCA/IG1vZHMubWFwKG0gPT4gbS5uYW1lICsgIiAoIiArIGZtdChtLnNpemUpICsgIikiKS5qb2luKCIsICIpIDogIm5vbmUiKSwKICAgICJtb2RyaW50aCAgIDogIiArIChzdGF0ZS5zbHVncy5sZW5ndGggPyBzdGF0ZS5zbHVncy5qb2luKCIsICIpIDogIm5vbmUiKSwKICAgICJ2ZXJzaW9uICAgIDogIiArICgkKCJ2ZXJzaW9uIikudmFsdWUgfHwgIj8iKSArICIgIGxvYWRlcjogIiArICQoImxvYWRlciIpLnZhbHVlICsKICAgICAgIiAgbWVtb3J5OiAiICsgJCgibWVtb3J5IikudmFsdWUgKyAiICBhc3NldHM6ICIgKyAoJCgiYXNzZXRzIikudmFsdWUgPT09ICIxIiA/ICJ5ZXMiIDogIm5vIiksCiAgICAicmVsYXkgc2V0ICA6ICIgKyAoJCgicmVsYXkiKS52YWx1ZS50cmltKCkgfHwgIm5vIiksCiAgICAiIiwgIi0tLSB0aGUgaGVscGVyJ3MgbG9nLCBsYXN0IDIwMCBsaW5lcyAtLS0iLCAuLi5sb2cuc2xpY2UoLTIwMCkKICBdLmpvaW4oIlxuIik7CiAgdHJ5IHsKICAgIGF3YWl0IG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHRleHQpOwogICAgJCgiZGlhZ3N0YXRlIikudGV4dENvbnRlbnQgPSAiY29waWVkIHRvIHRoZSBjbGlwYm9hcmQg4oCUIHBhc3RlIGl0IGludG8gdGhlIGlzc3VlIjsKICB9IGNhdGNoIChlKXsKICAgIGNvbnN0IHRhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgidGV4dGFyZWEiKTsKICAgIHRhLnZhbHVlID0gdGV4dDsKICAgIHRhLnN0eWxlLmNzc1RleHQgPSAicG9zaXRpb246Zml4ZWQ7dG9wOjEwcHg7bGVmdDoxMHB4O3dpZHRoOjkwJTtoZWlnaHQ6NTAlO3otaW5kZXg6OTkiOwogICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0YSk7IHRhLnNlbGVjdCgpOwogICAgJCgiZGlhZ3N0YXRlIikudGV4dENvbnRlbnQgPSAic2VsZWN0IGFsbCBhbmQgY29weSAodGhlIGNsaXBib2FyZCBBUEkgd2FzIHJlZnVzZWQpIjsKICB9Cn0KCi8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IGJhY2tncm91bmQgKi8KKGZ1bmN0aW9uIGJhY2tncm91bmQoKXsKICBjb25zdCBiZyA9ICQoImJnIik7CiAgbGV0IGZyYW1lID0gbnVsbCwgbXggPSAwLjUsIG15ID0gMC40OwogIGZ1bmN0aW9uIHBhaW50KCl7CiAgICBmcmFtZSA9IG51bGw7CiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc3R5bGUuc2V0UHJvcGVydHkoIi0tbXgiLCAobXggKiAxMDApLnRvRml4ZWQoMikgKyAiJSIpOwogICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnN0eWxlLnNldFByb3BlcnR5KCItLW15IiwgKG15ICogMTAwKS50b0ZpeGVkKDIpICsgIiUiKTsKICB9CiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoInBvaW50ZXJtb3ZlIiwgKGUpID0+IHsKICAgIGlmIChtb3Rpb24oKSA9PT0gInN0aWxsIikgcmV0dXJuOwogICAgbXggPSBlLmNsaWVudFggLyB3aW5kb3cuaW5uZXJXaWR0aDsKICAgIG15ID0gZS5jbGllbnRZIC8gd2luZG93LmlubmVySGVpZ2h0OwogICAgaWYgKGZyYW1lID09PSBudWxsKSBmcmFtZSA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShwYWludCk7CiAgfSwgeyBwYXNzaXZlOnRydWUgfSk7CiAgZnVuY3Rpb24gbW90aW9uKCl7IHRyeSB7IHJldHVybiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMUyArICJtb3Rpb24iKSB8fCAiZm9sbG93IjsgfSBjYXRjaChlKXsgcmV0dXJuICJmb2xsb3ciOyB9IH0KICB3aW5kb3cuYXBwbHlNb3Rpb24gPSAodmFsdWUpID0+IHsKICAgIHRyeSB7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKExTICsgIm1vdGlvbiIsIHZhbHVlKTsgfSBjYXRjaChlKXt9CiAgICBiZy5zdHlsZS5vcGFjaXR5ID0gdmFsdWUgPT09ICJzdGlsbCIgPyAiMC41NSIgOiAiMSI7CiAgfTsKICB3aW5kb3cuYXBwbHlGeCA9ICh2YWx1ZSkgPT4gewogICAgZG9jdW1lbnQuYm9keS5jbGFzc05hbWUgPSBkb2N1bWVudC5ib2R5LmNsYXNzTmFtZS5yZXBsYWNlKC9cYmZ4LVxTKy9nLCAiIikudHJpbSgpOwogICAgaWYgKHZhbHVlICYmIHZhbHVlICE9PSAibm9uZSIpIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LmFkZCh2YWx1ZSk7CiAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC50b2dnbGUoIm1vdGlvbi1mb2xsb3ciLCAobG9jYWxTdG9yYWdlLmdldEl0ZW0oTFMgKyAibW90aW9uIikgfHwgImZvbGxvdyIpID09PSAiZm9sbG93Iik7CiAgICB0cnkgeyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShMUyArICJmeCIsIHZhbHVlIHx8ICJub25lIik7IH0gY2F0Y2goZSl7fQogIH07Cn0pKCk7CgovKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSB3aXJpbmcgKi8KY29uc3QgU0hPUlRDVVRfTkFNRSA9ICJXZWJNQyBIZWxwZXIiOwpjb25zdCBTSEVMTF9MSU5FID0gIkQ9JChta3RlbXAgLWQgL3RtcC93ZWJtYy5YWFhYWFgpICYmIGNkIFwiJERcIiAmJiBjdXJsIC1mc1NMICIgKwogICJodHRwczovL2FtcGhpYmlhbmRldi5naXRodWIuaW8vd2VibWMtbGF1bmNoZXIvaGVscGVyL3dlYm1jLWhlbHBlci56aXAgLW8gaC56aXAgJiYgIiArCiAgImRpdHRvIC14IC1rIGguemlwIC4gJiYgcm0gaC56aXAgJiYgV0VCTUNfVFJBTlNJRU5UPTEgV0VCTUNfUEFHRV9VUkw9IiArCiAgImh0dHBzOi8vYW1waGliaWFuZGV2LmdpdGh1Yi5pby93ZWJtYy1sYXVuY2hlci9sb2NhbC5odG1sIC4vd2VibWMtaGVscGVyLmNvbW1hbmQiOwphc3luYyBmdW5jdGlvbiBzdGFydFZpYVNob3J0Y3V0KCl7CiAgY29uc3Qgbm90ZSA9ICQoImtpY2tzIik7CiAgbm90ZS50ZXh0Q29udGVudCA9ICJhc2tpbmcgU2hvcnRjdXRzIGZvciBcdTIwMWMiICsgU0hPUlRDVVRfTkFNRSArICJcdTIwMWTigKYiOwogIGxvY2F0aW9uLmhyZWYgPSAic2hvcnRjdXRzOi8vcnVuLXNob3J0Y3V0P25hbWU9IiArIGVuY29kZVVSSUNvbXBvbmVudChTSE9SVENVVF9OQU1FKTsKICBmb3IgKGxldCBpID0gMDsgaSA8IDQwOyBpKyspewogICAgYXdhaXQgbmV3IFByb21pc2UociA9PiBzZXRUaW1lb3V0KHIsIDE1MDApKTsKICAgIGlmIChhd2FpdCBwcm9iZShmYWxzZSkpeyBub3RlLnRleHRDb250ZW50ID0gInRoZSBoZWxwZXIgaXMgdXAg4oCUIHByZXNzIFBMQVkiOyByZXR1cm47IH0KICAgIG5vdGUudGV4dENvbnRlbnQgPSAid2FpdGluZyBmb3IgdGhlIGhlbHBlcuKApiAiICsgKChpICsgMSkgKiAxLjUpLnRvRml4ZWQoMCkgKyAicyI7CiAgfQogIG5vdGUudGV4dENvbnRlbnQgPSAiaXQgZGlkIG5vdCBjb21lIHVwLiBJcyB0aGUgU2hvcnRjdXQgbmFtZWQgZXhhY3RseSBcdTIwMWMiICsgU0hPUlRDVVRfTkFNRSArCiAgICAiXHUyMDFkLCBhbmQgaXMgQWxsb3cgUnVubmluZyBTY3JpcHRzIG9uPyI7Cn0KJCgiY29ubmVjdCIpLm9uY2xpY2sgPSAoKSA9PiB7IHN0YXRlLmhlbHBlciA9ICQoImhlbHBlciIpLnZhbHVlLnRyaW0oKS5yZXBsYWNlKC9cLyQvLCAiIik7IHByb2JlKHRydWUpOyB9OwokKCJwbGF5Iikub25jbGljayA9IGxhdW5jaDsKCiQoImhlbHAiKS5vbmNsaWNrID0gKCkgPT4gJCgiYWJvdXQiKS5zaG93TW9kYWwoKTsKJCgiYWJvdXRjbG9zZSIpLm9uY2xpY2sgPSAoKSA9PiAkKCJhYm91dCIpLmNsb3NlKCk7CiQoImNvcHlkaWFnIikub25jbGljayA9IGRpYWdub3N0aWNzOwokKCJraWNraGVscGVyIikub25jbGljayA9IHN0YXJ0VmlhU2hvcnRjdXQ7CiQoImxvZ0NsZWFyIikub25jbGljayA9ICgpID0+IHsgJCgibG9nIikuaW5uZXJIVE1MID0gIiI7IH07CiQoImRyYXdlclN0cmlwUm93Iikub25jbGljayA9IChlKSA9PiB7CiAgaWYgKGUudGFyZ2V0ICYmIGUudGFyZ2V0LmlkID09PSAibG9nSGlkZSIpIHJldHVybjsKICAkKCJsb2dIaWRlIikuY2xpY2soKTsKfTsKJCgibG9nSGlkZSIpLm9uY2xpY2sgPSAoKSA9PiB7CiAgLy8gVGhlIGFjdGl2aXR5IGRyYXdlcjogY29sbGFwc2VkIGl0IGlzIGEgc3RyaXAgeW91IGNhbiB3YXRjaCBwcm9ncmVzcyBpbiwgZXhwYW5kZWQgaXQgaXMgdGhlCiAgLy8gd2hvbGUgbG9nIGFjcm9zcyB0aGUgd2lkdGggb2YgdGhlIHdpbmRvdy4KICBjb25zdCBvcGVuID0gZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QudG9nZ2xlKCJkcmF3ZXItb3BlbiIpOwogICQoImxvZ0hpZGUiKS50ZXh0Q29udGVudCA9IG9wZW4gPyAiSGlkZSBsb2ciIDogIlNob3cgbG9nIjsKfTsKJCgiY29weWxpbmUiKS5vbmNsaWNrID0gYXN5bmMgKCkgPT4gewogIHRyeSB7IGF3YWl0IG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KFNIRUxMX0xJTkUpOyAkKCJjb3B5b2siKS50ZXh0Q29udGVudCA9ICJjb3BpZWQiOyB9CiAgY2F0Y2ggKGUpeyAkKCJjb3B5b2siKS50ZXh0Q29udGVudCA9ICJzZWxlY3QgaXQgYW5kIGNvcHkgYnkgaGFuZCI7IH0KfTsKLy8gT25lIHJlbGF5IHNldHRpbmcsIHRocmVlIGhvbmVzdCBtZWFuaW5nczogYXV0b21hdGljICh0aGUgaGVscGVyIGRlY2lkZXMsIGFuZCBpdCBrbm93cyBhYm91dCB0aGUKLy8gYnVpbHQtaW4gcmVsYXlzKSwgbmV2ZXIsIG9yIGEgVVJMIG9mIHlvdXIgb3duLgpmdW5jdGlvbiByZWxheUNob2ljZSgpewogIGNvbnN0IG1vZGUgPSAkKCJyZWxheU1vZGUiKS52YWx1ZTsKICBpZiAobW9kZSA9PT0gIm9mZiIpIHJldHVybiAib2ZmIjsKICBpZiAobW9kZSA9PT0gImN1c3RvbSIpIHJldHVybiAkKCJyZWxheSIpLnZhbHVlLnRyaW0oKSB8fCBudWxsOwogIHJldHVybiBudWxsOyAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRoZSBoZWxwZXIgcmVzb2x2ZXMgaXQsIHByb2JpbmcgdGhlIGJ1aWx0LWluIGxpc3QKfQpmdW5jdGlvbiByZWxheU1vZGVDaGFuZ2VkKCl7CiAgY29uc3QgY3VzdG9tID0gJCgicmVsYXlNb2RlIikudmFsdWUgPT09ICJjdXN0b20iOwogICQoInJlbGF5Q3VzdG9tUm93Iikuc3R5bGUuZGlzcGxheSA9IGN1c3RvbSA/ICJibG9jayIgOiAibm9uZSI7CiAga2VlcCgicmVsYXlNb2RlIik7CiAgc2hvd1JlbGF5SW5Vc2UoKTsKfQpmdW5jdGlvbiBzaG93UmVsYXlJblVzZSgpewogIGNvbnN0IGVsID0gJCgicmVsYXlJblVzZSIpOwogIGlmICghZWwpIHJldHVybjsKICBjb25zdCBoID0gc3RhdGUuaGVsbG8gfHwge307CiAgY29uc3QgbW9kZSA9ICQoInJlbGF5TW9kZSIpLnZhbHVlOwogIGlmIChtb2RlID09PSAib2ZmIil7IGVsLnRleHRDb250ZW50ID0gIlNldCB0byBjb25uZWN0IGRpcmVjdGx5OiBubyByZWxheSBpcyB1c2VkIGF0IGFsbC4iOyByZXR1cm47IH0KICBpZiAoaC5yZWxheSkgZWwudGV4dENvbnRlbnQgPSAiVGhlIGhlbHBlciBpcyBkb3dubG9hZGluZyB0aHJvdWdoICIgKyBoLnJlbGF5ICsgIi4iOwogIGVsc2UgaWYgKGgucmVsYXlCdWlsdEluKQogICAgZWwudGV4dENvbnRlbnQgPSAiTm8gcmVsYXkgbmVlZGVkIHlldCDigJQgIiArIGgucmVsYXlCdWlsdEluICsKICAgICAgICAgICAgICAgICAgICAgIiBidWlsdC1pbiBvbmUocykgYXJlIHRoZXJlIGlmIHRoaXMgbmV0d29yayBibG9ja3MgTW9qYW5nIG9yIGEgZ2FtZSBwb3J0LiI7CiAgZWxzZSBpZiAobW9kZSA9PT0gImN1c3RvbSIgJiYgJCgicmVsYXkiKS52YWx1ZS50cmltKCkpCiAgICBlbC50ZXh0Q29udGVudCA9ICJZb3VyIHJlbGF5IGlzIHVzZWQgZm9yIHRoZSBuZXh0IGxhdW5jaC4iOwogIGVsc2UgZWwudGV4dENvbnRlbnQgPSAiRG93bmxvYWRzIGdvIHN0cmFpZ2h0IHRvIE1vamFuZywgd2hpY2ggaXMgcmlnaHQgdW5sZXNzIHlvdXIgbmV0d29yayBibG9ja3MgaXQuIjsKfQpmdW5jdGlvbiByZWxheVVybFRvVGVzdCgpewogIGNvbnN0IG1vZGUgPSAkKCJyZWxheU1vZGUiKS52YWx1ZTsKICBpZiAobW9kZSA9PT0gImN1c3RvbSIpIHJldHVybiAkKCJyZWxheSIpLnZhbHVlLnRyaW0oKS5yZXBsYWNlKC9cLyQvLCAiIik7CiAgaWYgKG1vZGUgPT09ICJvZmYiKSByZXR1cm4gIiI7CiAgY29uc3QgaCA9IHN0YXRlLmhlbGxvIHx8IHt9OwogIHJldHVybiBoLnJlbGF5ID8gU3RyaW5nKGgucmVsYXkpLnJlcGxhY2UoL1wvJC8sICIiKSA6ICIiOwp9Ci8vIFRoZSBwcm9taXNlLCBtYWRlIGNoZWNrYWJsZSBmcm9tIHRoZSBwYWdlOiB3aGF0IG9mIG91cnMgaXMgb24gdGhpcyBtYWNoaW5lLCBhbmQgYSB3YXkgdG8gcmVtb3ZlIGl0Ci8vIHdpdGhvdXQgYSB0ZXJtaW5hbC4gRG93bmxvYWRzIGFyZSB0aGUgb25lIHRoaW5nIHRoYXQgZ3Jvd3Mgb24gaXRzIG93biwgc28gdGhleSBhcmUgbmFtZWQuCmZ1bmN0aW9uIHNob3dNYWNoaW5lU3RhdGUoKXsKICBpZiAoIXN0YXRlLmhlbGxvKXsgamdldCgiL2FwaS9oZWxsbyIsIDMwMDApLnRoZW4oKGgpID0+IHsgc3RhdGUuaGVsbG8gPSBoOyBzaG93TWFjaGluZVN0YXRlKCk7IH0pCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKCgpID0+IHt9KTsgcmV0dXJuOyB9CiAgY29uc3QgZWwgPSAkKCJtYWNoaW5lU3RhdGUiKTsKICBpZiAoIWVsKSByZXR1cm47CiAgY29uc3QgaXRlbXMgPSAoc3RhdGUuaGVsbG8gJiYgc3RhdGUuaGVsbG8uZm9vdHByaW50KSB8fCBbXTsKICBpZiAoIWl0ZW1zLmxlbmd0aCl7CiAgICBlbC50ZXh0Q29udGVudCA9ICJPbiB0aGlzIG1hY2hpbmU6IG5vdGhpbmcgb2Ygb3Vycy4gTm8gZmlsZXMsIG5vIGNhY2hlLCBubyBsb2dpbiBpdGVtLiI7CiAgICByZXR1cm47CiAgfQogIGNvbnN0IGJ5dGVzID0gaXRlbXMucmVkdWNlKChzdW0sIGl0ZW0pID0+IHN1bSArIChpdGVtLmJ5dGVzIHx8IDApLCAwKTsKICBjb25zdCBuYW1lcyA9IHt9OwogIGl0ZW1zLmZvckVhY2goKGl0ZW0pID0+IHsgbmFtZXNbaXRlbS53aGF0XSA9IChuYW1lc1tpdGVtLndoYXRdIHx8IDApICsgMTsgfSk7CiAgZWwudGV4dENvbnRlbnQgPSAiT24gdGhpcyBtYWNoaW5lOiAiICsgZm10KGJ5dGVzKSArICIg4oCUICIgKwogICAgT2JqZWN0LmtleXMobmFtZXMpLm1hcCgoaykgPT4gayArIChuYW1lc1trXSA+IDEgPyAiIMOXIiArIG5hbWVzW2tdIDogIiIpKS5qb2luKCIsICIpICsKICAgICIuIFNhbmRib3hlcyBnbyB3aGVuIGEgc2Vzc2lvbiBlbmRzOyB0aGUgcmVzdCB3YWl0cyB1bnRpbCB5b3UgcmVtb3ZlIGl0LiI7Cn0KJCgicHVyZ2UiKS5vbmNsaWNrID0gYXN5bmMgKCkgPT4gewogIGNvbnN0IGxpbmUgPSAkKCJwdXJnZVN0YXRlIik7CiAgY29uc3QgaXRlbXMgPSAoc3RhdGUuaGVsbG8gJiYgc3RhdGUuaGVsbG8uZm9vdHByaW50KSB8fCBbXTsKICBpZiAoIWNvbmZpcm0oIlJlbW92ZSBldmVyeXRoaW5nIHRoaXMgbGF1bmNoZXIgaGFzIG9uIHRoaXMgbWFjaGluZT9cblxuIiArCiAgICAgICAgICAgICAgICJTYW5kYm94ZXMsIGFueSBkb3dubG9hZCBjYWNoZSwgdGhlIGluc3RhbGxlZCBoZWxwZXIgYW5kIGl0cyBsb2dpbiBpdGVtLCB0aGUgbG9nLlxuIiArCiAgICAgICAgICAgICAgICJZb3VyIHdvcmxkcywgbW9kcyBhbmQgc2V0dGluZ3MgYXJlIGluIHRoaXMgYnJvd3NlciBhbmQgYXJlIG5vdCB0b3VjaGVkLiIpKSByZXR1cm47CiAgbGluZS50ZXh0Q29udGVudCA9IGl0ZW1zLmxlbmd0aCA/ICJyZW1vdmluZyAiICsgaXRlbXMubGVuZ3RoICsgIiBpdGVtKHMp4oCmIiA6ICJsb29raW5n4oCmIjsKICB0cnkgewogICAgY29uc3QgYW5zd2VyID0gYXdhaXQgKGF3YWl0IGFwaSgiL2FwaS9wdXJnZSIsIHsgbWV0aG9kOiJQT1NUIiwgdGltZW91dDoxMjAwMDAgfSkpLmpzb24oKTsKICAgIGxpbmUudGV4dENvbnRlbnQgPSBhbnN3ZXIucmVtb3ZlZCAmJiBhbnN3ZXIucmVtb3ZlZC5sZW5ndGgKICAgICAgPyAicmVtb3ZlZCAiICsgYW5zd2VyLnJlbW92ZWQubGVuZ3RoICsgIiBpdGVtKHMpLCAiICsgZm10KGFuc3dlci5ieXRlcykgKwogICAgICAgICIgZnJlZWQuIE5vdGhpbmcgb2Ygb3VycyBpcyBvbiB0aGlzIG1hY2hpbmUgbm93LiIKICAgICAgOiAidGhlcmUgd2FzIG5vdGhpbmcgb2Ygb3VycyBvbiB0aGlzIG1hY2hpbmUgdG8gYmVnaW4gd2l0aC4iOwogICAgc3RhdGUuaGVsbG8gPSBhd2FpdCBqZ2V0KCIvYXBpL2hlbGxvIiwgNDAwMCk7CiAgICBzaG93TWFjaGluZVN0YXRlKCk7CiAgfSBjYXRjaCAoZSl7CiAgICBsaW5lLnRleHRDb250ZW50ID0gImNvdWxkIG5vdCBkbyBpdDogIiArICgoZSAmJiBlLm1lc3NhZ2UpIHx8ICJubyBhbnN3ZXIgZnJvbSB0aGUgaGVscGVyIik7CiAgfQp9OwoKJCgicmVsYXlUZXN0Iikub25jbGljayA9IGFzeW5jICgpID0+IHsKICBjb25zdCBsaW5lID0gJCgicmVsYXlTdGF0ZSIpOwogIGNvbnN0IHVybCA9IHJlbGF5VXJsVG9UZXN0KCk7CiAgaWYgKCQoInJlbGF5TW9kZSIpLnZhbHVlID09PSAib2ZmIil7CiAgICBsaW5lLnRleHRDb250ZW50ID0gInRoaXMgaXMgc2V0IHRvIGNvbm5lY3QgZGlyZWN0bHksIHNvIHRoZXJlIGlzIG5vdGhpbmcgdG8gdGVzdCI7CiAgICByZXR1cm47CiAgfQogIGlmICghdXJsKXsKICAgIGxpbmUudGV4dENvbnRlbnQgPSAibm8gcmVsYXkgdG8gdGVzdCB5ZXQ6IHRoZSBoZWxwZXIgaGFzIG5vdCByZXBvcnRlZCBvbmUuIFN0YXJ0IGEgc2Vzc2lvbiBvbiBhICIKICAgICAgICAgICAgICAgICAgICAgKyAiYmxvY2tlZCBuZXR3b3JrLCBvciBjaG9vc2Ug4oCcTXkgb3duIHJlbGF54oCdIGFuZCBwYXN0ZSBpdHMgYWRkcmVzcy4iOwogICAgcmV0dXJuOwogIH0KICBsaW5lLnRleHRDb250ZW50ID0gImFza2luZyAiICsgdXJsICsgIuKApiI7CiAgdHJ5IHsKICAgIGNvbnN0IHIgPSBhd2FpdCBmZXRjaCh1cmwgKyAiL2hlYWx0aCIsIHsgY2FjaGU6Im5vLXN0b3JlIiB9KTsKICAgIGNvbnN0IGogPSBhd2FpdCByLmpzb24oKTsKICAgIGNvbnN0IGhvc3RzID0gKGouZmlsZXMgfHwgai5wcmVmaXhlcyB8fCBbXSkubGVuZ3RoOwogICAgbGluZS50ZXh0Q29udGVudCA9IGogJiYgai5vawogICAgICA/ICJpdCBhbnN3ZXJzIiArIChob3N0cyA/ICIsIGFuZCBrbm93cyAiICsgaG9zdHMgKyAiIGhvc3RzIiA6ICIiKSArCiAgICAgICAgKGoudHVubmVsID8gIiwgYW5kIGNhcnJpZXMgZ2FtZSBjb25uZWN0aW9ucyIgOiAiIikgKyAiLiIKICAgICAgOiAiaXQgYW5zd2VyZWQgc29tZXRoaW5nIHVuZXhwZWN0ZWQiOwogICAga2VlcCgicmVsYXkiKTsKICB9IGNhdGNoIChlKXsKICAgIGxpbmUudGV4dENvbnRlbnQgPSAibm8gYW5zd2VyIGZyb20gaXQgKGlzIHRoZSBVUkwgcmlnaHQsIGFuZCBpcyBpdCBkZXBsb3llZD8pIjsKICB9Cn07CiQoInJlbGF5TW9kZSIpLmFkZEV2ZW50TGlzdGVuZXIoImNoYW5nZSIsIHJlbGF5TW9kZUNoYW5nZWQpOwokKCJyZWxheSIpLmFkZEV2ZW50TGlzdGVuZXIoImNoYW5nZSIsICgpID0+IHsga2VlcCgicmVsYXkiKTsgc2hvd1JlbGF5SW5Vc2UoKTsgfSk7CiQoInNlcnZlciIpLmFkZEV2ZW50TGlzdGVuZXIoImNoYW5nZSIsICgpID0+IGtlZXAoInNlcnZlciIpKTsKZnVuY3Rpb24ga2VlcChrZXkpewogIHRyeSB7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKExTICsga2V5LCAkKGtleSkudmFsdWUudHJpbSgpKTsgfSBjYXRjaChlKXt9Cn0KJCgic3RheSIpLm9uY2xpY2sgPSAoZSkgPT4gewogIGUucHJldmVudERlZmF1bHQoKTsKICB0cnkgeyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShMUyArICJzdGF5IiwgIjEiKTsgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oTFMgKyAicmVkaXJlY3RGYWlsZWQiKTsgfSBjYXRjaChlMil7fQogIGxvZ0xpbmUoInRoaXMgcGFnZSB3aWxsIHN0YXkgaGVyZSBmcm9tIG5vdyBvbiBpbnN0ZWFkIG9mIGhhbmRpbmcgdGhlIHRhYiBvdmVyIik7Cn07CiQoImZ4U2VsZWN0Iikub25jaGFuZ2UgPSAoKSA9PiBhcHBseUZ4KCQoImZ4U2VsZWN0IikudmFsdWUpOwokKCJtb3Rpb25TZWxlY3QiKS5vbmNoYW5nZSA9ICgpID0+IGFwcGx5TW90aW9uKCQoIm1vdGlvblNlbGVjdCIpLnZhbHVlKTsKJCgicHJveHlBbGwiKS5vbmNoYW5nZSA9ICgpID0+IHsKICB0cnkgeyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShMUyArICJwcm94eUFsbCIsICQoInByb3h5QWxsIikuY2hlY2tlZCA/ICIxIiA6ICIwIik7IH0gY2F0Y2goZSl7fQogIGxvZ0xpbmUoJCgicHJveHlBbGwiKS5jaGVja2VkCiAgICA/ICJ0aGUgZ2FtZSdzIG93biBjb25uZWN0aW9ucyB3aWxsIGdvIHRocm91Z2ggdGhlIHJlbGF5IChuZWVkcyB0aGUgcmVsYXkgVVJMKSIKICAgIDogInRoZSBnYW1lIHdpbGwgY29ubmVjdCBkaXJlY3RseSBhZ2FpbiIpOwp9OwokKCJyZXN0cmljdGVkIikub25jaGFuZ2UgPSAoKSA9PiB7CiAgdHJ5IHsgbG9jYWxTdG9yYWdlLnNldEl0ZW0oTFMgKyAicmVzdHJpY3RlZCIsICQoInJlc3RyaWN0ZWQiKS5jaGVja2VkID8gIjEiIDogIjAiKTsgfSBjYXRjaChlKXt9CiAgbG9nTGluZSgkKCJyZXN0cmljdGVkIikuY2hlY2tlZAogICAgPyAicmVzdHJpY3RlZCBtb2RlOiBvdXIgb3duIEphdmEsIGZldGNoZWQgaW50byB0aGUgc2Vzc2lvbidzIGZvbGRlciIKICAgIDogInJlc3RyaWN0ZWQgbW9kZSBvZmY6IHRoZSBtYWNoaW5lJ3MgSmF2YSBtYXkgYmUgdXNlZCBhZ2FpbiIpOwp9OwokKCJ2ZXJzaW9uIikub25jaGFuZ2UgPSAoKSA9PiB7CiAgaWYgKCQoInZlcnNpb25CaWciKSkgJCgidmVyc2lvbkJpZyIpLnRleHRDb250ZW50ID0gJCgidmVyc2lvbiIpLnZhbHVlOwp9OwokKCJsb2FkZXIiKS5vbmNoYW5nZSA9ICgpID0+IHsKICAkKCJsb2FkZXJjdXN0b20iKS5zdHlsZS5kaXNwbGF5ID0gJCgibG9hZGVyIikudmFsdWUgPT09ICJjdXN0b20iID8gIiIgOiAibm9uZSI7Cn07CiQoIm1lbW9yeSIpLm9uaW5wdXQgPSAoKSA9PiB7ICQoImNoaXBNZW1vcnkiKS50ZXh0Q29udGVudCA9ICQoIm1lbW9yeSIpLnZhbHVlIHx8ICIyRyI7IH07CiQoImFzc2V0cyIpLm9uY2hhbmdlID0gKCkgPT4gewogICQoImNoaXBBc3NldHMiKS50ZXh0Q29udGVudCA9ICQoImFzc2V0cyIpLnZhbHVlID09PSAiMSIgPyAiYXNzZXRzOiBkb3dubG9hZCIgOiAiYXNzZXRzOiBza2lwcGVkIjsKfTsKJCgiZHJvcCIpLm9uY2xpY2sgPSAoKSA9PiAkKCJwaWNrZXIiKS5jbGljaygpOwokKCJwaWNrZXIiKS5vbmNoYW5nZSA9ICgpID0+IHsgYWRkRmlsZXMoWy4uLiQoInBpY2tlciIpLmZpbGVzXSk7ICQoInBpY2tlciIpLnZhbHVlID0gIiI7IH07CmZvciAoY29uc3QgZXYgb2YgWyJkcmFnZW50ZXIiLCJkcmFnb3ZlciJdKQogICQoImRyb3AiKS5hZGRFdmVudExpc3RlbmVyKGV2LCAoZSkgPT4geyBlLnByZXZlbnREZWZhdWx0KCk7ICQoImRyb3AiKS5jbGFzc0xpc3QuYWRkKCJvdmVyIik7IH0pOwpmb3IgKGNvbnN0IGV2IG9mIFsiZHJhZ2xlYXZlIiwiZHJvcCJdKQogICQoImRyb3AiKS5hZGRFdmVudExpc3RlbmVyKGV2LCAoKSA9PiAkKCJkcm9wIikuY2xhc3NMaXN0LnJlbW92ZSgib3ZlciIpKTsKJCgiZHJvcCIpLmFkZEV2ZW50TGlzdGVuZXIoImRyb3AiLCAoZSkgPT4geyBlLnByZXZlbnREZWZhdWx0KCk7CiAgYWRkRmlsZXMoWy4uLihlLmRhdGFUcmFuc2ZlciA/IGUuZGF0YVRyYW5zZmVyLmZpbGVzIDogW10pXSk7IH0pOwp3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigiZHJhZ292ZXIiLCAoZSkgPT4gZS5wcmV2ZW50RGVmYXVsdCgpKTsKd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoImRyb3AiLCAoZSkgPT4gZS5wcmV2ZW50RGVmYXVsdCgpKTsKJCgiZG9ic2VhcmNoIikub25jbGljayA9IHNlYXJjaE1vZHM7CiQoInNlYXJjaCIpLmFkZEV2ZW50TGlzdGVuZXIoImtleWRvd24iLCAoZSkgPT4geyBpZiAoZS5rZXkgPT09ICJFbnRlciIpIHNlYXJjaE1vZHMoKTsgfSk7CiQoIm9wZW5sb2NhbCIpLm9uY2xpY2sgPSAoZSkgPT4geyBlLnByZXZlbnREZWZhdWx0KCk7IHdpbmRvdy5vcGVuKCJodHRwOi8vMTI3LjAuMC4xOjc2NDUvIiwgIl9ibGFuayIsICJub29wZW5lciIpOyB9OwokKCJvcGVubG9jYWwyIikub25jbGljayA9IChlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgd2luZG93Lm9wZW4oImh0dHA6Ly8xMjcuMC4wLjE6NzY0NS8iLCAiX2JsYW5rIiwgIm5vb3BlbmVyIik7IH07CgovKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIHN0YXJ0LXVwICovCihmdW5jdGlvbiBpbml0KCl7CiAgLy8gQSBsYXVuY2hlciBwYWdlIGhhbmRzIGl0cyBjaG9pY2VzIG92ZXIgaW4gdGhlIGZyYWdtZW50OyB0aGlzIHBhZ2Ugc3RhcnRzIHRoZSBnYW1lIG9uIGFycml2YWwuCiAgY29uc3Qgd2FudGVkID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhsb2NhdGlvbi5oYXNoLnJlcGxhY2UoL14jLywgIiIpKTsKICBpZiAod2FudGVkLmdldCgicGxheSIpKXsKICAgIGlmICh3YW50ZWQuZ2V0KCJ2IikpICQoInZlcnNpb24iKS5kYXRhc2V0LndhbnQgPSB3YW50ZWQuZ2V0KCJ2Iik7CiAgICBpZiAod2FudGVkLmdldCgibCIpKXsKICAgICAgY29uc3QgbCA9IHdhbnRlZC5nZXQoImwiKTsKICAgICAgaWYgKFsic3RhYmxlIiwibGF0ZXN0Iiwibm9uZSJdLmluY2x1ZGVzKGwpKSAkKCJsb2FkZXIiKS52YWx1ZSA9IGw7CiAgICAgIGVsc2UgeyAkKCJsb2FkZXIiKS52YWx1ZSA9ICJjdXN0b20iOyAkKCJsb2FkZXJjdXN0b20iKS52YWx1ZSA9IGw7ICQoImxvYWRlcmN1c3RvbSIpLnN0eWxlLmRpc3BsYXkgPSAiIjsgfQogICAgfQogICAgaWYgKHdhbnRlZC5nZXQoIm0iKSl7CiAgICAgIHN0YXRlLnNsdWdzID0gd2FudGVkLmdldCgibSIpLnNwbGl0KCIsIikubWFwKHggPT4geC50cmltKCkpLmZpbHRlcihCb29sZWFuKTsKICAgICAgc2F2ZVNsdWdzKCk7CiAgICB9CiAgICBpZiAod2FudGVkLmdldCgidSIpKSAkKCJ1c2VybmFtZSIpLnZhbHVlID0gd2FudGVkLmdldCgidSIpOwogICAgaWYgKHdhbnRlZC5nZXQoIm1lbSIpKXsgJCgibWVtb3J5IikudmFsdWUgPSB3YW50ZWQuZ2V0KCJtZW0iKTsgJCgiY2hpcE1lbW9yeSIpLnRleHRDb250ZW50ID0gd2FudGVkLmdldCgibWVtIik7IH0KICAgIGlmICh3YW50ZWQuZ2V0KCJyZWxheSIpKSAkKCJyZWxheSIpLnZhbHVlID0gd2FudGVkLmdldCgicmVsYXkiKTsKICAgIHN0YXRlLmF1dG9QbGF5ID0gdHJ1ZTsKICB9CiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoIm1lc3NhZ2UiLCAoZSkgPT4gewogICAgaWYgKGUuZGF0YSAmJiBlLmRhdGEud2VibWMgPT09ICJoZWxsbyIgJiYgZS5zb3VyY2UpCiAgICAgIGUuc291cmNlLnBvc3RNZXNzYWdlKHsgd2VibWM6ImhlbGxvLWJhY2siLCBuYW1lOiJ3ZWJtYy1oZWxwZXIiLCB2ZXJzaW9uOiIwLjEuMCIgfSwgIioiKTsKICB9KTsKICBsb2FkU2x1Z3MoKTsKICByZW5kZXJNb2RzKCk7CiAgdHJ5IHsKICAgICQoInJlbGF5IikudmFsdWUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMUyArICJyZWxheSIpIHx8ICIiOwogICAgJCgicmVsYXlNb2RlIikudmFsdWUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMUyArICJyZWxheU1vZGUiKSB8fCAiYXV0byI7CiAgICAkKCJyZWxheUN1c3RvbVJvdyIpLnN0eWxlLmRpc3BsYXkgPSAkKCJyZWxheU1vZGUiKS52YWx1ZSA9PT0gImN1c3RvbSIgPyAiYmxvY2siIDogIm5vbmUiOwogICAgJCgic2VydmVyIikudmFsdWUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMUyArICJzZXJ2ZXIiKSB8fCAiIjsKICAgIGNvbnN0IGZ4ID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oTFMgKyAiZngiKSB8fCAiZngtZ2xvdyI7CiAgICBjb25zdCBtb3Rpb24gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMUyArICJtb3Rpb24iKSB8fCAiZm9sbG93IjsKICAgICQoImZ4U2VsZWN0IikudmFsdWUgPSBmeDsKICAgICQoIm1vdGlvblNlbGVjdCIpLnZhbHVlID0gbW90aW9uOwogICAgYXBwbHlGeChmeCk7CiAgICBhcHBseU1vdGlvbihtb3Rpb24pOwogICAgJCgicHJveHlBbGwiKS5jaGVja2VkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oTFMgKyAicHJveHlBbGwiKSA9PT0gIjEiOwogICAgJCgicmVzdHJpY3RlZCIpLmNoZWNrZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMUyArICJyZXN0cmljdGVkIikgPT09ICIxIjsKICB9IGNhdGNoKGUpe30KICAvLyBhIHNvZnQgYXJyaXZhbCByYXRoZXIgdGhhbiBhIGhhcmQgY3V0CiAgLy8gYSBzbWFsbCBlbnRyYW5jZSBmb3Igd2hhdGV2ZXIgdGhlIGZpcnN0IGNhcmQgaXMgY2FsbGVkIGluIHRoaXMgc2hlbGwKICBjb25zdCBmaXJzdENhcmQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCIuY2FyZCwgLnBhbmVsIik7CiAgaWYgKGZpcnN0Q2FyZCkgZmlyc3RDYXJkLmFuaW1hdGUoCiAgICBbeyBvcGFjaXR5OjAsIHRyYW5zZm9ybToidHJhbnNsYXRlWSg2cHgpIiB9LCB7IG9wYWNpdHk6MSwgdHJhbnNmb3JtOiJub25lIiB9XSwKICAgIHsgZHVyYXRpb246MzQwLCBlYXNpbmc6ImVhc2Utb3V0IiB9KTsKICAkKCJoZWxwZXIiKS52YWx1ZSA9IHN0YXRlLmhlbHBlciB8fCAiaHR0cDovLzEyNy4wLjAuMTo3NjQ1IjsKICBpZiAoaG9zdGVkKXsKICAgICQoInppcGRsIikuaHJlZiA9ICJoZWxwZXIvd2VibWMtaGVscGVyLnppcCI7CiAgICBpZiAoJCgiYXBwZGwiKSkgJCgiYXBwZGwiKS5ocmVmID0gImhlbHBlci9XZWJNQy1IZWxwZXItbWFjLnppcCI7CiAgICAkKCJvcGVubG9jYWwyIikuc3R5bGUuZGlzcGxheSA9ICIiOwogICAgJCgic3RheSIpLnN0eWxlLmRpc3BsYXkgPSAiIjsKICB9CiAgaWYgKC9NYWMvaS50ZXN0KG5hdmlnYXRvci51c2VyQWdlbnQpKXsKICAgICQoInNoZWxsbGluZSIpLnRleHRDb250ZW50ID0gU0hFTExfTElORTsKICAgICQoInNob3J0Y3V0Ym94Iikuc3R5bGUuZGlzcGxheSA9ICIiOwogIH0KICBjb25zdCB3aGVyZSA9IGNvbm5lY3Rpb24oKTsKICBpZiAoc3RhdGUuaGVscGVyKXsKICAgIHNldENvbm4oImJ1c3kiLCAiY29udGFjdGluZ+KApiIpOwogICAgcHJvYmUoZmFsc2UpLnRoZW4oKG9rKSA9PiB7CiAgICAgIGlmIChvayAmJiBzdGF0ZS5hdXRvUGxheSl7IHN0YXRlLmF1dG9QbGF5ID0gZmFsc2U7IGxhdW5jaCgpOyB9CiAgICB9KTsKICB9IGVsc2UgewogICAgc2V0Q29ubigiYmFkIiwgIm5vdCBjb25uZWN0ZWQiKTsKICAgIHNob3dPZmZsaW5lKCJkb3duIik7CiAgICAkKCJoZWxwZXIiKS52YWx1ZSA9ICJodHRwOi8vMTI3LjAuMC4xOjc2NDUiOwogIH0KICBpZiAod2hlcmUgPT09ICJub25lIil7CiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigibG9hZCIsICgpID0+IHsKICAgICAgaWYgKGNvbm5lY3Rpb24oKSAhPT0gIm5vbmUiKXsgJCgiaGVscGVyIikudmFsdWUgPSBzdGF0ZS5oZWxwZXI7IHByb2JlKGZhbHNlKTsgfQogICAgfSwgeyBvbmNlOnRydWUgfSk7CiAgfQogIC8vIEEgaG9zdGVkIGNvcHkgaGFuZHMgdGhlIHRhYiB0byB0aGUgaGVscGVyJ3Mgb3duIHBhZ2UgaW1tZWRpYXRlbHkuIE5vdGhpbmcgaXMgYXNrZWQgZmlyc3Q6IHRoaXMKICAvLyBicm93c2VyIHdpbGwgbm90IGxldCBhIGdpdGh1Yi5pbyBwYWdlIGZldGNoIDEyNy4wLjAuMSwgc28gdGhlIGxvY2FsIHBhZ2UgaXMgdGhlIG9ubHkgcGxhY2UgdGhlCiAgLy8gbGF1bmNoZXIgY2FuIHdvcmssIGFuZCBtYWtpbmcgdGhlIHZpc2l0b3IgcHJlc3MgUExBWSB0byBkaXNjb3ZlciB0aGF0IGlzIGEgc3RlcCBmb3Igbm90aGluZy4KICAvLwogIC8vIExhbmRpbmcgYmFjayBoZXJlIHdpdGhpbiBhIGZldyBzZWNvbmRzIG1lYW5zIHRoZSByZWRpcmVjdCBkaWQgbm90IGxhbmQgKG5vIGhlbHBlciBydW5uaW5nLCBzbwogIC8vIHRoZSBicm93c2VyIHNob3dlZCBpdHMgb3duIGVycm9yIHBhZ2UgYW5kIHRoZSB2aXNpdG9yIGNhbWUgYmFjayksIGFuZCB0aGVuIHRoaXMgcGFnZSBzdG9wcwogIC8vIHJlZGlyZWN0aW5nIGFuZCBvZmZlcnMgdGhlIHdheSB0byBnZXQgdGhlIGhlbHBlciBpbnN0ZWFkIG9mIGJvdW5jaW5nIHRoZW0gYWdhaW4uCiAgaWYgKGhvc3RlZCl7CiAgICBsZXQgc3RheSA9IGZhbHNlLCBmYWlsZWQgPSBmYWxzZSwgdHJpZWQgPSAwOwogICAgdHJ5IHsKICAgICAgc3RheSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKExTICsgInN0YXkiKSA9PT0gIjEiOwogICAgICBmYWlsZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMUyArICJyZWRpcmVjdEZhaWxlZCIpID09PSAiMSI7CiAgICAgIHRyaWVkID0gTnVtYmVyKGxvY2FsU3RvcmFnZS5nZXRJdGVtKExTICsgInJlZGlyZWN0QXQiKSB8fCAwKTsKICAgIH0gY2F0Y2goZSl7fQogICAgaWYgKHRyaWVkICYmIERhdGUubm93KCkgLSB0cmllZCA8IDgwMDApewogICAgICB0cnkgeyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShMUyArICJyZWRpcmVjdEZhaWxlZCIsICIxIik7IH0gY2F0Y2goZSl7fQogICAgICBmYWlsZWQgPSB0cnVlOwogICAgICBsb2dMaW5lKCJbcGFnZV0gdGhlIHJlZGlyZWN0IHRvIHRoZSBoZWxwZXIgZGlkIG5vdCBsYW5kLCBzbyB0aGlzIHBhZ2UgaXMgc3RheWluZyBwdXQiKTsKICAgIH0KICAgIGlmICghc3RheSAmJiAhZmFpbGVkKXsKICAgICAgdHJ5IHsgbG9jYWxTdG9yYWdlLnNldEl0ZW0oTFMgKyAicmVkaXJlY3RBdCIsIFN0cmluZyhEYXRlLm5vdygpKSk7IH0gY2F0Y2goZSl7fQogICAgICBsb2NhdGlvbi5yZXBsYWNlKCJodHRwOi8vMTI3LjAuMC4xOjc2NDUvIik7CiAgICAgIHJldHVybjsKICAgIH0KICAgIGlmIChmYWlsZWQpewogICAgICAkKCJub3RyZWFkeSIpLnN0eWxlLmRpc3BsYXkgPSAiIjsKICAgICAgJCgibm90cmVhZHkiKS5pbm5lckhUTUwgPSAnPGRpdiBjbGFzcz0iaGludCI+VGhlIGhlbHBlciBkaWQgbm90IGFuc3dlciBhdCAnICsKICAgICAgICAnPGNvZGU+aHR0cDovLzEyNy4wLjAuMTo3NjQ1LzwvY29kZT4g4oCUIHN0YXJ0IGl0IHdpdGggdGhlIFNob3J0Y3V0IG9yIHRoZSBkb3dubG9hZCBiZWxvdywgJyArCiAgICAgICAgJ3RoZW4gcHJlc3MgUExBWS48L2Rpdj4nOwogICAgfQogIH0KICBTdG9yZS51c2FnZSgpLnRoZW4oZXN0ID0+IHsKICAgIGlmIChlc3QudXNlZCkgbG9nTGluZSgidGhpcyBicm93c2VyIGFscmVhZHkgaG9sZHMgIiArIGZtdChlc3QudXNlZCkgKyAiIGZvciB0aGlzIHBhZ2UiKTsKICB9KTsKICBKb3VybmFsLmxvYWQoKS50aGVuKGFzeW5jIChqKSA9PiB7CiAgICBpZiAoIWopIHJldHVybjsKICAgIGNvbnN0IHN0ID0gKGoubWV0YSB8fCB7fSkuc3RhdGUgfHwgIiI7CiAgICBjb25zdCBzdG9yZWQgPSBhd2FpdCBTdG9yZS5nZXQoImxhc3Qtc2Vzc2lvbi56aXAiKTsKICAgIGlmIChzdG9yZWQgJiYgL2V4aXRlZHxjYW5jZWxsZWQvaS50ZXN0KHN0KSl7IGF3YWl0IEpvdXJuYWwuY2xlYXIoKTsgcmV0dXJuOyB9CiAgICBpZiAoIS9leGl0ZWR8Y2FuY2VsbGVkL2kudGVzdChzdCkpIHNob3dSZWNvdmVyeShqKTsKICB9KTsKfSkoKTsKCjwvc2NyaXB0Pgo8L2JvZHk+CjwvaHRtbD4K"
DEFAULT_MEMORY = "2G"

# Origin allowlist for the browser-side fetch. The page is either served by this
# helper, or hosted on GitHub Pages, or served by the repo's own test server.
ORIGIN_PATTERNS = [
    re.compile(r"^http://(localhost|127\.0\.0\.1)(:\d+)?$"),
    re.compile(r"^https://localhost(:\d+)?$"),
    re.compile(r"^https://[a-z0-9-]+\.github\.io$"),
    re.compile(r"^https://[a-z0-9-]+\.pages\.dev$"),
]

PROXY_CANDIDATES = [
    "socks5h://127.0.0.1:1080",
    "socks5h://127.0.0.1:1088",
    "socks5h://127.0.0.1:10808",
    "socks5h://127.0.0.1:7890",
]

ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


def log_ts():
    return time.strftime("%H:%M:%S")


# --------------------------------------------------------------------------- os facts


def os_name():
    p = sys.platform
    if p == "darwin":
        return "osx"
    if p.startswith("win"):
        return "windows"
    return "linux"


def os_arch():
    m = platform.machine().lower()
    if m in ("arm64", "aarch64"):
        return "arm64"
    if m in ("x86_64", "amd64"):
        return "x86_64"
    return m


def os_version():
    if os_name() == "osx":
        return platform.mac_ver()[0]
    return platform.release()


# --------------------------------------------------------------------------- rules

def _rule_applies(rule, features):
    """Mojang's rule predicate: os name/arch/version plus launcher features."""
    cond = rule.get("os")
    if cond:
        if "name" in cond and cond["name"] != os_name():
            return False
        if "arch" in cond:
            want = cond["arch"]
            have = os_arch()
            # Mojang says "x86" for 32-bit intel; treat it as a prefix match so a
            # rule written for x86 also matches x86_64 only when it says so.
            if want == "x86":
                if have not in ("x86", "i386", "i686"):
                    return False
            elif want != have:
                return False
        if "version" in cond:
            try:
                if not re.search(cond["version"], os_version()):
                    return False
            except re.error:
                return False
    feats = rule.get("features")
    if feats:
        for k, v in feats.items():
            if bool(features.get(k, False)) != bool(v):
                return False
    return True


def rules_allow(rules, features):
    """Empty rules mean allowed; otherwise the *last* matching rule decides."""
    if not rules:
        return True
    allow = False
    for rule in rules:
        if _rule_applies(rule, features):
            allow = (rule.get("action") == "allow")
    return allow


# --------------------------------------------------------------------------- curl

class CurlError(RuntimeError):
    pass


class Cancelled(Exception):
    """Raised when the visitor stops a launch that has not finished starting."""


class Curl:
    """Thin curl wrapper: SOCKS-aware, parallel-capable, sha1-verifying."""

    def __init__(self, proxy=None, retries=3):
        self.proxy = proxy
        self.retries = retries
        self.curl = shutil.which("curl") or "/usr/bin/curl"
        self._lock = threading.Lock()
        self.bytes_in = 0
        # Where temporary files (curl's --parallel config) are written. The session
        # points this at its own sandbox so that nothing of ours can survive outside
        # it, even if the helper dies mid-download.
        self.workdir = None
        self.relay = None
        # Running curl processes, so a cancel can kill a download in flight instead of making
        # somebody wait for 430 MB of assets when they picked the wrong version.
        self._live = set()
        self._abort = False

    def abort(self):
        """Stop every download now. Idempotent, safe to call from another thread."""
        with self._lock:
            self._abort = True
            live = list(self._live)
        for proc in live:
            try:
                proc.kill()
            except Exception:
                pass
        return len(live)

    def clear_abort(self):
        with self._lock:
            self._abort = False

    def aborted(self):
        with self._lock:
            return self._abort

    def _run_curl(self, args, timeout=None):
        """Every curl goes through here, tracked, so abort() can reach it."""
        if self.aborted():
            raise CurlError("cancelled")
        proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        with self._lock:
            self._live.add(proc)
        try:
            out, err = proc.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            out, err = proc.communicate()
        finally:
            with self._lock:
                self._live.discard(proc)
        if self.aborted():
            raise CurlError("cancelled")
        return proc.returncode, out or b"", err or b""

    def workdir_path(self):
        d = self.workdir if (self.workdir and os.path.isdir(self.workdir)) \
            else os.environ.get("TMPDIR", "/tmp")
        return os.path.join(d, "webmc-curl-%s.conf" % secrets.token_hex(6))

    def _base(self):
        args = [self.curl, "-sS", "-L", "--fail", "--connect-timeout", "20",
                "--retry", str(self.retries), "--retry-connrefused",
                "--retry-delay", "1", "--create-dirs"]
        if self.proxy:
            args += ["--proxy", self.proxy]
        return args

    def get(self, url, dest=None, sha1=None, timeout=900, headers=()):
        """Download to dest (or return bytes when dest is None)."""
        url = relayed(url, getattr(self, "relay", None))
        if dest and sha1 and os.path.exists(dest) and sha1_of(dest) == sha1:
            return dest  # already there, and correct
        args = self._base() + ["-m", str(timeout)]
        for h in headers:
            args += ["-H", h]
        if dest:
            os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
            tmp = dest + ".part"
            args += ["-o", tmp, url]
        else:
            args += [url]
        code, out, err = self._run_curl(args, timeout=timeout + 30)
        if code != 0:
            if dest and os.path.exists(dest + ".part"):
                os.unlink(dest + ".part")
            raise CurlError("curl %s -> %s: %s" % (
                url, code, err.decode("utf-8", "replace").strip()[:300]))
        if dest:
            if sha1 and sha1_of(tmp) != sha1:
                os.unlink(tmp)
                raise CurlError("sha1 mismatch for %s" % url)
            os.replace(tmp, dest)
            with self._lock:
                self.bytes_in += os.path.getsize(dest)
            return dest
        with self._lock:
            self.bytes_in += len(out)
        return out

    def json(self, url, timeout=120, headers=()):
        raw = self.get(url, dest=None, timeout=timeout, headers=headers)
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError as exc:
            raise CurlError("bad json from %s: %s" % (url, exc))

    def batch(self, items, progress=None, workers=16, headers=()):
        """items: [(url, dest, sha1|None)]. Parallel, verifies, retries stragglers.

        Large batches go through a single `curl --parallel -K config` process:
        one process for thousands of objects, rather than thousands of processes.
        """
        todo = [it for it in items if not (it[2] and os.path.exists(it[1])
                                           and sha1_of(it[1]) == it[2])]
        if not todo:
            if progress:
                progress(len(items), len(items))
            return []
        if progress:
            progress(len(items) - len(todo), len(items))
        failed = []
        if len(todo) > 24:
            failed = self._batch_parallel(todo, progress, len(items),
                                          len(items) - len(todo), workers)
        else:
            failed = self._batch_threads(todo, progress, len(items),
                                         len(items) - len(todo), workers)
            failed = self._batch_parallel(todo, progress, len(items),
                                          len(items) - len(todo), workers)
        # verify + retry, individually, so a bad file can never survive
        for attempt in range(2):
            if not failed or self.aborted():
                break
            retry, failed = failed, []
            for item in retry:
                url, dest, sha1 = item
                try:
                    self.get(url, dest=dest, sha1=sha1, headers=headers)
                except CurlError as exc:
                    failed.append(item)
                    self._last_error = str(exc)
            if progress:
                progress(len(items) - len(failed), len(items), attempt + 2)
        return failed

    def _batch_threads(self, todo, progress, total, already, workers):
        from concurrent.futures import ThreadPoolExecutor
        failed = []
        done = [already]
        lock = threading.Lock()

        def one(item):
            url, dest, sha1 = item
            try:
                self.get(url, dest=dest, sha1=sha1)
            except CurlError:
                with lock:
                    failed.append(item)
            finally:
                with lock:
                    done[0] += 1
                    if progress:
                        progress(done[0], total)

        with ThreadPoolExecutor(max_workers=workers) as pool:
            list(pool.map(one, todo))
        return failed

    def _batch_parallel(self, todo, progress, total, already, workers):
        cfg = self.workdir_path()
        failed = []
        try:
            with open(cfg, "w") as fh:
                for url, dest, _sha1 in todo:
                    fh.write('url = "%s"\noutput = "%s"\n' % (url, dest))
            args = self._base() + ["--parallel", "--parallel-max", str(workers),
                                   "-K", cfg]
            if self.proxy:
                args += ["--proxy", self.proxy]
            proc = self._run_curl(args, timeout=1800)
            err = proc[2].decode("utf-8", "replace")
            code = proc[0]
            # which ones actually arrived intact?
            done = 0
            for item in todo:
                if os.path.exists(item[1]) and (not item[2] or sha1_of(item[1]) == item[2]):
                    done += 1
                else:
                    failed.append(item)
            if self.aborted():
                # A cancel is not a failure to report: nothing should be retried.
                raise CurlError("cancelled")
            if progress:
                progress(already + done, total)
            if failed and not err.strip():
                err = "(curl --parallel reported no detail)"
            self._last_error = err.strip()[-400:] if failed else ""
        finally:
            if os.path.exists(cfg):
                os.unlink(cfg)
        return failed


def sha1_of(path, chunk=1 << 20):
    h = hashlib.sha1()
    with open(path, "rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


# --------------------------------------------------------------------------- java

VER_RE = re.compile(r'version "([^"]+)"')


def java_major(java_path):
    try:
        proc = subprocess.run([java_path, "-version"], stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, timeout=30)
    except Exception:
        return 0
    out = proc.stdout.decode("utf-8", "replace")
    m = VER_RE.search(out)
    if not m:
        return 0
    v = m.group(1)
    if v.startswith("1."):
        try:
            return int(v.split(".")[1])
        except ValueError:
            return 0
    try:
        return int(re.match(r"(\d+)", v).group(1))
    except Exception:
        return 0


def find_javas():
    """Every java on the machine, best-effort, cheapest checks first."""
    cands = []
    env = os.environ.get("WEBMC_JAVA")
    if env:
        cands.append(env)
    home = os.environ.get("JAVA_HOME")
    if home:
        cands.append(os.path.join(home, "bin", "java"))
    for base, globs in (
        (os.path.expanduser("~/.jdks"), ("*/Contents/Home/bin/java", "*/bin/java")),
        ("/Library/Java/JavaVirtualMachines", ("*/Contents/Home/bin/java",)),
        (os.path.expanduser("~/Library/Java/JavaVirtualMachines"), ("*/Contents/Home/bin/java",)),
        ("/opt/homebrew/opt", ("openjdk*/bin/java", "openjdk@*/bin/java")),
        ("/usr/local/opt", ("openjdk*/bin/java", "openjdk@*/bin/java")),
    ):
        if not os.path.isdir(base):
            continue
        for g in globs:
            import glob as _glob
            cands.extend(sorted(_glob.glob(os.path.join(base, g)), reverse=True))
    which = shutil.which("java")
    if which:
        cands.append(which)
    out = []
    for c in cands:
        if c and os.path.exists(c) and os.access(c, os.X_OK) and c not in out:
            out.append(c)
    return out


def pick_java(required, explicit=None, log=None):
    if explicit:
        if not os.path.exists(explicit):
            raise RuntimeError("--java %s does not exist" % explicit)
        return explicit, java_major(explicit)
    found = []
    for c in find_javas():
        mj = java_major(c)
        if mj:
            found.append((mj, c))
    if not found:
        return None, 0
    found.sort(key=lambda t: -t[0])
    if log:
        log("java candidates: " + ", ".join("%d @ %s" % (m, c) for m, c in found[:6]))
    best_major, best = found[0]
    if best_major < required:
        return best, best_major  # caller decides whether to fetch a JRE
    return best, best_major


def fetch_jre(major, root, curl, log):
    arch = {"arm64": "aarch64", "x86_64": "x64"}.get(os_arch(), "x64")
    plat = "mac" if os_name() == "osx" else ("windows" if os_name() == "windows" else "linux")
    ext = "zip" if plat == "windows" else "tar.gz"
    url = "%s/binary/latest/%d/ga/%s/%s/jre/hotspot/normal/eclipse" % (
        ADOPTIUM_API, major, plat, arch)
    log("no Java %d here - fetching a JRE from Adoptium (%s/%s)" % (major, plat, arch))
    dest = os.path.join(root, "jre.%s" % ext)
    curl.get(url, dest=dest, timeout=1800)
    out = os.path.join(root, "jre")
    os.makedirs(out, exist_ok=True)
    if ext == "tar.gz":
        with tarfile.open(dest) as tf:
            tf.extractall(out)
    else:
        with zipfile.ZipFile(dest) as zf:
            zf.extractall(out)
    for base, _dirs, files in os.walk(out):
        if "java" in files and os.path.basename(base) == "bin":
            cand = os.path.join(base, "java")
            if os.access(cand, os.X_OK):
                return cand, java_major(cand)
    raise RuntimeError("fetched a JRE but could not find bin/java in it")


# --------------------------------------------------------------------------- downloads

def maven_to_path(coords):
    """group:artifact:version[:classifier] -> (relative path, file name)."""
    parts = coords.split(":")
    if len(parts) < 3:
        return None, None
    group, artifact, version = parts[0], parts[1], parts[2]
    classifier = parts[3] if len(parts) > 3 else None
    name = "%s-%s%s.jar" % (artifact, version, ("-" + classifier) if classifier else "")
    return "/".join([group.replace(".", "/"), artifact, version, name]), name


def vanilla_url(group, artifact, version, classifier=None, repo="https://libraries.minecraft.net"):
    rel, name = maven_to_path(":".join([group, artifact, version] + ([classifier] if classifier else [])))
    return "%s/%s" % (repo, rel), rel


class Registry:
    """Every session this helper has run, and the mod jars they share.

    A visitor may open two windows, or launch 1.21.11 next to 1.12.2, so "a session" is a thing the
    helper has many of rather than a property of the helper itself.
    """

    def __init__(self, cfg, curl, log=print):
        self.cfg = cfg
        self.curl = curl
        # Six places in here log through the relay (the SOCKS proxy opening a connection, the
        # tunnel coming up); without this they raised instead of logging.
        self.log = log
        self.lock = threading.RLock()
        self.sessions = {}
        self.order = []
        self.mods_dir = os.path.join(tempfile.gettempdir(), "webmc-mods-%d" % os.getpid())
        os.makedirs(self.mods_dir, exist_ok=True)
        self.pending_mods = []
        self.pending_restore = None
        self.started = time.time()
        self.last_touch = self.started
        self.store = session_store_dir(cfg)
        if getattr(cfg, "store_sessions", False):
            os.makedirs(self.store, exist_ok=True)

    def launch(self, opts):
        sid = secrets.token_hex(3)
        root = os.path.join("/tmp", "webmc-%s" % secrets.token_hex(4))
        cfg = argparse.Namespace(**vars(self.cfg))
        cfg.root = root
        requested = opts.get("relay")
        if requested is None:
            requested = getattr(self.cfg, "relay", None)
        cfg.relay = resolve_relay(requested, log=self.log)
        if opts.get("restricted"):
            cfg.restricted = True
        if opts.get("tunnelEverything"):
            cfg.proxy_game = True
        session = Session(cfg, self.curl, manager=self, sid=sid)
        session.pending_restore = self.pending_restore
        if session.pending_restore:
            session.pending_restore_from = "the page"
        self.pending_restore = None
        # Nothing from the page? Then start from what the helper kept last time, so a world does
        # not depend on which origin the visitor happened to press PLAY on.
        if session.pending_restore is None and opts.get("restore", True):
            kept = self.newest_stored(opts.get("version") or DEFAULT_VERSION)
            if kept:
                session.pending_restore, name = kept
                session.pending_restore_from = "the helper's own copy (%s)" % name
        with self.lock:
            self.sessions[sid] = session
            self.order.append(sid)
            while len(self.order) > 24:            # keep the page's list bounded
                oldest = self.order.pop(0)
                self.sessions.pop(oldest, None)
        session.start(opts)
        return session

    def touch(self):
        """The idle exit asks whether anybody is still using the helper at all, which is a
        question about the helper rather than about one of its sessions."""
        with self.lock:
            self.last_touch = time.time()

    # ---- keeping a session, and starting the next one from it
    def store_session(self, session):
        """Copy a finished session's bundle where the *next* launch can find it, whichever origin
        started this one."""
        if not getattr(self.cfg, "store_sessions", False) or not session.result:
            return None
        if not os.path.exists(session.bundle_path):
            return None
        version = (session.instance or {}).get("version") or "unknown"
        safe = re.sub(r"[^A-Za-z0-9._-]", "_", "%s-%s" % (version, session.sid))
        dest = os.path.join(self.store, safe + ".zip")
        try:
            shutil.copy2(session.bundle_path, dest)
        except OSError as exc:
            session.log("could not keep the session for next time: %s" % exc)
            return None
        session.log("kept this session for next time: %s (%s)"
                    % (dest, ", ".join(session.result.get("worlds") or []) or "no world yet"))
        self.prune_store()
        return dest

    def prune_store(self):
        keep = max(1, int(getattr(self.cfg, "keep_sessions", 5) or 5))
        try:
            files = sorted((os.path.join(self.store, n) for n in os.listdir(self.store)
                            if n.endswith(".zip")), key=os.path.getmtime, reverse=True)
        except OSError:
            return
        for old in files[keep:]:
            try:
                os.unlink(old)
            except OSError:
                pass

    def newest_stored(self, version):
        """The most recent kept session for a version, for a launch that has nothing from the page."""
        if not getattr(self.cfg, "store_sessions", False):
            return None
        try:
            candidates = [os.path.join(self.store, n) for n in os.listdir(self.store)
                          if n.endswith(".zip") and n.startswith(re.sub(r"[^A-Za-z0-9._-]", "_", version) + "-")]
        except OSError:
            return None
        if not candidates:
            return None
        newest = max(candidates, key=os.path.getmtime)
        try:
            with open(newest, "rb") as fh:
                return fh.read(), os.path.basename(newest)
        except OSError:
            return None

    def pick(self, sid=None):
        with self.lock:
            if sid and sid in self.sessions:
                return self.sessions[sid]
            if not self.order:
                return None
            for candidate in reversed(self.order):
                session = self.sessions.get(candidate)
                if session and session.state in ("running", "cancelling"):
                    return session
            return self.sessions.get(self.order[-1])

    def list(self):
        with self.lock:
            return [self.sessions[sid].status() for sid in reversed(self.order)
                    if sid in self.sessions]

    def stop_all(self):
        for session in list(self.sessions.values()):
            try:
                session.stop()
            except Exception:
                pass

    def cleanup_all(self):
        for session in list(self.sessions.values()):
            try:
                session.cleanup(why="the helper is stopping")
            except Exception:
                pass
        shutil.rmtree(self.mods_dir, ignore_errors=True)

    # ---- the mods a visitor handed over, shared by every session
    def accept_mod(self, name, blob):
        keeper = Session(self.cfg, self.curl, manager=self, sid="keeper")
        return keeper.accept_mod(name, blob)

    def drop_mod(self, name):
        keeper = Session(self.cfg, self.curl, manager=self, sid="keeper")
        return keeper.drop_mod(name)

    def clear_mods(self):
        keeper = Session(self.cfg, self.curl, manager=self, sid="keeper")
        return keeper.clear_mods()

    @property
    def mods(self):
        with self.lock:
            return list(self.pending_mods)


# --------------------------------------------------------------------------- the tunnel
#
# A network that lets nothing out but HTTPS makes a Minecraft server unreachable, because the game
# dials a raw TCP port. The fix is to carry that TCP connection inside a WebSocket to a relay that
# dials the server on the visitor's behalf - which is what Cloudflare Workers can do, and what this
# project's gateway already implements.
#
# The protocol is the one documented in gateway/cloudflare-worker.js ("goldproxy.v1"), so the Worker
# that repository deploys works with this unchanged:
#
#   POST /v1/token {host,port}          -> {"token":…}
#   WS   /v1/connect  {"t":"open",…}    <- {"t":"ready",…}
#   then binary frames are raw TCP, and text frames are
#        {"t":"ack","n"} (flow control), {"t":"ping"/"pong","id"}, {"t":"error",…}, {"t":"end",…}


class WebSocketError(RuntimeError):
    pass


def recv_exact(sock, count, timeout=30):
    """Read exactly this many bytes, or fail. SOCKS has no concept of a short reply."""
    sock.settimeout(timeout)
    out = b""
    while len(out) < count:
        chunk = sock.recv(count - len(out))
        if not chunk:
            raise OSError("the connection closed before it had sent %d bytes" % count)
        out += chunk
    return out


def parse_socks_url(url):
    """socks5h://host:port -> (host, port, resolve_here). h means the proxy resolves names."""
    import urllib.parse as _u
    parts = _u.urlsplit(url if "://" in url else "socks5h://" + url)
    if not parts.hostname:
        raise ValueError("not a proxy address: %r" % url)
    return parts.hostname, int(parts.port or 1080), parts.scheme.lower() == "socks5"


def socks5_connect(proxy_url, host, port, timeout=30):
    """Open a TCP connection to host:port *through* a SOCKS5 proxy that is already running.

    This is the other half of what a relay does: a relay carries the connection over HTTPS for you,
    this hands it to a proxy you already have (a VPN client, Shadowsocks, an SSH -D tunnel). The game
    cannot tell the difference, and neither can the server.
    """
    proxy_host, proxy_port, resolve_here = parse_socks_url(proxy_url)
    sock = socket.create_connection((proxy_host, proxy_port), timeout=timeout)
    try:
        # offer "no authentication" only: the proxies people actually run locally accept it, and a
        # password prompt is not something this helper should be collecting
        sock.sendall(b"\x05\x01\x00")
        greeting = recv_exact(sock, 2, timeout)
        if greeting[0] != 5:
            raise OSError("that is not a SOCKS5 proxy (it answered version %d)" % greeting[0])
        if greeting[1] != 0:
            raise OSError("that proxy wants a username and password, which this helper does not ask for")
        if resolve_here:
            try:
                address = socket.gethostbyname(host)
            except Exception:
                address = None
            if address:
                request = b"\x05\x01\x00\x01" + socket.inet_aton(address) + struct.pack("!H", int(port))
            else:
                request = (b"\x05\x01\x00\x03" + bytes([len(host)]) + host.encode()
                           + struct.pack("!H", int(port)))
        else:
            request = (b"\x05\x01\x00\x03" + bytes([len(host)]) + host.encode()
                       + struct.pack("!H", int(port)))
        sock.sendall(request)
        reply = recv_exact(sock, 4, timeout)
        if reply[1] != 0:
            reasons = {1: "general failure", 2: "not allowed by that proxy's rules", 3: "network unreachable",
                       4: "host unreachable", 5: "connection refused", 6: "timed out", 7: "unsupported",
                       8: "unsupported address"}
            raise OSError("the proxy refused %s:%s: %s" % (host, port, reasons.get(reply[1], reply[1])))
        if reply[3] == 1:
            recv_exact(sock, 4, timeout)
        elif reply[3] == 4:
            recv_exact(sock, 16, timeout)
        elif reply[3] == 3:
            recv_exact(sock, recv_exact(sock, 1, timeout)[0], timeout)
        recv_exact(sock, 2, timeout)
        return sock
    except Exception:
        try:
            sock.close()
        except Exception:
            pass
        raise


def pump_sockets(left, right, stop, log=None, label="proxy"):
    """Copy bytes between two ordinary sockets until either closes. The non-relay half of bridge()."""
    def copy(source, target):
        try:
            while not stop.is_set():
                data = source.recv(32768)
                if not data:
                    break
                target.sendall(data)
        except Exception:
            pass
        finally:
            stop.set()
    threads = [threading.Thread(target=copy, args=(left, right), daemon=True),
               threading.Thread(target=copy, args=(right, left), daemon=True)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=3600)
    for sock in (left, right):
        try:
            sock.close()
        except Exception:
            pass


class RelayDialer:
    """A dialer whose connections are carried inside a WebSocket to a relay."""

    kind = "relay"

    def __init__(self, relay, log=print, via_proxy=None):
        self.relay = relay.rstrip("/")
        self.log = log
        self.via_proxy = via_proxy
        self._probed = None

    def describe(self):
        return "the relay %s" % self.relay

    def sees(self):
        return "the relay's address"

    def _needs_proxy(self):
        """A relay on a blocked hostname fails fast and for everybody: find out once, before dialling."""
        if self._probed is None:
            self._probed = False
            if self.via_proxy:
                try:
                    parts = urllib.parse.urlsplit(self.relay)
                    probe = socket.create_connection((parts.hostname, parts.port or 443), timeout=4)
                    probe.close()
                except Exception:
                    self._probed = True
                    self.log("relay: %s is not reachable from here; reaching it through %s"
                             % (self.relay, self.via_proxy))
        return self._probed

    def attach(self, client, host, port, on_open=None):
        return bridge(client, self.relay, host, port, self.log, on_open=on_open,
                      via_proxy=self.via_proxy if self._needs_proxy() else None,
                      keep_client=True)


class SocksDialer:
    """A dialer whose connections go through a SOCKS5 proxy the visitor already runs."""

    kind = "socks"

    def __init__(self, proxy_url, log=print):
        self.proxy_url = proxy_url
        self.log = log

    def describe(self):
        return "your own proxy at %s" % self.proxy_url

    def sees(self):
        return "your proxy's address"

    def attach(self, client, host, port, on_open=None):
        try:
            far = socks5_connect(self.proxy_url, host, port)
        except Exception as exc:  # noqa: BLE001
            # Deliberately do not close the client: the caller answers it with a SOCKS failure, which
            # is a sentence Java understands. A closed socket reads as "Malformed reply".
            self.log("proxy: %s:%s could not be opened through %s: %s" % (host, port, self.proxy_url, exc))
            return False
        if on_open:
            on_open()
        stop = threading.Event()
        threading.Thread(target=pump_sockets, args=(client, far, stop, self.log), daemon=True).start()
        return True


class DirectDialer:
    """No proxy: the connection is made from this machine, which is what a normal network wants."""

    kind = "direct"

    def __init__(self, log=print):
        self.log = log

    def describe(self):
        return "a direct connection"

    def sees(self):
        return "your own address"

    def attach(self, client, host, port, on_open=None):
        try:
            far = socket.create_connection((host, int(port)), timeout=30)
        except Exception as exc:  # noqa: BLE001
            self.log("direct: %s:%s could not be reached: %s" % (host, port, exc))
            return False
        if on_open:
            on_open()
        stop = threading.Event()
        threading.Thread(target=pump_sockets, args=(client, far, stop, self.log), daemon=True).start()
        return True


def make_dialer(relay=None, socks=None, log=print, via_proxy=None):
    """One decision, in one place: how does the game's network traffic leave this machine?

    A relay when there is one (it works on networks that block game ports), the visitor's own proxy if
    they have one, and a direct connection otherwise.
    """
    if relay:
        if socks:
            log("game traffic: going through %s, reached via %s" % (relay, socks))
        return RelayDialer(relay, log=log, via_proxy=via_proxy)
    if socks:
        return SocksDialer(socks, log=log)
    return DirectDialer(log=log)


def dialer_from(value, log=print):
    """Accept either a dialer or a bare relay URL, so older callers keep working."""
    if value is None or isinstance(value, (RelayDialer, SocksDialer, DirectDialer)):
        return value
    return RelayDialer(str(value), log=log)


def ws_connect(url, timeout=20, via_proxy=None):
    """The smallest WebSocket client that can carry a byte stream: handshake, frames, ping/pong.

    Python's standard library has no WebSocket client, and this file aims to depend on nothing but
    the standard library, so it does the handshake and the framing itself.
    """
    import ssl
    parts = urllib.parse.urlsplit(url)
    secure = parts.scheme in ("wss", "https")
    host = parts.hostname
    port = parts.port or (443 if secure else 80)
    path = parts.path or "/"
    if parts.query:
        path += "?" + parts.query
    if via_proxy:
        # Reach the relay itself through a proxy this machine already has. Useful when the network
        # blocks the relay's own hostname but a proxy on 127.0.0.1 answers, which is a common shape.
        sock = socks5_connect(via_proxy, host, port, timeout=timeout)
    else:
        sock = socket.create_connection((host, port), timeout=timeout)
    if secure:
        sock = ssl.create_default_context().wrap_socket(sock, server_hostname=host)
    key = base64.b64encode(os.urandom(16)).decode()
    request = ("GET %s HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
               "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n"
               # the gateway speaks this dialect and refuses anything else, which is a good thing:
               # a relay that accepted any upgrade would be a browser-accessible port scanner
               "Sec-WebSocket-Protocol: goldproxy.v1\r\n\r\n"
               % (path, parts.netloc, key))
    sock.sendall(request.encode())
    # read the response headers, one byte at a time so nothing of the first frame is consumed
    head = b""
    while b"\r\n\r\n" not in head:
        chunk = sock.recv(1)
        if not chunk:
            raise WebSocketError("the relay closed the connection during the handshake")
        head += chunk
        if len(head) > 8192:
            raise WebSocketError("the relay sent no usable handshake")
    status, _, rest = head.decode("utf-8", "replace").partition("\r\n")
    if "101" not in status:
        raise WebSocketError("the relay refused the WebSocket: %s" % status.strip())
    expect = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")
                                           .encode()).digest()).decode()
    if expect.lower() not in rest.lower():
        raise WebSocketError("the relay's handshake did not match")
    return sock


def ws_send(sock, data, opcode=2):
    """One masked frame. Clients must mask; servers must not."""
    header = bytearray([0x80 | opcode])
    length = len(data)
    if length < 126:
        header.append(0x80 | length)
    elif length < (1 << 16):
        header.append(0x80 | 126)
        header += struct.pack("!H", length)
    else:
        header.append(0x80 | 127)
        header += struct.pack("!Q", length)
    mask = os.urandom(4)
    header += mask
    masked = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
    with _ws_lock_for(sock):
        sock.sendall(bytes(header) + masked)


def ws_recv(sock, timeout=None):
    """One frame: (opcode, payload). Raises on a closed connection."""
    def exact(n):
        buf = b""
        while len(buf) < n:
            chunk = sock.recv(n - len(buf))
            if not chunk:
                raise WebSocketError("closed")
            buf += chunk
        return buf
    if timeout is not None:
        sock.settimeout(timeout)
    first = exact(2)
    opcode = first[0] & 0x0F
    masked = bool(first[1] & 0x80)
    length = first[1] & 0x7F
    if length == 126:
        length = struct.unpack("!H", exact(2))[0]
    elif length == 127:
        length = struct.unpack("!Q", exact(8))[0]
    mask = exact(4) if masked else None
    payload = exact(length) if length else b""
    if mask:
        payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
    return opcode, payload


_WS_LOCKS = {}


def _ws_lock_for(sock):
    """One lock per socket, so two threads (game->relay, relay->game) never interleave frames."""
    with threading.Lock():
        lock = _WS_LOCKS.get(id(sock))
        if lock is None:
            lock = threading.Lock()
            _WS_LOCKS[id(sock)] = lock
        return lock


def bridge(client, relay, host, port, log, on_open=None, timeout=120, via_proxy=None,
           keep_client=False):
    """Carry one TCP connection through the relay: the piece both the tunnel and the SOCKS proxy need.

    Returns True once the relay said it was ready, False if it could not be reached at all.
    """
    relay_host = relay.rstrip("/")
    try:
        # The token request goes the same way the socket will. Through a proxy when that is the only
        # route to the relay, or it would fail with a connection refused nobody could explain.
        answer = http_json(relay_host.replace("ws://", "http://").replace("wss://", "https://")
                           + "/v1/token", body={"host": host, "port": int(port)},
                           via_proxy=via_proxy, timeout=30)
        token = answer.get("token")
        if not token:
            raise WebSocketError("the relay did not issue a token")
        ws_url = relay_host.replace("https://", "wss://").replace("http://", "ws://") + "/v1/connect"
        sock = ws_connect(ws_url, via_proxy=via_proxy)
        ws_send(sock, json.dumps({"t": "open", "v": 1, "token": token, "host": host,
                                  "port": int(port)}).encode(), opcode=1)
        for _ in range(20):
            opcode, payload = ws_recv(sock)
            if opcode == 9:
                ws_send(sock, payload, opcode=10)
                continue
            if opcode == 8:
                raise WebSocketError("the relay closed the connection")
            if opcode != 1:
                continue
            message = json.loads(payload.decode("utf-8", "replace"))
            if message.get("t") == "ready":
                break
            if message.get("t") == "error":
                raise WebSocketError(message.get("message") or message.get("code") or "refused")
        else:
            raise WebSocketError("the relay never said it was ready")
    except Exception as exc:  # noqa: BLE001
        log("relay: %s:%s could not be reached: %s" % (host, port, exc))
        if not keep_client:
            try:
                client.close()
            except Exception:
                pass
        return False

    if on_open:
        on_open()
    stop = threading.Event()

    def to_relay():
        try:
            while not stop.is_set():
                data = client.recv(32768)
                if not data:
                    break
                ws_send(sock, data)
        except Exception:
            pass
        finally:
            stop.set()
            try:
                ws_send(sock, b"", opcode=8)
            except Exception:
                pass

    threading.Thread(target=to_relay, daemon=True).start()
    received = 0
    try:
        while not stop.is_set():
            opcode, payload = ws_recv(sock, timeout=timeout)
            if opcode in (2, 0):
                client.sendall(payload)
                # flow control is cumulative: the relay replaces its counter with this number
                received += len(payload)
                try:
                    ws_send(sock, json.dumps({"t": "ack", "n": received}).encode(), opcode=1)
                except Exception:
                    pass
            elif opcode == 1:
                message = json.loads(payload.decode("utf-8", "replace"))
                if message.get("t") == "ping":
                    ws_send(sock, json.dumps({"t": "pong", "id": message.get("id")}).encode(), 1)
                elif message.get("t") in ("end", "error"):
                    break
            elif opcode == 9:
                ws_send(sock, payload, opcode=10)
            elif opcode == 8:
                break
    except Exception:
        pass
    finally:
        try:
            client.close()
        except Exception:
            pass
    return True


class SocksBridge:
    """A local SOCKS5 proxy whose connections are carried by the relay.

    This is the setting for a network that blocks everything but HTTPS: Java routes *every* TCP
    connection a program makes through `-DsocksProxyHost`, so pointing the game at this proxy is what
    makes joining a server, authenticating and fetching skins work - not just one server chosen in
    advance. It needs no administrator and touches nothing outside the session.
    """

    def __init__(self, dialer, port=0, log=print):
        # A relay URL or any dialer, so the game can be pointed at this proxy whether the way out
        # is a relay, the visitor's own proxy, or a direct connection.
        self.dialer = dialer_from(dialer, log=log)
        self.relay = getattr(self.dialer, "relay", None)
        self.port = int(port or 0)
        self.log = log
        self.server = None
        self.thread = None
        self.running = False
        self.connections = 0
    def start(self):
        self.server = socket.socket()
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind(("127.0.0.1", self.port))
        self.server.listen(16)
        self.port = self.server.getsockname()[1]
        self.running = True

        def accept():
            while self.running:
                try:
                    client, _addr = self.server.accept()
                except OSError:
                    break
                threading.Thread(target=self._handle, args=(client,), daemon=True).start()

        self.thread = threading.Thread(target=accept, daemon=True)
        self.thread.start()
        self.log("proxy: SOCKS5 on 127.0.0.1:%d, every connection carried by %s"
                 % (self.port, self.dialer.describe()))
        return self.port

    def stop(self):
        self.running = False
        try:
            if self.server:
                self.server.close()
        except Exception:
            pass

    def _handle(self, client):
        try:
            greeting = client.recv(2)
            if len(greeting) < 2 or greeting[0] != 5:
                client.close()
                return
            methods = client.recv(greeting[1])
            if 0 not in methods:
                client.sendall(b"\x05\xff")      # no acceptable method
                client.close()
                return
            client.sendall(b"\x05\x00")           # no authentication
            head = client.recv(4)
            if len(head) < 4 or head[0] != 5 or head[1] != 1:
                client.close()
                return
            kind = head[3]
            if kind == 1:
                host = socket.inet_ntoa(client.recv(4))
            elif kind == 3:
                length = client.recv(1)[0]
                host = client.recv(length).decode("utf-8", "replace")
            elif kind == 4:
                host = socket.inet_ntop(socket.AF_INET6, client.recv(16))
            else:
                client.close()
                return
            port = struct.unpack("!H", client.recv(2))[0]
            def opened():
                # The reply the SOCKS client is blocked on. Without it the game waits for an answer
                # that never comes, then reads server bytes as if they were that answer.
                self._count(host, port)
                try:
                    client.sendall(b"\x05\x00\x00\x01" + socket.inet_aton("0.0.0.0")
                                   + struct.pack("!H", 0))
                except Exception:
                    pass

            # whichever dialer it is, it says when the far end is up
            ok = self.dialer.attach(client, host, port, on_open=opened)
            if not ok:
                client.sendall(b"\x05\x05\x00\x01\x00\x00\x00\x00\x00\x00")
        except Exception:
            try:
                client.close()
            except Exception:
                pass

    def _count(self, host, port):
        self.connections += 1
        self.log("proxy: %s:%s is open through %s" % (host, port, self.dialer.describe()))
class Tunnel:
    """One Minecraft server, reachable at 127.0.0.1:<local port> through a relay.

    The game connects to the local address as if it were the server; every connection is carried to
    the relay inside a WebSocket, and the relay dials the real server.
    """

    def __init__(self, dialer, host, port, local_port=0, log=print):
        self.dialer = dialer_from(dialer, log=log)
        self.relay = getattr(self.dialer, "relay", None)
        self.host = host
        self.port = int(port)
        self.local_port = int(local_port or 0)
        self.log = log
        self.server = None
        self.thread = None
        self.running = False
        self.connections = 0
    def _token(self):
        import urllib.request
        body = json.dumps({"host": self.host, "port": self.port}).encode()
        req = urllib.request.Request(self.relay.replace("ws://", "http://").replace("wss://", "https://")
                                     + "/v1/token", data=body,
                                     headers={"Content-Type": "application/json",
                                              "User-Agent": "%s/%s" % (NAME, VERSION)})
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode("utf-8", "replace"))
        token = data.get("token")
        if not token:
            raise WebSocketError("the relay did not issue a token: %s" % data)
        return token

    def _pump(self, client):
        """One game connection: open the far end however the dialer does, then copy both ways."""
        self.dialer.attach(client, self.host, self.port, on_open=self._opened)

    def _opened(self):
        self.connections += 1
        self.log("tunnel: %s:%d is open through %s"
                 % (self.host, self.port, self.dialer.describe()))
    def _pump_unused(self, client):
        try:
            token = self._token()
            ws_url = (self.relay.replace("https://", "wss://").replace("http://", "ws://")
                      .rstrip("/") + "/v1/connect")
            sock = ws_connect(ws_url)
            ws_send(sock, json.dumps({"t": "open", "v": 1, "token": token,
                                      "host": self.host, "port": self.port}).encode(), opcode=1)
            # wait for ready, ignoring anything else the relay says first
            for _ in range(20):
                opcode, payload = ws_recv(sock)
                if opcode == 9:
                    ws_send(sock, payload, opcode=10)
                    continue
                if opcode in (8,):
                    raise WebSocketError("the relay closed the connection")
                if opcode != 1:
                    continue
                message = json.loads(payload.decode("utf-8", "replace"))
                if message.get("t") == "ready":
                    break
                if message.get("t") == "error":
                    raise WebSocketError(message.get("message") or message.get("code") or "refused")
            else:
                raise WebSocketError("the relay never said it was ready")
            self.connections += 1
            self.log("tunnel: %s:%d is open through the relay" % (self.host, self.port))
            stop = threading.Event()

            def to_relay():
                try:
                    while not stop.is_set():
                        data = client.recv(32768)
                        if not data:
                            break
                        ws_send(sock, data)
                except Exception:
                    pass
                finally:
                    stop.set()
                    try:
                        ws_send(sock, b"", opcode=8)
                    except Exception:
                        pass

            up = threading.Thread(target=to_relay, daemon=True)
            up.start()
            received = 0
            while not stop.is_set():
                opcode, payload = ws_recv(sock, timeout=120)
                if opcode == 2 or opcode == 0:
                    client.sendall(payload)
                    # The relay's flow control is a *cumulative* count: it pauses the target while
                    # the client has more unacknowledged bytes than the window, and it sets its own
                    # counter from this number rather than adding to it. Sending the size of one
                    # frame here stalls a real session after a few hundred kilobytes.
                    received += len(payload)
                    try:
                        ws_send(sock, json.dumps({"t": "ack", "n": received}).encode(), opcode=1)
                    except Exception:
                        pass
                elif opcode == 1:
                    message = json.loads(payload.decode("utf-8", "replace"))
                    if message.get("t") == "ping":
                        ws_send(sock, json.dumps({"t": "pong", "id": message.get("id")}).encode(), 1)
                    elif message.get("t") in ("end", "error"):
                        break
                elif opcode == 9:
                    ws_send(sock, payload, opcode=10)
                elif opcode == 8:
                    break
        except Exception as exc:  # noqa: BLE001
            self.log("tunnel: %s:%d could not be reached through the relay: %s"
                     % (self.host, self.port, exc))
        finally:
            try:
                client.close()
            except Exception:
                pass

    def start(self):
        if self.dialer is None:
            raise WebSocketError("tunnelling a server needs a relay or a proxy "
                                 "(Settings → If a network blocks things)")
        self.server = socket.socket()
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind(("127.0.0.1", self.local_port))
        self.server.listen(4)
        self.local_port = self.server.getsockname()[1]
        self.running = True

        def accept():
            while self.running:
                try:
                    client, _addr = self.server.accept()
                except OSError:
                    break
                threading.Thread(target=self._pump, args=(client,), daemon=True).start()

        self.thread = threading.Thread(target=accept, daemon=True)
        self.thread.start()
        self.log("tunnel: %s:%d will be reachable at 127.0.0.1:%d through %s"
                 % (self.host, self.port, self.local_port, self.dialer.describe()))
        return self.local_port

    def stop(self):
        self.running = False
        try:
            if self.server:
                self.server.close()
        except Exception:
            pass


# --------------------------------------------------------------------------- session

class Session:
    """One sandbox, one game, one lifecycle.

    More than one of these can be alive at once - two windows, two versions - so each session gets
    its own Curl (its own downloads to abort) and its own sandbox, and shares only the mod jars the
    visitor handed over and the proxy/relay settings.
    """

    def __init__(self, cfg, curl, manager=None, sid=None):
        self.cfg = cfg
        # a private Curl, so stopping one session cannot abort another's downloads
        self.curl = Curl(proxy=getattr(curl, "proxy", None))
        self.curl.relay = getattr(cfg, "relay", None)
        self.manager = manager
        self.sid = sid or secrets.token_hex(3)
        self.lock = threading.RLock()
        self.lines = []
        self.state = "idle"          # idle|running|exited|cancelled|failed
        self.phase = ""
        self.phase_label = ""
        self.done = 0
        self.total = 0
        self.error = None
        self.instance = {}
        self.pid = None
        self.exit_code = None
        self.started_at = None
        self.ended_at = None
        self.result = None           # collected bundle info
        self.proc = None
        self.thread = None
        self.cleanup_deadline = None
        self.last_cleanup = None
        self.cancel_requested = False
        self.last_touch = time.time()
        self.pending_mods = []      # jars the page pushed in, waiting for a launch
        self.tunnel = None          # a server carried to us through a relay, when asked for
        self.socks = None           # a local SOCKS5 proxy the game itself is pointed at
        self.dialer = None          # how the game's own connections leave this machine
        self.quick_play = None      # 127.0.0.1:<port>, handed to the client to join
        self.java = None
        self.java_major = 0
        self.jre_fetched = False
        self._versions_cache = None

    # ---------------------------------------------------------------- root paths
    @property
    def root(self):
        return self.cfg.root

    @property
    def game_dir(self):
        return os.path.join(self.root, "game")

    @property
    def libs_dir(self):
        return os.path.join(self.root, "libraries")

    @property
    def assets_dir(self):
        return os.path.join(self.root, "assets")

    @property
    def natives_dir(self):
        return os.path.join(self.root, "natives")

    @property
    def versions_dir(self):
        return os.path.join(self.root, "versions")

    @property
    def bundle_path(self):
        return os.path.join(self.root, "session.zip")

    def write_file(self, rel, data):
        path = os.path.join(self.root, rel)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as fh:
            fh.write(data if isinstance(data, bytes) else data.encode("utf-8"))
        return path

    # ---------------------------------------------------------------- status
    def log(self, line, echo=True):
        line = ANSI_RE.sub("", str(line)).rstrip("\n")
        if not line.strip():
            return
        with self.lock:
            self.lines.append("[%s] %s" % (log_ts(), line))
            if len(self.lines) > 4000:
                del self.lines[:1000]
        if echo:
            sys.stdout.write("  %s\n" % line)
            sys.stdout.flush()

    def set(self, **kw):
        with self.lock:
            for k, v in kw.items():
                setattr(self, k, v)

    def status(self):
        with self.lock:
            total = self.total or 0
            data = {
                "sid": self.sid,
                "state": self.state,
                "phase": self.phase,
                "phaseLabel": self.phase_label,
                "progress": {
                    "done": self.done,
                    "total": total,
                    "percent": int(100 * self.done / total) if total else None,
                },
                "instance": dict(self.instance),
                "pid": self.pid,
                "exitCode": self.exit_code,
                "startedAt": self.started_at,
                "endedAt": self.ended_at,
                "error": self.error,
                "java": self.java,
                "javaMajor": self.java_major,
                "jreFetched": self.jre_fetched,
                "downloadedBytes": self.curl.bytes_in,
                "lines": len(self.lines),
                "result": self.result,
            }
        self.refresh_cleanup_deadline()
        data["cleanupAt"] = self.cleanup_deadline
        data["lastCleanup"] = self.last_cleanup
        data["pendingMods"] = [{"name": m["name"], "bytes": m["bytes"],
                               "title": m.get("title"), "version": m.get("version")}
                              for m in self.pending_mods]
        # A second tab (or the same visitor later) must be able to tell that another page
        # has already taken this session's files and the sandbox has been deleted, rather
        # than reporting a failed download.
        if data["result"]:
            data["result"] = dict(data["result"])
            data["result"]["available"] = os.path.exists(self.bundle_path)
        return data

    def refresh_cleanup_deadline(self):
        """After the game exits and the bundle exists, the sandbox gets a timer."""
        with self.lock:
            if (self.state in ("exited", "failed") and self.result
                    and self.cleanup_deadline is None and self.cfg.autoclean):
                self.cleanup_deadline = time.time() + self.cfg.autoclean

    def lines_since(self, n):
        with self.lock:
            return self.lines[n:], len(self.lines)

    # ---------------------------------------------------------------- lifecycle
    def start(self, opts):
        with self.lock:
            if self.state == "running":
                raise RuntimeError("a session is already running")
            self.state = "running"
            self.error = None
            self.exit_code = None
            self.result = None
            self.done = 0
            self.total = 0
            self.cleanup_deadline = None
            self.cancel_requested = False
            self.started_at = time.time()
            self.ended_at = None
        self.curl.clear_abort()
        self.thread = threading.Thread(target=self._run, args=(opts,), daemon=True)
        self.thread.start()

    def touch(self):
        """Remember that somebody is still talking to us: the idle exit uses this, so a helper
        nobody is driving disappears on its own instead of lingering as a background process."""
        with self.lock:
            self.last_touch = time.time()

    def _check_cancelled(self):
        if self.cancel_requested or self.curl.aborted():
            raise Cancelled("stopped on request")

    def cancel(self, why="the page asked for it"):
        """Stop a launch that has not started yet: the downloads, then the game.

        Stop used to mean "kill the game process", which did nothing while 430 MB of assets
        were still downloading - so picking the wrong version meant waiting for it. This
        interrupts the downloads, ends the job at its next step, and still collects what the
        attempt produced so the page can keep it.
        """
        with self.lock:
            self.cancel_requested = True
            was_running = self.state == "running"
        killed = self.curl.abort()
        game = self.stop()
        self.log("stop requested: cancelling everything%s%s"
                 % (" (%d download(s) killed)" % killed if killed else "",
                    " (game killed)" if game else ""))
        with self.lock:
            if was_running and not game:
                self.state = "cancelling"
        return {"cancelled": True, "downloads": killed, "game": game,
                "why": why, "state": self.state}

    def stop(self):
        self._stop_tunnel()
        with self.lock:
            proc = self.proc
        if proc and proc.poll() is None:
            self.log("stop requested - sending SIGTERM to pid %d" % proc.pid)
            try:
                proc.terminate()
            except Exception:
                pass
            for _ in range(40):
                if proc.poll() is not None:
                    break
                time.sleep(0.25)
            if proc.poll() is None:
                self.log("still alive - SIGKILL")
                try:
                    proc.kill()
                except Exception:
                    pass
            return True
        return False

    def _progress(self, label, done, total):
        with self.lock:
            self.phase_label = label
            self.done = done
            self.total = total

    def _phase(self, name, label=None, total=0, check_cancel=True):
        # Every step of a launch goes through here, so a stop lands between steps rather
        # than at the end of them. Collecting is the exception: once a stop has been
        # honoured, what the attempt produced still has to be saved, not cancelled again.
        if check_cancel:
            self._check_cancelled()
        with self.lock:
            self.phase = name
            self.phase_label = label or name
            self.done = 0
            self.total = total
        if label:
            self.log(label)

    # ---------------------------------------------------------------- the run
    def _run(self, opts):
        try:
            self.log("sandbox: %s" % self.root)
            self._prepare_root()
            if getattr(self, "pending_restore", None):
                try:
                    self.log("putting your last session back, from %s"
                             % getattr(self, "pending_restore_from", "a saved bundle"))
                    self.restore(self.pending_restore)
                except Exception as exc:  # noqa: BLE001
                    self.log("could not put the previous session back: %s" % exc)
            self._preseed_options()
            mc_version = opts["version"]

            # ---- version metadata, read first because it says which Java the client needs
            # (26.x is compiled for Java 25; handing it Java 21 fails with "class file version 69.0")
            self._phase("metadata", "reading %s from Mojang" % mc_version)
            vjson, vurl = self._version_json(mc_version)
            required = int((vjson.get("javaVersion") or {}).get("majorVersion") or 21)

            # ---- java
            self._phase("java", "looking for a Java runtime")
            if getattr(self.cfg, "restricted", False):
                # Restricted mode: never touch a Java the machine already has. The runtime comes
                # into the sandbox and dies with it, so nothing outside /tmp is read or run.
                self.log("restricted mode: a Java runtime will be fetched into the sandbox "
                         "rather than used from this machine")
                java, major = None, 0
                if self.cfg.java and java_major(self.cfg.java):
                    java, major = self.cfg.java, java_major(self.cfg.java)
            else:
                java, major = pick_java(required, explicit=self.cfg.java, log=self.log)
            if not java or major < required:
                if self.cfg.no_jre_download:
                    raise RuntimeError(
                        "no Java %d found (best: %s) and --no-jre-download was given"
                        % (required, java or "none"))
                if java:
                    self.log("best local Java is %d, this version needs %d - fetching one "
                             "into the sandbox (it dies with the sandbox)" % (major, required))
                java, major = fetch_jre(required, self.root, self.curl, self.log)
                self.jre_fetched = True
            self.java = java
            self.java_major = major
            self.log("java: %s (%d)" % (java, major))

            self.log("client: %s (%d MB)" % (
                vjson["id"], vjson["downloads"]["client"]["size"] // (1 << 20)))

            # ---- vanilla files
            client_jar = self._client_jar(vjson)
            libs = self._libraries(vjson, self.curl)
            assets_ok = self._assets(vjson, opts.get("assets", True))

            # ---- fabric
            loader_kind = (opts.get("loaderKind") or "fabric").lower()
            if loader_kind in ("none", "vanilla"):
                loader_kind = "none"
            loader_ver = opts.get("loader") or "auto"
            profile, loader_ver = self._loader_profile(loader_kind, mc_version, loader_ver)
            loader_libs = self._profile_libraries(profile)
            all_libs = libs + loader_libs

            # ---- mods
            mods = self._mods(opts.get("mods") or [], mc_version, loader_ver)
            local = list(self.cfg.mod_jar or []) + list(opts.get("localMods") or [])
            local += self._pending_mod_paths()
            mods += self._local_mods(local)

            # ---- how the game's traffic leaves this machine, decided once and said out loud
            wants_proxy = bool(opts.get("tunnelEverything") or self.cfg.proxy_game)
            server = (opts.get("tunnelServer") or "").strip()
            game_socks = self.cfg.game_proxy or self.cfg.proxy
            if (wants_proxy or server or self.cfg.relay) and not game_socks:
                found = detect_proxy(None, lambda m: None)
                if found:
                    self.log("a proxy is already running here (%s), so this session will use it" % found)
                    game_socks = found
            self.cfg.relay = resolve_relay(self.cfg.relay, log=self.log, via_proxy=game_socks)
            relay_via = _RELAY_CHOICE.get("via") or (game_socks if self.cfg.relay else None)
            self.dialer = make_dialer(relay=self.cfg.relay, socks=game_socks, log=self.log,
                                      via_proxy=relay_via)

            if wants_proxy:
                if self.dialer.kind == "direct":
                    self.log("the game would connect directly: give it a relay or a proxy first "
                             "(Settings → If a network blocks things)")
                else:
                    try:
                        self.socks = SocksBridge(self.dialer, log=self.log)
                        self.socks_port = self.socks.start()
                        self.log("the game's own connections will go through %s; the server will see %s"
                                 % (self.dialer.describe(), self.dialer.sees()))
                    except Exception as exc:  # noqa: BLE001
                        self.log("could not start the proxy: %s" % exc)
                        self.socks = None

            # ---- one server, carried to us, if one was asked for
            if server:
                host, _sep, port = server.rpartition(":")
                if not host or not port.isdigit():
                    self.log("that server address is not host:port - ignoring %r" % server)
                else:
                    try:
                        # servers are often a signpost: the name in the handshake stays the same, but
                        # the connection has to go where the SRV record points
                        real = minecraft_srv(host, via_proxy=_RELAY_CHOICE.get("via") or self.cfg.proxy,
                                             log=self.log)
                        dial_host, dial_port = (real[0], real[1]) if real else (host, int(port))
                        self.tunnel = Tunnel(self.dialer, dial_host, dial_port,
                                             local_port=int(opts.get("tunnelPort") or 0),
                                             log=self.log)
                        local = self.tunnel.start()
                        self.quick_play = "127.0.0.1:%d" % local
                        self.log("the game will join %s; that is carried to %s:%s through %s, so the "
                                 "server will see %s" % (self.quick_play, host, port,
                                                         self.dialer.describe(), self.dialer.sees()))
                    except Exception as exc:  # noqa: BLE001
                        self.log("could not tunnel %s: %s" % (server, exc))
                        self.tunnel = None

            # ---- command
            self._phase("launch", "starting the game")
            cmd, classpath = self._build_command(
                vjson, profile, client_jar, all_libs, mc_version, loader_ver,
                opts.get("username") or "Player", opts.get("memory") or DEFAULT_MEMORY,
                mods)
            self.write_file("launch-command.txt",
                            "\n".join(shell_quote(c) for c in cmd) + "\n")
            if self.cfg.dry_run:
                self.log("dry run: command written to %s/launch-command.txt"
                         % self.root)
                self.log("dry run: not starting the game")
                self.instance = {
                    "version": mc_version, "loader": "fabric-%s" % loader_ver,
                    "mods": [m["name"] for m in mods],
                    "username": opts.get("username") or "Player",
                    "memory": opts.get("memory") or DEFAULT_MEMORY, "offline": True,
                }
                with self.lock:
                    self.state = "exited"
                    self.exit_code = 0
                    self.phase = "dry-run"
                    self.phase_label = "dry run complete"
                    self.ended_at = time.time()
                self._collect()
                return
            self.log("classpath: %d entries" % len(classpath))
            self.log("mods: %s" % (", ".join(m["name"] for m in mods) if mods else "(none)"))
            self.log("assets: %s" % ("downloaded" if assets_ok else "SKIPPED (missing sounds/textures)"))

            logfile = open(os.path.join(self.root, "console.log"), "wb")
            self.proc = subprocess.Popen(cmd, cwd=self.game_dir, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
            self.pid = self.proc.pid
            self.instance = {
                "version": mc_version,
                "loader": ("%s-%s" % (loader_kind, loader_ver)) if loader_kind != "none" else "vanilla",
                "mods": [m["name"] for m in mods],
                "username": opts.get("username") or "Player",
                "memory": opts.get("memory") or DEFAULT_MEMORY,
                "offline": True,
            }
            self.log("pid %d - minecraft is running; close the window when you are done" % self.pid)
            with self.lock:
                self.state = "running"
            sink = threading.Thread(target=self._pump, args=(self.proc.stdout, logfile),
                                    daemon=True)
            sink.start()
            code = self.proc.wait()
            sink.join(timeout=10)
            logfile.close()
            self.exit_code = code
            self.log("game exited with code %s" % code)
            self._collect()
            with self.lock:
                self.state = "cancelled" if code not in (0, None) and code < 0 else "exited"
                self.phase = "done"
                self.phase_label = "session finished"
                self.ended_at = time.time()
        except Cancelled as exc:
            self.log("stopped: %s" % exc)
            try:
                # Even a stopped attempt keeps its log: that is the difference between
                # "it didn't work" and "it didn't work and nobody knows why".
                self._collect()
            except Exception as collect_problem:  # noqa: BLE001
                self.log("nothing could be collected: %s" % collect_problem)
            with self.lock:
                self.state = "cancelled"
                self.phase = "cancelled"
                self.phase_label = "Stopped"
                self.ended_at = time.time()
        except Exception as exc:  # noqa: BLE001 - surfaced to the page
            if isinstance(exc, CurlError) and str(exc) == "cancelled":
                with self.lock:
                    self.state = "cancelled"
                    self.phase = "cancelled"
                    self.phase_label = "Stopped"
                    self.ended_at = time.time()
                self.log("stopped on request")
                try:
                    self._collect()
                except Exception:  # noqa: BLE001
                    pass
            else:
                self.error = "%s: %s" % (type(exc).__name__, exc)
                self.log("FAILED - %s" % self.error)
                with self.lock:
                    self.state = "failed"
                    self.phase = "failed"
                    self.phase_label = "failed"
                    self.ended_at = time.time()

        finally:
            # Whatever happened, the sandbox now has a deadline: if the page never collects the
            # result, the watchdog deletes it.
            self.refresh_cleanup_deadline()

    def _pump(self, stream, logfile):
        interesting = re.compile(
            r"Loading \d+ mods|fabric-loader|KnotClient|LWJGL|Backend library|Setting user|"
            r"OpenGL|Sound engine|Started|Stopping|Exception|Error|crash|Mixin|"
            r"Preparing|Reloading|thread", re.I)
        for raw in iter(stream.readline, b""):
            logfile.write(raw)
            logfile.flush()
            text = ANSI_RE.sub("", raw.decode("utf-8", "replace"))
            if interesting.search(text):
                self.log(text, echo=False)
            else:
                with self.lock:
                    self.lines.append("[%s] %s" % (log_ts(), text.rstrip()))

    # ---------------------------------------------------------------- sandbox
    def _prepare_root(self):
        os.makedirs(self.root, mode=0o700, exist_ok=True)
        os.chmod(self.root, 0o700)
        for d in (self.game_dir, self.libs_dir, self.assets_dir,
                  os.path.join(self.assets_dir, "indexes"),
                  os.path.join(self.assets_dir, "objects"),
                  self.natives_dir, self.versions_dir,
                  os.path.join(self.game_dir, "mods"),
                  os.path.join(self.game_dir, "saves")):
            os.makedirs(d, exist_ok=True)
        self.curl.workdir = self.root
        if getattr(self.cfg, "relay", None):
            # Everything downloaded this session goes through the relay instead of straight to
            # Mojang - which is the point of it on a network that blocks Mojang.
            self.curl.relay = self.cfg.relay
            self.log("relay: every download goes through %s" % self.cfg.relay)
        self._write_owner()
        self._link_cache()

    def _write_owner(self):
        """A note to whoever finds this directory later: who made it, and when.

        If this helper is ever killed outright (SIGKILL, a crash, the machine going
        down) the sandbox is left behind with nobody to delete it. The next helper to
        start reads this, sees that the owning process is gone, and deletes it there
        and then - rather than waiting for an arbitrary age to pass.
        """
        data = {
            "pid": os.getpid(),
            "started": time.time(),
            "helper": VERSION,
            "argv": sys.argv[1:],
            "boot": _boot_id(),
        }
        try:
            with open(os.path.join(self.root, "owner.json"), "w") as fh:
                json.dump(data, fh, indent=1)
        except OSError:
            pass

    def _link_cache(self):
        """Optional: borrow Mojang's immutable files from a cache instead of
        re-downloading 450 MB every time. Off by default - the promise is that a
        session leaves nothing behind, and only the visitor can decide to trade
        that for speed. The sandbox symlinks the cache; deleting the sandbox
        unlinks them and leaves the cache alone."""
        if not self.cfg.cache:
            return
        cache = os.path.abspath(os.path.expanduser(self.cfg.cache))
        for name in ("assets", "libraries"):
            src = os.path.join(cache, name)
            dst = os.path.join(self.root, name)
            os.makedirs(os.path.join(src, "indexes"), exist_ok=True)
            os.makedirs(os.path.join(src, "objects"), exist_ok=True)
            if os.path.islink(dst):
                os.unlink(dst)
            elif os.path.isdir(dst):
                shutil.rmtree(dst, ignore_errors=True)
            elif os.path.exists(dst):
                os.unlink(dst)
            os.symlink(src, dst)
        # the client jar and the version json are immutable too, so they cache by
        # name: a second launch then needs no network for them at all
        cver = os.path.join(cache, "versions")
        os.makedirs(cver, exist_ok=True)
        for entry in os.listdir(cver):
            src = os.path.join(cver, entry)
            dst = os.path.join(self.versions_dir, entry)
            if os.path.exists(dst) or os.path.islink(dst):
                continue
            os.symlink(src, dst)
        self.log("cache: assets, libraries and the client jar are borrowed from %s" % cache)

    def _version_json(self, version):
        cache = os.path.join(self.versions_dir, "%s.json" % version)
        if os.path.exists(cache):
            with open(cache) as fh:
                data = json.load(fh)
            return data, data.get("_url", "")
        manifest = self.curl.json(MANIFEST_URL, headers=self._ua())
        rels = [v for v in manifest["versions"] if v["type"] == "release"]
        match = None
        for v in manifest["versions"]:
            if v["id"] == version:
                match = v
                break
        if not match:
            near = ", ".join(v["id"] for v in (rels or manifest["versions"])[:8])
            raise RuntimeError("version %s is not in Mojang's list (newest releases: %s)"
                               % (version, near))
        data = self.curl.json(match["url"], headers=self._ua())
        data["_url"] = match["url"]
        os.makedirs(self.versions_dir, exist_ok=True)
        with open(cache, "w") as fh:
            json.dump(data, fh)
        return data, match["url"]

    def versions(self):
        with self.lock:
            if self._versions_cache:
                return self._versions_cache
        manifest = self.curl.json(MANIFEST_URL, headers=self._ua())
        rel = [v["id"] for v in manifest["versions"] if v["type"] == "release"][:40]
        allv = [v["id"] for v in manifest["versions"]][:40]
        out = {"latest": manifest["latest"], "releases": rel, "newest": allv}
        with self.lock:
            self._versions_cache = out
        return out

    def _client_jar(self, vjson):
        dl = vjson["downloads"]["client"]
        dest = os.path.join(self.versions_dir, "%s" % dl.get("path", "client.jar"))
        if os.path.isdir(dest):
            dest = os.path.join(dest, "client.jar")
        self._phase("client", "client jar (%.0f MB)" % (dl["size"] / 1048576.0))
        self.curl.get(dl["url"], dest=dest, sha1=dl.get("sha1"), headers=self._ua())
        self._progress("client jar", 1, 1)
        return dest

    def _libraries(self, vjson, curl):
        features = self._features()
        wanted = []
        natives = []
        for lib in vjson["libraries"]:
            if not rules_allow(lib.get("rules"), features):
                continue
            art = lib.get("downloads", {}).get("artifact")
            if art:
                wanted.append((art["url"], os.path.join(self.libs_dir, art["path"]),
                               art.get("sha1"), lib.get("name", "")))
            elif lib.get("name"):
                # no explicit downloads block: build it from maven coordinates
                rel, _name = maven_to_path(lib["name"])
                if rel:
                    repo = (lib.get("url") or "https://libraries.minecraft.net").rstrip("/")
                    wanted.append(("%s/%s" % (repo, rel), os.path.join(self.libs_dir, rel),
                                   None, lib.get("name", "")))
            if lib.get("natives"):
                natives.append(lib)
        # Apple Silicon: Mojang lists both natives-macos and natives-macos-arm64 with
        # identical rules, so both would land on the classpath and LWJGL could extract
        # the x86_64 dylib. Prefer the arm64 variant and drop the plain one.
        wanted = self._prefer_arch(wanted)
        self._phase("libraries", "libraries (%d)" % len(wanted), len(wanted))
        failed = curl.batch([(u, d, s) for u, d, s, _n in wanted],
                            progress=self._progress_cb("libraries"), headers=self._ua())
        if failed:
            self.log("WARNING: %d libraries failed: %s" % (
                len(failed), "; ".join(os.path.basename(f[1]) for f in failed[:4])))
        paths = [d for _u, d, _s, _n in wanted if os.path.exists(d)]
        # classic natives (pre-1.19): extract into natives/
        for lib in natives:
            art = lib.get("downloads", {}).get("classifiers", {}) or {}
            key = lib["natives"].get(os_name())
            if key and key in art:
                entry = art[key]
                jar = os.path.join(self.libs_dir, entry["path"])
                try:
                    curl.get(entry["url"], dest=jar, sha1=entry.get("sha1"))
                    self._extract_natives(jar, self.natives_dir, lib.get("extract"))
                    paths.append(jar)
                except CurlError as exc:
                    self.log("native %s failed: %s" % (lib.get("name"), exc))
        return paths

    def _prefer_arch(self, wanted):
        if os_name() != "osx" or os_arch() != "arm64":
            return wanted
        out = []
        bases = set()
        for url, dest, sha1, name in wanted:
            if ":natives-macos-arm64" in name or "natives-macos-arm64" in url:
                bases.add(name.split(":natives-macos-arm64")[0])
        for url, dest, sha1, name in wanted:
            if "natives-macos" in name and "natives-macos-arm64" not in name:
                base = name.split(":natives-macos")[0]
                if base in bases:
                    continue  # arm64 variant exists; skip x86_64
            out.append((url, dest, sha1, name))
        return out

    def _extract_natives(self, jar, dest, extract):
        exclude = (extract or {}).get("exclude", []) or []
        with zipfile.ZipFile(jar) as zf:
            for info in zf.namelist():
                if info.endswith("/"):
                    continue
                if any(info.startswith(e) for e in exclude):
                    continue
                target = os.path.join(dest, info)
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with zf.open(info) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out)
                if info.endswith(".dylib") or info.endswith(".so") or info.endswith(".dll"):
                    os.chmod(target, 0o755)

    def _assets(self, vjson, download=True):
        idx = vjson["assetIndex"]
        idx_path = os.path.join(self.assets_dir, "indexes", "%s.json" % idx["id"])
        self._phase("assets", "asset index %s" % idx["id"])
        self.curl.get(idx["url"], dest=idx_path, sha1=idx.get("sha1"), headers=self._ua())
        if not download:
            self.log("asset download skipped on request")
            return False
        with open(idx_path) as fh:
            data = json.load(fh)
        objects = data["objects"]
        items = []
        for name, obj in objects.items():
            h = obj["hash"]
            items.append(("%s/%s/%s" % (RESOURCES_URL, h[:2], h),
                          os.path.join(self.assets_dir, "objects", h[:2], h), h))
        mb = sum(o["size"] for o in objects.values()) / 1048576.0
        self._phase("assets", "assets (%d objects, %.0f MB)" % (len(items), mb), len(items))
        t0 = time.time()
        failed = self.curl.batch(items, progress=self._progress_cb("assets"),
                                 headers=self._ua())
        if failed:
            # Missing assets are survivable: the game runs with missing textures.
            self.log("WARNING: %d assets missing (~%s). The game will still start." % (
                len(failed), "; ".join(os.path.basename(f[1]) for f in failed[:3])))
        self.log("assets done in %.0fs" % (time.time() - t0))
        return True

    def _fabric_profile(self, mc_version, loader):
        """Fabric hands a profile over directly, and it is the one loader with a stable list to
        choose from - so 'stable' means something here, where Forge and NeoForge just take the
        newest build for the version."""
        text = str(loader).lower()
        want = None if text in ("stable", "latest", "auto", "newest", "", "none") \
            else str(loader).lstrip("fabric-loader-")
        cache_file = self._loader_cache_path("fabric", mc_version, want) if (want and self.cfg.cache) else None
        if cache_file and os.path.exists(cache_file):
            with open(cache_file) as fh:
                prof = json.load(fh)
            self.log("fabric loader %s for %s (from the cache; no network needed)"
                     % (prof.get("_loader"), mc_version))
            return prof, prof.get("_loader")
        try:
            meta = self.curl.json("%s/versions/loader/%s" % (FABRIC_META, mc_version),
                                  headers=self._ua())
        except CurlError:
            if want is None:
                cached = self._newest_cached_profile("fabric", mc_version)
                if cached:
                    prof, lv = cached
                    self.log("fabric: meta.fabricmc.net is unreachable, so the cached loader %s "
                             "is being used for %s" % (lv, mc_version))
                    return prof, lv
            raise
        if not meta:
            raise RuntimeError("Fabric has no loader for Minecraft %s" % mc_version)
        if want is None:
            stable = [e for e in meta if e["loader"].get("stable")]
            pick = meta[0] if text == "latest" else (stable[0] if stable else meta[0])
        else:
            pick = None
            for entry in meta:
                if entry["loader"]["version"] == want:
                    pick = entry
                    break
            if not pick:
                raise RuntimeError("Fabric loader %s does not exist for %s (newest: %s)"
                                   % (want, mc_version,
                                      ", ".join(e["loader"]["version"] for e in meta[:5])))
        version = pick["loader"]["version"]
        self.log("fabric loader %s for %s%s" % (version, mc_version,
                 "" if pick["loader"].get("stable") else " (not marked stable)"))
        profile = self.curl.json("%s/versions/loader/%s/%s/profile/json"
                                 % (FABRIC_META, mc_version, version), headers=self._ua())
        profile["_loader"] = version
        profile["_kind"] = "fabric"
        path = self._loader_cache_path("fabric", mc_version, version)
        if path:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as fh:
                json.dump(profile, fh, indent=1)
        return profile, version

    def _newest_cached_profile(self, kind, mc_version):
        """The loader profile from the most recent cached launch of this version, so a machine
        with no network can still start what it started before."""
        if not self.cfg.cache:
            return None
        cache = os.path.abspath(os.path.expanduser(self.cfg.cache))
        directory = os.path.join(cache, kind)
        if not os.path.isdir(directory):
            return None
        best = None
        for name in os.listdir(directory):
            if not name.startswith(mc_version + "-") or not name.endswith(".json"):
                continue
            path = os.path.join(directory, name)
            try:
                with open(path) as fh:
                    prof = json.load(fh)
                stamp = os.path.getmtime(path)
            except (OSError, ValueError):
                continue
            if best is None or stamp > best[0]:
                best = (stamp, prof)
        if not best:
            return None
        prof = best[1]
        return prof, prof.get("_loader")

    def _loader_profile(self, kind, mc_version, loader):
        """Resolve a loader for a version, as a version document.

        Fabric hands one over directly; Forge and NeoForge publish the same shape inside their
        installer jar, so all three arrive here as {mainClass, libraries, arguments} and the
        rest of the launch path does not care which one it is.
        """
        if kind in ("none", "vanilla", "", None):
            return None, None
        if kind == "fabric":
            return self._fabric_profile(mc_version, loader)
        if kind not in LOADER_KINDS:
            raise RuntimeError("unknown loader %r (known: %s)" % (kind, ", ".join(LOADER_KINDS)))
        if kind not in SUPPORTED_LOADERS:
            raise RuntimeError(
                "%s is not supported yet: its build resolves and its libraries download, but the "
                "client jar it needs (client-<mc>-<stamp>-srg.jar) is produced by its own "
                "installertools patch step, which this helper does not run. Use "
                "--loader-kind fabric - which is the loader most mods are published for - or "
                "watch the repository for this." % kind)

        want = None if str(loader).lower() in ("auto", "latest", "newest", "stable", "", "none") \
            else str(loader)
        cached = self._loader_cache_path(kind, mc_version, want) if (want and self.cfg.cache) else None
        if cached and os.path.exists(cached):
            with open(cached) as fh:
                prof = json.load(fh)
            self.log("%s %s for %s (from the cache; no network needed)"
                     % (kind, prof.get("_loader"), mc_version))
            return prof, prof.get("_loader")

        try:
            versions = self._loader_versions(kind, mc_version)
        except CurlError as exc:
            if want:
                raise RuntimeError(
                    "could not ask %s which builds exist for %s (%s). With --cache and a "
                    "previous launch of this exact loader build, it can be reused offline."
                    % (kind, mc_version, exc))
            raise
        if not versions:
            raise RuntimeError("%s has no build for Minecraft %s" % (kind, mc_version))
        version = want or versions[-1]
        if want and want not in versions:
            raise RuntimeError("%s %s does not exist for %s (newest: %s)"
                               % (kind, want, mc_version, ", ".join(versions[-3:])))
        profile = self._loader_from_installer(kind, mc_version, version)
        path = self._loader_cache_path(kind, mc_version, version)
        if path:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as fh:
                json.dump(profile, fh, indent=1)
        return profile, version

    def _loader_versions(self, kind, mc_version):
        """Newest last, for this Minecraft version. NeoForge numbers itself 21.11.x for 1.21.11
        and 26.3.x for 26.3, so the mapping is not always the obvious one."""
        xml = self.curl.get(LOADER_METADATA[kind], dest=None, timeout=120).decode("utf-8", "replace")
        everything = re.findall(r"<version>([^<]+)</version>", xml)
        if kind == "forge":
            # forge is <minecraft>-<forge>
            return [v.split("-", 1)[1] for v in everything if v.startswith(mc_version + "-")]
        prefix = (".".join(mc_version.split(".")[1:]) if mc_version.startswith("1.")
                  else ".".join(mc_version.split(".")[:2])) + "."
        return [v for v in everything if v.startswith(prefix)]

    def _loader_installer_url(self, kind, mc_version, version):
        if kind == "forge":
            return "%snet/minecraftforge/forge/%s-%s/forge-%s-%s-installer.jar" % (
                LOADER_MAVEN[kind], mc_version, version, mc_version, version)
        return "%snet/neoforged/neoforge/%s/neoforge-%s-installer.jar" % (
            LOADER_MAVEN[kind], version, version)

    def _loader_from_installer(self, kind, mc_version, version):
        url = self._loader_installer_url(kind, mc_version, version)
        dest = os.path.join(self.versions_dir, "%s-installer-%s.jar" % (kind, version))
        self.log("%s %s for %s: reading its own version document" % (kind, version, mc_version))
        self.curl.get(url, dest=dest, timeout=600, headers=self._ua())
        try:
            with zipfile.ZipFile(dest) as zf:
                if "version.json" not in zf.namelist():
                    raise RuntimeError("%s %s has no version.json to read" % (kind, version))
                profile = json.loads(zf.read("version.json").decode("utf-8", "replace"))
        except zipfile.BadZipFile:
            raise RuntimeError("%s %s did not download as a jar" % (kind, version))
        profile["_loader"] = version
        profile["_kind"] = kind
        libs = profile.get("libraries") or []
        if not libs:
            raise RuntimeError("%s %s lists no libraries" % (kind, version))
        self.log("  %s %s: %s, %d libraries, %s"
                 % (kind, version, profile.get("mainClass"), len(libs),
                    "inherits " + str(profile.get("inheritsFrom"))))
        return profile

    def _loader_cache_path(self, kind, mc_version, version):
        if not self.cfg.cache or not version:
            return None
        cache = os.path.abspath(os.path.expanduser(self.cfg.cache))
        return os.path.join(cache, kind, "%s-%s.json" % (mc_version, version))

    def _profile_libraries(self, profile):
        """Every library a loader profile names, into the sandbox.

        Forge and NeoForge carry full download blocks (url + sha1 + path); Fabric carries only
        Maven coordinates, so the path is built from those. All three end up in the same place.
        """
        if not profile:
            return []
        kind = profile.get("_kind") or "fabric"
        if kind in ("forge", "neoforge"):
            # Forge and NeoForge do not ship a usable client jar: their own installer runs
            # installertools over the vanilla jar to produce client-<mc>-<stamp>-srg.jar and
            # ...-extra.jar, and their bootstrap refuses to start without them. Until the helper
            # runs that step itself, say so here rather than letting FML report a "corrupted
            # installation" twenty seconds later.
            self.log("  %s needs its own client-patching step (installertools), which this helper "
                     "does not run yet - the game will most likely refuse to start." % kind)
        out = []
        for lib in profile.get("libraries", []):
            if not rules_allow(lib.get("rules"), self._features()):
                continue
            artifact = (lib.get("downloads") or {}).get("artifact") or {}
            rel = artifact.get("path")
            url = artifact.get("url")
            sha1 = artifact.get("sha1")
            if rel and url:
                dest = os.path.join(self.libs_dir, rel)
            else:
                name = lib.get("name") or ""
                repo = (lib.get("url") or "").rstrip("/")
                if not repo:
                    if name.startswith("net.minecraftforge"):
                        repo = LOADER_MAVEN["forge"].rstrip("/")
                    elif name.startswith("net.neoforged"):
                        repo = LOADER_MAVEN["neoforge"].rstrip("/")
                    else:
                        repo = "https://libraries.minecraft.net"
                rel, _n = maven_to_path(name)
                if not rel:
                    continue
                dest = os.path.join(self.libs_dir, rel)
                url = "%s/%s" % (repo, rel)
            out.append(dest)
            if not os.path.exists(dest):
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                try:
                    self.curl.get(url, dest=dest, sha1=sha1, headers=self._ua())
                except CurlError as exc:
                    self.log("library %s could not be fetched: %s" % (os.path.basename(dest), exc))
        if out:
            self._phase(kind, "%s %s libraries" % (kind, profile.get("_loader")),
                        len(profile.get("libraries", [])))
            self._progress("%s libraries" % kind, len(out), len(out))
        return out

    def _features(self):
        return {
            "is_demo_user": False,
            "has_custom_resolution": False,
            "has_quick_plays_support": False,
            "is_quick_play_singleplayer": False,
            "is_quick_play_multiplayer": False,
            "is_quick_play_realms": False,
        }

    def _local_mods(self, paths):
        """Jars already on this machine, copied into the sandbox's mods folder.
        These are deleted with everything else when the session ends."""
        out = []
        mods_dir = os.path.join(self.game_dir, "mods")
        for p in paths:
            src = os.path.abspath(os.path.expanduser(p))
            if not os.path.exists(src):
                self.log("mod jar %s does not exist - skipped" % src)
                continue
            if not src.endswith(".jar"):
                self.log("mod jar %s is not a .jar - skipped" % src)
                continue
            dest = os.path.join(mods_dir, os.path.basename(src))
            shutil.copy2(src, dest)
            self.log("mod %s (local file, copied into the sandbox)" % os.path.basename(src))
            out.append({"name": os.path.basename(src), "slug": "local",
                        "version": "local file", "file": os.path.basename(src),
                        "path": dest})
        return out

    def _mods(self, slugs, mc_version, loader_ver):
        out = []
        if not slugs:
            return out
        self._phase("mods", "mods from Modrinth (%d)" % len(slugs), len(slugs))
        mods_dir = os.path.join(self.game_dir, "mods")
        for i, slug in enumerate(slugs):
            try:
                q = urllib.parse.urlencode({
                    "loaders": json.dumps(["fabric"]),
                    "game_versions": json.dumps([mc_version]),
                })
                versions = self.curl.json("%s/project/%s/version?%s" % (MODRINTH_API, slug, q),
                                          headers=self._ua())
                if not versions:
                    self.log("mod %s has no Fabric build for %s - skipped" % (slug, mc_version))
                    self._progress("mods", i + 1, len(slugs))
                    continue
                v = versions[0]
                files = [f for f in v["files"] if f.get("primary")] or v["files"]
                f = files[0]
                dest = os.path.join(mods_dir, f["filename"])
                self.curl.get(f["url"], dest=dest, headers=self._ua())
                self.log("mod %s %s -> %s" % (v.get("name") or slug, v["version_number"],
                                              f["filename"]))
                out.append({"name": v.get("name") or slug, "slug": slug,
                            "version": v["version_number"], "file": f["filename"],
                            "path": dest})
            except CurlError as exc:
                self.log("mod %s could not be fetched: %s" % (slug, exc))
            self._progress("mods", i + 1, len(slugs))
        return out

    def _build_command(self, vjson, profile, client_jar, libs, mc_version, loader_ver,
                       username, memory, mods):
        features = self._features()
        if profile:
            main_class = profile.get("mainClass") or vjson["mainClass"]
            version_name = profile.get("id") or ("fabric-loader-%s-%s" % (loader_ver, mc_version))
            jvm_args = list(vjson["arguments"]["jvm"])
            for a in profile.get("arguments", {}).get("jvm", []) or []:
                if isinstance(a, str) or rules_allow(a.get("rules"), features):
                    jvm_args.append(a)
            game_args = profile.get("arguments", {}).get("game") or vjson["arguments"]["game"]
            version_type = "Fabric"
        else:
            main_class = vjson["mainClass"]
            version_name = vjson["id"]
            jvm_args = list(vjson["arguments"]["jvm"])
            game_args = vjson["arguments"]["game"]
            version_type = vjson.get("type", "release")

        classpath = list(libs)
        if client_jar not in classpath:
            classpath.append(client_jar)
        cp = os.pathsep.join(classpath)
        offline_uuid = offline_uuid_for(username)
        sub = {
            "auth_player_name": username,
            "version_name": version_name,
            "game_directory": self.game_dir,
            "assets_root": self.assets_dir,
            "assets_index_name": vjson["assetIndex"]["id"],
            "auth_uuid": offline_uuid,
            "auth_access_token": "0",
            "auth_session": "0",
            "user_type": "legacy",
            "version_type": version_type,
            "user_properties": "{}",
            "clientid": "",
            "auth_xuid": "",
            "launcher_name": NAME,
            "launcher_version": VERSION,
            "natives_directory": self.natives_dir,
            "library_directory": self.libs_dir,
            "classpath": cp,
            "classpath_separator": os.pathsep,
            "resolution_width": "1280",
            "resolution_height": "720",
            "quickPlayPath": "",
            "quickPlaySingleplayer": "",
            "quickPlayMultiplayer": "",
            "quickPlayRealms": "",
        }
        cmd = [self.java, "-Xmx%s" % memory]
        if getattr(self, "socks", None):
            # Java routes every TCP connection a program makes through these, so the game's own
            # multiplayer, authentication and skin fetching all travel inside the relay
            cmd += ["-DsocksProxyHost=127.0.0.1", "-DsocksProxyPort=%d" % self.socks_port,
                    "-Djava.net.useSystemProxies=false"]
        if os_name() == "osx":
            cmd += ["-Dapple.awt.application.appearance=system"]
        cmd += ["-Dfabric.gameJarPath=%s" % client_jar]
        cmd += materialise(jvm_args, sub, features)
        cmd += [main_class]
        cmd += materialise(game_args, sub, features)
        if self.quick_play:
            # 1.20 and later can join straight away: the difference between "connect to
            # 127.0.0.1:35565 yourself" and pressing PLAY and already being in the server
            cmd += ["--quickPlayMultiplayer", self.quick_play]
        return cmd, classpath

    def _preseed_options(self):
        """A brand new session has no options.txt, and Minecraft's title screen then asks whether to
        turn the narrator on - every single time, for somebody who never wanted it. One line fixes
        that; anything restored from a previous session still wins, because this writes only when
        there is nothing there."""
        path = os.path.join(self.game_dir, "options.txt")
        if os.path.exists(path):
            return
        try:
            with open(path, "w") as fh:
                fh.write("narrator:0\n")
            self.log("wrote a starter options.txt (narrator off, so the title screen does not ask)")
        except OSError:
            pass

    def _collect(self):
        self._phase("collect", "collecting what the session wrote", check_cancel=False)
        wanted = ["saves", "logs", "crash-reports", "screenshots", "config",
                  "options.txt", "servers.dat", "usercache.json", "realms_persistence.json"]
        files = []
        with zipfile.ZipFile(self.bundle_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for rel in wanted:
                src = os.path.join(self.game_dir, rel)
                if not os.path.exists(src):
                    continue
                if os.path.isfile(src):
                    zf.write(src, rel)
                    files.append({"path": rel, "size": os.path.getsize(src)})
                    continue
                for base, _dirs, names in os.walk(src):
                    for n in names:
                        full = os.path.join(base, n)
                        arc = os.path.relpath(full, self.game_dir)
                        try:
                            zf.write(full, arc)
                            files.append({"path": arc, "size": os.path.getsize(full)})
                        except OSError:
                            pass
            # the console log is ours, and it is the thing that explains a crash
            console = os.path.join(self.root, "console.log")
            if os.path.exists(console):
                zf.write(console, "console.log")
                files.append({"path": "console.log", "size": os.path.getsize(console)})
            # The helper's own account of the attempt, always. A launch that was stopped (or that
            # died) before the game started has no console.log at all, and this is then the only
            # record of what it was doing - which is the whole difference between "it didn't work"
            # and "it didn't work and nobody knows why".
            with self.lock:
                helper_lines = list(self.lines)
            if helper_lines:
                payload = ("\n".join(helper_lines) + "\n").encode("utf-8")
                zf.writestr("helper.log", payload)
                files.append({"path": "helper.log", "size": len(payload)})
            launch = os.path.join(self.root, "launch-command.txt")
            if os.path.exists(launch):
                zf.write(launch, "launch-command.txt")
                files.append({"path": "launch-command.txt", "size": os.path.getsize(launch)})
        total = os.path.getsize(self.bundle_path)
        worlds = sorted({f["path"].split("/")[1] for f in files
                         if f["path"].startswith("saves/") and len(f["path"].split("/")) > 2})
        self.result = {
            "bundle": "session.zip",
            "bytes": total,
            "files": len(files),
            "worlds": worlds,
            "hasCrash": any(f["path"].startswith("crash-reports/") for f in files),
            "exitCode": self.exit_code,
            "collectedAt": time.time(),
        }
        if self.manager:
            try:
                self.manager.store_session(self)
            except Exception as exc:  # noqa: BLE001 - keeping it is best-effort
                self.log("could not keep this session for next time: %s" % exc)
        self.log("collected %d files (%.1f MB) into session.zip%s" % (
            len(files), total / 1048576.0,
            " - worlds: " + ", ".join(worlds) if worlds else ""))
        return self.result



    def _stop_tunnel(self):
        if getattr(self, "socks", None):
            try:
                self.socks.stop()
            except Exception:
                pass
            self.socks = None
        if self.tunnel:
            try:
                self.tunnel.stop()
            except Exception:
                pass
            self.tunnel = None

    def cleanup(self, why="the page asked for it"):
        """Delete the sandbox. This is the promise the whole design rests on."""
        if not os.path.isdir(self.root):
            receipt = {"removed": 0, "path": self.root, "already": True, "why": why}
            with self.lock:
                self.last_cleanup = receipt
            return receipt
        if self.cfg.keep:
            return {"removed": 0, "path": self.root, "kept": True, "why": why,
                    "note": "--keep was given, nothing deleted"}
        size = 0
        files = 0
        leftovers = []
        for base, _dirs, names in os.walk(self.root):
            for n in names:
                full = os.path.join(base, n)
                try:
                    if os.path.islink(full):
                        continue          # borrowed from the cache: not ours to count
                    size += os.path.getsize(full)
                    files += 1
                except OSError:
                    pass
        self._stop_tunnel()
        shutil.rmtree(self.root, ignore_errors=True)
        with self.lock:
            self.cleanup_deadline = None
        # Anything of ours that a crash could have scattered outside the sandbox.
        for pattern in ("webmc-curl-*.conf", "webmc-*.part"):
            import glob as _glob
            for stray in _glob.glob(os.path.join(os.environ.get("TMPDIR", "/tmp"), pattern)):
                try:
                    size += os.path.getsize(stray)
                    os.unlink(stray)
                    leftovers.append(stray)
                except OSError:
                    pass
        gone = not os.path.exists(self.root)
        receipt = {"removed": size, "files": files, "path": self.root, "gone": gone,
                   "why": why, "strays": leftovers, "at": time.time()}
        with self.lock:
            self.last_cleanup = receipt
        self.log("deleted %s (%s files, %.1f MB freed)%s"
                 % (self.root, files, size / 1048576.0,
                    "" if gone else " -- SOMETHING IS STILL THERE"))
        return receipt

    def restore(self, blob):
        """Put a previous session's bundle back into the game dir before launch.

        The page calls this *after* cleanup has deleted the sandbox, so the whole
        tree has to be rebuilt first - on a warm cache that costs nothing.
        """
        self._prepare_root()
        tmp = os.path.join(self.root, "restore-%s.zip" % secrets.token_hex(4))
        with open(tmp, "wb") as fh:
            fh.write(blob)
        count = 0
        with zipfile.ZipFile(tmp) as zf:
            for info in zf.namelist():
                if info.startswith("/") or ".." in info.split("/"):
                    continue
                zf.extract(info, self.game_dir)
                count += 1
        os.unlink(tmp)
        self.log("restored %d files from the browser into the sandbox" % count)
        return {"restored": count}

    # ---------------------------------------------------------------- pushed mods
    @property
    def local_mods_dir(self):
        """Where the jars the visitor handed over live. Shared by every session, because a mod
        list belongs to the visitor rather than to one launch."""
        if self.manager:
            return self.manager.mods_dir
        return os.path.join(self.root, "localmods")

    def _pending_mod_paths(self):
        directory = self.local_mods_dir
        if not os.path.isdir(directory):
            return []
        return [os.path.join(directory, n) for n in sorted(os.listdir(directory))
                if n.endswith(".jar")]

    def accept_mod(self, name, blob):
        """Take a jar from the browser.

        It lives inside the sandbox and is deleted with it; the page keeps its own
        copy, so a visitor's mods travel with the browser rather than with the
        computer - which is the same promise the rest of this makes.
        """
        safe = re.sub(r"[^A-Za-z0-9._+ -]", "_", os.path.basename(name or "mod.jar"))
        if not safe.lower().endswith(".jar"):
            safe += ".jar"
        if not blob:
            raise ValueError("empty file")
        if len(blob) > 64 * 1024 * 1024:
            raise ValueError("that jar is larger than 64 MB")
        if blob[:2] != b"PK":
            raise ValueError("that is not a jar (a jar is a zip, and this does not start like one)")
        try:
            with zipfile.ZipFile(io.BytesIO(blob)) as zf:
                names = zf.namelist()
                is_mod = any(n == "fabric.mod.json" or n.endswith("/fabric.mod.json")
                             or n == "META-INF/mods.toml" or n == "mcmod.info" for n in names)
                title = version = None
                if "fabric.mod.json" in names:
                    meta = json.loads(zf.read("fabric.mod.json").decode("utf-8", "replace"))
                    title = meta.get("name") or meta.get("id")
                    version = meta.get("version")
        except (zipfile.BadZipFile, ValueError, KeyError):
            raise ValueError("that jar could not be read")
        if not is_mod:
            raise ValueError("no fabric.mod.json, META-INF/mods.toml or mcmod.info inside, "
                             "so this is a library or a plain zip rather than a mod")
        os.makedirs(self.local_mods_dir, exist_ok=True)
        dest = os.path.join(self.local_mods_dir, safe)
        with open(dest, "wb") as fh:
            fh.write(blob)
        entry = {"name": safe, "bytes": len(blob), "title": title, "version": version}
        with self.lock:
            self.pending_mods = [m for m in self.pending_mods if m["name"] != safe] + [entry]
        self.log("mod %s taken from the browser (%s, %.1f MB)%s"
                 % (safe, title or "unnamed", len(blob) / 1048576.0,
                    "" if version is None else " " + str(version)))
        return entry

    def drop_mod(self, name):
        safe = re.sub(r"[^A-Za-z0-9._+ -]", "_", os.path.basename(name or ""))
        path = os.path.join(self.local_mods_dir, safe)
        if os.path.exists(path):
            os.unlink(path)
        with self.lock:
            self.pending_mods = [m for m in self.pending_mods if m["name"] != safe]
        return {"dropped": safe}

    def clear_mods(self):
        dropped = 0
        if os.path.isdir(self.local_mods_dir):
            for n in os.listdir(self.local_mods_dir):
                try:
                    os.unlink(os.path.join(self.local_mods_dir, n))
                    dropped += 1
                except OSError:
                    pass
        with self.lock:
            self.pending_mods = []
        return {"dropped": dropped}

    def search_mods(self, query, mc_version=None, limit=12):
        """Modrinth search, done here rather than in the page: the helper can reach it
        through the visitor's proxy on a network where the browser cannot."""
        q = urllib.parse.urlencode({
            "query": query, "limit": limit,
            "facets": json.dumps([["project_type:mod"], ["categories:fabric"]]
                                 + ([["versions:%s" % mc_version]] if mc_version else [])),
        })
        data = self.curl.json("%s/search?%s" % (MODRINTH_API, q), headers=self._ua())
        out = []
        for hit in data.get("hits", []):
            out.append({
                "slug": hit.get("slug"), "title": hit.get("title"),
                "description": (hit.get("description") or "")[:200],
                "downloads": hit.get("downloads"), "author": hit.get("author"),
                "icon": hit.get("icon_url"), "versions": (hit.get("versions") or [])[-4:],
            })
        return {"results": out, "query": query}

    # ---------------------------------------------------------------- helpers
    def _ua(self):
        return ("User-Agent: %s/%s (+https://github.com/derek/webmc)" % (NAME, VERSION),)

    def _progress_cb(self, label):
        def cb(done, total, _round=None):
            self._progress(label, done, total)
        return cb


def materialise(args, sub, features):
    """Flatten and substitute Mojang's argument list."""
    out = []
    for a in args:
        if isinstance(a, str):
            out.append(a)
            continue
        if not rules_allow(a.get("rules"), features):
            continue
        val = a.get("value")
        if isinstance(val, list):
            out.extend(val)
        elif val is not None:
            out.append(val)
    return [substitute(x, sub) for x in out]


PLACEHOLDER = re.compile(r"\$\{([a-zA-Z0-9_]+)\}")


def substitute(text, sub):
    return PLACEHOLDER.sub(lambda m: str(sub.get(m.group(1), "")), text)


def offline_uuid_for(name):
    digest = bytearray(hashlib.md5(("OfflinePlayer:" + name).encode("utf-8")).digest())
    digest[6] = (digest[6] & 0x0F) | 0x30
    digest[8] = (digest[8] & 0x3F) | 0x80
    return str(uuidlib.UUID(bytes=bytes(digest)))


def shell_quote(s):
    if re.match(r"^[A-Za-z0-9_@%+=:,./-]+$", s or ""):
        return s
    return "'" + (s or "").replace("'", "'\\''") + "'"


def port_open(host, port, timeout=0.25):
    s = socket.socket()
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def detect_proxy(explicit, curl_log):
    if explicit in ("none", "direct", ""):
        return None
    if explicit:
        return explicit
    for cand in PROXY_CANDIDATES:
        host_port = cand.split("://", 1)[1]
        host, port = host_port.split(":")
        if not port_open(host, int(port)):
            continue
        try:
            probe = Curl(proxy=cand)
            probe.get(MANIFEST_URL, dest=None, timeout=25)
            curl_log("proxy: %s (Mojang reachable through it)" % cand)
            return cand
        except CurlError as exc:
            curl_log("proxy candidate %s could not reach Mojang: %s" % (cand, exc))
    return None


# --------------------------------------------------------------------------- page

PAGE_SUFFIX = """
<script>
window.__WEBMC__ = { helper: "http://127.0.0.1:%(port)d", token: "%(token)s",
                     served: "helper" };
</script>
"""


# --------------------------------------------------------------------------- http

class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "%s/%s" % (NAME, VERSION)
    protocol_version = "HTTP/1.1"

    # ---- plumbing
    def log_message(self, fmt, *args):
        if self.server.verbose:
            sys.stderr.write("http %s\n" % (fmt % args))

    def _cors(self):
        origin = self.headers.get("Origin")
        allowed = None
        if origin:
            if origin in self.server.extra_origins or any(p.match(origin) for p in ORIGIN_PATTERNS):
                allowed = origin
        if allowed:
            self.send_header("Access-Control-Allow-Origin", allowed)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers",
                         "content-type, x-webmc-token, access-control-request-private-network")
        # Chrome 142+ gates public -> loopback behind Local Network Access. Answering
        # the preflight with this header is what keeps the bridge usable where an
        # admin has not blocked it outright.
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Cache-Control", "no-store")

    def _send(self, code, body=b"", ctype="application/json", extra=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code, obj):
        self._send(code, json.dumps(obj, indent=1))

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return b""
        return self.rfile.read(n)

    def _json_body(self):
        raw = self._body()
        if not raw:
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError:
            return {}

    def _authed(self):
        if self.path.split("?")[0] in ("/api/hello", "/", "/go", "/favicon.ico"):
            return True
        return self.headers.get("X-WebMC-Token") == self.server.token

    def _guard(self):
        if self._authed():
            return True
        self._json(403, {"error": "bad or missing X-WebMC-Token"})
        return False

    # ---- routes
    def do_OPTIONS(self):
        self._send(204)

    def do_HEAD(self):
        self.do_GET()

    def _session(self, query):
        """The session a request is about: ?id=… , or the newest one still working."""
        sid = (query.get("id") or [None])[0]
        return self.server.registry.pick(sid)

    def do_GET(self):
        parts = urllib.parse.urlsplit(self.path)
        path, query = parts.path, urllib.parse.parse_qs(parts.query)
        reg = self.server.registry
        s = self._session(query)
        if s:
            s.touch()
        else:
            reg.touch()
        if path == "/favicon.ico":
            return self._send(204)
        if path == "/":
            return self._page()
        if path == "/go":
            return self._go(query)
        if path == "/api/hello":
            return self._json(200, {
                "ok": True, "name": NAME, "version": VERSION,
                "platform": {"os": os_name(), "arch": os_arch(), "version": os_version()},
                "sandbox": (s.root if s else reg.cfg.root),
                "sessions": len(reg.sessions),
                "store": {"dir": reg.store,
                          "kept": len([n for n in os.listdir(reg.store) if n.endswith(".zip")])
                                  if os.path.isdir(reg.store) else 0},
                "proxy": self.server.curl.proxy or "direct",
                "relay": (s.cfg.relay if s else reg.cfg.relay) or None,
                "relayBuiltIn": len(DEFAULT_RELAYS),
                "relayMode": ("custom" if (s.cfg.relay if s else reg.cfg.relay)
                              and (s.cfg.relay if s else reg.cfg.relay) not in DEFAULT_RELAYS
                              else "auto" if (s.cfg.relay if s else reg.cfg.relay) else "off"),
                "downloads": self.server.curl.bytes_in,
                "autocleanSeconds": (s.cfg.autoclean if s else reg.cfg.autoclean),
                "footprint": machine_footprint(cache=s.cfg.cache if s else reg.cfg.cache),
                "features": ["fabric", "real-jvm", "opfs-bundle", "restore", "modrinth",
                             "local-mods", "mod-search", "audit"],
            })
        if not self._guard():
            return
        if path == "/api/sessions":
            return self._json(200, {"sessions": reg.list()})
        if path == "/api/status":
            if not s:
                return self._json(200, {"state": "idle", "phase": "idle", "phaseLabel": "Ready",
                                        "progress": {"done": 0, "total": 0, "percent": None},
                                        "instance": {}, "pid": None, "exitCode": None,
                                        "result": None})
            return self._json(200, s.status())
        if path == "/api/search":
            q = (query.get("q") or [""])[0].strip()
            if not q:
                return self._json(400, {"error": "give me something to search for (?q=sodium)"})
            try:
                return self._json(200, s.search_mods(q, (query.get("mc") or [None])[0]))
            except CurlError as exc:
                return self._json(502, {"error": str(exc)})
        if path == "/api/localmods":
            return self._json(200, {"mods": [{"name": m["name"], "bytes": m["bytes"],
                                              "title": m.get("title"),
                                              "version": m.get("version")}
                                             for m in reg.mods],
                                    "dir": reg.mods_dir})
        if path == "/api/versions":
            try:
                return self._json(200, s.versions())
            except CurlError as exc:
                return self._json(502, {"error": str(exc)})
        if path == "/api/log":
            since = int((query.get("since") or ["0"])[0] or 0)
            if not s:
                return self._json(200, {"lines": [], "next": since})
            lines, nxt = s.lines_since(since)
            return self._json(200, {"lines": lines, "next": nxt})
        if path == "/api/result":
            if not s:
                return self._json(404, {"error": "no session"})
            return self._json(200, {"result": s.result, "state": s.state,
                                    "exitCode": s.exit_code, "error": s.error})
        if path == "/api/bundle.zip":
            if not s or not s.result or not os.path.exists(s.bundle_path):
                return self._json(404, {"error": "no bundle yet"})
            with open(s.bundle_path, "rb") as fh:
                blob = fh.read()
            return self._send(200, blob, "application/zip", {
                "Content-Disposition": 'attachment; filename="webmc-session.zip"'})
        return self._json(404, {"error": "no such endpoint", "path": path})

    def do_POST(self):
        parts = urllib.parse.urlsplit(self.path)
        path, query = parts.path, urllib.parse.parse_qs(parts.query)
        reg = self.server.registry
        s = self._session(query)
        if s:
            s.touch()
        else:
            reg.touch()
        if not self._guard():
            return
        # ---- the mods a visitor brings with them
        if path == "/api/localmods":
            if (query.get("clear") or [""])[0]:
                return self._json(200, reg.clear_mods())
            drop = (query.get("drop") or [""])[0]
            if drop:
                return self._json(200, reg.drop_mod(drop))
            name = self.headers.get("X-WebMC-Mod-Name") or "mod.jar"
            try:
                return self._json(200, reg.accept_mod(name, self._body()))
            except ValueError as exc:
                return self._json(400, {"error": str(exc), "name": name})
        if path == "/api/launch":
            body = self._json_body()
            opts = {
                "version": body.get("version") or DEFAULT_VERSION,
                "loader": body.get("loader") or "auto",
                "loaderKind": body.get("loaderKind") or "fabric",
                "relay": body.get("relay") or self.server.registry.cfg.relay,
                "tunnelServer": body.get("tunnelServer"),
                "tunnelPort": body.get("tunnelPort"),
                "tunnelEverything": bool(body.get("tunnelEverything")),
                "restricted": bool(body.get("restricted")),
                "mods": body.get("mods") or [],
                "username": body.get("username") or "Player",
                "memory": body.get("memory") or DEFAULT_MEMORY,
                "assets": body.get("assets", True),
            }
            try:
                # Every launch is its own session, so a second window - or another version - can
                # run while the first is still playing.
                started = reg.launch(opts)
            except Exception as exc:  # noqa: BLE001
                return self._json(400, {"error": str(exc)})
            return self._json(202, {"started": True, "id": started.sid, "instance": opts})
        if path == "/api/stop":
            # One button, whichever state a session is in: mid-download it cancels, running it
            # kills the game. With no session named it stops the newest one that is working.
            if not s:
                return self._json(200, {"cancelled": False, "note": "nothing is running"})
            return self._json(200, s.cancel())
        if path == "/api/restore":
            blob = self._body()
            if not s:
                # The page restores before it launches, so keep the bundle until then: the next
                # launch unpacks it into its own sandbox before the game starts.
                reg.pending_restore = blob
                return self._json(200, {"queued": len(blob)})
            if not blob:
                return self._json(400, {"error": "empty body"})
            try:
                return self._json(200, s.restore(blob))
            except Exception as exc:  # noqa: BLE001
                return self._json(400, {"error": "not a usable bundle: %s" % exc})
        if path == "/api/purge":
            body = self._read_json()
            result = purge(cache=self.server.registry.cfg.cache, log=lambda m: print(m, flush=True))
            return self._json(200, {"ok": True, "removed": result["removed"],
                                    "bytes": result["bytes"]})
        if path == "/api/cleanup":
            if not s:
                return self._json(200, {"removed": 0, "gone": True, "already": True})
            return self._json(200, s.cleanup())
        return self._json(404, {"error": "no such endpoint", "path": path})

    # ---- the helper's own copy of the page
    def _page(self):
        page = self.server.page_path
        if (not page or not os.path.exists(page)) and _EMBEDDED_PAGE:
            # Self-healing: the sandbox (and the page written into it) is deleted when a session
            # ends, and the page has to come back for the next visit.
            page = materialise_embedded_page(os.environ.get("WEBMC_CLEANUP_DIR")
                                             or os.path.dirname(self.server.registry.cfg.root)) or page
            self.server.page_path = page
        if not page or not os.path.exists(page):
            return self._json(200, {
                "name": NAME, "version": VERSION,
                "note": "page not found next to the helper; use /api/* or pass --page",
                "hint": "http://127.0.0.1:%d/api/hello" % self.server.server_address[1],
            })
        with open(page, "rb") as fh:
            html = fh.read().decode("utf-8")
        inject = PAGE_SUFFIX % {"port": self.server.server_address[1],
                                "token": self.server.token}
        # This has to land before the page's own script runs, or the page cannot see the
        # token it was just handed. Injecting it at the end made a helper-served page
        # say "not connected" while talking to the helper that served it.
        placed = False
        for marker, before in (("<head>", False), ("</head>", True), ("</body>", True)):
            if marker in html:
                html = html.replace(marker, (inject + marker) if before else (marker + inject), 1)
                placed = True
                break
        if not placed:
            html = inject + html
        self._send(200, html, "text/html; charset=utf-8")

    def _go(self, query):
        """Hand the token to a hosted copy of the page, via the URL fragment."""
        target = (query.get("to") or [""])[0]
        if not target:
            return self._send(400, "missing ?to=", "text/plain")
        parsed = urllib.parse.urlsplit(target)
        ok = (parsed.scheme in ("http", "https") and (
            any(p.match("%s://%s" % (parsed.scheme, parsed.netloc)) for p in ORIGIN_PATTERNS)
            or parsed.netloc.endswith("github.io")))
        if not ok:
            return self._send(400, "refusing to redirect to %s" % target, "text/plain")
        frag = "helper=http://127.0.0.1:%d&t=%s" % (self.server.server_address[1],
                                                    self.server.token)
        sep = "&" if "#" in target else "#"
        loc = target + sep + frag
        self.send_response(302)
        self._cors()
        self.send_header("Location", loc)
        self.send_header("Content-Length", "0")
        self.end_headers()


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, addr, handler, registry, curl, token, page_path, origins, verbose):
        self.registry = registry
        self.curl = curl
        self.token = token
        self.page_path = page_path
        self.extra_origins = set(origins)
        self.verbose = verbose
        super().__init__(addr, handler)


# --------------------------------------------------------------------------- cli

def default_page(root):
    """Where the launcher page is, when it is not given.

    One file has to be able to serve its own page, so an embedded copy is written out next to the
    sandbox's files. That copy has to be re-creatable, not written once: the sandbox is deleted
    when a session ends, and the page used to be deleted with it, so after the first session the
    helper answered "/" with "page not found next to the helper".
    """
    if _EMBEDDED_PAGE:
        return materialise_embedded_page(root)
    here = globals().get("__file__")
    if not here:
        return None
    guess = os.path.join(os.path.dirname(os.path.abspath(here)), os.pardir, "page", "index.html")
    return os.path.abspath(guess) if os.path.exists(guess) else None


def materialise_embedded_page(root):
    import base64
    path = os.path.join(root, "page.html")
    try:
        if os.path.exists(path) and os.path.getsize(path) > 0:
            return path
        os.makedirs(root, exist_ok=True)
        with open(path, "wb") as fh:
            fh.write(base64.b64decode(_EMBEDDED_PAGE))
        return path
    except Exception:
        return None


def default_root():
    return os.path.join("/tmp", "webmc-%s" % secrets.token_hex(4))


def sweep_stale_sandboxes(older_than=6 * 3600, keep=None, log=print):
    """A helper that was killed hard (or a machine that went down) leaves its
    sandbox behind. /tmp is emptied on reboot anyway, but the promise is that
    nothing survives a session, so clear out anything old enough that it cannot
    belong to a session still in progress."""
    removed = 0
    freed = 0
    now = time.time()
    try:
        names = os.listdir("/tmp")
    except OSError:
        return 0, 0
    for name in names:
        if not name.startswith("webmc-"):
            continue
        path = os.path.join("/tmp", name)
        if keep and os.path.abspath(path) == os.path.abspath(keep):
            continue
        if not os.path.isdir(path):
            continue
        # Ours means: the default naming (webmc-<8 hex>) or a directory that carries
        # our owner.json (which also covers a custom --root). A directory someone else
        # named webmc-something is not ours to delete.
        owner = read_owner(path)
        if not re.fullmatch(r"webmc-[0-9a-f]{8}", name) and owner is None:
            continue
        try:
            age = now - os.path.getmtime(path)
        except OSError:
            continue
        # Ours with no owner file can only mean a hard kill in the first second of a session, before
        # the note was written. Ours by name, so a quarter of an hour is enough to be sure it is not
        # somebody's session that is simply very quiet.
        abandoned = owner is not None and not pid_alive(owner.get("pid"))
        if owner is None and re.fullmatch(r"webmc-[0-9a-f]{8}", name) and age > 900:
            abandoned = True
        # Two reasons to delete: the helper that owned it is gone (so nobody will ever
        # clean it), or it is simply old. The first one is why this is fast: a sandbox
        # left by a crash is removed on the next run, not six hours later.
        if not abandoned and age < older_than:
            continue
        try:
            for base, _dirs, files in os.walk(path):
                for f in files:
                    full = os.path.join(base, f)
                    try:
                        if not os.path.islink(full):
                            freed += os.path.getsize(full)
                    except OSError:
                        pass
            shutil.rmtree(path, ignore_errors=True)
            removed += 1
            log("cleared leftover sandbox %s (%s)"
                % (path, "its helper is gone" if abandoned else "older than %.0fh" % (older_than / 3600.0)))
        except OSError:
            pass
    import glob as _glob
    for stray in _glob.glob(os.path.join(os.environ.get("TMPDIR", "/tmp"), "webmc-curl-*.conf")):
        try:
            freed += os.path.getsize(stray)
            os.unlink(stray)
            removed += 1
        except OSError:
            pass
    if removed:
        log("cleared %d leftover item(s) from earlier runs (%.0f MB)"
            % (removed, freed / 1048576.0))
    return removed, freed


def read_owner(path):
    try:
        with open(os.path.join(path, "owner.json")) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def pid_alive(pid):
    """Is that pid still a live process of ours? Unknown counts as alive, so the
    sweep never deletes a sandbox it cannot be sure about."""
    if not pid:
        return True
    try:
        os.kill(int(pid), 0)
        return True
    except ProcessLookupError:
        return False
    except (PermissionError, ValueError, OSError):
        return True


def _boot_id():
    """Distinguishes 'this pid is gone' from 'this pid was reused after a reboot'."""
    try:
        return "%.0f" % time.time()
    except Exception:
        return ""


AGENT_LABEL = "dev.amphibian.webmc-helper"
INSTALLED_DIR = "~/Library/Application Support/webmc"
AGENT_PLIST = "~/Library/LaunchAgents/dev.amphibian.webmc-helper.plist"
LOG_FILE = "~/Library/Logs/webmc-helper.log"
SHIPPED = (("helper/webmc_helper.py", 0o755),
           ("helper/start-helper.command", 0o755),
           ("page/index.html", 0o644))


def session_store_dir(cfg=None):
    """Where a finished session is kept so the next launch can start from it.

    Your world has to live somewhere between sessions, and the browser is the wrong only place for
    it: storage belongs to an origin, and this launcher legitimately runs on two of them (the helper's
    own page at 127.0.0.1:7645, and a hosted copy on github.io). A session saved by one is invisible
    to the other, which is exactly how worlds and options come to reset. So the helper keeps a copy
    of each session's bundle as well, and restores from it when the page has nothing to offer.
    """
    if cfg is not None and getattr(cfg, "store", None):
        return os.path.abspath(os.path.expanduser(cfg.store))
    if os_name() == "osx":
        base = "~/Library/Application Support/webmc"
    elif os_name() == "windows":
        base = os.path.join(os.environ.get("LOCALAPPDATA") or "~", "webmc")
    else:
        base = os.path.join(os.environ.get("XDG_DATA_HOME") or "~/.local/share", "webmc")
    return os.path.expanduser(os.path.join(base, "sessions"))


def installed_paths():
    return {"dir": os.path.expanduser(INSTALLED_DIR),
            "plist": os.path.expanduser(AGENT_PLIST),
            "log": os.path.expanduser(LOG_FILE)}


def agent_plist_text(python, helper, page_url, port):
    def esc(text):
        return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
    args = [python, helper, "--server-only", "--port", str(port)]
    if page_url:
        args += ["--page-url", page_url]
    return """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>%s</string>
  <key>ProgramArguments</key>
  <array>%s</array>
  <key>RunAtLoad</key><true/>
  <!-- Come back if it ever stops: whether it crashed or exited on its own after a long quiet spell,
       launchd starts it again in seconds and it deletes its sandbox on the way out, so nothing
       accumulates. This is what makes "installed" mean "always there" instead of "was there once". -->
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>10</integer>
  <key>WorkingDirectory</key><string>%s</string>
  <key>StandardOutPath</key><string>%s</string>
  <key>StandardErrorPath</key><string>%s</string>
</dict>
</plist>
""" % (AGENT_LABEL,
       "".join("<string>%s</string>" % esc(a) for a in args),
       esc(os.path.dirname(helper)),
       esc(os.path.expanduser(LOG_FILE)), esc(os.path.expanduser(LOG_FILE)))


def install(source_py, page_url=None, port=7645, log=print, open_page=True):
    """Install for a Mac with no terminal in the way.

    macOS runs a user's own launch agents without an administrator, so this needs no
    privilege: it copies the helper into the user's Application Support, writes one plist
    into the user's LaunchAgents, and asks launchd to start it now and at every login. The
    point is that nobody has to open Terminal or keep a window alive - the page finds a
    helper already running.

    It still keeps nothing of the game: the sandbox under /tmp is deleted as usual, and
    `--uninstall` removes both files in one step.
    """
    if os_name() != "osx":
        log("  --install is the macOS path; elsewhere run it however you start things")
        return 1
    paths = installed_paths()
    # Already up (a second double-click, or an opened file again): do not start a second one on
    # the same port and report it as a failure.
    if already_running("127.0.0.1", port):
        log("  a helper is already running on 127.0.0.1:%d - nothing to do" % port)
        if open_page:
            url = "http://127.0.0.1:%d/" % port
            if page_url:
                url = "%sgo?to=%s" % (url, urllib.parse.quote(page_url, safe=""))
            threading.Timer(0.8, lambda: subprocess.run(["open", url])).start()
        return 0
    os.makedirs(os.path.join(paths["dir"], "helper"), exist_ok=True)
    if not source_py or not os.path.exists(source_py):
        log("  cannot find the helper to install (%s)" % source_py)
        return 2
    import re as _re
    text = open(source_py, "rb").read()
    if b"_EMBEDDED_PAGE = \"\"" in text:
        # A copy from the repository cannot serve its own page; the single-file build can, because
        # the page is inside it. Installing the repository copy is still fine (it keeps whatever
        # page sits next to it), so only the missing-page case is worth a word.
        log("  note: this copy has no page inside it; install the downloadable file instead if "
            "you want the helper to serve its own page")
    helper = os.path.join(paths["dir"], "helper", "webmc_helper.py")
    with open(helper, "wb") as fh:
        fh.write(text)
    os.chmod(helper, 0o755)
    log("  installed the helper to %s" % helper)
    plist = agent_plist_text(sys.executable or "/usr/bin/python3", helper,
                             page_url, port)
    os.makedirs(os.path.dirname(paths["plist"]), exist_ok=True)
    with open(paths["plist"], "w") as fh:
        fh.write(plist)
    log("  wrote a launch agent: %s" % paths["plist"])

    uid = os.getuid()
    target = "gui/%d" % uid
    subprocess.run(["launchctl", "bootout", "%s/%s" % (target, AGENT_LABEL)],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    started = subprocess.run(["launchctl", "bootstrap", target, paths["plist"]],
                             capture_output=True, text=True)
    if started.returncode != 0:
        log("  launchctl could not start it: %s" % (started.stderr or started.stdout).strip())
        log("  the page still works if you start it by hand; see --help")
    else:
        # bootstrap already launches it (RunAtLoad). Asking again with kickstart -k kills the
        # instance that just came up - which is exactly the "installed but nothing is
        # listening" symptom this had before.
        for _ in range(20):
            if already_running("127.0.0.1", port):
                break
            time.sleep(0.5)
        if not already_running("127.0.0.1", port):
            subprocess.run(["launchctl", "kickstart", "%s/%s" % (target, AGENT_LABEL)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            time.sleep(1.5)
        if already_running("127.0.0.1", port):
            log("  launchd started it, and starts it again at every login")
        else:
            log("  launchd has it, but nothing is answering yet - the page will say so; "
                "see %s" % paths["log"])
    log("  log: %s" % paths["log"])
    log("  remove it again with: python3 '%s' --uninstall" % helper)

    if open_page:
        url = "http://127.0.0.1:%d/" % port
        if page_url:
            url = "%sgo?to=%s" % (url, urllib.parse.quote(page_url, safe=""))
        threading.Timer(1.2, lambda: subprocess.run(["open", url])).start()
    return 0


def dir_bytes(path):
    total = 0
    for base, _dirs, files in os.walk(path):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(base, name))
            except OSError:
                pass
    return total


def temp_sandboxes():
    """Every sandbox this helper left in the temp directory, newest last."""
    import glob as _glob
    found, seen = [], set()
    for base in {os.environ.get("TMPDIR", "/tmp"), "/tmp"}:
        for path in _glob.glob(os.path.join(base, "webmc-*")):
            name = os.path.basename(path)
            if path in seen:
                continue
            if not (os.path.isdir(path) and (read_owner(path) is not None
                                             or re.fullmatch(r"webmc-[0-9a-f]{8}", name))):
                continue
            seen.add(path)
            found.append(path)
    return found


def machine_footprint(cache=None):
    """Everything of ours on this machine, with sizes, so "nothing is left" is checkable.

    The audit used to look only at /tmp. That is how 592 MB of cached assets sat on a machine whose
    owner had asked for nothing to be left there: the promise has to be an inventory, not a glance.
    """
    paths = installed_paths()
    items = []
    for key, label in (("dir", "installed helper"), ("plist", "login agent"),
                       ("log", "log file")):
        path = os.path.expanduser(paths[key])
        if os.path.exists(path) or os.path.isdir(path):
            items.append({"what": label, "path": path,
                          "bytes": dir_bytes(path) if os.path.isdir(path) else os.path.getsize(path)})
    if cache:
        cache_path = os.path.abspath(os.path.expanduser(cache))
        if os.path.isdir(cache_path):
            items.append({"what": "download cache", "path": cache_path,
                          "bytes": dir_bytes(cache_path)})
    store = session_store_dir()
    if os.path.isdir(store):
        items.append({"what": "kept sessions", "path": store, "bytes": dir_bytes(store)})
    for path in temp_sandboxes():
        items.append({"what": "sandbox", "path": path, "bytes": dir_bytes(path)})
    return items


def purge(cache=None, log=print, keep_log=False):
    """Remove every trace of this launcher from this machine, and say what was removed."""
    items = machine_footprint(cache=cache)
    if not items:
        log("  this machine has nothing of ours on it: no files, no cache, no login item")
        return {"removed": [], "bytes": 0}
    freed = 0
    removed = []
    # the login item first, so nothing restarts while the rest goes
    uid = os.getuid()
    subprocess.run(["launchctl", "bootout", "gui/%d/%s" % (uid, AGENT_LABEL)],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for item in items:
        if keep_log and item["what"] == "log file":
            continue
        path = item["path"]
        try:
            if os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
            else:
                os.unlink(path)
            removed.append(item["what"])
            freed += item["bytes"]
            log("  removed %-16s %s" % (item["what"], path))
        except Exception as exc:  # noqa: BLE001
            log("  could not remove %s: %s" % (path, exc))
    log("  %d thing(s), %.1f MB. Nothing of ours is on this machine now."
        % (len(removed), freed / 1048576.0))
    return {"removed": removed, "bytes": freed}


def uninstall(log=print):
    paths = installed_paths()
    uid = os.getuid()
    subprocess.run(["launchctl", "bootout", "gui/%d/%s" % (uid, AGENT_LABEL)],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    removed = []
    for key in ("plist", "dir"):
        path = paths[key]
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
            removed.append(path)
        elif os.path.exists(path):
            os.unlink(path)
            removed.append(path)
    cleared, freed = sweep_stale_sandboxes(older_than=0, keep=None, log=lambda *_: None)
    log("  removed: %s" % (", ".join(removed) if removed else "nothing (it was not installed)"))
    if cleared:
        # sweep_stale_sandboxes returns (how many, how many bytes). Getting that order wrong once
        # printed five million "items" for 5.5 MB of sandboxes, which is a good way to frighten
        # somebody who is about to read the output of an uninstaller.
        log("  and cleared %d leftover sandbox(es), %.1f MB" % (cleared, freed / 1048576.0))
    if os.path.exists(os.path.expanduser(paths["log"])):
        try:
            os.unlink(os.path.expanduser(paths["log"]))
            log("  removed the log too: %s" % paths["log"])
        except OSError:
            pass
    return 0


def audit(root=None, cache=None, clean=False, log=print):
    """Say what *this helper* has on the machine, and optionally remove it.

    Written for the question the whole design is about: "did it leave anything
    behind?" Only things this helper creates are claimed here - a sandbox
    (webmc-<8 hex>), or a stray curl config. Other webmc-* entries in the temp
    directory belong to other parts of the project and are reported as a count, never
    touched.
    """
    import glob as _glob
    tmp = os.environ.get("TMPDIR", "/tmp")
    mine = []
    theirs = 0

    def size_of(path):
        total = 0
        if os.path.isdir(path):
            for base, _dirs, files in os.walk(path):
                for f in files:
                    full = os.path.join(base, f)
                    try:
                        if not os.path.islink(full):
                            total += os.path.getsize(full)
                    except OSError:
                        pass
        else:
            try:
                total = os.path.getsize(path)
            except OSError:
                pass
        return total

    seen = set()
    for pattern in ("webmc-*",):
        for base in (tmp, "/tmp"):
            for path in _glob.glob(os.path.join(base, pattern)):
                if path in seen:
                    continue
                is_dir = os.path.isdir(path)
                owner = read_owner(path) if is_dir else None
                ours = (is_dir and (owner is not None
                                    or re.fullmatch(r"webmc-[0-9a-f]{8}", os.path.basename(path)))) \
                    or (not is_dir and re.match(r"webmc-(curl-.*\.conf|.*\.part)$",
                                                os.path.basename(path)))
                if not ours:
                    continue
                seen.add(path)
                mine.append({"path": path,
                             "kind": "sandbox" if is_dir else "stray file",
                             "bytes": size_of(path), "owner": owner,
                             "abandoned": bool(owner and not pid_alive(owner.get("pid")))})
    for base in (tmp, "/tmp"):
        for path in _glob.glob(os.path.join(base, "webmc-*")):
            if path in seen:
                continue
            if cache and path == os.path.abspath(os.path.expanduser(cache)):
                continue
            theirs += 1
    if root and os.path.isdir(root) and os.path.abspath(root) not in seen:
        mine.append({"path": root, "kind": "this session's sandbox", "bytes": size_of(root),
                     "owner": read_owner(root), "abandoned": False})

    log("")
    log("  %s %s - what is on this machine" % (NAME, VERSION))
    log("  " + "-" * 58)
    if not mine:
        log("  nothing: no sandbox, no stray file. /tmp has none of ours.")
    for item in mine:
        log("  %-20s %s" % (item["kind"], item["path"]))
        if item["owner"]:
            log("  %-20s started %s by pid %s%s"
                % ("", time.strftime("%H:%M:%S", time.localtime(item["owner"].get("started", 0))),
                   item["owner"].get("pid"),
                   " - that process is gone, so this is litter" if item["abandoned"]
                   else " - running now"))
        log("  %-20s %.1f MB" % ("", item["bytes"] / 1048576.0))
    store = session_store_dir()
    if os.path.isdir(store):
        kept = sorted(n for n in os.listdir(store) if n.endswith(".zip"))
        log("  %-20s %s" % ("kept sessions", store))
        log("  %-20s %d session(s), %.1f MB - your worlds and options, so the next launch does not "
            % ("", len(kept), size_of(store) / 1048576.0))
        log("  %-20s start empty (--forget-sessions removes them)" % "")
    if cache:
        path = os.path.abspath(os.path.expanduser(cache))
        size = size_of(path) if os.path.isdir(path) else 0
        log("  %-20s %s" % ("cache", path))
        log("  %-20s %.1f MB %s" % ("", size / 1048576.0,
              "- kept on purpose, only ever used with --cache" if size else "- not present"))
    paths = installed_paths()
    if os.path.exists(paths["plist"]) or os.path.isdir(paths["dir"]):
        log("  %-20s %s" % ("installed", paths["dir"]))
        log("  %-20s %s" % ("", paths["plist"]))
        log("  %-20s installed on purpose so the page always finds a helper; remove both"
            % "")
        log("  %-20s with --uninstall (no administrator needed)" % "")
    if theirs:
        log("  %-20s %d other webmc-* entries in the temp directory that this helper"
            % ("not ours", theirs))
        log("  %-20s did not create (the test suite's webmc-site-* and friends)." % "")
    log("  %-20s %s" % ("writes to", (root or "/tmp/webmc-<random>/") +
                                        " - and nothing else; that path is deleted when "
                                        "the session ends"))
    log("  %-20s %s" % ("privileges", "none: no sudo, no administrator, no installer, no write "
                                      "outside /tmp and your own home; it listens on "
                                      "127.0.0.1 only"))
    log("")
    if clean:
        removed = 0
        freed = 0
        for item in mine:
            if item["kind"] == "this session's sandbox":
                continue
            try:
                if os.path.isdir(item["path"]):
                    shutil.rmtree(item["path"], ignore_errors=True)
                else:
                    os.unlink(item["path"])
                removed += 1
                freed += item["bytes"]
            except OSError:
                pass
        log("  removed %d of ours (%.1f MB); nothing else was touched"
            % (removed, freed / 1048576.0))
        log("")
    return mine


def install_signal_handlers(log=print):
    """Closing the terminal window, or any ordinary kill, has to run the cleanup
    that deletes the sandbox. Without this a double-clicked .command that the
    visitor closes would leave 600 MB under /tmp."""
    def bye(signum, _frame):
        try:
            name = signal.Signals(signum).name
        except Exception:
            name = str(signum)
        log("\n  received %s - cleaning up" % name)
        raise SystemExit(0)
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGQUIT):
        try:
            signal.signal(sig, bye)
        except (ValueError, OSError, AttributeError):
            pass


def parse_args(argv):
    ap = argparse.ArgumentParser(
        prog=NAME,
        description="Run real Minecraft + Fabric locally from a web page, keep nothing.")
    ap.add_argument("--port", type=int, default=7645)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--root", default=None,
                    help="sandbox directory (default /tmp/webmc-<random>)")
    ap.add_argument("--allow-origin", action="append", default=[], metavar="ORIGIN",
                    help="extra page origin allowed to talk to this helper")
    ap.add_argument("--page", default=None, help="path to the launcher page to serve at /")
    ap.add_argument("--page-url", default=None,
                    help="hosted page to hand the token to when /go is used")
    ap.add_argument("--open", action="store_true", help="open the browser at / (or /go)")
    ap.add_argument("--java", default=None, help="java executable to use")
    ap.add_argument("--proxy", default=None,
                    help="SOCKS/HTTP proxy for downloads, or 'none' (default: auto)")
    ap.add_argument("--game-proxy", default=os.environ.get("WEBMC_GAME_PROXY") or None, metavar="URL",
                    help="how the game's own connections leave this machine: a SOCKS5 URL like "
                         "socks5h://127.0.0.1:1080. Defaults to --proxy, then to a proxy found on the "
                         "usual ports, then to a direct connection")
    ap.add_argument("--proxy-game", action="store_true",
                    help="also send the game's own connections through the relay: a local SOCKS5"
                         " proxy, with the JVM pointed at it, so servers, sign-in and skins work"
                         " on a network that blocks everything but HTTPS")
    ap.add_argument("--restricted", action="store_true",
                    help="restricted mode: use only the Java runtime in the sandbox, never a"
                         " system one, and never look outside /tmp (for machines where Java is"
                         " present but blocked, or policies watch what runs)")
    ap.add_argument("--relay", default=os.environ.get("WEBMC_RELAY") or None, metavar="URL",
                    help="fetch everything through this relay instead of directly (the Cloudflare "
                         "Worker in relay/ does this), for networks where Mojang is blocked. "
                         "\"auto\" (the default) uses the built-in relay when there is one, and "
                         "\"off\" never uses one")
    ap.add_argument("--no-jre-download", action="store_true",
                    help="never fetch a JRE; fail instead")
    ap.add_argument("--keep", action="store_true",
                    help="do not delete the sandbox at the end (debugging)")
    ap.add_argument("--cache", default=os.environ.get("WEBMC_CACHE_DIR") or None,
                    help="reuse assets and libraries from this directory instead of "
                         "downloading them again (off by default: a session normally "
                         "downloads everything into its sandbox)")
    ap.add_argument("--autoclean", type=int, default=900,
                    help="seconds after the session ends before the sandbox is deleted "
                         "(0 disables; default 900)")
    ap.add_argument("--server-only", action="store_true",
                    help="start idle: no game is launched until the page asks")
    ap.add_argument("--launch", action="store_true",
                    help="launch immediately instead of waiting for the page")
    ap.add_argument("--version", default=DEFAULT_VERSION,
                    help="Minecraft version (default %s)" % DEFAULT_VERSION)
    ap.add_argument("--loader-kind", default="fabric",
                    help="which loader: fabric (default) or none for vanilla. Forge and NeoForge "
                         "are refused until their client-patching step is implemented")
    ap.add_argument("--loader", default="auto",
                    help="loader version, or 'auto'/'stable'/'latest' for the newest suitable "
                         "build of the chosen kind")
    ap.add_argument("--server", default=None, metavar="HOST:PORT",
                    help="a Minecraft server to reach through the relay, for networks that "
                         "block game ports: the client joins it automatically")
    ap.add_argument("--tunnel-port", type=int, default=0, metavar="PORT",
                    help="the local port that receives that server (default: any free one)")
    ap.add_argument("--mods", default="",
                    help="comma-separated Modrinth slugs, e.g. fabric-api,modmenu")
    ap.add_argument("--mod-jar", action="append", default=[], metavar="PATH",
                    help="a Fabric mod jar on this machine to copy into the sandbox "
                         "(repeatable). It is deleted with the sandbox afterwards.")
    ap.add_argument("--username", default="Player")
    ap.add_argument("--memory", default=DEFAULT_MEMORY)
    ap.add_argument("--no-assets", action="store_true",
                    help="skip the ~450 MB of sounds and textures")
    ap.add_argument("--dry-run", action="store_true",
                    help="download everything, build the command, do not start the game")
    ap.add_argument("--install", action="store_true",
                    help="macOS: keep this helper in Application Support and let launchd start it "
                         "now and at every login, so nothing has to be run by hand (no admin)")
    ap.add_argument("--install-source", default=None, metavar="PATH",
                    help="with --install: the file to install (default: this one)")
    ap.add_argument("--purge", action="store_true",
                    help="remove everything of ours from this machine (cache, installed files, "
                         "login item, log, sandboxes) and say what went, then exit")
    ap.add_argument("--uninstall", action="store_true",
                    help="remove what --install put there (and any leftover sandbox)")
    ap.add_argument("--audit", action="store_true",
                    help="say what this project has left on the machine, then exit")
    ap.add_argument("--audit-clean", action="store_true",
                    help="with --audit: remove every leftover (never a running session)")
    ap.add_argument("--store", default=os.environ.get("WEBMC_STORE") or None, metavar="DIR",
                    help="where finished sessions are kept, when keeping them is asked for "
                         "(off by default: a session belongs in the browser, and the helper "
                         "deletes the rest)")
    ap.add_argument("--keep-sessions", type=int, default=5, metavar="N",
                    help="how many finished sessions to keep, when a store is in use")
    ap.add_argument("--store-sessions", action="store_true",
                    help="keep finished sessions on disk too (the browser is the only place one is kept otherwise)")
    ap.add_argument("--forget-sessions", action="store_true",
                    help="delete the kept sessions (your worlds and options) and exit")
    ap.add_argument("--idle-exit", type=int, default=0, metavar="SECONDS",
                    help="shut down after this long with nobody using the page (0 = never; the "
                         "background launcher passes 1800 so a backgrounded helper does not "
                         "outlive its usefulness)")
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--print-token", action="store_true")
    return ap.parse_args(argv)


def enforce_deadlines(registry, stop, log=print, every=10.0):
    """The safety net, actually enforced.

    Two jobs, both about a helper that is still running when nobody is watching:

    * the page normally deletes the sandbox as soon as it has the session's files. If it never
      comes back - tab closed, browser crashed, visitor walked away - the helper has to do it
      itself, or the whole promise quietly fails.
    * a helper started in the background has to end when its page is gone, or "nothing left
      behind" would be true of the game and false of the thing that ran it.
    """
    while not stop.is_set():
        stop.wait(every)
        if stop.is_set():
            break
        for session in list(registry.sessions.values()):
            with session.lock:
                deadline = session.cleanup_deadline
                state = session.state
            if deadline and time.time() >= deadline and state != "running":
                log("  the page has not collected session %s by %s - deleting its sandbox"
                    % (session.sid, time.strftime("%H:%M:%S", time.localtime(deadline))))
                session.cleanup(why="nobody collected it before the deadline")
        with registry.lock:
            newest = registry.pick()
        label = newest.last_touch if newest else registry.last_touch
        idle_for = time.time() - label
        # A page that is open counts as interest even when nobody is clicking: the page pings us
        # every twenty seconds, which is what stops "left the tab open, came back to a dead helper".
        idle_limit = getattr(registry.cfg, "idle_exit", 0) or 0
        busy = any(s.state == "running" for s in list(registry.sessions.values()))
        if idle_limit and not busy and idle_for > idle_limit:
            log("  nothing has asked anything for %s - shutting down and leaving nothing behind"
                % (("%.0f minutes" % (idle_for / 60.0)) if idle_for >= 120
                   else ("%.0f seconds" % idle_for)))
            for each in list(registry.sessions.values()):
                each.cleanup(why="the helper was idle")
            # Reuse the ordinary shutdown path so the sandbox is deleted exactly once and the
            # process disappears instead of becoming a stray background process.
            os.kill(os.getpid(), signal.SIGTERM)
            return


def already_running(host, port):
    """Is the thing on that port one of ours? Asked politely, without curl."""
    import urllib.request
    try:
        with urllib.request.urlopen("http://%s:%d/api/hello" % (host, port), timeout=3) as r:
            return json.loads(r.read().decode("utf-8", "replace")).get("name") == NAME
    except Exception:
        return False


def main(argv=None):
    args = parse_args(argv if argv is not None else sys.argv[1:])
    cfg = argparse.Namespace(**vars(args))
    if not cfg.root:
        cfg.root = default_root()
    cfg.root = os.path.abspath(os.path.expanduser(cfg.root))
    install_signal_handlers()

    # The single-file .command writes the helper out of a heredoc to a temp file. Once python has
    # read it, that copy has no reason to exist: delete it, so "it leaves nothing behind" is true
    # of the helper as well as of the game.
    _self = os.environ.get("WEBMC_SELF_DELETE")
    if _self and not args.install:
        try:
            os.unlink(_self)
        except OSError:
            pass

    if args.audit:
        audit(root=cfg.root if os.path.isdir(cfg.root) else None,
              cache=cfg.cache, clean=args.audit_clean)
        return 0

    if getattr(args, "purge", False):
        # before anything else, including the "a helper is already running" shortcut: a purge
        # that silently opened a page instead would be worse than useless
        purge(cache=cfg.cache)
        return 0

    if args.forget_sessions:
        store = session_store_dir(cfg)
        freed = 0
        kept = 0
        if os.path.isdir(store):
            for name in os.listdir(store):
                path = os.path.join(store, name)
                try:
                    freed += os.path.getsize(path)
                    os.unlink(path)
                    kept += 1
                except OSError:
                    pass
        print("  removed %d kept session(s) from %s (%.1f MB)" % (kept, store, freed / 1048576.0))
        return 0

    if args.uninstall:
        uninstall()
        return 0

    if args.install:
        source = args.install_source or globals().get("__file__")
        return install(source, page_url=args.page_url, port=args.port)

    print("")
    print("  %s %s" % (NAME, VERSION))
    print("  " + "-" * 62)
    sweep_stale_sandboxes(keep=cfg.root)

    curl = Curl()
    if args.restricted and not args.proxy:
        # in restricted mode even the proxy hunt is skipped: it is a network probe of the local
        # machine, and someone asking for this wants as little of that as possible
        proxy = None
        print("  restricted mode: not probing for a local proxy")
    else:
        proxy = detect_proxy(args.proxy, lambda m: print("  " + m))
    curl.proxy = proxy
    if not proxy:
        print("  proxy: none (using the network directly)")

    # which proxy did we end up with, and does it work at all?
    try:
        curl.get(MANIFEST_URL, dest=None, timeout=20)
        print("  network: Mojang reachable")
    except CurlError as exc:
        print("  network: NOT reachable - %s" % exc)
        print("  hint: if this machine needs a SOCKS tunnel, run it on 127.0.0.1:1080")
        print("        or pass --proxy socks5h://host:port")

    registry = Registry(cfg, curl)
    registry.started = time.time()
    page = args.page or default_page(cfg.root)
    token = secrets.token_hex(16)
    try:
        httpd = Server((args.host, args.port), Handler, registry, curl, token, page,
                       args.allow_origin, args.verbose)
    except OSError as exc:
        if exc.errno in (errno.EADDRINUSE, errno.EACCES):
            # Being already started is not an error: it is what happens when somebody opens the
            # launcher twice, or double-clicks it again after using it earlier.
            if already_running(args.host, args.port):
                url = "http://%s:%d/" % (args.host, args.port)
                print("  a helper is already running there - opening its page instead of "
                      "starting a second one")
                target = url
                if args.page_url:
                    target = "%sgo?to=%s" % (url, urllib.parse.quote(args.page_url, safe=""))
                opener = "open" if os_name() == "osx" else ("start" if os_name() == "windows"
                                                           else "xdg-open")
                try:
                    subprocess.run([opener, target])
                except Exception:
                    print("  open %s yourself" % target)
                return 0
            print("  ERROR: cannot listen on %s:%d - %s" % (args.host, args.port, exc))
            print("  hint: something else is on that port; use --port 7646")
            return 2
        raise
    port = httpd.server_address[1]
    url = "http://%s:%d/" % (args.host, port)
    print("  page:   %s" % url)
    if page and os.path.exists(page):
        print("  serving %s" % page)
    if args.page_url:
        print("  hosted: %s/go?to=%s" % (url, urllib.parse.quote(args.page_url, safe="")))
    if args.print_token:
        print("  token:  %s" % token)

    if args.open:
        opener = "open" if os_name() == "osx" else ("start" if os_name() == "windows" else "xdg-open")
        target = url
        if args.page_url:
            target = "%sgo?to=%s" % (url, urllib.parse.quote(args.page_url, safe=""))
        threading.Timer(0.6, lambda: subprocess.run([opener, target])).start()

    if args.launch:
        opts = {
            "tunnelServer": args.server,
            "tunnelPort": args.tunnel_port,
            "version": args.version,
            "loader": args.loader,
            "loaderKind": args.loader_kind,
            "relay": args.relay,
            "tunnelEverything": args.proxy_game,
            "gameProxy": args.game_proxy,
            "restricted": args.restricted,
            "mods": [m.strip() for m in (args.mods or "").split(",") if m.strip()],
            "localMods": list(args.mod_jar or []),
            "username": args.username,
            "memory": args.memory,
            "assets": not args.no_assets,
        }
        print("  launching %s%s with %s" % (
            opts["version"],
            " + " + opts["loaderKind"] if opts["loaderKind"] not in ("none", "") else " vanilla",
            ", ".join(opts["mods"]) or "no mods"))
        print("")
        registry.launch(opts)

    if not args.server_only:
        print("")
        print("  Play is a button on the page; this process only listens.")
        print("  Everything is written under %s and deleted after" % cfg.root)
        print("  the session's files have been saved. Ctrl-C to quit.")
    print("")
    try:
        stop_watchdog = threading.Event()
        watchdog = threading.Thread(
            target=enforce_deadlines, args=(registry, stop_watchdog), daemon=True)
        watchdog.start()
        httpd.serve_forever()
    except (KeyboardInterrupt, SystemExit):
        print("\n  shutting down")
    finally:
        stop_watchdog.set()
        registry.stop_all()
        if not cfg.keep:
            registry.cleanup_all()
        else:
            print("  --keep was given: %s is still there" % cfg.root)
        httpd.server_close()
        # A transient run (started by a Shortcut, say) is staged in /tmp by the file that launched
        # it. Deleting that staging directory here is what makes "nothing left behind" include the
        # helper as well as the game.
        staging = os.environ.get("WEBMC_CLEANUP_DIR")
        here = os.path.abspath(staging) if staging else None
        tempdirs = {os.path.abspath(os.environ.get("TMPDIR", "/tmp")), "/tmp", "/private/tmp",
                    os.path.abspath(tempfile.gettempdir())}
        # Only ever remove a directory this helper's own launcher made: a direct child of a temp
        # directory, named webmc.<something>. The first version of this checked for a "/tmp/" prefix
        # and therefore never fired on macOS, where the staging directory is under /var/folders.
        remove_staging = bool(here and os.path.basename(here).startswith("webmc.")
                              and os.path.dirname(here) in tempdirs and os.path.isdir(here))
        if remove_staging:
            size = 0
            for base, _dirs, files in os.walk(here):
                for f in files:
                    try:
                        size += os.path.getsize(os.path.join(base, f))
                    except OSError:
                        pass
            shutil.rmtree(here, ignore_errors=True)
            print("  removed the staging directory %s (%.1f MB)" % (here, size / 1048576.0))
    return 0


if __name__ == "__main__":
    sys.exit(main())
WEBMC_HELPER_SOURCE

PAGE="${WEBMC_PAGE_URL-https://amphibiandev.github.io/webmc-launcher/local.html}"
LOGFILE="$STAGE/run.log"

if [ "${1:-}" = "--uninstall" ]; then
  "$PY" -u "$SOURCE" --uninstall "${@:2}"
  STATUS=$?
  rm -rf "$STAGE"
  exit $STATUS
fi

if [ "${WEBMC_FOREGROUND:-0}" != "0" ]; then
  export WEBMC_SELF_DELETE="$SOURCE"
  if [ -n "$PAGE" ]; then
    exec "$PY" -u "$SOURCE" --open --page-url "$PAGE" "$@"
  fi
  exec "$PY" -u "$SOURCE" --open "$@"
fi

# Transient: run out of the staging directory, leave nothing at all behind. This is the mode a
# Shortcut uses, so a session costs the machine nothing permanent - no install, no staging
# directory, no sandbox. Everything, including a fetched Python, goes when the helper exits.
if [ "${WEBMC_TRANSIENT:-0}" != "0" ]; then
  export WEBMC_SELF_DELETE="$SOURCE"
  CACHEARG=""
  [ "${WEBMC_CACHE:-0}" != "0" ] && CACHEARG="$HOME/Library/Caches/webmc"
  if [ -n "$PAGE" ] && [ -n "$CACHEARG" ]; then
    nohup "$PY" -u "$SOURCE" --server-only --idle-exit 1800 --port 7645 --page-url "$PAGE" --cache "$CACHEARG" >>"$LOGFILE" 2>&1 &
  elif [ -n "$PAGE" ]; then
    nohup "$PY" -u "$SOURCE" --server-only --idle-exit 1800 --port 7645 --page-url "$PAGE" >>"$LOGFILE" 2>&1 &
  elif [ -n "$CACHEARG" ]; then
    nohup "$PY" -u "$SOURCE" --server-only --idle-exit 1800 --port 7645 --cache "$CACHEARG" >>"$LOGFILE" 2>&1 &
  else
    nohup "$PY" -u "$SOURCE" --server-only --idle-exit 1800 --port 7645 >>"$LOGFILE" 2>&1 &
  fi
  # Wait for it properly: fetching a Python and starting a JVM-less HTTP server takes a moment,
  # and reporting "did not come up" while it is coming up is how a working helper looks broken.
  READY=0
  WAITED=0
  while [ "$WAITED" -lt 30 ]; do
    if [ -n "$(curl -s -m 2 http://127.0.0.1:7645/api/hello 2>/dev/null)" ]; then READY=1; break; fi
    sleep 1
    WAITED=$((WAITED + 1))
  done
  if [ "$READY" = "1" ]; then
    echo "webmc-helper is running from $STAGE - nothing here survives the session."
    exit 0
  fi
  echo "The helper did not come up. What it said:"
  tail -10 "$LOGFILE" 2>/dev/null
  read -r -p "press return to close " _
  exit 1
fi

# Install: keep a copy in Application Support and let launchd start it now and at every login.
if [ -n "$PAGE" ]; then
  "$PY" -u "$SOURCE" --install --install-source "$SOURCE" --port 7645 --page-url "$PAGE" >>"$LOGFILE" 2>&1
else
  "$PY" -u "$SOURCE" --install --install-source "$SOURCE" --port 7645 >>"$LOGFILE" 2>&1
fi
STATUS=$?

if [ "$STATUS" = "0" ]; then
  echo "WebMC Helper is installed and running - this window closes itself."
  echo
  echo "From now on it starts by itself at every login: press Play on the launcher page"
  echo "and Minecraft starts on this computer. You can delete this downloaded file."
  echo
  echo "To remove it completely later:"
  echo "    "$HOME/Library/Application Support/webmc/helper/webmc_helper.py" --uninstall"
  echo "    (or run this downloaded file again with --uninstall)"
else
  echo "It did not finish. What it said:"
  tail -20 "$LOGFILE" 2>/dev/null
  read -r -p "press return to close " _
  exit 1
fi
exit 0
